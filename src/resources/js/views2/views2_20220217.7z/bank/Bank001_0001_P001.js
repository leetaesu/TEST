var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VBank0010001P001View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'bank',
		v_storageSubKeyName : '',

		tempRow : null
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {		
		ajax_call : function(exeType){
			if ( exeType == 'S1' ){
				var param = pageUnit.trn_param;				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001P001001Ajax",
						data : pageUnit.trn_param,
						async : true,
						success : pageUnit.fn.set_section_1,
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);	
			}
			else if ( exeType == 'S2' ){
				var param = pageUnit.trn_param;				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001P001002Ajax",
						data : param,
						async : true,
						success : function(res){
							var resultMap = res.XMB2025_Q01;
							
							if(resultMap && resultMap.resp_gubn == "0"){
								if(resultMap.out_count != "0000"){
									$("#output").text(JSON.stringify(resultMap));
									pageUnit.fn.set_section_2(resultMap);
								}
							}else{
								mydataCommon.msg.alert({msg : resultMap.resp_mesg});
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
						}
				}
				mydataCommon.ajax(jsonObj);	
			}	
		} 		
	},
	// 단위 진입부 함수
	init : function(){
		
		pageUnit.eventBind();
	
		// Highcharts Default options (하이차트 사용시 필수 적용)
        Highcharts.setOptions(KW_MOBILE.highcharts.general);
        
        
		pageUnit.trn.ajax_call('S1'); // 은행 계좌구성 조회
		setTimeout(function(){pageUnit.trn.ajax_call('S2');;},200); //은행 3개월 잔액변동추이 조회

	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$(".sub-close , .modal-footer").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_section_1 : function(data){			
			
			var outData = data.XMB2020_Q01;
			if (outData && outData.resp_gubn == "0"){
				
				$("#totalMoney").text(mydataCommon.util.addComma(outData.remna_sum));
				outData.ioa_remna_sum = mydataCommon.util.addComma(outData.ioa_remna_sum);
				outData.dpst_remna_sum = mydataCommon.util.addComma(outData.dpst_remna_sum);
				outData.svngs_remna_sum = mydataCommon.util.addComma(outData.svngs_remna_sum);
				outData.etc_remna_sum = mydataCommon.util.addComma(outData.etc_remna_sum);
				outData.fc_remna_sum = mydataCommon.util.addComma(outData.fc_remna_sum);
				outData.fob_remna_sum = mydataCommon.util.addComma(outData.fob_remna_sum);

				ao_html('#acctCompo', outData);
			}
			
			//차트 그리기
			var ioa_rt = parseInt(outData.ioa_rt); //입출금 비율
			var dpst_rt = parseInt(outData.dpst_rt); //예금 비율
			var svngs_rt = parseInt(outData.svngs_rt); //적금 비율
			var etc_rt = parseInt(outData.etc_rt); //기타 비율
			var fc_rt = parseInt(outData.fc_rt); //외환 비율
			var fob_rt = parseInt(outData.fob_rt); //선불 비율

			var cate =[''];
			//주식
			 var chartObj = mydataCommon.design.chartStackedBar('myBankAssetInfo',[
   				{ name: '입출금', data: [ioa_rt], color: '#fe74a2', index: 6 },
				{ name: '예금', data: [dpst_rt], color: '#ff9933', index: 5 },
				{ name: '적금', data: [svngs_rt], color: '#66ccff', index: 4 },
				{ name: '기타', data: [etc_rt], color: '#6666cc', index: 3 },
				{ name: '외환', data: [fc_rt] , color: '#66cccc', index: 2 },
				{ name: '선불머니', data:[fob_rt] , color: '#d1d6e8', index: 1 }
            ],cate,150);			
			 
			 
		},
		set_section_2 : function(outData){			
			
			var g1 = outData.g1;
			
			outData.yy_mm1 = '-'; 
			outData.ioa_remna1 = '-';
			outData.dpst_remna1 = '-';
			outData.svngs_remna1 = '-';
			outData.etc_remna1 = '-';
			outData.fc_remna1 = '-';
			outData.fob_remna1 = '-';
			outData.acnt_remna1 = '-';
			outData.ioa_rt1 = '0';
			outData.dpst_rt1 = '0';
			outData.svngs_rt1 = '0';
			outData.etc_rt1 = '0';
			outData.fc_rt1 = '0';
			
			outData.yy_mm2 = '-';
			outData.ioa_remna2 = '-';
			outData.dpst_remna2 = '-';
			outData.svngs_remna2 = '-';
			outData.etc_remna2 = '-';
			outData.fc_remna2 = '-';
			outData.fob_remna2 = '-';
			outData.acnt_remna2 = '-';
			outData.ioa_rt2 = '0';
			outData.dpst_rt2 = '0';
			outData.svngs_rt2 = '0';
			outData.etc_rt2 = '0';
			outData.fc_rt2 = '0';
			
			outData.yy_mm3 = '-';
			outData.ioa_remna3 = '-';
			outData.dpst_remna3 = '-';
			outData.svngs_remna3 = '-';
			outData.etc_remna3 = '-';
			outData.fob_remna3 = '-';
			outData.fob_remna1 = '-';
			outData.acnt_remna3 = '-';
			outData.ioa_rt3 = '0';
			outData.dpst_rt3 = '0';
			outData.svngs_rt3 = '0';
			outData.etc_rt3 = '0';
			outData.fc_rt3 = '0';
			
			for(var i=0; i<g1.length; i++){
				
				if(i == 0 ){
					outData.yy_mm1 = mydataCommon_02.util.getStrDate(outData.g1[i].yy_mm);
					outData.ioa_remna1 = mydataCommon.util.addComma(outData.g1[i].ioa_remna);
					outData.dpst_remna1 = mydataCommon.util.addComma(outData.g1[i].dpst_remna);
					outData.svngs_remna1 = mydataCommon.util.addComma(outData.g1[i].svngs_remna);
					outData.etc_remna1 = mydataCommon.util.addComma(outData.g1[i].etc_remna);
					outData.fc_remna1 = mydataCommon.util.addComma(outData.g1[i].fc_remna);
					outData.fob_remna1 = mydataCommon.util.addComma(outData.g1[i].fob_remna);
					outData.acnt_remna1 = mydataCommon.util.addComma(outData.g1[i].acnt_remna);
					
					outData.ioa_rt1 = mydataCommon.util.addComma(outData.g1[i].ioa_rt);
					outData.dpst_rt1 = mydataCommon.util.addComma(outData.g1[i].dpst_rt);
					outData.svngs_rt1 = mydataCommon.util.addComma(outData.g1[i].svngs_rt);
					outData.etc_rt1 = mydataCommon.util.addComma(outData.g1[i].etc_rt);
					outData.fc_rt1 = mydataCommon.util.addComma(outData.g1[i].fc_rt);
					
				}else if(i == 1 ){
					outData.yy_mm2 = mydataCommon_02.util.getStrDate(outData.g1[i].yy_mm);
					outData.ioa_remna2 = mydataCommon.util.addComma(outData.g1[i].ioa_remna);
					outData.dpst_remna2 = mydataCommon.util.addComma(outData.g1[i].dpst_remna);
					outData.svngs_remna2 = mydataCommon.util.addComma(outData.g1[i].svngs_remna);
					outData.etc_remna2 = mydataCommon.util.addComma(outData.g1[i].etc_remna);
					outData.fc_remna2 = mydataCommon.util.addComma(outData.g1[i].fc_remna);
					outData.fob_remna2 = mydataCommon.util.addComma(outData.g1[i].fob_remna);
					outData.acnt_remna2 = mydataCommon.util.addComma(outData.g1[i].acnt_remna);
					
					outData.ioa_rt2 = mydataCommon.util.addComma(outData.g1[i].ioa_rt);
					outData.dpst_rt2 = mydataCommon.util.addComma(outData.g1[i].dpst_rt);
					outData.svngs_rt2 = mydataCommon.util.addComma(outData.g1[i].svngs_rt);
					outData.etc_rt2 = mydataCommon.util.addComma(outData.g1[i].etc_rt);
					outData.fc_rt2 = mydataCommon.util.addComma(outData.g1[i].fc_rt);
						
				}else if(i == 2 ){
					outData.yy_mm3 = mydataCommon_02.util.getStrDate(outData.g1[i].yy_mm);
					outData.ioa_remna3 = mydataCommon.util.addComma(outData.g1[i].ioa_remna);
					outData.dpst_remna3 = mydataCommon.util.addComma(outData.g1[i].dpst_remna);
					outData.svngs_remna3 = mydataCommon.util.addComma(outData.g1[i].svngs_remna);
					outData.etc_remna3 = mydataCommon.util.addComma(outData.g1[i].etc_remna);
					outData.fc_remna3 = mydataCommon.util.addComma(outData.g1[i].fc_remna);
					outData.fob_remna3 = mydataCommon.util.addComma(outData.g1[i].fob_remna);
					outData.acnt_remna3 = mydataCommon.util.addComma(outData.g1[i].acnt_remna);
					
					outData.ioa_rt3 = mydataCommon.util.addComma(outData.g1[i].ioa_rt);
					outData.dpst_rt3 = mydataCommon.util.addComma(outData.g1[i].dpst_rt);
					outData.svngs_rt3 = mydataCommon.util.addComma(outData.g1[i].svngs_rt);
					outData.etc_rt3 = mydataCommon.util.addComma(outData.g1[i].etc_rt);
					outData.fc_rt3 = mydataCommon.util.addComma(outData.g1[i].fc_rt);
				}
			}
			ao_html('#bal3Cmpr', outData);
			
			//차트 그리기
			var ioa_rt1 = parseInt(outData.ioa_rt1); //입출금 비율1
			var ioa_rt2 = parseInt(outData.ioa_rt2); //입출금 비율2
			var ioa_rt3 = parseInt(outData.ioa_rt3); //입출금 비율3
			var dpst_rt1 = parseInt(outData.dpst_rt1); //예금 비율1
			var dpst_rt2 = parseInt(outData.dpst_rt2); //예금 비율2
			var dpst_rt3 = parseInt(outData.dpst_rt3); //예금 비율3
			var svngs_rt1 = parseInt(outData.svngs_rt1); //적금 비율1
			var svngs_rt2 = parseInt(outData.svngs_rt2); //적금 비율2
			var svngs_rt3 = parseInt(outData.svngs_rt3); //적금 비율3
			var etc_rt1 = parseInt(outData.etc_rt1); //기타 비율1
			var etc_rt2 = parseInt(outData.etc_rt2); //기타 비율2
			var etc_rt3 = parseInt(outData.etc_rt3); //기타 비율3
			var fc_rt1 = parseInt(outData.fc_rt1); //외화 비율1
			var fc_rt2 = parseInt(outData.fc_rt2); //외화 비율2
			var fc_rt3 = parseInt(outData.fc_rt3); //외화 비율3
			var fob_rt1 = parseInt(outData.fc_fob1); //선불머니 비율3
			var fob_rt2 = parseInt(outData.fc_fob2); //선불머니 비율3
			var fob_rt3 = parseInt(outData.fc_fob3); //선불머니 비율3

			
			
			
			 var chartObj = mydataCommon.design.chartColumnStack('acctColumnChart',[
				{ name: '입출금', data: [ioa_rt1, ioa_rt2, ioa_rt3], color: '#fe74a2', index: 6 },
				{ name: '예금', data: [dpst_rt1, dpst_rt2, dpst_rt3], color: '#ff9933', index: 5 },
				{ name: '적금', data: [svngs_rt1, svngs_rt2, svngs_rt3], color: '#66ccff', index: 4 },
				{ name: '기타', data: [etc_rt1, etc_rt2, etc_rt3], color: '#6666cc', index: 3 },
				{ name: '외환', data: [fc_rt1, fc_rt2, fc_rt3] , color: '#66cccc', index: 2 },
				{ name: '선불머니', data:[fob_rt1, fob_rt2, fob_rt3] , color: '#d1d6e8', index: 1 }
			],[outData.yy_mm1, outData.yy_mm2, outData.yy_mm3],220);			
			
			
		},
		req_error : function(data){
			mydataCommon_02.util.log(['Bank001_0001_P001.js :: req_error ----------> ', data]);
		},
		req_complete : function(data){
			mydataCommon_02.util.log(['Bank001_0001_P001.js :: req_complete ----------> ', data]);
		}
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	
	pageUnit.init();
});
