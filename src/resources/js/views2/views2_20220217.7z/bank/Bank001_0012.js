var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VBank0010002View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'bank',
		v_storageSubKeyName : '',

		tempRow : null,
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		strt_dt : null,
		end_dt : null,
		next_page_base_val : null,
		qry_tp : ""
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			
			// 상단 메인 조회
			if ( exeType == 'S' ){
				var jsonObj = {
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010012001Ajax",
						async : false,
						success : function(data){
							var outData = data.XMF2004_Q01;
							ao_html('#bankInfoDtl', outData);
						},
						error : pageUnit.fn.req_error					
				}
				mydataCommon.ajax(jsonObj);
			}
			//하단
			else if ( exeType == 'S1' ){
				var jsonObj = {
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010012002Ajax",
						async : false,
						success : function(data){
							var outData = data.XMF2005_Q01;
							ao_html('#tab02_CyberMnDetail', outData);
						},
						error : pageUnit.fn.req_error					
				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S2' ){
				var jsonObj = {
						
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010012003Ajax",
						async : false,
						success : function(res){
							
							var resultMap = res.XMF1006_U01;	
							if(resultMap && resultMap.resp_gubn == "0"){
								
								if(pageUnit.trn_param.next_page_base_val =="") 
									ao_html('#bankInfoLst', resultMap); //최초 조회
								else 
									ao_append('#bankInfoLst', resultMap); // 연속조회

								if("Y" == resultMap.cont_gubn){
									pageUnit.trn_param.next_page_base_val = resultMap.next_page_base_val;
									$("#btnMoreItem").show();
								}else{
									pageUnit.trn_param.next_page_base_val = "";
									$("#btnMoreItem").hide();
								}
								
								KW_MOBILE.guiEvent.detailBox.init();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}			
			
		} 				  
	},
	// 단위 진입부 함수
	init : function(){
		var pageParam = mydataCommon.page.getSubParamData('VBank0010001View');
		pageUnit.trn_param = pageParam;
		pageUnit.eventBind();
		//상단메인
		pageUnit.trn.ajax_call('S');
		//계좌정보
		pageUnit.trn.ajax_call('S1');	
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){

		$(".sub-prev").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true, callback:"callback_callSendViewData"});
		});	
		
		
		$(".icon-refresh").off("click").on("click", function (){
			
		});
		// 거래내역으로 이동
		$('#tab_01').on("click", function(){
			mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt) {
				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = end_dt;
				pageUnit.trn.ajax_call('S2');
			});
		});
		
		//오픈뱅킹으로 이동하기
		$(document).on("click", "#goOpenBank", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"352"});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 계좌번호 복사
		// 계좌 상세 - 상단
		
		// 계좌 상세 - 거래내역 리스트 탭
		
		// 계좌 상세 - 계좌정보 탭
		set_section_3 : function(data){
			var outData = data.XMB2036_Q01;
			var last_pdin_sqnc;
			var tot_sqnc;
			var progress_result;
			
			if(outData.resp_gubn == '0'){
				
				last_pdin_sqnc = parseInt(outData.last_pdin_sqnc);
				tot_sqnc = parseInt(outData.tot_sqnc);				
				progress_result = last_pdin_sqnc/tot_sqnc * 100;
				
				
				outData.progress_result = progress_result
				outData.open_dt = mydataCommon_02.util.getStrDate(outData.open_dt);
				outData.expr_dt = mydataCommon_02.util.getStrDate(outData.expr_dt);
				outData.mm_pdin_amt = mydataCommon_02.util.addComma(outData.mm_pdin_amt);
				outData.engg_amt = mydataCommon_02.util.addComma(outData.engg_amt);
				
				ao_html('#acctInfo', outData);
										
			}
		},
		get_moreXmb1005 : function(next_page_val){
			pageUnit.trn_param.myd_next_page_base_val = next_page_val;
			pageUnit.trn.ajax_call('S1');
		},
		req_error : function(data){
			mydataCommon_02.util.log(['VBank0010002.js :: req_error ----------> ', data]);
		},
		req_complete : function(data){
			mydataCommon_02.util.log(['VBank0010002.js :: req_complete ----------> ', data]);
		}
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	
	pageUnit.init();
});