var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VBank0010002View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'bank',
		v_storageSubKeyName : '',

		tempRow : null,
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		myd_strt_dt : null,
		myd_end_dt : null,
		myd_next_page_base_val : null,
		qry_tp : ""
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			
			// 상단 메인 조회
			if ( exeType == 'S' ){
				var jsonObj = {
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010009001Ajax",
						async : false,
						success : pageUnit.fn.set_section_0,
						error : pageUnit.fn.req_error					
				}
				mydataCommon.ajax(jsonObj);
			}
			//하단
			else if ( exeType == 'S1' ){
				var jsonObj = {
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010009002Ajax",
						async : false,
						success : pageUnit.fn.set_section_1,
						error : pageUnit.fn.req_error					
				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S2' ){
				var jsonObj = {
						
						data : pageUnit.trn_param,
						url : pageCom.prop.contextPath + "/bank/SBank0010009003Ajax",
						async : false,
						success : function(res){
							var resultMap = res.XMF1005_U01;	
							if(resultMap && resultMap.resp_gubn == "0"){
								
								if(pageUnit.trn_param.next_page_base_val =="") 
									ao_html('#bankInfoLst','bankInfoLst_tmpl', resultMap); //최초 조회
								else 
									ao_append('#bankInfoLst','bankInfoLst_tmpl', resultMap); // 연속조회

								if("Y" == resultMap.cont_gubn){
									pageUnit.trn_param.next_page_base_val = resultMap.next_page_base_val;
									$("#btnMoreItem").show();
								}else{
									pageUnit.trn_param.next_page_base_val = "";
									$("#btnMoreItem").hide();
								}
								
								KW_MOBILE.guiEvent.detailBox.init();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}			
			
		} 				  
	},
	// 단위 진입부 함수
	init : function(){
		var pageParam = mydataCommon.page.getSubParamData('VBank0010001View');
		pageUnit.trn_param = pageParam;
		pageUnit.eventBind();
		//상단메인
		pageUnit.trn.ajax_call('S');
		//계좌정보
		pageUnit.trn.ajax_call('S1');	
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){

		$(".sub-prev").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true, callback:"callback_callSendViewData"});
		});	
		
		// 거래내역으로 이동
		$('#tab_01').on("click", function(){
			mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt) {
				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = end_dt;
				pageUnit.trn.ajax_call('S2');
			});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 계좌번호 복사
		// 계좌 상세 - 상단
		
		set_section_0 : function(data){
			var outData = data.XMF2002_Q01;
			ao_html('#bankInfoDtl', outData);
		},
		
		// 계좌 상세 계좌정보 리스트 탭
		set_section_1 : function(data){
			var outData = data.XMF2003_Q01;
			ao_html('#tab02_CyberMnDetail', outData);
		},
		req_error : function(data){
			mydataCommon_02.util.log(['VBank0010002.js :: req_error ----------> ', data]);
		},
		req_complete : function(data){
			mydataCommon_02.util.log(['VBank0010002.js :: req_complete ----------> ', data]);
		}
		
	},
};
// 페이지 on load시 진입부
$(document).ready(function(){
	
	pageUnit.init();
});