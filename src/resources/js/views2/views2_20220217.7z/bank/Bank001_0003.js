var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VBank0010003View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'bank',
		v_storageSubKeyName : '',
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		stk_rcmn_svc_tp : null
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			
			if ( exeType == 'S' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010003Ajax",
						data : pageUnit.trn_param,
						async : false,
						success : function(res){
							var resultMap = res.XMB4005_Q01;	
							
							if(resultMap && resultMap.resp_gubn == "0"){
								pageUnit.fn.set_section(resultMap);
							}else{
								mydataCommon.msg.alert({msg : resultMap.resp_mesg});
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
		} 				  
	},
	// 단위 진입부 함수
	init : function(){
		var pageParam = mydataCommon.page.getSubParamData('VBank0010001View');
		pageUnit.trn_param = pageParam;
		pageUnit.eventBind();	
		pageUnit.trn.ajax_call('S');
		$("#myRemMoney").text(mydataCommon.util.getPrice(pageUnit.trn_param.tuja_amt));
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){

		$(".sub-prev").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});	
		
		// 계좌정보로 이동
		$('#tab_02').on("click", function(){
			//임시 카드정보로 이동
			$('#frm').attr('action', mydataCommon_02.prop.ctrl_prefix + 'VBank0010005View').submit();
		});
		
		// 더 많은 추천 상품 보기
		$("#goReco").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0101", callback:"callback_callMoveView"});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		//오픈 뱅킹으로 투자자금 가져오기
		getTujaAmt : function(){
			document.location.href = pageCom.prop.contextPath+"/bank/VBank0010003P004Pop";

		},
		//상품 자세히 보기
		go_itemInfo : function(gds_tp, stk_code, gds_risk_grade_nm, crd_grade_nm){
			
			if(gds_tp == '03'){ //펀드
			
				pageUnit.fn.goAccList_fund(stk_code);
				
			}else if(gds_tp == '04'){ //단기사채
				
				pageUnit.fn.goAccList_shrt_prdb(stk_code, crd_grade_nm);
				
			}else if(gds_tp == '05'){ //장외채권
			
				pageUnit.fn.goAccList_otc_bond(stk_code, gds_risk_grade_nm, crd_grade_nm);
				
			}else if(gds_tp == '06'){ //RP
			
				pageUnit.fn.goAccList_rp(stk_code);
				
			}else if(gds_tp == '08'){ //ELS/ELB
			
				pageUnit.fn.goAccList_elsb(stk_code);
			}
		},
		goAccList_fund : function (stk_code) {
			//#펀드상세  /reco/VReco0020001View
			
			mydataCommon.util.setData("stk_code",stk_code);
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0201", callback:"callback_callMoveView", viewType:"half"});
			
//			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020001View";
		},
		goAccList_otc_bond : function (stk_code, gds_risk_grade_nm, crd_grade_nm) {
			//#장외 채권 /reco/VReco0020002View
			
			var crd_evlt_grde_tp = crd_grade_nm.replace(/[0-9+-]/gi,'');
			mydataCommon.util.setData("stk_code",stk_code);
			mydataCommon.util.setData("bond_cls_tp",gds_risk_grade_nm);
			mydataCommon.util.setData("crd_evlt_grde_tp",crd_evlt_grde_tp);
			
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0202", callback:"callback_callMoveView", viewType:"half"});
			
//			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020002View";
		},
		goAccList_shrt_prdb : function (stk_code, crd_grade_nm) {
			//#단기사채상세 /reco/VReco0020003View
			
			var crd_evlt_grde_tp = "%%%";
			mydataCommon.util.setData("stk_code",stk_code);
			mydataCommon.util.setData("crd_evlt_grde_tp",crd_evlt_grde_tp);
			
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0203", callback:"callback_callMoveView", viewType:"half"});
			
//			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020003View";
		},
		goAccList_rp : function (stk_code) {
			//#RP상품상세  /reco/VReco0020004View
			
			mydataCommon.util.setData("stk_code",stk_code); 
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0204", callback:"callback_callMoveView", viewType:"half"});
			
//			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020004View";
		},
		goAccList_elsb : function (stk_code) {
			
			//#파생결합증권 상세 /reco/VReco0020005View
			mydataCommon.util.setData("stk_code",stk_code);
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0205", callback:"callback_callMoveView", viewType:"half"});
			
//			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020005View";
		},
		
		//투자성향 확인하기
		conf_TujaTend : function(){
			
			document.location.href = pageCom.prop.contextPath+"/bank/VBank0010003P003Pop";
		},
		
		set_section : function(result){
			
			// 투자성향, 투자가능금액
			if(result.invt_prpn_tp == '1'){
				result.invt_prpn_tp = '공격투자형';
			}else if(result.invt_prpn_tp == '2'){
				result.invt_prpn_tp = '적극투자형';
			}else if(result.invt_prpn_tp == '3'){
				result.invt_prpn_tp = '위험중립형';
			}else if(result.invt_prpn_tp == '4'){
				result.invt_prpn_tp = '안정추구형';
			}else if(result.invt_prpn_tp == '5'){
				result.invt_prpn_tp = '안정형';
			}
			
			if(pageUnit.prop.stk_rcmn_svc_tp != '2'){
				result.amt_cont1 = mydataCommon.util.addComma(pageUnit.prop.tuja_amt) + '원 ';
				result.amt_cont2 = '으로 투자가능한 상품';
			}
			else{
				result.amt_cont1 = '';
				result.amt_cont2 = '투자가능한 상품';
			}	
			
			
			// 상품 리스트
			var g1 = result.g1;
			
			for(var i=0; i<g1.length; i++){
				
				if( i == 0)
					result.g1[i].borderTp = 'no-border';
				else
					result.g1[i].borderTp = '';
				
				// 펀드
				if(result.g1[i].gds_tp == '03'){
					
					result.g1[i].gds_tpNm = '펀드';
					
					result.g1[i].text1_1 = '운용규모';
					result.g1[i].text1_2 = mydataCommon.util.addComma(mydataCommon.util.roundNumber(result.g1[i].fund_oprt_scl/100000000, 0)) + '억 원';
					
					result.g1[i].text2_1 = '1개월 수익률';
					result.g1[i].text2_2 = result.g1[i].fund_1_errt + '%';
						
					result.g1[i].text3_1 = '3개월 수익률';
					result.g1[i].text3_2 = '';
					result.g1[i].text3_3 = result.g1[i].fund_3_errt + '%';
					result.g1[i].text3_4 = '';
						
				}// 단기사채
				else if(result.g1[i].gds_tp == '04'){
					
					result.g1[i].gds_tpNm = '단기사채';
					
					result.g1[i].text1_1 = '(세전)수익률';
					result.g1[i].text1_2 = result.g1[i].shrt_prdb_taxb_errt + '%';
					
					result.g1[i].text2_1 = '잔존일수';
					result.g1[i].text2_2 = result.g1[i].shrt_prdb_remn_dys;
					
					result.g1[i].text3_1 = '예상수입(세전,연)';
					result.g1[i].text3_2 = '1억원 투자시';
					result.g1[i].text3_3 = mydataCommon.util.addComma(result.g1[i].shrt_expc_incm) + '원';
					result.g1[i].text3_4 = '';
						
				}// 장외채권
				else if(result.g1[i].gds_tp == '05'){
					
					result.g1[i].gds_tpNm = '장외채권';
					
					result.g1[i].text1_1 = '(세전)수익률';
					result.g1[i].text1_2 = result.g1[i].otc_bond_taxb_errt + '%';
					
					result.g1[i].text2_1 = '잔존일수';
					result.g1[i].text2_2 = result.g1[i].otc_bond_remn_dys;
					
					result.g1[i].text3_1 = '예상수입(연)';
					result.g1[i].text3_2 = '100만원 투자시';
					result.g1[i].text3_3 = mydataCommon.util.addComma(result.g1[i].otc_bond_expc_incm ) + '원';
					result.g1[i].text3_4 = '(세전)';
						
				}// RP
				else if(result.g1[i].gds_tp == '06'){
					
					result.g1[i].gds_tpNm = 'RP';
					
					result.g1[i].text1_1 = '(세전)수익률';
					result.g1[i].text1_2 = result.g1[i].rp_taxb_errt;
					
					result.g1[i].text2_1 = '잔존일수';
					result.g1[i].text2_2 = result.g1[i].rp_remn_dys;
					
					result.g1[i].text3_1 = '예상수입(연)';
					result.g1[i].text3_2 = '100만원 투자시';
					result.g1[i].text3_3 = mydataCommon.util.addComma(result.g1[i].rp_expc_incm) + '원';
					result.g1[i].text3_4 = '(세전)';
				}
				
				// 펀드 위험등급  
				if(result.g1[i].gds_tp == '03'){
					if(result.g1[i].gds_risk_grade_nm == '매우높은위험')
						result.g1[i].risk_color = '1';
					else if(result.g1[i].gds_risk_grade_nm == '높은위험')
						result.g1[i].risk_color = '2';
					else if(result.g1[i].gds_risk_grade_nm == '다소높은위험')
						result.g1[i].risk_color = '3';
					else if(result.g1[i].gds_risk_grade_nm == '보통위험')
						result.g1[i].risk_color = '4';
					else if(result.g1[i].gds_risk_grade_nm == '낮은위험')
						result.g1[i].risk_color = '5';
					else if(result.g1[i].gds_risk_grade_nm == '매우낮은위험')
						result.g1[i].risk_color = '6';
				}
				else{ // 금융상품(펀드제외) 위험등급
					if(result.g1[i].gds_risk_grade_nm == '초고위험')
						result.g1[i].risk_color = '1';
					else if(result.g1[i].gds_risk_grade_nm == '고위험')
						result.g1[i].risk_color = '2';
					else if(result.g1[i].gds_risk_grade_nm == '중위험')
						result.g1[i].risk_color = '3';
					else if(result.g1[i].gds_risk_grade_nm == '저위험')
						result.g1[i].risk_color = '4';
					else if(result.g1[i].gds_risk_grade_nm == '초저위험')
						result.g1[i].risk_color = '5';
					else if(result.g1[i].gds_risk_grade_nm == '무위험')
						result.g1[i].risk_color = '6';
				}
				
				ao_html('#recoFundList', result);
			}
		},
		req_error : function(data){
			mydataCommon_02.util.log(['VBank0010003.js :: req_error ----------> ', data]);
		},
		req_complete : function(data){
			mydataCommon_02.util.log(['VBank0010003.js :: req_complete ----------> ', data]);
		}
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	
	pageUnit.init();
});
