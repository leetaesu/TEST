var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VBank0010001View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'bank',
		v_storageSubKeyName : '',
		
		//연속조회용
		ioAccnt_cont_gubn : "N",
		ioAccnt_next_data : "", 

		savingsAccnt_cont_gubn : "N",
		savingsAccnt_next_data : "",
		
		etcAccnt_cont_gubn : "N",
		etcAccnt_next_data : "",
		
		globalAccnt_cont_gubn : "N",
		globalAccnt_next_data : "",

		cyberAccnt_cont_gubn : "N",
		cyberAccnt_next_data : ""
		
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		acnt_sqno : null,
		cont_gubn : "N",
		next_data : ""

	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			
			
			// 은행 리로드
			if( exeType == 'U1_Realod' ){
			
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/UBank0010001001Ajax",
						
						success : pageUnit.fn.set_section_1,
						error : pageUnit.fn.set_section_reload_error				
				}
				mydataCommon.ajax(jsonObj);
			}// 은행 계좌 금액 상위 목록 조회_원화
			// 전제화면조회
			else if ( exeType == 'allSearch' ){
				
				// 합계조회
				setTimeout(function(){pageUnit.trn.ajax_call('S2_SumTotal');},10);
				// 알림조회
//				setTimeout(function(){pageUnit.trn.ajax_call('S3_Alim');},20);
				// 원화조회
				setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_ioAccnt');},35);
				setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_SavingsAccnt');},40);
				setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_etcAccnt');},45);
				// 외화조회
				setTimeout(function(){pageUnit.trn.ajax_call('S5_Global');},50);
				// 만기조회
				setTimeout(function(){pageUnit.trn.ajax_call('S6_ExpireDate');},55);
				// 여유자금조회
				setTimeout(function(){pageUnit.trn.ajax_call('S7_SpareMoney');},65);
				// 예금현황
				setTimeout(function(){pageUnit.trn.ajax_call('S8_DepositMoney');},75);
				// 적금현황
				setTimeout(function(){pageUnit.trn.ajax_call('S9_SavingsMoney');},85);
				
				setTimeout(function(){pageUnit.trn.ajax_call('S10_bankFinanCpnyList');},95);

				setTimeout(function(){pageUnit.trn.ajax_call('S16_SyberMoneyList');},100);

				
				
				// 나의 심플투자 현황
				setTimeout(function(){pageUnit.trn.ajax_call('S14_simpleInvestList');},90);
			}

			// 뱅킹 연결 여부 조회
			else if ( exeType == 'S1_AssetConnGb' ){
				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001001Ajax",
						success : pageUnit.fn.set_AssetConnGb,
						error : pageUnit.fn.req_error					
				}
				mydataCommon.ajax(jsonObj);
			}			
			
			// 뱅킹 합계 조회
			else if( exeType == 'S2_SumTotal' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001002Ajax",
						success : pageUnit.fn.set_SumTotal,
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			
			// 알림 조회
			else if( exeType == 'S3_Alim' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001003Ajax",
						success : function(res){
							var resultMap = res.XMT1001_Q01;		
							
							if(resultMap.msg_cntn == ""){
								$("#bankAlim").hide();
							}
							else if(resultMap && resultMap.resp_gubn == "0"){
								pageUnit.fn.set_Alim(resultMap);
							}else{
								mydataCommon.msg.alert({msg : "알림:" + resultMap.resp_mesg});
							}
							
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			// 알림 삭제
			else if( exeType == 'D1_AlimDel' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/DBank0010001001Ajax",
						success : pageUnit.fn.set_section_5,
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);
			}
			
			else if( exeType == 'S4_Krw_ioAccnt' ){
				pageUnit.trn_param.cont_gubn = pageUnit.prop.ioAccnt_cont_gubn;
				pageUnit.trn_param.next_data = pageUnit.prop.ioAccnt_next_data;
				var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank00100010041Ajax",
					data : pageUnit.trn_param,
					success : function(res){
						
						var resultMap = res.XMB2001_Q01;
						
						// 수시입출금
						if(resultMap && resultMap.resp_gubn == "0"){
							if(parseInt(resultMap.out_count) > 0){
								$("#a_2001q0101").show();
								pageUnit.fn.set_section_Krw(resultMap, 1);
							}else 
								$("#a_2001q0101").hide();
						}else{
							$("#a_2001q0101").hide();
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S4_Krw_SavingsAccnt' ){
				pageUnit.trn_param.cont_gubn = pageUnit.prop.savingsAccnt_cont_gubn;
				pageUnit.trn_param.next_data = pageUnit.prop.savingsAccnt_next_data;

				var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank00100010042Ajax",
					data : pageUnit.trn_param,
					success : function(res){
						var resultMap = res.XMB2001_Q01;
						// 예적금
						if(resultMap && resultMap.resp_gubn == "0"){
							if(parseInt(resultMap.out_count) > 0){
								$("#a_2001q0102").show();
								pageUnit.fn.set_section_Krw(resultMap, 2);
							}else 
								$("#a_2001q0102").hide();
						}else{
							$("#a_2001q0102").hide();
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S4_Krw_etcAccnt' ){
				pageUnit.trn_param.cont_gubn = pageUnit.prop.etcAccnt_cont_gubn;
				pageUnit.trn_param.next_data = pageUnit.prop.etcAccnt_next_data;

				var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank00100010043Ajax",
					data : pageUnit.trn_param,
					success : function(res){
						var resultMap = res.XMB2001_Q01;
						// 기타
						if(resultMap && resultMap.resp_gubn == "0"){
							if(parseInt(resultMap.out_count) > 0){
								$("#a_2001q0103").show();
								pageUnit.fn.set_section_Krw(resultMap, 3);
							}else 
								$("#a_2001q0103").hide();
						}else{
							$("#a_2001q0103").hide();
						}						},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
			}	
			
			//선불머니.
			else if (exeType == "S16_SyberMoneyList"){
				pageUnit.trn_param.cont_gubn = pageUnit.prop.cyberAccnt_cont_gubn;
				pageUnit.trn_param.next_data = pageUnit.prop.cyberAccnt_next_data;

				var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank0010001016Ajax",
					data : pageUnit.trn_param,
					success : function(res){
						var resultMap = res.XMF2001_Q01;				
						if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
							pageUnit.fn.set_section_SyberMoney(resultMap);
						}else{
							$("#myPrepaymentInfo").hide();
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
			}
			
			// 외화
			else if( exeType == 'S5_Global' ){
				pageUnit.trn_param.cont_gubn = pageUnit.prop.globalAccnt_cont_gubn;
				pageUnit.trn_param.next_data = pageUnit.prop.globalAccnt_next_data;
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001005Ajax",
						data : pageUnit.trn_param,
						success : function(res){
							var resultMap = res.XMB2001_Q02;	

							if(resultMap && resultMap.resp_gubn == "0"){
								if(parseInt(resultMap.out_count) > 0){
//									$("#a_2001q02").show();
									pageUnit.fn.set_section_Global(resultMap);
								}else{
									$("#a_2001q02").hide();
								}
							}else{
								$("#a_2001q02").hide();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			//만기안내
			else if( exeType == 'S6_ExpireDate' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001006Ajax",
						success : function(res){
							var resultMap = res.XMB2021_Q01;				
						
							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
//								$("#matrInfo").show();
								pageUnit.fn.set_section_ExpireDate(resultMap);
							}else{
								$("#myExpireDateInfo").hide();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			// 여유자금 안내 
			else if( exeType == 'S7_SpareMoney' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001007Ajax",
						success : function(res){
							var resultMap = res.XMB2005_Q01;				
						
							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
								pageUnit.fn.set_section_SpareMoney(resultMap);
							}else{
								$("#leftFund").hide();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			// 예금현황 
			else if( exeType == 'S8_DepositMoney' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001008Ajax",
						success : function(res){
							var resultMap = res.XMB2010_Q01;				
						
							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
								pageUnit.fn.set_section_DepositMoney(resultMap);
							}else{
								$("#myDepositInfo").hide();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			// 적금현황 
			else if( exeType == 'S9_SavingsMoney' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001009Ajax",
						success : function(res){
							var resultMap = res.XMB2010_Q02;				

							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
								pageUnit.fn.set_section_SavingsMoney(resultMap);
							}else{
								$("#mySavingsInfo").hide();
							}
						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S10_bankFinanCpnyList' ){
				var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank0010001010Ajax",
					success : function(res){
						var resultMap = res.XMB2004_Q01;		
						if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > 0){
							pageUnit.prop.orgnlist = resultMap.g1;
							pageUnit.trn.ajax_call("S11_bankGroupAcntList") ;
						}
							
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}

				}
				mydataCommon.ajax(jsonObj);
			}
			else if( exeType == 'S11_bankGroupAcntList'){
				
				$.each(pageUnit.prop.orgnlist, function(idx, item){

					var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001011Ajax",
						data : {"orgn_code":item.orgn_code},
						
						success : function(data){
							data.idx = idx+1;
							ao_append("#tab_panel02", "tab_panel02_tmpl", data);
							KW_MOBILE.guiEvent.accordion.init('#mcode0'+data.idx);
							
							if(data.XMB2004_Q02.cont_gubn == "Y") $("#cmpnyGrMoreItem" + item.orgn_code).show();

						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
					}
					mydataCommon.ajax(jsonObj);
				});
			}
			// 나의 심플투자현황-원장
			else if( exeType == 'S14_simpleInvestList' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001014Ajax",
						
						success : function(res){
							var resultMap = res.TDG5105_Q04;
							if(resultMap.out_count>0 && resultMap.resp_gubn =="0"){
								ao_html('noSimpleInv', 'noSimpleInv2_tmpl', resultMap);
							}else{
								ao_html('noSimpleInv', 'noSimpleInv1_tmpl', resultMap);
							}
						    KW_MOBILE.guiEvent.swiper.runSwiper('#noSimpleInv', false);

						},
						error : function(e1, e2, e3){
							mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
						}
				}
				mydataCommon.ajax(jsonObj);
			}
			
			// 나와비슷한 투자자 상품 조회(금리형)
			else if( exeType == 'S12_top5InterestList' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001012Ajax",
						
						
						success : function(res){
							var resultMap = res.XMB4001_Q01;		
							
							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > "0"){
//								$("#recoItem").show();
								pageUnit.fn.set_section_6(resultMap);
							}
						},
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);
			}
			// 나와비슷한 투자자 상품 조회(펀드형)
			else if( exeType == 'S13_top5FundList' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/bank/SBank0010001013Ajax",
						success : function(res){
							var resultMap = res.XMB4001_Q02;		
							
							if(resultMap && resultMap.resp_gubn == "0" && resultMap.out_count > "0"){
								pageUnit.fn.set_section_7(resultMap);
							}
						},
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);
			}
		} 				  
	},
	// 단위 진입부 함수
	init : function(){
		if(mydataCommon.util.isLoc) loa.fn.offLogCollapsed(); // 콘솔디버그 활성화
		pageUnit.eventBind();
		//01:공통(MY), 02:뱅킹, 03:투자, 04:대출, 05:보험, 06:연금, 07:신용, 08:카드
		pageCom.loadNoti.init('#notiPlace', "02", {isTest : false}); 
		// Highcharts Default options (하이차트 사용시 필수 적용)
        Highcharts.setOptions(KW_MOBILE.highcharts.general);
        mydataCommon.util.getRollingBanner({elementId : "#rollingBannerPlace", banr_tp : "1", banr_exps_tp : "02", acnt_lnkg_exps_tp : "01"});   
		// 화면 집입 시 뱅킹 연결 여부 확인
		pageUnit.trn.ajax_call('S1_AssetConnGb');
		pageUnit.trn.ajax_call('S12_top5InterestList'); // 1.나와비슷한 투자자들 상품(금리형)조회-연결여부와 관계없이 조회
		pageUnit.trn.ajax_call('S13_top5FundList'); // 2.나와비슷한 투자자들 상품(편드형)조회-연결여부와 관계없이 조회


	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		// 은행 리로드
		$(document).on("click", "#bank_load", function() {
			pageUnit.trn.ajax_call('U1_Realod');
		});
		
		//심플투자(영S) 이동하기
		$(document).on("click", "#goSimpleTuja", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"380"});
		});
		
		// 알림설정 링크
		$(".text-link.icon-link.link-sm").off('click').on('click', function(){
			pageCom.setNotiService();
		});

		// 알림목록 링크
		$(".text-link.icon-link.link-sm.ml10").off('click').on('click', function(){
			pageCom.goNotiList();
		});
		
		// 알림상품 이동 링크
		$(document).on("click", "#msg_cntn", function() {
//			location.href = '/bank/VBank0010005View';
			
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId: "BANK0105", callback:"callback_callMoveView", viewType:"full"});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		
//		setTimeout(function(){pageUnit.trn.ajax_call('S2_SumTotal');},10);
//		// 원화조회
//		setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_ioAccnt');},35);
//		setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_SavingsAccnt');},40);
//		setTimeout(function(){pageUnit.trn.ajax_call('S4_Krw_etcAccnt');},45);
//		// 외화조회
//		setTimeout(function(){pageUnit.trn.ajax_call('S5_Global');},50);
//		// 만기조회
//		setTimeout(function(){pageUnit.trn.ajax_call('S6_ExpireDate');},55);
//		// 여유자금조회
//		setTimeout(function(){pageUnit.trn.ajax_call('S7_SpareMoney');},65);
//		// 예금현황
//		setTimeout(function(){pageUnit.trn.ajax_call('S8_DepositMoney');},75);
//		// 적금현황
//		setTimeout(function(){pageUnit.trn.ajax_call('S9_SavingsMoney');},85);
//		
//		setTimeout(function(){pageUnit.trn.ajax_call('S10_bankFinanCpnyList');},95);
//
//		setTimeout(function(){pageUnit.trn.ajax_call('S16_SyberMoneyList');},100);

		moreItem : function (gb){
			switch(gb){
				case '1' : pageUnit.trn.ajax_call('S4_Krw_ioAccnt'); break;
				case '2' : pageUnit.trn.ajax_call('S4_Krw_SavingsAccnt'); break;
				case '3' : pageUnit.trn.ajax_call('S4_Krw_etcAccnt'); break;
				case '4' : pageUnit.trn.ajax_call('S16_SyberMoneyList'); break;
				case '5' : pageUnit.trn.ajax_call('S5_Global'); break;
			}
		},		
		
		
		allview5 : function(){
			pageUnit.trn.ajax_call('S16_SyberMoneyList');
		},
		cmpnyGrMoreItem : function(orgn_code, gb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/bank/SBank0010001011Ajax",
					data : {
						"orgn_code" : orgn_code,
						"cont_gubn" : mydataCommon.util.nvl($("#contGubn"+orgn_code).val(),	$("#appendContGubn"+orgn_code).val()),
						"next_data" : mydataCommon.util.nvl($("#nextData"+orgn_code).val(), $("#appendNextData"+orgn_code).val())
					},
					
					success : function(data){
						$("#tab02_cmpyGroupNext"+data.XMB2004_Q02.orgn_code).show();
						ao_append("#tab02_cmpyGroupNext"+data.XMB2004_Q02.orgn_code, "tab02_cmpyGroupNext_tmpl", data)
						
						if(data.XMB2004_Q02.cont_gubn != "Y"){
							$("#cmpnyGrMoreItem"+data.XMB2004_Q02.orgn_code).hide()
							
							$("#appendContGubn"+orgn_code).val("");
							$("#appendNextData"+orgn_code).val("");

						}else{
							$("#appendContGubn"+orgn_code).val(data.XMB2004_Q02.cont_gubn);
							$("#appendNextData"+orgn_code).val(data.XMB2004_Q02.next_data);
						}
						$("#contGubn"+orgn_code).val("");
						$("#nextData"+orgn_code).val("");
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+exeType+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
		},
		
		
		
		
		// 뱅킹 자산 연결
		set_bankConnect : function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"callback_callMoveView"});
			
		},
		//펀드 매수(영S) 이동하기
		go_fund : function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"61"});
		},
		//채권 매수(영S) 이동하기
		go_bond : function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"857"});
		},
		//계좌 상세-원화
		goAccList : function(acnt_no, acnt_sqno, orgn_code){
			
			pageUnit.trn_param.orgn_code = orgn_code;
			pageUnit.trn_param.acnt_no = acnt_no;
			pageUnit.trn_param.acnt_sqno = acnt_sqno;
			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VBank0010001View');
			
			// /bank/VBank0010002View
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0102", callback:"callback_callMoveView", viewType:"full"});
			
		
		},
		
		//계좌 상세-외화
		goGlbalAccList : function(acnt_no, acnt_sqno, orgn_code){
			pageUnit.trn_param.orgn_code = orgn_code;
			pageUnit.trn_param.acnt_no = acnt_no;
			pageUnit.trn_param.acnt_sqno = acnt_sqno;
			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VBank0010001View');
			
			// VBank0010006View
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0106", callback:"callback_callMoveView", viewType:"full"});
			
		},
		//선불머니-상세
		goCyberMnDetail : function(orgn_code, fob_id, efnc_acct_id, efnc_orgn_acct_id ){
			
			pageUnit.trn_param.fob_id = fob_id;
			pageUnit.trn_param.orgn_code = orgn_code;
			
			if(efnc_acct_id != ""){
				pageUnit.trn_param.efnc_acct_id = efnc_acct_id;
				mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0109", callback:"callback_callMoveView", viewType:"full"});
			}else{
				pageUnit.trn_param.efnc_orgn_acct_id = efnc_orgn_acct_id;
				mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0112", callback:"callback_callMoveView", viewType:"full"});
			}
			
			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VBank0010001View');
			
			// VBank0010006View
			
		},
		// 선물머니-결제상세
		goPaymentDetailInfo : function(fob_id, efnc_orgn_acct_id, orgn_code){
			
			pageUnit.trn_param.fob_id = fob_id;
			pageUnit.trn_param.efnc_orgn_acct_id = efnc_orgn_acct_id;
			pageUnit.trn_param.orgn_code = orgn_code;

			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VBank0010001View');

			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0112", callback:"callback_callMoveView", viewType:"full"});
		},
		//계좌 현황
		goAccStatus : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK01P01", callback:"callback_callMoveView", viewType:"full"});
		},
		// 상품목록 보러가기
		goRecoItem : function(tp, amt){
			// tp = 01:여유쟈금,02:예적금현황,03:만기안내
			
			pageUnit.trn_param.stk_rcmn_svc_tp = tp;
			
			if(tp != '2') pageUnit.trn_param.tuja_amt = amt;
			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VBank0010001View');
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK0103", callback:"callback_callMoveView", viewType:"full"});
		},
		// 뱅킹 비연결-연결에 따른 숨기기-보이기 처리
		set_AssetConnGb : function(data){		
			
			var outData = data.XMB2002_Q01;

			if(outData.resp_gubn == '0'){
				// 연결 Yes
				if(outData.yn == 'Y'){ 
					$("#top_connect01").hide();
					$("#top_connect02").show();
					pageUnit.trn.ajax_call("allSearch");
				}
				// 연결 No
				else if(outData.yn == 'N'){ 
					$("#top_connect01").show();
					$("#top_connect02").hide();
				}
			}
								
		},
		// 은행 리로드 완료 후
		set_section_1 : function(data){	
			
			var outData = data.XMB1001_U01;
			
			if(outData.resp_gubn == '0'){
				
				$("#List2001q0101").html('');
				$("#List2001q0102").html('');
				$("#List2001q0103").html('');
				$("#List2001q02").html('');
				
				mydataCommon.msg.alert({msg : "연결된 자산 정보를 업데이트 하였습니다."});
				pageUnit.trn.ajax_call('allSearch');
			}
			else mydataCommon.msg.alert({msg : outData.resp_mesg});
			
		},
		// 원화 조회
		set_section_Krw : function(data, tp){
		
			var acct_titl = "";
			
			if(tp == 1){
				
				// 상품별 합계 부분
				acct_titl = "수시 입출금";
				data.acct_titl = acct_titl;
				data.amt_sum = mydataCommon.util.addComma(data.amt_sum);
				
				if(pageUnit.prop.ioAccnt_cont_gubn == "Y"){
					$("#a_2001q0101Next").show();
					data.btnNm = "송금";
					data.viewId= "353"
					mydataCommon.util.consoleOut(data);
					ao_append('#a_2001q0101Next', 'tab01_mainAccntNext_tmpl',data);//연속데이터
				}else{
					ao_html('#a_2001q0101', data);
					KW_MOBILE.guiEvent.accordion.init("#a_2001q0101");
				}
				
				if(data.cont_gubn == "Y"){
					$("#allView1").show();
					pageUnit.prop.ioAccnt_cont_gubn = data.cont_gubn;
					pageUnit.prop.ioAccnt_next_data = data.next_data;
				}else{
					$("#allView1").hide();
					pageUnit.trn_param.cont_gubn = "N";
					pageUnit.trn_param.next_data = "";
					pageUnit.prop.ioAccnt_cont_gubn = "N";
					pageUnit.prop.ioAccnt_next_data = "";

				}
			}
			else if(tp == 2){
				
				// 상품별 합계 부분
				acct_titl = "예·적금";
				data.acct_titl = acct_titl;
				data.amt_sum = mydataCommon.util.addComma(data.amt_sum);
				
				if(pageUnit.prop.savingsAccnt_cont_gubn == "Y"){
					$("#a_2001q0102Next").show();
					data.btnNm = "입금";
					data.viewId= "352"
					ao_append('#a_2001q0102Next', 'tab01_mainAccntNext_tmpl',data);//연속데이터
				}else{
					ao_html('#a_2001q0102', data)
					KW_MOBILE.guiEvent.accordion.init("#a_2001q0102");
				}

				if(data.cont_gubn == "Y"){
					$("#allView2").show();
					pageUnit.prop.savingsAccnt_cont_gubn = data.cont_gubn;
					pageUnit.prop.savingsAccnt_next_data = data.next_data;
				}else{
					$("#allView2").hide();
					pageUnit.trn_param.cont_gubn = "N";
					pageUnit.trn_param.next_data = "";
					pageUnit.prop.savingsAccnt_cont_gubn = "N";
					pageUnit.prop.savingsAccnt_next_data = "";

				}
			}
			else if(tp == 3){
				
				// 상품별 합계 부분
				acct_titl = "기타";
				data.acct_titl = acct_titl;
				data.amt_sum = mydataCommon.util.addComma(data.amt_sum);
				
				if(pageUnit.prop.etcAccnt_cont_gubn == "Y"){
					data.btnNm = "이체";
					data.viewId= "354"
					$("#a_2001q0103Next").show();
					ao_append('#a_2001q0103Next', 'tab01_mainAccntNext_tmpl',data);//연속데이터
				}else{
					ao_html('#a_2001q0103', data);
					KW_MOBILE.guiEvent.accordion.init("#a_2001q0103");
				}

				if(data.cont_gubn == "Y"){
					$("#allView3").show();
					pageUnit.prop.etcAccnt_cont_gubn = data.cont_gubn;
					pageUnit.prop.etcAccnt_next_data = data.next_data;
				}else{
					$("#allView3").hide();
					pageUnit.trn_param.cont_gubn = "N";
					pageUnit.trn_param.next_data = "";
					pageUnit.prop.etcAccnt_cont_gubn = "N";
					pageUnit.prop.etcAccnt_next_data = "";

				}
			}
		},
		// 외화 조회
		set_section_Global : function(data){
			
			// 상품별 합계 부분
			acct_titl = "외화";
			data.acct_titl = acct_titl;
			data.amt_sum = mydataCommon.util.addComma(data.amt_sum);
			
			if(pageUnit.prop.globalAccnt_cont_gubn == "Y"){
				$("#a_2001q02Next").show();
				ao_append('#a_2001q02Next', 'tab01_mainAccntNext_tmpl',data);//연속데이터
			}else{
				ao_html('#a_2001q02', data);
				KW_MOBILE.guiEvent.accordion.init("#a_2001q02");
				KW_MOBILE.guiEvent.toolTip.init('#a_2001q02Tooltip');
			}
			
			if(data.cont_gubn == "Y"){
				$("#allView4").show();
				pageUnit.prop.globalAccnt_cont_gubn = data.cont_gubn;
				pageUnit.prop.globalAccnt_next_data = data.next_data;
			}else{
				$("#allView4").hide();
				pageUnit.trn_param.cont_gubn = "N";
				pageUnit.trn_param.next_data = "";
				pageUnit.prop.globalAccnt_cont_gubn = "N";
				pageUnit.prop.globalAccnt_next_data = "";
			}
			
		},
		//선불머니 조회
		set_section_SyberMoney : function(data){ 
			data.amt_sum = mydataCommon.util.getPrice(data.amt_sum);
			
			if(pageUnit.prop.cyberAccnt_cont_gubn == "Y"){
				$("#myPrepaymentInfoNext").show();
				ao_append('#myPrepaymentInfoNext', 'myPrepaymentInfoNext_tmpl',data);//연속데이터
			}else{
				ao_html('#myPrepaymentInfo', data);
				KW_MOBILE.guiEvent.accordion.init('#myPrepaymentInfo');
				KW_MOBILE.guiEvent.toolTip.init('#cyberMoneyTooltip');
			}

			
			if(data.cont_gubn == "Y"){
				$("#allView5").show();
				pageUnit.prop.cyberAccnt_cont_gubn = data.cont_gubn;
				pageUnit.prop.cyberAccnt_next_data = data.next_data;
			}else{
				$("#allView5").hide();
				pageUnit.trn_param.cont_gubn = "N";
				pageUnit.trn_param.next_data = "";
				pageUnit.prop.cyberAccnt_cont_gubn = "N";
				pageUnit.prop.cyberAccnt_next_data = "";
			}
		},

		
		// 알림 조회
		set_section_5 : function(data){
			
			var outData = data.resultMap;
			
			if(outData.resp_gubn == '0'){
				$("#bankAlim").hide();
			}
		},
		//내게 맞는 관심 상품 조회_금리형 TOP5
		set_section_6 : function(result){
			// 리스트 부분
			var g1 = result.g1;
			var gds_risk_grade_nm;
			for(var i=0; i<g1.length; i++){
				
				gds_risk_grade_nm = result.g1[i].gds_risk_grade_nm;
		
				
                //[D] 위험등급 : grade-danger1~5(초고위험,고위험,중위험,저위험,초저위험)

				//grade-danger1~5
				if(gds_risk_grade_nm == '초고위험')
					result.g1[i].risk_color = '1';
				else if(gds_risk_grade_nm == '고위험')
					result.g1[i].risk_color = '2';
				else if(gds_risk_grade_nm == '중위험')
					result.g1[i].risk_color = '3';
				else if(gds_risk_grade_nm == '저위험')
					result.g1[i].risk_color = '4';
				else if(gds_risk_grade_nm == '초저위험')
					result.g1[i].risk_color = '5';
			}
			ao_html('#a_4001q0101', result);
		},
		//내게 맞는 관심 상품 조회_펀드 TOP5
		set_section_7 : function(result){
			
			// 리스트 부분
			var g1 = result.g1;
			var gds_risk_grade_nm;
			for(var i=0; i<g1.length; i++){
				
				gds_risk_grade_nm = result.g1[i].gds_risk_grade_nm;
		
				if(gds_risk_grade_nm == '매우높은위험')
					result.g1[i].risk_color = '1';
				else if(gds_risk_grade_nm == '높은위험')
					result.g1[i].risk_color = '2';
				else if(gds_risk_grade_nm == '다소높은위험')
					result.g1[i].risk_color = '3';
				else if(gds_risk_grade_nm == '보통위험')
					result.g1[i].risk_color = '4';
				else if(gds_risk_grade_nm == '낮은위험')
					result.g1[i].risk_color = '5';
				else if(gds_risk_grade_nm == '매우낮은위험')
					result.g1[i].risk_color = '5';
			}
			ao_html('#a_4001q0102', result);

		},
		// 메인 상단 합계 표시
		set_SumTotal : function(data){ 
			var outData = data.XMB2003_Q01;
			outData.amt_sum = mydataCommon.util.addComma(outData.amt_sum);
			ao_html('#bankInfoDtl', outData);
			
		},
		
		// 만기 안내
		set_section_ExpireDate : function(result){ 
			var outData = result;
//			mydataCommon.util.consoleOut(outData)
			ao_html('#swiperHeader', outData);
			ao_html('#swiperList', outData);

			if(pageUnit.prop.version_view) $('#matrInfoTop').hide();
			
		    KW_MOBILE.guiEvent.swiper.runSwiper('#swiperList', false);
		    

		},
		// 여유자금 안내
		set_section_SpareMoney : function(result){ 
			
			ao_html('#leftFund', result);
			var cate = [];
			var data = [];
			
			$.each(result.g1, function(idx, item){
				cate.push(mydataCommon.util.getStrDate(item.dt));
				data.push(Number(item.amt));

			});
			
	        //여유자금 차트
	        var area = new Highcharts.Chart('chart-area', Highcharts.merge (    
	                KW_MOBILE.highcharts.types.area,
	                {            
	                    chart: { 
	                        type: 'areaspline',
	                        height: 250
	                    },
	                    xAxis:{                        
	                        categories: cate
	                    },
	                    yAxis: [
	                        {
	                            labels:{ formatter: function() {return this.value} },
	                            title: { text: '(만원)', rotation: 0, align: 'low', textAlign: 'right', offset: 10, y: 20 },                            
	                            tickInterval: 200,
	                            plotLines: [{
	                                value: result.max_amt,           //최대값
	                                color: '#66ccff',                                
	                                width: 1,
	                                zIndex: 10,
	                                dashStyle: 'shortdash'
	                            },
	                            {
	                                value: result.min_amt,           //최소값
	                                color: '#f274a2',                                
	                                width: 1,
	                                zIndex: 10,
	                                dashStyle: 'shortdash'
	                            }],
	                        }
	                    ],
	                    plotOptions: {                        
	                        areaspline: {
	                            fillColor: {
	                                linearGradient: {
	                                    x1: 0,
	                                    y1: 0,
	                                    x2: 0,
	                                    y2: 1
	                                },
	                                stops: [
	                                    [0, '#e7e7f7'],
	                                    [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
	                                    
	                                ]
	                            },
	                            marker: {
	                                enabled: false
	                            },
	                            lineWidth: 2,
	                            lineColor: '#6666cc',
	                            states: {
	                                hover: {
	                                    lineWidth: 1
	                                }
	                            },
	                            threshold: null
	                        }
	                    },
	                    series: [{                        
	                        name: '',
	                        data: data
	                    }]                    
	                }

	            ));

			
			
		},
		// 예금 현황
		set_section_DepositMoney : function(result){ 
			$.each(result.g1, function (idx,item){
				last_pdin_sqnc = parseInt(item.last_pdin_sqnc);
				tot_sqnc = parseInt(item.tot_sqnc);				
				progress_result = last_pdin_sqnc /tot_sqnc  * 100;
				item.progress_result = Math.round(progress_result);
			});

			ao_html("#myDepositInfo",result);
			KW_MOBILE.guiEvent.swiper.runSwiper('#swiperList1');
		},
		// 적금 현황
		set_section_SavingsMoney : function(result){ 
			
			$.each(result.g1, function (idx,item){
				last_pdin_sqnc = parseInt(item.last_pdin_sqnc);
				tot_sqnc = parseInt(item.tot_sqnc);				
				progress_result = last_pdin_sqnc /tot_sqnc  * 100;
				item.progress_result = Math.round(progress_result);
			});
			ao_html("#mySavingsInfo", result);
			KW_MOBILE.guiEvent.swiper.runSwiper('#swiperList2');
		},
		
		// 심플투자 현황-원장
		set_section_reload_error : function(data) {
			var outData = data.resultMap;
			mydataCommon.util.log([ 'VBank0010001.js :: set_section_reload_error ----------> ',	data ]);
			alert(outData);
			mydataCommon.msg.alert({msg : outData.resp_mesg});
		},
		req_error : function(data){
			mydataCommon_02.util.log(['VBank0010001.js :: req_error ----------> ', data]);
		},
		req_complete : function(data){
			mydataCommon_02.util.log(['VBank0010001.js :: req_complete ----------> ', data]);
		} 		
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		// 심플투자 현황 차트
		char_section_13 : function( opt ){
			
			// Gauge 차트 - 달성률
	        var chartGuage = new Highcharts.chart('chart-goal', Highcharts.merge (
	            KW_MOBILE.highcharts.types.solidgauge,
	            {
	                chart: { width: 80, height: 80 },
	                pane: {
	                    background: { borderWidth: 11 }
	                },
	                plotOptions: {
	                    solidgauge: { 
	                        borderWidth: 11, 
	                        borderColor: '#e22d72' 
	                    }
	                },
	                series: [{
	                    data: opt.data,
	                    dataLabels: { enabled: false }
	                }]
	            }
	        ));
		}
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});







