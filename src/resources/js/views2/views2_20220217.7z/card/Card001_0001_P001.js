var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VCard0010001P001Pop',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'card',
		v_storageSubKeyName : '',	
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
				/* ========= 나의 카드현황 상세 XMC2109_Q02 (당월비율)========= */
				if(exeType == 'getXMC2109_Q02') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001P001001Ajax",
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				
			});//promise end
		}//ajax_call end

	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		
		var ajax_call = pageUnit.trn.ajax_call;
		ajax_call('getXMC2109_Q02')
		.then(function(data){
			mydataCommon.util.consoleOut(data , "나의 카드현황 상세 XMC2109_Q02 (당월비율)");
			pageUnit.fn.set_XMC2109_Q02(data);
		})
		.catch(function(e){
			console.error(e);
		});
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		// 닫기
		$(document).on("click", ".sub-close", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		$(document).on("click", ".btn-footer", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});		
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 카드현황 상세 XMC2109_Q02 (당월비율)
		set_XMC2109_Q02 : function(data){
			var outData = data.XMC2109_Q02;
			
			if(outData && outData.resp_gubn == "0") {
				
				/*############ 나의 카드현황 사용금액 합계 section ############*/ 
				ao_html('#cardUseInfo', outData);
				
				if(parseInt(outData.out_count) > 0){
					/*############ 카드사용현황 : 조회 카드별 결제승인금액 항목 및 합산 금액 section ############*/
					outData.strt_dt = mydataCommon.util.getStrDate(outData.strt_dt);
					outData.end_dt = mydataCommon.util.getStrDate(outData.end_dt);
					ao_html('#cardUseInfoDtls', outData);
					
					// 카드사용현황 바차트-스택 셋팅
					var chartId = 'chart-bar-stack';
					var cate = [''];
					//var colors = ['#ffcc40', '#eb6c9c', '#f39262'];
					var colors = ['#fe74a2', '#ff9933', '#66ccff', '#6666cc', '#66cccc', 'd1d6e8 '];
					var chartBarStackData = new Array();
					
					//차트에 넣을 Data 셋팅
					$.each(outData.g1, function(i, v){
						var map ={};
						var idex = outData.g1.length-i;
						
						map.name = v.orgn_nm;
						map.data = [parseFloat(v.rt)];
						map.color = colors[i];
						map.index = idex;
						
						chartBarStackData.push(map);
					})
					
					//barStack 공통 차트  적용
					var chartObj = mydataCommon.design.chartStackedBar(chartId,chartBarStackData,cate,150);
					mydataCommon.util.consoleOut( chartBarStackData ," 카드사용 비중 차트 Data ");
					
					/*############ 이전 2개월 사용금액 변동 추이 section ############*/
					
					// 테이블 합계 컬럼 설정
					outData.this_mm = mydataCommon.util.getStrDate(outData.g1[0].this_mm);
					outData.lest_mm = mydataCommon.util.getStrDate(outData.g1[0].lest_mm);
					outData.this_mm_amt_sum = outData.g1[0].this_mm_amt_sum;
					outData.last_mm_amt_sum = outData.g1[0].last_mm_amt_sum;
					
					ao_html('#cardBillAmtTable', outData);
					
					// 이전 2개월 사용금액 변동 추이 컬럼차트-스택 셋팅
					
					// 컬럼차트의 y축 max 값 구하기 (단위 :100만) 
					function getMaxInt(obj) {
						var max = 0;
						var rst = 0;
						
						var amt= parseInt(obj.this_mm_amt_sum);
						var lest_amt= parseInt(obj.last_mm_amt_sum);
						
						max = ( amt >= lest_amt ? amt : lest_amt);
						rst = (Math.floor(max / 1000000)+1)* 1000000;
						
						return rst;
					}
					var max = getMaxInt(outData);
					
					// 이전 2개월 사용금액 변동 추이 상단 컬럼차트-스택 셋팅
					chartId = 'chart-column-stack';
					cate = [ outData.this_mm , outData.lest_mm];
					colors = ['#fe74a2', '#ff9933', '#66ccff', '#6666cc', '#66cccc','d1d6e8 '];
					var directOptions ={
							// 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
							'userSetOptionAppend' : true,
							'yAxis' : { 'min': 0, 					
										'max': max, // y축 max 값
										'tickInterval' : 100000, // y축 단위
										'labels' : {'formatter': function() {return this.value;}} }, // 디폴트 value+'%' -> value 로 변경
							'plotOptions' : {
										'series':{ 'stacking':'normal'}	// 디폴트 'percent' -> 'normal' 로 변경
							}
						}
					
					var chartColumnData = new Array();
					
					// 차트에 넣을 Data 셋팅
					$.each(outData.g1, function(i, v){
						var map ={};
						var idex = (i+1);
						
						map.name = v.orgn_nm;
						map.data = [parseInt(v.this_mm_amt), parseInt(v.last_mm_amt)];
						map.color = colors[i];
						map.index = idex;
						
						chartColumnData.push(map);
					})
					mydataCommon.util.consoleOut(directOptions);
					// columnStack 공통 차트 적용
					var chartObj = mydataCommon.design.chartColumnStack(chartId,chartColumnData,cate,230,directOptions);
					mydataCommon.util.consoleOut( chartColumnData ," 이전 2개월 사용금액 변동 추이 차트 Data ");
					
				}else{
					 mydataCommon.msg.alert({msg : outData.resp_mesg});
				}
			} else {
				 mydataCommon.msg.alert({msg : outData.resp_mesg});
				mydataCommon.util.consoleOut( [] ,outData.resp_mesg+":: 카드현황 상세 XMC2109_Q02");
			}
		},
		getMaxint : function(obj){
			
			
		},
	},
	
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 	}
};

// 페이지 on load시 진입부
$(document).ready(function(){
	 Highcharts.setOptions(KW_MOBILE.highcharts.general);
	pageUnit.init();
});

