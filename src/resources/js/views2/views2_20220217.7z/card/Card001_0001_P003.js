var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VCard0010001P003Pop",
		v_storageKeyName : 'card',
		v_storageSubKeyName : '',
		dt : "",
		next_key:""
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {

				/* =========== 카드 사용 캘린더 XMC2102_Q01 ========== */
				if (exeType == 'getXMC2102_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001004Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				} 
				/* ========= 카드 사용 캘린더 상세 XMC2102_Q02 ========= */
				else if(exeType == 'getXMC2102_Q02') {
					var data = {"base_dt" : $datepicker.data('datepicker')._prevOnSelectValue.replaceAll("-","")};
					mydataCommon.util.consoleOut(data);
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001P003Ajax",
							data :{"base_dt" : $datepicker.data('datepicker')._prevOnSelectValue.replaceAll("-","")},
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				
			});//promise end
		}//ajax_call end
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		pageUnit.fn.allSearch()
//		pageUnit.fn.dateCal();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(value){
		// 닫기
		$(document).on("click", ".sub-close", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		$(document).on("click", ".btn-footer", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});		
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		allSearch : function(data){
			
			$('#baseYymm').empty();
			
			$('#card_calendar').empty();
			
			$('#cardDate').empty();
			
			$('#cardDtl').empty();
			
			// 월별 카드사용내역 조회
			pageUnit.trn.ajax_call('getXMC2102_Q01')
			.then(function(data){
				mydataCommon.util.consoleOut(data , "월별 카드사용내역 조회");
				pageUnit.fn.set_XMC2102_Q01(data);
			}).catch(function(e){
				console.error(e);
			});
			
		},
		
		// 월별 카드사용내역 조회
		set_XMC2102_Q01 : function(data) {
			
			var outData = data.XMC2102_Q01;
			 if(outData.resp_gubn == "0"){
				 
				 var g1 = outData.g1;
					var use_dt = "";
					var use_dt_mm = "";
					var use_dt_dd = "";
					var tmpDateList = [];
					var tmpMoneyList = [];
					
					for(var i=0; i<g1.length; i++){
						use_dt = g1[i].base_dt;
						use_dt_mm = use_dt.substring(4,6);
						use_dt_dd = use_dt.substring(6,8);
						tmpDateList[i] = parseInt(use_dt_dd);
						tmpMoneyList[i] = g1[i].use_amt;
					}
					$('#baseYymm').text(Number((mydataCommon.util.getStrDate()).substring(4,6))+'월 카드 캘린더');

					eventDates = tmpDateList;
					eventMoney = tmpMoneyList;
					mydataCommon.util.consoleOut(eventDates);
					mydataCommon.util.consoleOut(eventMoney);
//					pageUnit.fn.dateCal(eventDates, eventMoney);
					
					var calOb = { 'eventDates': tmpDateList, 'eventMoney': tmpMoneyList};
					pageUnit.fn.setCalendar(calOb);
					
//					mydataCommon.util.consoleOut($datepicker.data('datepicker')._prevOnSelectValue);
			 }else{
				 mydataCommon.msg.alert({msg : outData.resp_mesg});
				 
			 }
		},	
		//카드 사용 캘린더 상세
		set_XMC2102_Q02 : function(data) {
			
			var outData = data.XMC2102_Q02;
			if(outData && outData.resp_gubn == "0") {
				
				pageUnit.prop.dt = $datepicker.data('datepicker')._prevOnSelectValue.replaceAll("-","").substring(4,6);

//				var use_dt_mm = (mydataCommon.util.getStrDate()).substring(4,6);
//				var use_dt_dd = (mydataCommon.util.getStrDate()).substring(6,8);
				outData.today_dt = mydataCommon.util.getStrDate();
				outData.baseYymm = Number(pageUnit.prop.dt);
	
				ao_html("#baseYymm" , outData);
				ao_html("#cardDate" , outData);
				
				outData.out_count = parseInt(outData.out_count);
				ao_html("#cardDtl" , outData);
//				$.each(outData.g1, function(i, v){
//					ao_append("#cardDtl" , v);
//				});
				
			} else {
				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		setCalendar: function(obj){
			var eventDates =  obj.eventDates,
	            eventMoney = obj.eventMoney; // 사용한 금액 
	            currentDate = new Date(),
	            $datepicker = $('#card_calendar'),

	        $datepicker.datepicker({
	        	minDate : new Date(currentDate.getFullYear(), currentDate.getMonth(), '1'),
			    maxDate : new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()),
//			    showOtherMonths false 이전달, 다음달 날짜 표기안됨
			    showOtherMonths :false,
	            language: 'ko',
	            firstDay: 1,
	            onRenderCell: function(date, cellType) {
	                var currentDt = date.getDate();

	                if (cellType == 'day' && eventDates.indexOf(currentDt) != -1) {
	                	
	                	if(currentDate.getMonth() == date.getMonth()){
	                		if(eventMoney[currentDt-1] == null) {
	                			eventMoney[currentDt-1] = 0;
	                		}
	                		return {
	                            html: currentDt + `<span class="date-price" value="${eventMoney[currentDt-1]}" id="datePrice${currentDt}">${mydataCommon.util.addComma(eventMoney[currentDt-1])}</span>`
	                        }
	                	}
	                }
	            },
	            onSelect: function() {
	            	if($datepicker.data('datepicker').selectedDates[0] != undefined){
	            		$("#cardDtl").html('');
		    			$("#cardDate").html('');
		    			
		    			pageUnit.trn.ajax_call('getXMC2102_Q02')
		    			.then(function(data){
		    				mydataCommon.util.consoleOut(data , "일별 카드사용내역 조회");
		    				pageUnit.fn.set_XMC2102_Q02(data);
		    			}).catch(function(e){
		    				console.error(e);
		    			});
		    			
//		    			if($("#datePrice"+$datepicker.data('datepicker').selectedDates[0].getDate()).text() != "0"){
//		    				
//		    			}
	            	}
	            }
	        });

	        // Default selection
	        $datepicker.data('datepicker')
	            .selectDate(new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()));
		},
		
		//리로드
		set_reload : function(data){

			var outData = data.resultMap;
			 if(outData.resp_gubn == "0"){
				 
				pageUnit.fn.allSearch(outData);
				mydataCommon.msg.alert({msg : "업데이트 하였습니다."});
				
			 }else{
				 mydataCommon.msg.alert({msg : outData.resp_mesg});
			 }
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
	}
};

// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
window.onload =function(){
}