var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : 'VCard0010002View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'card',
		v_storageSubKeyName : '',
		tempRow : null,
		toDayDt : mydataCommon.util.getStrDate(),
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		cont_gubn : '',
		card_id : '',
		myd_orgn_code :'',
		strt_dt : '',
		end_dt : '',
		
		next_page_base_val : '',  //국내승인 거래내역 next key
		next_page_out :'',		//해외승인 거래내역 next key
			
		radio_trans_gb : '1',
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){

			/* ========= 카드 상세 -카드정보 조회 XMC2103_Q02 ========= */
			if (exeType == 'getXMC2103_Q02') {
				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/card/SCard0010002001Ajax",
						//cache : true,
						data : pageUnit.trn_param,
						success : pageUnit.fn.set_XMC2103_Q02,
						error : pageUnit.fn.set_section_search_error
				}
				mydataCommon.ajax(jsonObj);
			} 
			/* ========= 카드상세 국내승인내역 XMC2103_Q03 ========= */
			else if(exeType == 'getXMC2103_Q03') {
				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/card/SCard0010002002Ajax",
						//cache : true,
						data : pageUnit.trn_param,
						success : pageUnit.fn.set_XMC2103_Q03,
						error : pageUnit.fn.set_section_search_error
				}
				mydataCommon.ajax(jsonObj);
			}
			/* ========= 카드상세 해외승인내역 XMC2103_Q05 ========= */
			else if(exeType == 'getXMC2103_Q05') {
				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/card/SCard0010002003Ajax",
						//cache : true,
						data : pageUnit.trn_param,
						success : pageUnit.fn.set_XMC2103_Q05,
						error : pageUnit.fn.set_section_search_error
				}
				mydataCommon.ajax(jsonObj);
			}
		}
	},
	// 단위 진입부 함수
	init : function(){
		var param = mydataCommon.page.getSubParamData('VCard0010001View');
			pageUnit.trn_param.card_id = param.card_id;
			pageUnit.trn_param.myd_orgn_code = param.myd_orgn_code;

			pageUnit.eventBind();
			pageUnit.trn.ajax_call('getXMC2103_Q02');
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){

		// 뒤로가기
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
			//document.location.href = pageCom.prop.contextPath+"/card/VCard0010001View";
		});
		
		
		/*$(document).on("click", "#month_cal_rdo_14", function() {
			var baseDtArr = mydataCommon.util.getStrDate(pageUnit.prop.toDayDt).split('.');
			var baseYY = parseInt(baseDtArr[0])-1;
			console.log(baseYY.toString());
			$('.datepicker--nav-title').html(baseYY.toString());
		});*/
		
		// 거래내역으로 이동
		$(document).on("click", "#tab_02", function() {
			var radio_trans_gb = $("[name='radio_trans_gb']").val();
			
			mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt) {

				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = '';	
				//기간 선택 일경우 과거 5년부터 과거 1년까지 
				if($('#month_cal_rdo_14').prop('checked')){
					
					var baseDtArr = mydataCommon.util.getStrDate(pageUnit.prop.toDayDt).split('.'),
						strtDtArr = mydataCommon.util.getStrDate(strt_dt).split('.'),
						endDtArr = mydataCommon.util.getStrDate(end_dt).split('.');
					var baseDtYY = parseInt(baseDtArr[0]),
						strtDtYY = parseInt(strtDtArr[0]),
						endDtYY = parseInt(endDtArr[0]);
					var baseDtMMDD = parseInt(baseDtArr[1]+baseDtArr[2]),
						strtDtMMDD = parseInt(strtDtArr[1]+strtDtArr[2]),
						endDtMMDD = parseInt(endDtArr[1]+endDtArr[2]);
					
					if( (strtDtYY => baseDtYY-4 && strtDtMMDD > baseDtMMDD ) &&
						(endDtYY <= baseDtYY-1 && endDtMMDD < baseDtMMDD ) ){
						pageUnit.trn_param.strt_dt = strt_dt;
						pageUnit.trn_param.end_dt = end_dt;	
					} else {
						mydataCommon.msg.alert({msg : "기간선택시 과거 5년부터 과거 1년까지 거래내역 조회가 가능합니다."});
					}
				}
				
				pageUnit.trn_param.radio_trans_gb = radio_trans_gb;
				$('#dmstcCardTransInfo').empty();
				$('#ovrCardTransInfo').empty();
				$('#ovrNoDataCmt').empty();
				$('#dmstcNoDataCmt').empty();
				/*ajax call*/
				if(radio_trans_gb =="1"){		//국내승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q03');
					$('#trans_gb_001').show();
					$('#trans_gb_002').hide();
					

				}else{							//해외승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q05');
					$('#trans_gb_002').show();
					$('#trans_gb_001').hide();
					
				}
			});	
		});
		
		$(document).on("change", "[name='radio_trans_gb']", function() {
			var radio_trans_gb = $(this).val();
			
			mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt) {
				
				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = '';	
				//기간 선택 일경우 과거 5년부터 과거 1년까지 
				if($('#month_cal_rdo_14').prop('checked')){
					
					var baseDtArr = mydataCommon.util.getStrDate(pageUnit.prop.toDayDt).split('.'),
						strtDtArr = mydataCommon.util.getStrDate(strt_dt).split('.'),
						endDtArr = mydataCommon.util.getStrDate(end_dt).split('.');
					var baseDtYY = parseInt(baseDtArr[0]),
						strtDtYY = parseInt(strtDtArr[0]),
						endDtYY = parseInt(endDtArr[0]);
					var baseDtMMDD = parseInt(baseDtArr[1]+baseDtArr[2]),
						strtDtMMDD = parseInt(strtDtArr[1]+strtDtArr[2]),
						endDtMMDD = parseInt(endDtArr[1]+endDtArr[2]);
					
					if( (strtDtYY => baseDtYY-4 && strtDtMMDD > baseDtMMDD ) &&
						(endDtYY <= baseDtYY-1 && endDtMMDD < baseDtMMDD ) ){
						pageUnit.trn_param.strt_dt = strt_dt;
						pageUnit.trn_param.end_dt = end_dt;	
					} else {
						mydataCommon.msg.alert({msg : "기간선택시 과거 5년부터 과거 1년까지 거래내역 조회가 가능합니다."});
					}
				}
				pageUnit.trn_param.radio_trans_gb = radio_trans_gb;
				$('#dmstcCardTransInfo').empty();
				$('#ovrCardTransInfo').empty();
				$('#ovrNoDataCmt').empty();
				$('#dmstcNoDataCmt').empty();
				/*ajax call*/
				if(radio_trans_gb =="1"){		//국내승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q03');
					$('#trans_gb_001').show();
					$('#trans_gb_002').hide();
					

				}else{							//해외승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q05');
					$('#trans_gb_002').show();
					$('#trans_gb_001').hide();
				}
			});	
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		//카드 상세 -카드정보 셋팅
		set_XMC2103_Q02 : function(data) {
			mydataCommon.util.consoleOut( data ,"카드 상세 -카드정보 조회");
			
			var outData = data.XMC2103_Q02;
			if (outData && outData.resp_gubn =="0") {

				if(!(parseInt(outData.out_count)>0)){
					mydataCommon.msg.alert({msg : outData.resp_mesg});
				}
				// 선불카드의 경우 카드사포인트, 상세정보 추후 추가될 예정이라고함 .
				ao_html('#info', outData);
				ao_html('#cardInfoDtl', outData);
			} else {
				mydataCommon.util.consoleOut(outData);
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		//카드상세 국내승인내역 XMC2103_Q03
		set_XMC2103_Q03 : function(data) {
			mydataCommon.util.consoleOut( data ,"카드상세 - 국내승인내역");
			
			var outData = data.XMC2103_Q03;
			
			if (outData && outData.resp_gubn =="0") {

				if(parseInt(outData.out_count)>0){
					ao_html('#dmstcBtnMoreWrap', outData);
					$.each(outData.g1, function(i, v) {
						ao_append('#dmstcCardTransInfo', v);			
					});	
				}else{
					$('#dmstcNoDataCmt').html('<p class="fc-gray">거래 내역이 없습니다.</p>');
					$('#dmstcNoDataCmt').show();
				}
			} else {
				$('#dmstcNoDataCmt').html('<p class="fc-gray">거래 내역이 없습니다.</p>');
				$('#dmstcNoDataCmt').show();
			}
		},
		//카드상세 해외승인내역 XMC2103_Q05
		set_XMC2103_Q05 : function(data) {
			mydataCommon.util.consoleOut( data ,"카드상세 - 해외승인내역");
			
			var outData = data.XMC2103_Q05;
			
			if (outData && outData.resp_gubn =="0") {
				if(parseInt(outData.out_count)>0){
					ao_html('#ovrBtnMoreWrap', outData);
					$.each(outData.g1, function(i, v) {
						ao_append('#ovrCardTransInfo', v);			
					});
				}else{
					$('#ovrNoDataCmt').html('<p class="fc-gray">거래 내역이 없습니다.</p>');
					$('#ovrNoDataCmt').show();
				}
			} else {
				$('#ovrNoDataCmt').html('<p class="fc-gray">거래 내역이 없습니다.</p>');
				$('#ovrNoDataCmt').show();
			}
		},
		goLoadData : function( cont_gubn, next_data , tp ) {

			//data set
			pageUnit.trn_param.cont_gubn = cont_gubn;
			
			if(tp=="1"){ //국내승인내역
				pageUnit.trn_param.next_page_base_val = next_data;
				
				//ajax call
				pageUnit.trn.ajax_call('getXMC2103_Q03').then(function(data) {
					
					mydataCommon.util.consoleOut( data ,"국내승인내역 추가 불러오기");
					pageUnit.fn.set_XMC2103_Q03(data);
					
				}).catch(function(e){
					console.error(e);
				});	
			}else if(tp=="2"){ //해외승인내역
				pageUnit.trn_param.next_page_out = next_data;
				
				//ajax call
				pageUnit.trn.ajax_call('getXMC2103_Q05').then(function(data) {
					
					mydataCommon.util.consoleOut( data ,"해외승인내역 추가 불러오기");
					pageUnit.fn.set_XMC2103_Q05(data);
					
				}).catch(function(e){
					console.error(e);
				});	
			}
		},
		goLoadCardTransInfo(trans_gb){
			var radio_trans_gb = trans_gb;
			mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt) {

				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = end_dt;
				pageUnit.trn_param.radio_trans_gb = radio_trans_gb;
				$('#dmstcCardTransInfo').empty();
				$('#ovrCardTransInfo').empty();
				$('#ovrNoDataCmt').empty();
				$('#dmstcNoDataCmt').empty();
				/*ajax call*/
				if(radio_trans_gb =="1"){		//국내승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q03');
					$('#trans_gb_001').show();
					$('#trans_gb_002').hide();
					

				}else{							//해외승인내역
					pageUnit.trn.ajax_call('getXMC2103_Q05');
					$('#trans_gb_002').show();
					$('#trans_gb_001').hide();
					
				}
			});	

		},
		set_section_search_error : function(data) {
			var outData = data.resultMap;
			mydataCommon.util.log([ 'Card001_0002.js :: set_section_search_error ----------> ',	data ]);
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		 
	}
};

// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
