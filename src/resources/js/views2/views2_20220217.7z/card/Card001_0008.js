var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VCard0010008View",
		v_storageKeyName : 'card',
		v_storageSubKeyName : ''
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		cont_gubn : '',
		next_data: '',
		card_id : '',
		myd_orgn_code :'',
		strt_dt : mydataCommon.util.getFirstDay(),
		end_dt : mydataCommon.util.getLastDay()
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				var param = mydataCommon.page.getSubParamData('VCard0010001View');
				
				/* ========= 카드 상세 -카드정보 조회 XMC2103_Q02 ========= */
				if (exeType == 'getXMC2103_Q02') {
					
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010002001Ajax",
							//cache : true,
							data : pageUnit.trn_param,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				} 
				/* ========= 카드상세 청구내역 조회 XMC2103_Q04 ========= */
				else if (exeType == 'getXMC2103_Q04') {
					
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010008Ajax",
							data :  pageUnit.trn_param,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				} 
			})
		},
	},
	// 단위 진입부 함수
	init : function(){
		var param = mydataCommon.page.getSubParamData('VCard0010001View');
//		pageUnit.trn_param.card_id = "60005309";
		
		pageUnit.trn_param.card_id = param.card_id; 
		pageUnit.trn_param.myd_orgn_code = param.myd_orgn_code;
		
		pageUnit.eventBind();
		
		pageUnit.trn.ajax_call('getXMC2103_Q02')
		.then(function(data){
			mydataCommon.util.consoleOut( data ,"카드 상세 -카드정보 조회");
			pageUnit.fn.set_XMC2103_Q02(data);

			return pageUnit.trn.ajax_call('getXMC2103_Q04');
		}).then(function(data){
			mydataCommon.util.consoleOut( data ,"카드상세 청구내역 조회");
			pageUnit.fn.set_XMC2103_Q04(data);
			KW_MOBILE.guiEvent.detailBox.init();
		}).catch(function(e){
			console.error(e);
		});
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(value){
		// 뒤로가기
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 카드 상세 - 카드정보 조회 XMC2103_Q02
		set_XMC2103_Q02 : function(data) {
			var outData = data.XMC2103_Q02;
			
			if (outData && outData.resp_gubn =="0") {
				
				//카드상세 상단 
				ao_html('#info', outData);
				
				//카드정보 탭 KIWMYD_CRD_001_0003
				ao_html('#cardInfoDtl', outData);
				
			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 카드 상세 - 청구내역 조회 XMC2103_Q04
		set_XMC2103_Q04 : function(data) {
			
			var outData = data.XMC2103_Q04;
			
			if (outData && outData.resp_gubn =="0") {
				
				ao_html('#moreViewList', outData);
				
				$.each(outData.g1, function(i, v){
					ao_append('#cardBillDtl', v);
				});
				
			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		set_section_search_error : function(data) {
			var outData = data.resultMap;
			mydataCommon.util.log([ 'Card001_0008.js :: set_section_search_error ----------> ',	data ]);
//			mydataCommon.msg.alert({msg : outData.resp_mesg});
		},
		goLoadData : function( cont_gubn, next_data ) {

			//data set
			pageUnit.trn_param.cont_gubn = cont_gubn;
			pageUnit.trn_param.next_data = next_data;
			
			//ajax call
			pageUnit.trn.ajax_call('getXMC2103_Q04').then(function(data) {
				
				mydataCommon.util.consoleOut( data ,"거래내역 추가 불러오기");
				pageUnit.fn.set_XMC2103_Q04(data);
				KW_MOBILE.guiEvent.detailBox.init();
			}).catch(function(e){
				console.error(e);
			});	

		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});

