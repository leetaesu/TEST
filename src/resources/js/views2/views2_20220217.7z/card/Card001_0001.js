var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		testMode : false,
		payPlanCnt : 0,
		isConnect : false,
		cust_nm : '',
		v_id : 'VCard0010001View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'card',
		v_storageSubKeyName : '',
		base_dt : mydataCommon.util.getStrDate(),
		
		next_key : '',
		cont_gubn : '',
		
		moreView_myCard : {
			next_key : '',
			cont_gubn : '',
		},
		moreView_lestMonthBill : {
			next_key : '',
			cont_gubn : '',
		},
		
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		card_id : '',
		myd_orgn_code : '',
//		alimi_seq : null,
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
				/* =========== 카드자산연결여부 조회 XMC2130_Q01 ========== */
				if (exeType == 'getXMC2130_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001002Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				} 
				/* ========= 카드 사용금액 합계 조회 XMC2101_Q01 ========= */
				else if(exeType == 'getXMC2101_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001003Ajax",
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* ========= 카드 사용 캘린더 조회 2102_Q01 ========= */
				else if(exeType == 'getXMC2102_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001004Ajax",
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* =========== 보유카드 목록 조회 XMC2103_Q01 ========== */
				else if(exeType == 'getXMC2103_Q01') {
					var param = pageUnit.prop.moreView_myCard;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001005Ajax",
							//cache : true,
							data : param,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* =========== 당월결제예정금액 조회 XMC2104_Q01 ========== */
				else if(exeType == 'getXMC2104_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001006Ajax",
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}		
					
					mydataCommon.ajax(jsonObj);	
				}
				/* =========== 지난달청구금액 조회 XMC2105_Q01 ========== */
				else if(exeType == 'getXMC2105_Q01') {
					var param = pageUnit.prop.lestMonthBill;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001007Ajax",
							data : param,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}		
					
					mydataCommon.ajax(jsonObj);	
				}
				/* =========== 리볼빙 조회 XMC2106_Q01 ========== */
				else if(exeType == 'getXMC2106_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001008Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* =========== 단기대출 조회 XMC2107_Q01 ========== */
				else if(exeType == 'getXMC2107_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001009Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* =========== 포인트 조회 XMC2108_Q01 ========== */
				else if(exeType == 'getXMC2108_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001010Ajax",
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}
					mydataCommon.ajax(jsonObj);
				}
				/* =========== 나의 카드현황 조회 XMC2002_Q01 ========== */
				else if(exeType == 'getXMC2109_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001011Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}		
					mydataCommon.ajax(jsonObj);		
				}	
				/* =========== 연령별 최다 이용카드 조회 XMC2110_Q01 ========== */
				else if(exeType == 'getXMC2110_Q01') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/card/SCard0010001013Ajax",
							//cache : true,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							}
					}		
					mydataCommon.ajax(jsonObj);	
				}
				/* =========== 화면 리로드 버튼 시작 XMC1001_U01 ========== */
				else if(exeType == 'getXMC1001_U01') {
					
					var jsonObj = {
							url : pageCom.prop.contextPath+ "/card/UCard00100010001Ajax",
//							async : false,
							success : res,
							error : function(data) {
								pageUnit.fn.set_section_search_error(data);
								res();
							},
							
						}
						mydataCommon.ajax(jsonObj);
				}
			});//promise end
		},
	},//trn end
	// 단위 진입부 함수
	init : function(){
		mydataCommon.util.removeAllData();
		pageUnit.eventBind();
		
		// 카드자산연결여부 조회
		pageUnit.trn.ajax_call('getXMC2130_Q01')
		.then(function(data){
			mydataCommon.util.consoleOut(data , "card/getJsonXMC2130_Q01 :카드자산연결여부 조회");
			pageUnit.fn.set_XMC2130_Q01(data);
		}).catch(function(e){
			console.error(e);
		});
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){			
		//툴팁 열기
		$(document).on("click", ".tooltip", function() {
			 $(this).next('.tooltip-box').addClass('is-open').after('<div class="dimmed"></div>');
             $('body').addClass('fixed');
		});
		
		//툴팁 닫기
		$(document).on("click", ".tooltip-close", function() {
			$('.tooltip-box').removeClass('is-open');
            $('.dimmed').remove();
            $('body').removeClass('fixed');
		});
		
		//모달 닫기
		$(document).on("click", "#modal-close", function() {
			KW_MOBILE.guiEvent.popup.closePop('#modal_popup');
		});
		
		//알림 연결
		$(document).on("click", "#cardInfo", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"CARD0102", callback:"callback_callMoveView",viewType:"full"});			
			
		});

		//캘린더 더보기
		$(document).on("click", "#calDtl", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"CARD01P03", callback:"callback_callMoveView",viewType:"full"});			
		});
		
		 //카드 혜택 추천 더보기(카드 웹뷰) - KCB 카드 추천 서비스(카드 웹뷰) 차후 연동 예정
		$(document).on("click", "#cardBnf, #cardBnf2", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"CARD0106", callback:"callback_callMoveView",viewType:"full"});
		});		
		
		// 카드 진단 서비스 더보기 - KCB 진단 서비스(카드 웹뷰) 차후 연동 예정
		$(document).on("click", "#cardSvc, #cardSvc2", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"CARD0107", callback:"callback_callMoveView",viewType:"full"});
		});
		
		// 자산 연결하기
		$(document).on("click", ".go-link", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"callback_callMoveView"});
		});

	},
	// 단위 전용 함수 모음 패키지
	fn : {
		//카드자산연결여부 조회
		set_XMC2130_Q01 : function(data) {
			
			var outData = data.XMC2130_Q01;
			if(outData && outData.resp_gubn == "0"){
				
				pageUnit.init.isConnect = outData.mycard_yn;					
				
				if(pageUnit.init.isConnect == "Y"){
					/*카드자산연결정보가 있을 경우 KIWMYD_CRD_001_0001*/
					$('#VCard0010000View').hide();
					$('#VCard0010001View').show();
					pageUnit.fn.allSearch();
					
					
				} else {
					/*카드자산연결정보가 없을 경우 KIWMYD_CRD_001_0000*/
					$('#VCard0010001View').hide();
					$('#VCard0010000View').show();
					
					pageUnit.trn.ajax_call('getXMC2001_Q06')
					.then(function(data){
						mydataCommon.util.consoleOut( data ,"/card/SCard0010001006Ajax: 연령별 최다 이용카드 조회");
						var outData = data.XMC2001_Q06;
						if(outData && outData.resp_gubn == "0"){
							
							if(!(parseInt(outData.out_count) > 0)) {
								
								$('#cardRankAge2').hide();
								return;
								
							} else {
								ao_html("#cardRankAge2",outData);
								$('#cardRankAge2').show();
							}
							
						} else {
							mydataCommon.msg.alert({msg : outData.resp_mesg});
						}
					}).catch(function(e){
						console.error(e);
					});
				}
			}else{
//					mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		//새로고침
		allSearch : function() {
			
			$('#useAmt').empty();
			$('#use7DaysAmt').empty();	
			
			$('#myCard').empty();
			$('#myCardList').empty();
			
			$('#payPlan').empty();
			$('#sumCard').empty();
			
			$('#chrg').empty();
			$('#chrgList').empty();
			
			$('#revo').empty();
			$('#revoList').empty();
			
			$('#shortLoan').empty();
			$('#shortLoanList').empty();
			
			$('#myPoint').empty();
			$('#myPointList').empty();

			$('#cardStatus').empty();
			
			$('#cardRank').empty();
			$('#cardRankAge').empty();

			var ajax_call = pageUnit.trn.ajax_call;
			
			ajax_call('getXMC2101_Q01')
			.then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2101_Q01: 카드 사용금액 합계 조회");
				pageUnit.fn.set_XMC2101_Q01(data);
				
				//알림내역셋팅
				pageCom.loadNoti.init('#notiPlace', "08", {isTest : true}); 
				return ajax_call('getXMC2102_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2102_Q01: 주간캘린더 카드 사용금액 합계 조회");
				pageUnit.fn.set_XMC2102_Q01(data);
				
				return ajax_call('getXMC2103_Q01');
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2103_Q01: 보유카드 목록 조회");
				pageUnit.fn.set_XMC2103_Q01(data);
				return ajax_call('getXMC2104_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2104_Q01: 당월 결제예정금액 조회");
				pageUnit.fn.set_XMC2104_Q01(data);
				return ajax_call('getXMC2105_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"card/getJsonXMC2105_Q01: 지난달 청구금액 조회");
				pageUnit.fn.set_XMC2105_Q01(data);
				return ajax_call('getXMC2106_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2106_Q01: 리볼빙 조회");
				pageUnit.fn.set_XMC2106_Q01(data);
				return ajax_call('getXMC2107_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/SCard0010001002003Ajax: 단기대출 조회");
				pageUnit.fn.set_XMC2107_Q01(data);
				return ajax_call('getXMC2108_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/SCard0010001010Ajax: 포인트 조회");
				pageUnit.fn.set_XMC2108_Q01(data);
				return ajax_call('getXMC2109_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/SCard0010001004Ajax: 나의 카드현황 조회");
				pageUnit.fn.set_XMC2109_Q01(data);
				$('#CardService').show();
				return ajax_call('getXMC2110_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data ,"/card/getJsonXMC2001_Q06: 연령별 최다 이용카드 조회");
				pageUnit.fn.set_XMC2110_Q01(data);
				
			}).catch(function(e){
				console.error(e);
			})
			
			
		},
		//카드 사용금액 합계
		set_XMC2101_Q01 : function(data) {
			
				var outData = data.XMC2101_Q01;
				if(outData && outData.resp_gubn == "0"){
					
					ao_html('#sectionUseAmt', outData);
					$('#sectionUseAmt').show();
				}else{
//					mydataCommon.msg.alert({msg : outData.resp_mesg});
				}
		},
		//주간캘린더 카드사용금액 합계 조회 XMC2102_Q01
		set_XMC2102_Q01 : function(data) {
			var outData = data.XMC2102_Q01;
			if(outData && outData.resp_gubn == "0"){
				ao_html('#weeklyUseAmt', outData);
				$('#sectionWeeklyUseAmt').show();

			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 보유카드 목록
		set_XMC2103_Q01 : function(data) {

			var outData = data.XMC2103_Q01;
			if(outData && outData.resp_gubn == "0"){
				
				var g1 = outData.g1;

				if(parseInt(outData.use_mm) < 10){
					outData.use_mm = parseInt(outData.use_mm);
				}
				
				outData.base_dt = mydataCommon.util.getStrDate();
				ao_html('#myCard', outData);
				ao_html('#moreViewRrn', outData);

				$.each(outData.g1, function(i, v) {
					var msg = v.err_msg;
					var errMsgArr = msg.split('. ');
					var arr = [];
					
					$.each(errMsgArr, function(i2, v2) {
						arr.push({'err_cmt': v2});
					});
					
					v.err_msg_arr = arr;
					ao_append('#myCardList', v);
				});
				
				$('#sectionMyCard').show();
			}else{
				mydataCommon.util.consoleOut( [] ,outData.resp_mesg+":: 보유카드");
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 당월 결제예정금액 
		set_XMC2104_Q01 : function(data) {
			
			var outData = data.XMC2104_Q01;
			if(outData && outData.resp_gubn == "0"){

				var base_dt = pageUnit.prop.base_dt,
					base_mm = parseInt(base_dt.substring(4,6));

				outData.base_mm = base_mm;
				ao_html('#payPlan', outData);					

				$.each(outData.g1, function(i, v) {
					var msg = v.err_msg;
					var errMsgArr = msg.split('. ');
					var arr = [];
					
					$.each(errMsgArr, function(i2, v2) {
						arr.push({'err_cmt': v2});
					});
					
					v.err_msg_arr = arr;
					ao_append('#sumCard', v);			
				});

				$('#sectionPayPlan').show();

			}else{
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 지날달 청구금액
		set_XMC2105_Q01 : function(data) {
			
			var outData = data.XMC2105_Q01;
			if(outData && outData.resp_gubn == "0"){
				
				if(parseInt(outData.out_count) > 0){
					
					ao_html('#chrg', outData);					
					ao_html('#moreViewBill', outData);
					
					$.each(outData.g1, function(i, v) {
						var msg = v.err_msg;
						var errMsgArr = msg.split('. ');
						var arr = [];
						
						$.each(errMsgArr, function(i2, v2) {
							arr.push({'err_cmt': v2});
						});
						
						v.err_msg_arr = arr;
						ao_append('#chrgList', v);			
					});

					$('#sectionBiledAmt').show();
					
				}else {
					
				}
				
				

			}else{
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 리볼빙
		set_XMC2106_Q01 : function(data) {

			var outData = data.XMC2106_Q01;
			if(outData && outData.resp_gubn == "0"){
	
			ao_html('#revo', outData);
			
			$.each(outData.g1, function(i, v) {
				var msg = v.err_msg;
				var errMsgArr = msg.split('. ');
				var arr = [];
				
				$.each(errMsgArr, function(i2, v2) {
					arr.push({'err_cmt': v2});
				});
				
				v.err_msg_arr = arr;
				ao_append('#revoList', v);
			});
			$('#sectionRevo').show();

			}else{
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
			
		},
		// 단기대출
		set_XMC2107_Q01 : function(data) {
			
			var outData = data.XMC2107_Q01;
			if(outData && outData.resp_gubn == "0"){
				
				ao_html('#shortLoan', outData);
				
				$.each(outData.g1, function(i, v) {
					var msg = v.err_msg;
					var errMsgArr = msg.split('. ');
					var arr = [];
					
					$.each(errMsgArr, function(i2, v2) {
						arr.push({'err_cmt': v2});
					});
					
					v.err_msg_arr = arr;
					ao_append('#shortLoanList', v);
				});
				
				$('#sectionLoan').show();

			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		// 보유포인트
		set_XMC2108_Q01 : function(data) {
			
			var outData = data.XMC2108_Q01;
			if(outData && outData.resp_gubn == "0"){
					
				ao_html('#myPoint', outData);
				
				$.each(outData.g1, function(i, v) {
					var msg = v.err_msg;
					var errMsgArr = msg.split('. ');
					var arr = [];
					
					$.each(errMsgArr, function(i2, v2) {
						arr.push({'err_cmt': v2});
					});
					
					v.err_msg_arr = arr;
					ao_append('#myPointList', v);
				});
				
				$('#sectionPoint').show();		
			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}

		},
		// 나의 카드현황 조회
		set_XMC2109_Q01 : function(data) {
			
				var outData = data.XMC2109_Q01;
				if(outData && outData.resp_gubn == "0"){
					var cmt = "",
						mmAmt = parseInt(outData.this_mm_amt),
						lastMmAmt = parseInt(outData.last_mm_amt);
					
					if( (mmAmt-lastMmAmt) < 0 ){
						cmt = "줄었어요.";
					} else{
						cmt = "늘었어요.";
					}
					
					outData.amt_diff_cmt = cmt;
					
					ao_html('#cardStatus', outData);
					 
					
					//나의 카드현황 컬럼차트 셋팅
					var color = ['#d1d6e8', '#6666cc'];
					var data = [{name : "전월", y: lastMmAmt, color: color[0], dataLabels: {color: color[0]}},
								{name : "당월", y: mmAmt, color: color[1], dataLabels: {color: color[1]}}];
					var labelFormat ='{point.y:,.0f}원';
					
					var directOptions = {
							userSetOptionAppend : true,
//							isViewLegend : false,
							title : false,
							credits : false,
							exporting : false,
							tooltip : false,
		                    yAxis: {
		                        min: 0,
		                        gridLineWidth: 1,
		                        visible: true,
		                    },
		                    legend: {
		                        enabled: false,
		                        reversed: true
		                    }
					};
					
					var chartObj = mydataCommon.design.chartColumn('chart-column',data,null,labelFormat,null,directOptions);
					
					$('#sectionCardStatus').show();
					 
				}else{
					mydataCommon.util.consoleOut( [] ,outData.resp_mesg+":: 나의 카드현황");
//					mydataCommon.msg.alert({msg : outData.resp_mesg});
				}
		},
		//연령별 최다 이용카드 XMC2110_Q01
		set_XMC2110_Q01 : function(data){
			
			var outData = data.XMC2110_Q01;
			if(outData && outData.resp_gubn == "0"){
				
				if(!(parseInt(outData.out_count) > 0)) {
					
					$('#cardRankAge').hide();
					return;
					
				} else {
					ao_html("#cardRankAge",outData);
					$('#cardRankAge').show();
				}
				
			} else {
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		//리로드
		set_XMC1001_U01 : function(data){

			var outData = data.XMC1001_U01;
			 if(outData.resp_gubn == "0"){
				 
				mydataCommon.msg.alert({msg : "연결된 자산 정보를 업데이트 하였습니다."});
				
			 }else{

//				 mydataCommon.msg.alert({msg : outData.resp_mesg});
				 ao_html('#reloadErrMsg', outData);
				 KW_MOBILE.guiEvent.popup.openPop('#modal_popup');
			 }
		},
		//알림삭제 Callback Function
		Callback_delNotiResult : function(resultMap){
			
			if (resultMap && resultMap.resp_gubn == "0") {
				//(처리내용) 알림 삭제
				//(파라미터)
				//alimiSeq		: 필수, 삭제할 알림 번호
				//alimiClsTp	: 필수, 메뉴별 코드 ('01', ~~)
				//baseDt		: 선택, 기본값 - 현재일자, "20210902", mydataCommon.util.getStrDate()
				//fnCallback	: 선택, 삭제 후 처리 함수, function(resultMap){}
				//(사용방법)
				//pageCom.delNoti(1,'03','20210101',function(resultMap){ 
				//	if (resultMap && resultMap.resp_gubn == "0") {
				//		//성공시 처리
				//	} else {
				//		//실패시 처리
				//	}
				//});
				
				//알림섹션 초기화
				$("#cardAlim").empty();
				$("#msg_cntnList").empty();
				//알림내역 다시 로드
				pageUnit.trn.getCard0010001007Ajax();
//				pageUnit.fn.goLoadData('cardAlim','','');
			} else {
				mydataCommon.msg.alert({msg : resultMap.resp_mesg});
			}
		},
		//상세화면 팝업
		popDetail : function(myd_orgn_code, card_id, gry_tp){

			var urlMapId = "";

			// 카드상세
			if(gry_tp =="1") {
				pageUnit.trn_param.card_id = card_id;
				pageUnit.trn_param.myd_orgn_code = myd_orgn_code;
				urlMapId = "CARD0102";
			}
			//당월결제 상세 -> 월카드캘린더 
			else if(gry_tp =="2") {
				urlMapId = "CARD01P03"
			}
			//청구금액 상세 
			else if(gry_tp =="3") {
				pageUnit.trn_param.card_id = card_id;
				pageUnit.trn_param.myd_orgn_code = myd_orgn_code;
				urlMapId = "CARD0108";
			}
			//리볼빙 상세
			else if(gry_tp =="4") {
				pageUnit.trn_param.myd_orgn_code = myd_orgn_code;
				urlMapId = "CARD0104"
					
			}//단기대출 상세
			else if(gry_tp =="5") {
				pageUnit.trn_param.myd_orgn_code = myd_orgn_code;
				urlMapId = "CARD0105"
					
			}//카드현황 페이지
			else if(gry_tp =="6") {
				urlMapId = "CARD01P01"
					
			}else if(gry_tp =="8") {}else {return;}
			
			mydataCommon.page.setSubParamData(pageUnit.trn_param,'VCard0010001View');
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:urlMapId, callback:"callback_callMoveView" ,viewType:"full"});
		},
		//새로고침 & 더보기
		goLoadData : function(el, loadType) {
			var $taget = $(el);
			var load_gubn = $taget.data('loadGubn');
			mydataCommon.util.consoleOut('pageUnit.fn.goLoadData > load_gubn='+load_gubn);
			var loadDataMap = {
					next_key : '',
					cont_gubn : '',
			};
			
			//loadType 별 ajax 호출
			switch (loadType) {
				case 'reload':  //새로고침
					
					pageUnit.trn.ajax_call('getXMC1001_U01')
					.then(function(data){
						mydataCommon.util.consoleOut(data , "reload");
						
						var outData = data.XMC1001_U01;
						outData.load_gubn = load_gubn;
						if( outData && outData.resp_gubn == "0" ){
							
							if (load_gubn == "update_all") { // --전체
								
								//전체 다시 조회
								mydataCommon.util.consoleOut( load_gubn ,"update_all");
								pageUnit.fn.allSearch();
								mydataCommon.msg.alert({msg : "연결된 자산 정보를 업데이트 하였습니다."});
								
							} else if (load_gubn == "myCard") {// --보유카드
								
								$('#myCard').empty();
								$('#myCardList').empty();
								
								//더보기 param 초기화
								pageUnit.prop.moreView_myCard = loadDataMap;
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2103_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"보유카드 목록 research");
									pageUnit.fn.set_XMC2103_Q01(data);
								});
								mydataCommon.msg.alert({msg : "보유카드 목록 정보를 업데이트 하였습니다."});
							} else if (load_gubn == "setlFrcs") {// --당월결제예정금액
								
								$('#payPlan').empty();
								$('#sumCard').empty();
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2104_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"당월결제예정금액 research");
									pageUnit.fn.set_XMC2104_Q01(data);
								});
								mydataCommon.msg.alert({msg : "당월 결제예정금액 목록 정보를 업데이트 하였습니다."});
							} else if (load_gubn == "lestMonthBill") {// --지난달청구금액
								$('#chrg').empty();
								$('#chrgList').empty();
								
								//더보기 param 초기화
								pageUnit.trn_param.lestMonthBill = param;
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2105_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"지난달청구금액 research");
									pageUnit.fn.set_XMC2105_Q01(data);
								});
								mydataCommon.msg.alert({msg : "지난달 청구금액 목록 정보를 업데이트 하였습니다."});
							} else if (load_gubn == "revo") {// --리볼빙
								
								$('#revo').empty();
								$('#revoList').empty();	
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2106_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"리볼빙 research");
									pageUnit.fn.set_XMC2106_Q01(data);
								});
								mydataCommon.msg.alert({msg : "리볼빙 목록 정보를 업데이트 하였습니다."});
							} else if (load_gubn == "shortLoan") {// --단기대출
								
								$('#shortLoan').empty();
								$('#shortLoanList').empty();	
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2107_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"단기대출 research");
									pageUnit.fn.set_XMC2107_Q01(data);
								});
								mydataCommon.msg.alert({msg : "단기대출 목록 정보를 업데이트 하였습니다."});
							} else if (load_gubn == "point") {// --포인트
								
								$('#shortLoan').empty();
								$('#shortLoanList').empty();	
								
								//ajax_call
								pageUnit.trn.ajax_call('getXMC2108_Q01')
								.then(function(data){
									mydataCommon.util.consoleOut( data ,"포인트 research");
									pageUnit.fn.set_XMC2108_Q01(data);
								});
								mydataCommon.msg.alert({msg : "보유 포인트 목록 정보를 업데이트 하였습니다."});
							}else{
//								mydataCommon.util.consoleOut();
//								mydataCommon.util.log([ 'Card001_0001.js ajax_call(getXMC1001_U01) :: reload_error ----------> ',	outData ]);
							}
						} else {
							
//							(공통) 서비스 I/O오류시 팝업 KIWMYD_BNK_001_0001_P002 메인 리프레시 버튼과 연계 (차후 개발)
							 ao_html('#reloadErrMsg', outData);
							 KW_MOBILE.guiEvent.popup.openPop('#modal_popup');
						}
	
					}).catch(function(e){
						console.error(e);
						
						//(공통) 서비스 I/O오류 팝업
						 ao_html('#reloadErrMsg', outData);
						 KW_MOBILE.guiEvent.popup.openPop('#modal_popup');					
					}); // ajax_call getXMC1001_U01 end
					
					break;
					
				case 'moreView':  //더보기 검색
					loadDataMap.next_key = $taget.data('nextKey');
					loadDataMap.cont_gubn = $taget.data('contGubn');
					mydataCommon.util.consoleOut(loadDataMap);
					 
					if (load_gubn == "myCard") { //보유카드
						
						pageUnit.prop.moreView_myCard = loadDataMap;
						
						//ajax call
						pageUnit.trn.ajax_call('getXMC2103_Q01')
						.then(function(data) {
							mydataCommon.util.consoleOut( data ,"보유카드 :: 등록된 더 많은 카드 불러오기");
							pageUnit.fn.set_XMC2103_Q01(data);
						}).catch(function(e){
							console.error(e);
						});	
						
					} else if (load_gubn == "lestMonthBill") { //지난달청구금액
					
						pageUnit.prop.lestMonthBill = loadDataMap;
						
						//ajax call
						pageUnit.trn.ajax_call('getXMC2105_Q01')
						.then(function(data) {
							mydataCommon.util.consoleOut( data ,"청구내역 :: 등록된 더 많은 카드 불러오기");
							pageUnit.fn.set_XMC2105_Q01(data);
						}).catch(function(e){
							console.error(e);
						});	
					} else { }
					
					break;
			}//switch end
		},
		set_section_reload_error : function(data) {
			var outData = data.resultMap;
			mydataCommon.util.log([ 'Card001_0001.js :: set_section_reload_error ----------> ',	data ]);
		},
		set_section_search_error : function(data) {
			var outData = data.resultMap;
			mydataCommon.util.log([ 'Card001_0001.js :: set_section_search_error ----------> ',	data ]);
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
});


