var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		detailTableIdx : 0,
		v_id : 'VCard0010004View',
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'card',
		v_storageSubKeyName : '',
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		card_id : '',
		myd_orgn_code : '',
		
		cont_gubn : '',
		next_data : '',
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getXMC2106_Q02 : function(){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/card/SCard0010004Ajax",
					data : pageUnit.trn_param,
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.XMC2106_Q02;
						mydataCommon.util.consoleOut(res,"리볼빙 상세");
						mydataCommon.util.consoleOut(resultMap);
						
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#output").text(JSON.stringify(resultMap));
							pageUnit.fn.set_XMC2106_Q02(resultMap);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		} 
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		
		var param = mydataCommon.page.getSubParamData('VCard0010001View');
		pageUnit.trn_param = param;
		
		pageUnit.trn.getXMC2106_Q02();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		// 뒤로가기
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
//			document.location.href = pageCom.prop.contextPath+"/card/VCard0010001View";
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_XMC2106_Q02 : function(result) {
			var g1 = result.g1;
			ao_html('#revo', result);
			
			for(var i=0; i<g1.length; i++){
				++pageUnit.prop.detailTableIdx;
				g1[i].rqst_dt = mydataCommon.util.getStrDate(g1[i].rqst_dt);
				ao_append("#revoDtl" , g1[i]);
			}
		},
		goLoadData : function(cont_gubn, next_data){
			pageUnit.trn_param.cont_gubn = cont_gubn;
			pageUnit.trn_param.next_data = next_data;
			pageUnit.trn.getXMC2106_Q02();
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : { 
	}
};

// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});

