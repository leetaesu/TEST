'use strict';

var pageUnit = {
	prop : {
		// 자산연결 여부
		insu_yn : '',
				
		realName 	: '',
		customNo 	: '',

		//local 개발구분
		profiles : '',
	}, 
	init : function() {
		var pf	= pageUnit.fn;
		var my	= mydataCommon;
    	
		pageUnit.prop.profiles = location.href.indexOf('local') > -1 ? 'local':'prod';
		
		// 프로퍼티 설정
		pageUnit.prop.insu_yn 			= $('#insu_yn').val();
		pageUnit.prop.realName 			= $('#realName').val();
		pageUnit.prop.customNo 			= $('#customNo').val();
		
		
		pageUnit.eventBind(my, pf);
		pageUnit.onLoad(my, pf);
	},
	onLoad : function(my, pf) {
		$('.real_name').text(pageUnit.prop.realName);
	}, 
	eventBind : function(my, pf) {	
		// 자산연결 링크
		$('.btn-header.icon-connect,.btn-plus.mt10,.btn-module.icon-add').off('click').on('click', function() {
			my.appBridge.webviewReq({command:'callMoveView', urlMapId:'AUTH0101', callback:'', viewType:''});
		});
		// 무료 보험 전문가 채팅 상담 버튼
		$('#insu_chat').off('click').on('click', function() {
			var inTime 	= '키움에셋플래너 보험 전문가와 상담하기 위해<br />채팅상담 페이지로 이동하시겠습니까?';
			var outTime = '키움에셋플래너 보험 전문가에게 편하게 상담 신청하세요.<br />고객님 입장에서 보험을 점검해 드려요.';
			var alert	= '';
			var nowHours = new Date().getHours();
			var weekNum	 = new Date(mydataCommon.util.getStrDate().format('####-##-##')).getDay(); 
			if(nowHours >= 9 && nowHours < 20) {
				alert = weekNum === 0 || weekNum === 6 ? outTime:inTime;
			} else {
				alert = outTime;
			}
			$('#chat_pop_content').html(alert);
			KW_MOBILE.guiEvent.popup.openPop('#chat_pop');
		});
		// 무료 보험 전문가 채팅 상담 취소 버튼
		$('#chat_pop_cancel').off('click').on('click', function() {
			KW_MOBILE.guiEvent.popup.closePop('#chat_pop');
		});
		// 무료 보험 전문가 채팅 상담 확인 버튼
		$('#chat_pop_ok').off('click').on('click', function() {
			var inTime		= 'https://www.moneykiwoom.com';
			var outTime 	= 'https://consult.kiwoomap.com/channel/kiwoominsu';
			var targetUrl 	= '';
			var nowHours = new Date().getHours();
			var weekNum	 = new Date(mydataCommon.util.getStrDate().format('####-##-##')).getDay(); 
			if(nowHours >= 9 && nowHours < 20) {
				targetUrl = weekNum === 0 || weekNum === 6 ? outTime:inTime;
			} else {
				targetUrl = outTime;
			}
			KW_MOBILE.guiEvent.popup.closePop('#chat_pop');
			$('#frm').attr({'target':'_blank','action':targetUrl}).submit();
		});
		// 실손보험 링크
		$('#silson1,#silson2,#silson3,#silson4,#silson5,#silson6').off('click').on('click', function() {
			var objUrl = {
				'local':{
					'silson1':'https://silson82t.com?c=kw&pg=gnnetFAQ',
					'silson2':'https://silson82t.com/silson?c=kw',
					'silson3':'https://silson82t.com/denti?c=kw',
					'silson4':'https://silson82t.com/picture?c=kw',
					'silson5':'https://silson82t.com?c=kw&pg=myPage',
					'silson6':'tel:15881709',
					},
				'prod':{
					'silson1':'https://silson82.com?c=kw&pg=gnnetFAQ',
					'silson2':'https://silson82.com/silson?c=kw',
					'silson3':'https://silson82.com/denti?c=kw',
					'silson4':'https://silson82.com/picture?c=kw',
					'silson5':'https://silson82.com?c=kw&pg=myPage',
					'silson6':'tel:15881709',
				}
			};
			var targetId 			= $(this).attr('id');
			document.location.href 	= objUrl[pageUnit.prop.profiles][targetId];
		});
	},
	fn : {
		
	},
};
$(document).ready(function(){
	pageUnit.init();
});