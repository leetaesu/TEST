'use strict';

var pageUnit = {
	prop : {
		// 기관코드
		orgn_code 		: '',
		// 보험계약번호
		insr_cntr_no 	: '',
		// 보험종류구분
		insr_cls_tp		: '',
		// 정보조회 공통 파라미터 
		commonParam 	: {},
		// 납입내역 파라미터
		listParam 		: {},
		// 더보기 카운터
		moreButCount	: 0,
		//더 보기 버튼 시 url
		moreButUrl		: '',	
		
		// localstorage key
		v_storageKeyName 	: 'insu',
		v_storageSubKeyName : 'VIns0010002View',
	},
	init : function() {
		var pf	= pageUnit.fn;
		var my	= mydataCommon;
		
		var params 					= my.page.getSubParamData();
		pageUnit.prop.orgn_code 	= params.orgn_code;
		pageUnit.prop.insr_cntr_no 	= params.insr_cntr_no;
		pageUnit.prop.insr_cls_tp 	= params.insr_cls_tp;
		pageUnit.prop.commonParam 	= {'orgn_code':pageUnit.prop.orgn_code, 'insr_cntr_no':pageUnit.prop.insr_cntr_no};
		
		pageUnit.prop.moreButCount	= 0;
		
		pageUnit.eventBind(my, pf);
		pageUnit.onLoad(my, pf);
	},
	onLoad : function(my, pf) {
		if(pageUnit.prop.insr_cls_tp === '07') {
			$('#sub-title').text('보증보험 상세');
			$('#tab_01').text('거래정보');
			// 보증보험 상세 정보 조회(최상단) XMR4003_Q01
			my.ajax2("/insu/GetXmr4003Q01Ajax", pageUnit.prop.commonParam, pf.setXmr4003Q01);
			// 보증보험 상품 정보 조회(상품정보탭) XMR4002_Q02
			my.ajax2("/insu/GetXmr4002Q02Ajax", pageUnit.prop.commonParam, pf.setXmr4002Q02);
			// 보증보험 납입내역 조회(납입내역탭) XMR4004_U01(카렌다 ui)
			my.calendar2.init('#month_cal', function (strt_dt, end_dt, clickIndex) {
				console.warn(strt_dt+' : '+end_dt+ ' : '+ clickIndex);
				pageUnit.prop.listParam		= {'strt_dt':strt_dt, 'end_dt':end_dt};
				pageUnit.prop.moreButCount	= 0;	//더 보기 카운터 초기화
				$.extend(pageUnit.prop.listParam, pageUnit.prop.commonParam);
				
				my.ajax2('/insu/GetXmr4004U01Ajax', pageUnit.prop.listParam, pf.setXmr4004U01);
			});
		} else {
			// 보험 상세 정보 조회(공통 최상단)XMR3061_Q01
			my.ajax2("/insu/SIns0010002001Ajax", pageUnit.prop.commonParam, pf.setIns0010002001);
			// 보험 상품 정보 조회(상품정보탭) XMR3062_Q01
			my.ajax2("/insu/SIns0010002002Ajax", pageUnit.prop.commonParam, pf.setIns0010002002);
			// 보험 납입내역 조회(납입내역탭) XMR3064_Q01,XMR3064_U02(카렌다 ui)
			my.calendar2.init('#month_cal', function (strt_dt, end_dt, clickIndex) {
				console.warn(strt_dt+' : '+end_dt+ ' : '+ clickIndex);
				var url			= '';
				var callbackFn	= function() {};
				
				var clickIndexAllow = [0,1,2,3];	// 1개월, 3개월, 6개월, 12개월
				if(clickIndex in clickIndexAllow) {
					// 일년내
					url 					= '/insu/SIns0010003Ajax';
					pageUnit.prop.listParam	= {'qry_strt_dt':strt_dt, 'qry_end_dt':end_dt};
					callbackFn				= pf.setIns0010002003;
				} else {
					// 일년전
					url 					= '/insu/GetXmr3064U02Ajax';
					pageUnit.prop.listParam	= {'qry_base_yymm':strt_dt.substr(0, 6)};
					callbackFn				= pf.setXmr3064U02;
				}
				pageUnit.prop.moreButUrl	= url;	//더 보기 버튼 시 url
				pageUnit.prop.moreButCount	= 0;	//더 보기 카운터 초기화
				$.extend(pageUnit.prop.listParam, pageUnit.prop.commonParam);
				my.ajax2(url, pageUnit.prop.listParam, callbackFn);
			});
		}
		
	},
	eventBind : function(my, pf) {	
		// 이전
		$('.sub-prev').off('click').on('click', function(){
			my.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		// 납입내역 더 보기 버튼
		$('#more_but').off('click').on('click', function(){
			var next_data_param 		= {};
			var url 					= '';
			var callbackFn 				= function(){};
			next_data_param.cont_gubn 	= 'Y';	// 다음조회 여부
			
			if(pageUnit.prop.insr_cls_tp === '07') {
				next_data_param.next_data 	= $(this).attr('data-next_data');
				url 						= '/insu/GetXmr4004U01Ajax';
				callbackFn 					= pf.setXmr4004U01;
			} else {
				if(pageUnit.prop.moreButUrl === '/insu/GetXmr3064U02Ajax') {
					// 일년전
					next_data_param.next_page_val 	= $(this).attr('data-next_page_val');
					url 							= '/insu/GetXmr3064U02Ajax';
					callbackFn						= pf.setXmr3064U02;
				} else {
					// 일년내
					next_data_param.next_data 	= $(this).attr('data-next_data');
					url 						= '/insu/SIns0010003Ajax';
					callbackFn 					= pf.setIns0010002003;
				}
			}
			pageUnit.prop.moreButCount++;	// 더보기 카운터를 증가시킴
			$.extend(next_data_param, pageUnit.prop.listParam);
			my.ajax2(url, next_data_param, callbackFn);
		});
		// 피보험자 셀렉트박스 호출
		my.util.eBind('change', '.custom-select.piboheomja .fw-b', function(e, obj) {
			pf.getXmr3063Q03($(obj).val(), my);
		});
	},
	fn : {
		// 보험 상세 정보 조회(공통상단)XMR3061_Q01
		setIns0010002001 : function(result, param, my) {
			if(result.resp_gubn == '1') {
				my.msg.alert({msg : result.resp_mesg});
				return false;
			}
			result.pdin_dd1 = "납입주기 : <span class='fc-primary-dark'>매월 " + (function() {
								return result.pdin_dd === '99' ? '말일</span>':result.pdin_dd + "일</span>"})();
			result.org_nm	= '';
			result.gds_nm	= '<h4>'+ result.gds_nm + '</h4>';
			if(result.crnc_code === 'KRW') {
				result.pdin_insr_amt = my.util.getPrice(result.pdin_insr_amt);
				result.crnc_code 	 = '원';
			} else {
				result.pdin_insr_amt = my.util.getPrice(result.pdin_insr_amt, 2);
			}
			ao_html('#content_header', result);
		},
		// 보험 상품 정보 조회(상품정보탭)XMR3062_Q01
		setIns0010002002 : function(result, param, my) {
			if(result.resp_gubn == '1') {
				my.msg.alert({msg : result.resp_mesg});
				$('#piboheomja_box').hide();
				return false;
			}
			result.cntct_dt = my.util.getStrDate(result.cntct_dt); 	//계약일자
			result.expr_dt 	= my.util.getStrDate(result.expr_dt);	//만기일자
			result.pdin_dd 	= '매월' + (result.pdin_dd === '99' ? '말':result.pdin_dd) + '일';
			// 변액보험여부
			result.insr_kind_tp = result.univ_yn === 'Y' ? '변액':'';
			// 유니버셜여부
			result.insr_kind_tp += result.vrin_yn == 'Y' ? '유니버셜':'';
			
			var cntr_stat_code = {"02":"정상", "03":"실효", "04":"만기"};
			result.cntr_stat_tp = cntr_stat_code[result.cntr_stat_tp];
			ao_append('#content_body', 'content_body1_tmpl', result);
			
			if(Number(result.qry_cnt) > 0) {
				if(Number(result.qry_cnt) > 1) {	// 피보험자 셀렉트박스
					$('.fw-b.piboheomja').hide();
					$.each(result.g1, function(i, row) {
						$('.custom-select.piboheomja .fw-b').append($('<option></option>')
														.attr('value', row.insr_cntrr_no)
														.text(row.insr_cntrr_nm)
						);
					});
				} else {							// 피보험자 span태그
					$('.fw-b.piboheomja').text(result.g1[0].insr_cntrr_nm);
					$('.custom-select.piboheomja').hide();
				}
				// 피보험자[0] 특약호출
				pageUnit.fn.getXmr3063Q03(result.g1[0].insr_cntrr_no, my);
			} else {
				$('#piboheomja_box').hide();
			}
		},
		// 피보험자별 보험  특약정보 조회(상품정보) XMR3063_Q03
		getXmr3063Q03 : function(insr_cntrr_no, my) {
			var param = {
					orgn_code 		: pageUnit.prop.orgn_code,
					insr_cntr_no	: pageUnit.prop.insr_cntr_no,
					insr_cntrr_no	: insr_cntrr_no					// 피보험자 순번
			};
			my.ajax2("/insu/SIns0010002003Ajax", param, function(result) {
				if(result.resp_gubn == "1") {
					my.msg.alert({msg : '특약 '+result.resp_mesg});
					$('#content_teugyak').hide();
					return false;
				}
				$.each(result.g1, function(i, row) {
					if(row.crnc_code === 'KRW') {
						row.spag_join_amt 	=  my.util.getPrice(row.spag_join_amt);
						row.crnc_code 		= '원';
					} else {
						row.spag_join_amt =  my.util.getPrice(row.spag_join_amt, 2);
					}
					row.expr_dt = my.util.getStrDate(row.expr_dt);
				});
				ao_html('#content_teugyak', result);
			});
		},
		// 보험 납입내역 조회(납입내역탭) XMR3064_Q01
		setIns0010002003 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				my.msg.alert({msg : '납입'+result.resp_mesg});
				$('.btn-wrap.footer').hide();
				return false;
			}
			$.each(result.g1, function(i, row) {
				if(row.crnc_code === 'KRW') {
					row.real_pdin_insr_amt 	=  my.util.getPrice(row.real_pdin_insr_amt);
					row.crnc_display1 		= 'none';
					row.crnc_display2 		= 'block';
				} else {
					row.real_pdin_insr_amt = my.util.getPrice(row.real_pdin_insr_amt, 2);
					row.crnc_display1 		= 'block';
					row.crnc_display2 		= 'none';
				}
				row.pdin_dt = row.pdin_dt.format('####.##.##');
			});
			if(pageUnit.prop.moreButCount > 0) {
				ao_append('#content_list', result.g1);
			} else {
				ao_html('#content_list', result.g1);
			}
			pageUnit.prop.moreButCount++;
			
			// 더보기 버튼 보임/숨김 처리
			if(result.next_data) {
				$('#more_but').attr({
        			'data-next_data' 	: result.next_data,
        		});
				$('.btn-wrap.footer').show();
			} else {
				$('.btn-wrap.footer').hide();
			}
		},
		// 보험 납입내역 조회(납입내역탭) XMR3064_U02:검색일년전 :원장에 따른 next_page_val
		setXmr3064U02 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				my.msg.alert({msg : '납입'+result.resp_mesg});
				$('.btn-wrap.footer').hide();
				return false;
			}
			$.each(result.g1, function(i, row) {
				if(row.crnc_code === 'KRW') {
					row.real_pdin_insr_amt 	=  my.util.getPrice(row.real_pdin_insr_amt);
					row.crnc_display1 		= 'none';
					row.crnc_display2 		= 'block';
				} else {
					row.real_pdin_insr_amt = my.util.getPrice(row.real_pdin_insr_amt, 2);
					row.crnc_display1 		= 'block';
					row.crnc_display2 		= 'none';
				}
				row.pdin_dt = row.pdin_dt.format('####.##.##');
			});
			if(pageUnit.prop.moreButCount > 0) {
				ao_append('#content_list', result.g1);
			} else {
				ao_html('#content_list', result.g1);
			}
			pageUnit.prop.moreButCount++;
			
			// 더보기 버튼 보임/숨김 처리
			if(result.next_page_val) {
				$('#more_but').attr({
        			'data-next_page_val' : result.next_page_val,
        		});
				$('.btn-wrap.footer').show();
			} else {
				$('.btn-wrap.footer').hide();
			}
		},
		
		// 보험 상세 정보 조회(공통상단)XMR3061_Q01
		setXmr4003Q01 : function(result, param, my) {
			if(result.resp_gubn == '1') {
				my.msg.alert({msg : result.resp_mesg});
				return false;
			}
			result.pdin_dd1 		= "납입주기 : <span class='fc-primary-dark'>"+result.grin_pdin_term_nm+'</span>';
			result.orgn_nm			= '<h3>'+ result.orgn_nm + '</h3>';
			result.gds_nm			= '<h4>'+ result.gds_nm + '</h4>';
			result.pdin_insr_amt 	= my.util.getPrice(result.pdin_infe_sum);
			result.crnc_code 	 	= '원';
			ao_html('#content_header', result);
		},
		
		// 보증보험 상품 정보 조회(상품정보탭) XMR4002_Q02
		setXmr4002Q02 : function(result, param, my) {
			if(result.resp_gubn == '1') {
				$('#piboheomja_box').hide();
				return false;
			}
			$('#piboheomja_box').hide();										// 공통 피보험자특약 부분 감춤
			result.cntct_dt 		= my.util.getStrDate(result.cntct_dt); 		// 계약체결일자
			result.cntr_end_dt 		= my.util.getStrDate(result.cntr_end_dt);	// 계약종료일자
			result.insr_join_amt 	= my.util.getPrice(result.insr_join_amt);
			result.tot_pdin_infe 	= my.util.getPrice(result.tot_pdin_infe);
		
			$.each(result.g1, function(i, row) {
				if(i === 0) {
					result.insu_nms = row.insu_nm;
				} else {
					result.insu_nms += ',' +row.insu_nm;
				}
			});
			ao_append('#content_body', 'content_body2_tmpl', result);
		},
		
		// 보증보험 납입내역 조회(납입내역탭) XMR4004_U01
		setXmr4004U01 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				my.msg.alert({msg : '납입'+result.resp_mesg});
				$('.btn-wrap.footer').hide();
				return false;
			}
			$.each(result.g1, function(i, row) {
				row.real_pdin_insr_amt 	=  my.util.getPrice(row.real_pdin_infe);
				row.crnc_display1 		= 'none';
				row.crnc_display2 		= 'block';
				row.pay_way_nm			= row.grin_pdin_way_nm;
				row.pdin_dt				= row.pdin_dt.format('####.##.##');
			});
			if(pageUnit.prop.moreButCount > 0) {
				ao_append('#content_list', result.g1);
			} else {
				ao_html('#content_list', result.g1);
			}
			pageUnit.prop.moreButCount++;
			
			// 더보기 버튼 보임/숨김 처리
			if(result.next_data) {
				$('#more_but').attr({
        			'data-next_data' : result.next_data
        		});
				$('.btn-wrap.footer').show();
			} else {
				$('.btn-wrap.footer').hide();
			}
		},
		
	},
};
$(document).ready(function(){
	pageUnit.init();
});
