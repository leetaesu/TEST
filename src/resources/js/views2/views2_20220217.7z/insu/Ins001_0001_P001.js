'use strict';

var pageUnit = {
	prop : {
		// localstorage key
		v_storageKeyName 	: 'insu',
		v_storageSubKeyName : 'VIns0010001P001Pop',
	},
	init : function(){
		var my = mydataCommon;
		var pf = pageUnit.fn;
		
		// Highcharts Default options
		Highcharts.setOptions(KW_MOBILE.highcharts.general);
		
		pageUnit.eventBind(my);
		pageUnit.onLoad(my, pf);
	},
	onLoad : function(my, pf) {
		// 보험 비중별 조회(차트 및 그리드) XMR3041_Q01
		my.ajax2('/insu/GetXmr3041Q01Ajax', '', pf.setXmr3041Q01);
		// 보험료 납부현황 조회 XMR3042_Q01
		my.ajax2('/insu/GetXmr3042Q01Ajax', '', pf.setXmr3042Q01);
	},
	eventBind : function(my){
		// 닫기
		$('.sub-close,.btn-footer.navy').off('click').on('click', function(){
			my.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
	},
	fn : {
		// 보험 비중별 조회 : 차트 및 그리드 XMR3041_Q01
		setXmr3041Q01 : function(result, param, my) {
			if(result.resp_gubn == "1"){
				return false;
			}
			$('#insr_amt_m_sum').text(my.util.getPrice(result.insr_amt_m_sum));
			var chartData = {
					id   : 'my_insu_chart',
					data : [] 
			};
			var colors 		= ['#fe74a2','#ff9933','#66ccff','#6666cc','#66cccc','#fe74a2','#ff9933','#66ccff'];
			var listColors	= ['pink','tangerine','sky','violet','green','pink','tangerine','sky'];
			var lastIndex 	= Object.keys(result.g1).length;
			
			$.each(result.g1, function(i, row) {
				chartData.data.push({
					name 	: row.insr_kind_nm,
					data 	: [Number(row.insr_amt_m_per)],
					color 	: colors[i],
					index 	: lastIndex--
				});
				row.list_color  = listColors[i];
				row.insr_amt_m 	= my.util.getPrice(row.insr_amt_m);
			});
			ao_html('#my_insu_chart_subject', result.g1);
			ao_html('#my_insu_list', result.g1);
			
			pageUnit.design.chartXmr3041Q01(chartData);
		},
		
		// 보험 납부현황 조회 XMR3042_Q01
		setXmr3042Q01 : function(result) {
			if(result.resp_gubn == "1"){
				$('#my_insu_list2').hide();
				return false;
			}			
			$.each(result.g1, function(i, row) {
				row.pdin_sqnc_text 	= row.pdin_rate == '100' ?
						"<span class='fw-b'>완료</span>":"<span class='fw-b'> "+row.pdin_sqnc+"</span>회";
			});
			ao_append('#my_insu_list2', result.g1);
		}
	},
	design : {
		// 보험 상품 구성 현황
		chartXmr3041Q01 : function(chartData) {
	        var chartStack = new Highcharts.Chart(chartData.id, Highcharts.merge (
	            KW_MOBILE.highcharts.types.stackedBar,
	            {
	                chart: {
	                    height: 150
	                },
	                xAxis: {
	                    enable: false,
	                    visible: false
	                },
	                yAxis: {
	                    labels:{ formatter: function() {return this.value+'%';} }
	                },
	                plotOptions: {
	                    column: {
	                        pointWidth: 40
	                    },
	                    series: {
	                        pointPadding: 0.8,
	                        groupPadding: 0.8
	                    }
	                },
	                series: chartData.data,
	                legend: {
	                    enabled: false,
	                    reversed: true
	                }
	            }
	        ));
		}
	},
};
$(document).ready(function() {
	pageUnit.init();
});
