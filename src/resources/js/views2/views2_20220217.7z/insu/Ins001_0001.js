'use strict';

var pageUnit = {
	prop : {
		// 자산연결 여부
		insu_yn : '',
		
		// 월보험료 조회용
		insu_category : null,
		
		// 화면갱신여부 스와이프 실행횟수
		swiper1ExeNum : 0,
		swiper2ExeNum : 0,
		
		realName 	: '',
		customNo 	: '',
		
		insr_category : null,
		
		// 상품유형별 탭 카운터 
		insr_tp_count : {},
		// 보험사별 탭 카운터
		company_count : {},
		// 병원이용내역 카운터
		carduse_count : 0,
		// local 개발구분
		profiles : '',
		
		// localstorage key
		v_storageKeyName : 'insu',
	}, 
	init : function() {
		var pf	= pageUnit.fn;
		var my	= mydataCommon;
    	
		pageUnit.prop.profiles 			= location.href.indexOf('local') > -1 ? 'local':'prod';
		
		// 프로퍼티 설정
		pageUnit.prop.insu_yn 			= $('#insu_yn').val();
		pageUnit.prop.realName 			= $('#realName').val();
		pageUnit.prop.customNo 			= $('#customNo').val();
		pageUnit.prop.insr_tp_count 	= {'01':0,'02':0,'03':0,'04':0,'05':0,'06':0,'07':0};
		pageUnit.prop.company_count		= {};
		pageUnit.prop.insu_category 	= {
			'01':'보장성보험','02':'저축성보험','03':'자동차보험','04':'실효보험','05':'만기보험','06':'소멸보험','07':'보증보험'
		};
		pageUnit.prop.carduse_count		= 0;
		
		// 보험 종류 카테고리
		var objInsu = $.parseJSON($('#insr_category').val());
		pageUnit.prop.insr_category = new Map();
		$.each(objInsu, function(i, row){
			pageUnit.prop.insr_category.put(row.insr_kind_tp, row.insr_cls_tp);
		});
		
		// Highcharts Default options
        Highcharts.setOptions(KW_MOBILE.highcharts.general);
        
        loa.fn.onLogCollapsed();
		
		pageUnit.eventBind(my, pf);
		pageUnit.onLoad(my, pf);
	},
	onLoad : function(my, pf) {
		var todayYmd = my.util.getStrDate();
		
		// 최상단 최종기준일자,월보험료,건수 조회 XMR1010_Q01
    	my.ajax2('/insu/GetXmr1010q01Ajax', '', function(result) {
			$('#real_name').text(pageUnit.prop.realName);
			$('#insr_amt_m').text(my.util.getPrice(result.insr_amt_m));
			$('#insr_cnt_m').text(result.insr_cnt_m);
			$('#last_base_dt').text(result.last_base_dt);
    	});
    	
    	// 공통 알림
    	pageCom.loadNoti.init('#notiPlace', '05');
		
    	// 탭1 상품유형별 (보장성보험,저축성보험,자동차보험,실효보험,만기보험,소멸보험) - 보험분류별 월 보험료 조회 XMR1021_Q01
		$.each(pageUnit.prop.insu_category, function(key, value) {
			if(key === '07') {
				// 상품유형별 탭1 보증보험 xmr4001_Q01
				my.ajax2('/insu/GetXmr4001Q01Ajax', '', pf.setXmr4001Q01);
			} else {
				my.ajax2('/insu/GetXmr1021Q01Ajax', {'insr_cls_tp':key}, pf.setXmr1021q01);
			}
		});
		
		// 탭2 보험사별  - 보험사리스트조회 XMR3051_Q01
		my.ajax2('/insu/GetXmr3051Q01Ajax', '', function(result) {
			if(result && result.resp_gubn == "0") {
				$.each(result.g1, function(i, row) {
					// 보험사별 가입내역 조회 XMR3051_Q02
					pageUnit.prop.company_count[row.myd_orgn_code] = 0;	// 보험사별 카운터
					my.ajax2('/insu/GetXmr3051Q02Ajax', {'myd_orgn_code':row.myd_orgn_code}, pf.setXmr3051q02);
				});
			} 
		});
		
		// 병원/약국 이용 내역 확인(카드)-진료 이용내역 합계 조회 XMR2031_Q01
		my.ajax2('/insu/SIns0010001012Ajax', '', pf.setIns0010001012);
		
		// 납입안내  XMR3071_Q01
		my.ajax2('/insu/SIns0010001008Ajax', {'dt':todayYmd}, pf.setIns0010001008);
		
		// 만기안내  XMR3071_Q02
		my.ajax2('/insu/SIns0010001009Ajax', {'dt':todayYmd}, pf.setIns0010001009);
		
		// 연령별 보험 평균 보장 내역  XMR1031_Q02 
		my.ajax2('/insu/SIns0010001006Ajax', '', pf.setIns0010001006);
		
		// 보험 현황  XMR2004_Q01
		my.ajax2('/insu/SIns0010001007Ajax', '', pf.setIns0010001007);
	}, 
	eventBind : function(my, pf) {
		// 나의 보험 현황 풀팝업 
		my.util.eBind('click', '#my_insu_pop1,#my_insu_pop2', function(e, obj) {
			my.appBridge.webviewReq({
				command:'callMoveView', urlMapId:'INSU01P01', 
				callback:'callback_callMoveView', viewType:'half'
			});
		});
		// 메인 상단 새로고침
		$('.btn-icon-only.icon-refresh.type-white').off('click').on('click', function() {
			var refresh = function(isExe) {
				if(!isExe) return false;
				$('.btn-icon-only.icon-refresh.type-white').hide();
				$("#update_ing").html('&nbsp;&nbsp;&nbsp;&nbsp;업데이트 진행 중..').show();		
				my.ajax2('/insu/SIns0010001015Ajax', '', function(result) {
					//result.resp_gubn = '1';
					//result.resp_mesg = '오류발생';
					if(result && result.resp_gubn == '0') {
						my.msg.alert({msg : '연결된 자산 정보를 업데이트 하였습니다.'});
						$('#tab_panel02').empty();
						pageUnit.init();
					} else {
						my.msg.confirm({
							msg : '서비스 연결 오류\n\n'+result.resp_mesg,
							cancleBtnText:"확인",
							confirmBtnText:"재시도",
							callBackFn : refresh
						});
					}
					$("#update_ing").fadeOut(300);
					$('.btn-icon-only.icon-refresh.type-white').show();
				});
			};
			refresh(true);
		});
		// 해지 환급금 문의하기 버튼
		my.util.eBind('click','.btn-module.tel', function(e, obj) {
			var targetTel = $(obj).attr('data-tel');
			document.location.href = 'tel:'+targetTel;
		});
		// 등록된 더 많은 보험 불러오기(탭1 상품유형별) 버튼
		my.util.eBind('click', '.btn-module.insr_more', function(e, obj) {
			var inputParam = {
					'insr_cls_tp':$(obj).attr('data-insr_cls_tp'),
					'next_data': $(obj).attr('data-next_data'),
					'cont_gubn': 'Y'
			};
			my.ajax2('/insu/GetXmr1021Q01Ajax', inputParam, pf.setXmr1021q01);
		});
		// 등록된 더 많은 보험 불러오기(탭1 상품유형별:보증보험) 버튼
		my.util.eBind('click', '#insu_month_morebut_bojeung', function(e, obj) {
			var inputParam = {
					'next_data': $(obj).attr('data-next_data'),
					'cont_gubn': 'Y'
			};
			my.ajax2('/insu/GetXmr4001Q01Ajax', inputParam, pf.setXmr4001Q01);
		});
		// 등록된 더 많은 보험 불러오기(탭 2 보험사별) 버튼
		my.util.eBind('click', '.btn-module.insr_more_company_list', function(e, obj) {
			var inputParam = {
					'myd_orgn_code':$(obj).attr('data-myd_orgn_code'),
					'next_data': $(obj).attr('data-next_data'),
					'cont_gubn': 'Y'
			};
			my.ajax2('/insu/GetXmr3051Q02Ajax', inputParam, pf.setXmr3051q02);
		});
		// 보험상세페이지 이동(자동차보험일 경우 003페이지로)
		my.util.eBind('click', '.sub-link.insr_detail', function(e, obj) {
			var orgn_code 		= $(obj).attr('data-orgn_code');
			var insr_cntr_no 	= $(obj).attr('data-insr_cntr_no');
			var insr_cls_tp 	= $(obj).attr('data-insr_cls_tp');
			var urlMapId 		= insr_cls_tp === '03' ? 'INSU0103':'INSU0102'; 
			var params = {
					'orgn_code'		:	orgn_code,		// 기관코드
					'insr_cntr_no' 	:	insr_cntr_no,	// 보험계약번호
					'insr_cls_tp' 	:	insr_cls_tp		// '01':'보장성보험','02':'저축성보험','03':'자동차보험',
														// '04':'실효보험','05':'만기보험','06':'소멸보험',
														// '07':'보증보험'
			};
			my.page.setSubParamData(params, 'VIns0010002View');
			my.page.setSubParamData(params, 'VIns0010003View');
			my.appBridge.webviewReq({
				command:'callMoveView', urlMapId:urlMapId, 
				callback:'callback_callMoveView', viewType:'half'
			});
		});
		// 입금 버튼
		my.util.eBind('click', '.btn-round.sm.navy.insr_ipgeum_but', function(e, obj) {
			my.msg.alert({msg:'입금기능은 준비중입니다.'});
		});
		// 병원/약국이용내역 더보기 버튼
		my.util.eBind('click', '#usecard_more_but', function(e, obj) {
			var inputParam = {
					'next_data': $(obj).attr('data-next_data'),
					'cont_gubn': 'Y'
			};
			my.ajax2('/insu/SIns0010001012Ajax', inputParam, pf.setIns0010001012);
		});
		// 병원/약국이용내역 새로고침 버튼
		my.util.eBind('click', '#use_refresh_but', function(e, obj) {
			my.ajax2('SIns0010001017Ajax', '', function(result) {
				if(result && result.resp_gubn === '0') {
					pageUnit.prop.carduse_count = 0;
					my.ajax2('/insu/SIns0010001012Ajax', '', pf.setIns0010001012);	
					my.msg.alert({msg : '카드 승인 내역을 업데이트 하였습니다'});
				} else {
					my.msg.alert({msg : result.resp_mesg});
				}		
			});
		});
		// 무료 보험 전문가 채팅 상담 버튼
		$('#insu_chat').off('click').on('click', function() {
			var inTime 	= '키움에셋플래너 보험 전문가와 상담하기 위해<br />채팅상담 페이지로 이동하시겠습니까?';
			var outTime = '키움에셋플래너 보험 전문가에게 편하게 상담 신청하세요.<br />고객님 입장에서 보험을 점검해 드려요.';
			var alert	= '';
			var nowHours = new Date().getHours();
			var weekNum	 = new Date(mydataCommon.util.getStrDate().format('####-##-##')).getDay(); 
			if(nowHours >= 9 && nowHours < 20) {
				alert = weekNum === 0 || weekNum === 6 ? outTime:inTime;
			} else {
				alert = outTime;
			}
			$('#chat_pop_content').html(alert);
			KW_MOBILE.guiEvent.popup.openPop('#chat_pop');
		});
		// 무료 보험 전문가 채팅 상담 취소 버튼
		$('#chat_pop_cancel').off('click').on('click', function() {
			KW_MOBILE.guiEvent.popup.closePop('#chat_pop');
		});
		// 무료 보험 전문가 채팅 상담 확인 버튼
		$('#chat_pop_ok').off('click').on('click', function() {
			var inTime		= 'https://www.moneykiwoom.com';
			var outTime 	= 'https://consult.kiwoomap.com/channel/kiwoominsu';
			var targetUrl 	= '';
			var nowHours = new Date().getHours();
			var weekNum	 = new Date(mydataCommon.util.getStrDate().format('####-##-##')).getDay(); 
			if(nowHours >= 9 && nowHours < 20) {
				targetUrl = weekNum === 0 || weekNum === 6 ? outTime:inTime;
			} else {
				targetUrl = outTime;
			}
			KW_MOBILE.guiEvent.popup.closePop('#chat_pop');
			$('#frm').attr({'target':'_blank','action':targetUrl}).submit();
		});
		// 실손보험 링크
		$('#silson1,#silson2,#silson3,#silson4,#silson5,#silson6').off('click').on('click', function() {
			var objUrl = {
				'local':{
					'silson1':'https://silson82t.com?c=kw&pg=gnnetFAQ',
					'silson2':'https://silson82t.com/silson?c=kw',
					'silson3':'https://silson82t.com/denti?c=kw',
					'silson4':'https://silson82t.com/picture?c=kw',
					'silson5':'https://silson82t.com?c=kw&pg=myPage',
					'silson6':'tel:15881709',
					},
				'prod':{
					'silson1':'https://silson82.com?c=kw&pg=gnnetFAQ',
					'silson2':'https://silson82.com/silson?c=kw',
					'silson3':'https://silson82.com/denti?c=kw',
					'silson4':'https://silson82.com/picture?c=kw',
					'silson5':'https://silson82.com?c=kw&pg=myPage',
					'silson6':'tel:15881709',
				}
			};
			var targetId 			= $(this).attr('id');
			document.location.href 	= objUrl[pageUnit.prop.profiles][targetId];
		});
	},
	fn : {
		// 탭1 보험분류별 월 보험료 조회(보장성,저축,자동차,실효,만기,소멸)  XMR1021_Q01
		setXmr1021q01 : function(result, param, my) {
			var insr_cls_tp	= param.insr_cls_tp;
			if( result.resp_gubn == "1") {
				$('#insu_month_'+ insr_cls_tp).hide();
				return false;
	        }
			result.insr_cls_tp			= insr_cls_tp;
	        result.insuCategoryTopName 	= pageUnit.prop.insu_category[insr_cls_tp];
            result.pdin_suma_m 			= my.util.getPrice(result.pdin_suma_m);

            $.each(result.g1, function(i, row) {
            	row.insr_cls_tp = insr_cls_tp;
    			if(row.crnc_code === 'KRW') {
    				row.pdin_amt_m 	= my.util.getPrice(row.pdin_amt_m);
    				row.crnc_code	= '원';
    			} else {
    				row.pdin_amt_m 	= my.util.getPrice(row.pdin_amt_m, 2);
    			}
    			if(row.err_yn === 'Y') {
    				row.err_class 		= 'error';
    				row.err_alert_class = 'bullet-noti fc-orange ml50';
    				row.err_alert		= row.err_msg;
    			} else {
    				row.err_class 		= '';
    				row.err_alert_class = '';
    				row.err_alert		= '';
    			}
			});
            if($.inArray(insr_cls_tp, ['05', '06', '07']) > -1) {			// 실효,만기,소멸
            	ao_html('#insu_month_'+ insr_cls_tp, result);
            } else {														// 보장성,저축,자동차
            	if(pageUnit.prop.insr_tp_count[insr_cls_tp] > 0) {
                	ao_append('#insu_month_list_'+ insr_cls_tp, result.g1);
                } else {
                	ao_html('#insu_month_'+ insr_cls_tp, result);
                	ao_html('#insu_month_list_'+ insr_cls_tp, result.g1);
                	KW_MOBILE.guiEvent.accordion.init('#insu_month_'+ insr_cls_tp);	// 아코디언 초기화(열기)
                }
            	// 더보기 버튼 처리
            	if(result.next_data) {
            		$('#insu_month_morebut_'+insr_cls_tp).attr({
            			'data-insr_cls_tp' 	: insr_cls_tp,
            			'data-next_data' 	: result.next_data
            		});
            		$('#insu_month_morediv_'+insr_cls_tp).show();
            	} else {
            		$('#insu_month_morediv_'+insr_cls_tp).hide();
            	}
            }
            pageUnit.prop.insr_tp_count[insr_cls_tp]++;
		},
		// 탭1 보증보험 xmr4001_Q01
		setXmr4001Q01 : function(result, param, my) {
			var insr_cls_tp	= '07';
			if( result.resp_gubn == "1") {
				$('#insu_month_'+ insr_cls_tp).hide();
				return false;
	        }
			result.insr_cls_tp		= insr_cls_tp;
            result.tot_pdin_sum 	= my.util.getPrice(result.tot_pdin_sum);

            $.each(result.g1, function(i, row) {
            	row.insr_cls_tp 	= insr_cls_tp;
    			row.pdin_infe_sum 	= my.util.getPrice(row.pdin_infe_sum);
    			if(row.err_yn === 'Y') {
    				row.err_class 		= 'error';
    				row.err_alert_class = 'bullet-noti fc-orange ml50';
    				row.err_alert		= row.err_msg;
    			} else {
    				row.err_class 		= '';
    				row.err_alert_class = '';
    				row.err_alert		= '';
    			}
			});
        	if(pageUnit.prop.insr_tp_count[insr_cls_tp] > 0) {
            	ao_append('#insu_month_list_'+ insr_cls_tp, result.g1);
            } else {
            	ao_html('#insu_month_'+ insr_cls_tp, result);
            	ao_html('#insu_month_list_'+ insr_cls_tp, result.g1);
            	KW_MOBILE.guiEvent.accordion.init('#insu_month_'+ insr_cls_tp);
            }
        	// 더보기 버튼 처리
        	if(result.next_data) {
        		$('#insu_month_morebut_'+insr_cls_tp).attr({
        			'data-insr_cls_tp' 	: insr_cls_tp,
        			'data-next_data' 	: result.next_data
        		});
        		$('#insu_month_morediv_'+insr_cls_tp).show();
        	} else {
        		$('#insu_month_morediv_'+insr_cls_tp).hide();
        	}
            pageUnit.prop.insr_tp_count[insr_cls_tp]++;
		},
		// 보험사별 가입내역 조회 XMR3051_Q02
		setXmr3051q02 : function(result, param, my) {
			var myd_orgn_code = param.myd_orgn_code;
			if(result.resp_gubn == "1") {
				$('#'+myd_orgn_code+'_top').hide();
				return false;
	        }
			result.myd_orgn_code 	= myd_orgn_code;
			result.tot_pdin_amt 	= my.util.getPrice(result.tot_pdin_amt);
			$.each(result.g1, function(index, row) {
				if(row.crnc_code === 'KRW') {
					row.insr_amt_m 	= my.util.getPrice(row.insr_amt_m);
					row.crnc_code	= '원';
				} else {
					row.insr_amt_m 	= my.util.getPrice(row.insr_amt_m, 2);
				}
				if(row.err_yn === 'Y') {
    				row.err_class 		= 'error';
    				row.err_alert_class = 'bullet-noti fc-orange ml50';
    				row.err_alert		= row.err_msg;
    			} else {
    				row.err_class 		= '';
    				row.err_alert_class = '';
    				row.err_alert		= '';
    			}
				row.insr_cls_tp		= pageUnit.prop.insr_category.get(row.insr_kind_tp);
				row.myd_orgn_code	= myd_orgn_code;
			});
			 if(pageUnit.prop.company_count[myd_orgn_code] > 0) {
            	ao_append('#'+myd_orgn_code+'_list', 'insu_companylist_loop_tmpl', result.g1);
            } else {
            	ao_append('#tab_panel02', 'insu_companylist_top_tmpl', result);
            	ao_html('#'+myd_orgn_code+'_list', 'insu_companylist_loop_tmpl', result.g1);
            	KW_MOBILE.guiEvent.accordion.init('#'+myd_orgn_code+'_top');
            }
            if(result.next_data) {
        		$('#'+myd_orgn_code+'_morebut').attr({
        			'data-myd_orgn_code' 	: myd_orgn_code,
        			'data-next_data' 		: result.next_data
        		});
        		$('#'+myd_orgn_code+'_morediv').show();
        	} else {
        		$('#'+myd_orgn_code+'_morediv').hide();
        	}
			pageUnit.prop.company_count[myd_orgn_code]++;
		},
		// 병원/약국 이용 내역 XMR2031_Q01
		setIns0010001012 : function(result, param, my) {
			if(result.resp_gubn === "1") {
				ao_html('#carduse_top', result);
				ao_html('#carduse_list', [{'use_orgn_mch_nm':'사용내역이 없습니다.'}]);
				$('#carduse_sub1').hide();
				$('#carduse_sub2').hide();
				$('#usecard_more_div').hide();
				KW_MOBILE.guiEvent.toolTip.init();
				return false;
			}
			result.qry_st_dt 			= my.util.getStrDate(result.qry_st_dt);
			result.qry_end_dt			= my.util.getStrDate(result.qry_end_dt);
			result.tot_md_pay_amt		= my.util.getPrice(result.tot_md_pay_amt);
			
			var use_orgn_tp_code 	= {'1':'병원','2':'의원','3':'치과','4':'약국','5':'기타'};
			$.each(result.g1, function(i, row) {
				row.use_orgn_use_dt		= my.util.getStrDate(row.use_orgn_use_dt);
				row.use_orgn_use_amt 	= my.util.getPrice(row.use_orgn_use_amt);
				row.use_orgn_tp_name	= use_orgn_tp_code[row.use_orgn_tp];
				row.use_org_use_amt_won	= '원';
			});
			if(pageUnit.prop.carduse_count > 0) {
				ao_append('#carduse_list', result.g1);
			} else {
				ao_html('#carduse_top', result);
				ao_html('#carduse_list', result.g1);
				KW_MOBILE.guiEvent.toolTip.init();	// 툴팁 초기화
			}
			if(result.next_data) {
        		$('#usecard_more_but').attr({
        			'data-next_data' : result.next_data
        		});
        		$('#usecard_more_div').show();
        	} else {
        		$('#usecard_more_div').hide();
        	}
			pageUnit.prop.carduse_count++;
		},
		// 납입안내
		setIns0010001008 : function(result, param, my) {
			var tagId = '#ins0010001008';
			if(result.resp_gubn == "1") {
				$(tagId).hide();
				return false;
			}
			var beforeCount = $(tagId + ' .swiper-slide').length;
			$.each(result.g1, function(i, row) {
				if(row.crnc_code === 'KRW') {
					row.pdin_amt 	= my.util.getPrice(row.pdin_amt);
					row.crnc_code 	= '원';
				} else {
					row.pdin_amt 	= my.util.getPrice(row.pdin_amt, 2);
				}
				row.diff 			= 'D' + row.pdin_diff_dys_sign + row.pdin_diff_dys;
				row.nxtr_pdin_dt 	= mydataCommon.util.getStrDate(row.nxtr_pdin_dt);
			});
			ao_html(tagId, result);
			if(pageUnit.prop.swiper1ExeNum === 0 || beforeCount !== Number(result.qry_cnt)) {
				KW_MOBILE.guiEvent.swiper.runSwiper(tagId + '_list');
			}
			pageUnit.prop.swiper1ExeNum++;
		},
		// 만기안내
		setIns0010001009 : function(result, param, my) {
			var tagId = '#ins0010001009';
			if(result.resp_gubn == "1") {
				$(tagId).hide();
				return false;
			}
			var beforeCount = $(tagId + ' .swiper-slide').length;
			$.each(result.g1, function(i, row){
				row.expr_rmnd_dys 	= 'D-'+row.expr_rmnd_dys; 
				row.expr_dt 		= my.util.getStrDate(row.expr_dt);
				//row.expr_amt		= my.util.getPrice(row.expr_amt);
			});
			ao_html(tagId, result);
			if(pageUnit.prop.swiper2ExeNum === 0 || beforeCount !== Number(result.qry_cnt)) {	
				KW_MOBILE.guiEvent.swiper.runSwiper(tagId+'_list');
			} 
			pageUnit.prop.swiper2ExeNum++;
		},
		// 메인 연령별 보험 평균 보장 내역  XMR1031_Q02 
		setIns0010001006 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				$('#age_section').hide();
				return false;
			}
			// ex : 30대 남성
			$('#age_user').text(result.insr_age_tp + '0 대 ' + 
									(function(){return result.gndr_tp === '1' ? '남성':'여성'})()
			);
			var chartData 	= {
					id 		: 'age_chart',
					data 	: []
			};
			var colors		= ['#6666cc','#d1d6e8','#d1d6e8','#d1d6e8','#d1d6e8','#d1d6e8','#d1d6e8','#d1d6e8'];
			var dataColors	= ['#3c3e90','#b9bece','#b9bece','#b9bece','#b9bece','#b9bece','#b9bece','#b9bece'];
			$.each(result.g1, function(i, row) {
				// 보장내역 top 2
				if(i < 2) {
					$('#age_insu_result_name_'+i).text(row.dgns_tp_nm);
					$('#age_insu_result_amt_'+i).text(my.util.getPrice(row.avg_join_asrn_amt)+'만원');
				} 
				
				chartData.data.push({
					name		: row.dgns_tp_nm, 
					y			: Number(row.avg_join_asrn_amt), 
					color		: colors[i],
					dataLabels 	: {color: dataColors[i]}
				});
			});
			pageUnit.design.chartIns0010001006(chartData);
		},
		// 메인 보험 현황 XMR2004_Q01
		setIns0010001007 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				$('#hyeonhwang_section').hide();
				return false;
			} 
			var chartData 	= {
					id		: 'hyeonhwang_chart',
					data	: []	
			};
			$.each(result.g1, function(i, row){
				chartData.data.push({
					name	: row.insr_kind_nm, 
					y		: Number(row.insr_kind_suma), 
					color	: '#6666cc'
				});
			});
			pageUnit.design.chartIns0010001007(chartData);
		},
	},
	design : {
		// 연령별 보험 평균 보장 내역 스크롤 차트
		chartIns0010001006 : function(chartData) {
			var chartColumn = new Highcharts.Chart(chartData.id, Highcharts.merge (
            KW_MOBILE.highcharts.types.column,{
                chart: {
                    min: -0.25,//yAxis 위치를 안쪽으로 변경하면서 첫번째 컬럼과 간격 조정
                    height: 200,
                    marginLeft: 0,
                    marginRight: 0,
                    events: {
                        load: function(){
                            var barCnt = this.pointCount;//컬럼 개수
                            //컬럼이 3개 이상일 경우 스크롤 영역 생성
                            if(barCnt>2) {
                                $("#"+chartData.id).parent(".chart-wrapper")
                                	.wrap("<div class='chart-wrapper-full' style='height:200px'></div>");
                                this.setSize((barCnt*2)*($(window).width()/7.8),this.chartHeight);
                                $("#"+chartData.id).width(this.chartWidth);
                            }
                        }
                    }
                },
                yAxis: {
                    gridLineWidth: 1,
                    enable:true,
                    visible: true,
                    min:0,
                    //max:100,
                    //tickInterval:20,
                    labels:{
                        style: { fontSize: '10px' }
                    },
                },
                series: [{
                    dataLabels: {
                        enabled: true,
                        format: '{point.y:,.0f}'
                    },
                    data: chartData.data
                }]
            }));
		},
		// 보험 현황 컬럼차트
		chartIns0010001007 : function(chartData) {
			var chartColumn = new Highcharts.Chart(chartData.id, Highcharts.merge (
	            KW_MOBILE.highcharts.types.column,
	            {
	                series: [{
	                    dataLabels: {
	                        enabled: true,
	                        format: '{point.y:,.0f}'
	                    },
	                    data: chartData.data
	                }],
	                yAxis: {
	                    gridLineWidth: 1,
	                    enable:true,
	                    visible: true,
	                    min: 0,
	                    //max: 1000,
	                    //tickInterval: 200,
	                }
	            }
	        ));
		},
	}
};
$(document).ready(function(){
	pageUnit.init();
});