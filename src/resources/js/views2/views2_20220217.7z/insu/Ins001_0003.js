'use strict';

var pageUnit = {
	prop : {
		// 기관코드
		orgn_code 		: '',
		// 보험계약번호
		insr_cntr_no 	: '',
		// 조회  파라미터 
		inputParam 		: '',
		// localstorage key
		v_storageKeyName 	: 'insu',
		v_storageSubKeyName : 'VIns0010003View',	
		
	},
	init : function() {
		var pf	= pageUnit.fn;
		var my	= mydataCommon;
		
		var params 					= my.page.getSubParamData();
		pageUnit.prop.orgn_code 	= params.orgn_code;
		pageUnit.prop.insr_cntr_no 	= params.insr_cntr_no;
		
		pageUnit.prop.inputParam 	= {'orgn_code':pageUnit.prop.orgn_code, 'insr_cntr_no':pageUnit.prop.insr_cntr_no};
		
		pageUnit.eventBind(my, pf);
		pageUnit.onLoad(my, pf);
	},
	onLoad : function(my, pf) {
		// 자동차 보험 상세정보 조회 XMR3065_Q01
		my.ajax2("/insu/GetXmr3065Q01Ajax", pageUnit.prop.inputParam, pf.setXmr3065Q01);
	},
	eventBind : function(my, pf) {	
		// 이전
		$('.sub-prev').off('click').on('click', function(){
			my.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
	},
	fn : {
		// 자동차 보험 상세정보 조회 XMR3065_Q01
		setXmr3065Q01 : function(result, param, my) {
			if(result.resp_gubn == "1") {
				my.msg.alert({msg : result.resp_mesg});
				return false;
			}
			$.each(result.g1, function(i, row) {
	            row.real_pdin_insr_amt	= my.util.getPrice(row.real_pdin_insr_amt);
	            row.cntr_dt 			= my.util.getStrDate(row.cntr_dt);  
	            row.expr_dt				= my.util.getStrDate(row.expr_dt);
	            row.self_car_dama_yn	= row.self_car_dama_yn == "Y" ? "가입":"미가입";
	            row.self_brdn_amt		= my.util.getPrice(row.self_brdn_amt);
			});
			ao_html('#auto_detail', result.g1);
		}
		
	},
};
$(document).ready(function(){
	pageUnit.init();
});
