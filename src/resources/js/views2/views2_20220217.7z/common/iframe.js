/**
 * common/iframe 호출 방법
 * 
 * (1) viewtype이 half인 경우
 * 
 * mydataCommon.util.setArrayData('mydata_cmm_data', {iframe: {title: '화면명', url: '화면 주소', viewtype: 'half'}});
 * 
 * webviewReq 호출 
 *   mydataCommon.appBridge.webviewReq({
 *   command : "callMoveView",
 *   urlMapId : "IFRAME",
 *   viewType : 'half'
 * });
 * 
 * (2) location.href 인 경우
 * 
 * mydataCommon.util.setArrayData('mydata_cmm_data', {iframe: {title: '화면명', url: '화면 주소', viewtype: null}});
 * location.href = pageCom.prop.contextPath + '/common/iframe'
 * 
 */
var pageUnit = {
	prop: {
		loc_cmm_param_key : "mydata_cmm_data",
		iframe: null
	},
	init: function () {
		$.extend(pageUnit.prop, mydataCommon.util.getArrayData(pageUnit.prop.loc_cmm_param_key));
		var iframe = pageUnit.prop.iframe;
		var url = iframe.url;
		
		$('#title').text(iframe.title);
		
		$.get(url, function (data, status, jqXHR) {
			var opt = jqXHR.getResponseHeader('x-frame-options');
			if (!opt) {
				$('#ifrm').attr('src', url);
			} else {
				// iframe 이 안되는 경우
				location.href = url;
			}
		});
	},
	fn: {
		goPrev: function () {
			switch (pageUnit.prop.iframe.viewtype) {
				case 'half':
					mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true}); break;
				default:
					history.back(); break;
			}
		}
	}
}

$(document).ready(function() {
	pageUnit.init();
});
