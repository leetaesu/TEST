/**
 * 테스트 계정 로그인
 */
var pageUnit = {
	prop : {},
	// 단위 진입부 함수
	init : function() {
		$.get('getUsers', function (res2) {
			ao_html('bts', {g: res2});

			$.get('getUser', function(res) {
				if (res.userId) {
					$bts.find('[data-user-id="'+res.userId+'"]').addClass('bb');
				} else {
					$bts.find('#logout').addClass('bb');
				}
			}, 'json');
		}, 'json');
		
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function() {
		$bts.on('click', 'button:not(#logout)', function () {
			var no = $(this).index() + 1;
			$.get('putUserByOrderNo/' + no, function (res) {
				if (res.userId) {
					$bts.find('.bb').removeClass('bb');
					$bts.find('[data-user-id="'+res.userId+'"]').addClass('bb');
				}
			}, 'json');
		});
		
		// 유저 초기화
		$bts.on('click', '#logout', function () {
			var $this = $(this);
			$.get('initUser', function (res) {
				if (res) {
					$bts.find('.bb').removeClass('bb');
					$this.addClass('bb');
				}
			}, 'json');
		});
		
		$login_btn.click(() => {
			$.get('putUser', {
				customNo: $custNo_input.val(),
				realName: $realName_input.val()
			}, function (res) {
				if (res.customNo) {
					$bts.find('.bb').removeClass('bb');
				}
			}, 'json');
		})
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		goPrev : function(data) {
			mydataCommon.appBridge.webviewReq({
				command : "callSendViewData",
				callback : "",
				popClose : true
			});
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {}
};
// 페이지 on load시 진입부
$(document).ready(function() {
	pageUnit.init();
});