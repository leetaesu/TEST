/**
 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
 * @description 공통 API Class
 * @작성일 : 2021.12.21
 * @작성자 : 윤성민
 */

/**
 * @description 자바스크립트 String 프로토타입 재정의
 */

'use strict';
String.prototype.format = function(formatStr) {
	if(!this.valueOf()){
		return "";
	}
	if(typeof formatStr == "undefined" || typeof param == "null"){
		return this.valueOf();
	}
	var tempValue = this.valueOf();
	var tempFarr = [];
	var tempSarr = [];
	var tempReturnValueArr = [];
	// 포맷 스트링을 char 단위로 배열에 담음
	for(var i = 0; i < formatStr.length; i++){
		tempFarr.push(formatStr.substr(i, 1));
	}
	// 해당 문자 스트링을 char 단위로 배열에 담음
	for(var i = 0; i < tempValue.length; i++){
		tempSarr.push(tempValue.substr(i, 1));
	}
	var targetStringCheckCnt = 0;
	for(var i = 0; i < tempFarr.length; i++){
		if(tempFarr[i] == "#"){
			// 리턴할 배열에 포맷대상 스트링의 char단위로 삽입
			tempReturnValueArr.push(tempSarr[targetStringCheckCnt]);
			targetStringCheckCnt++;
		}else{
			// 리턴할 배열에 포맷 char을 삽입
			tempReturnValueArr.push(tempFarr[i]);
		}
	}
	return tempReturnValueArr.join("");
};

// String Parsing
(function (exports) {
	
	// regex for separating the various parts of an identifier from each other
	var identifierIdentifier = /^(?:\[([^\.\[\]]+)\]|\.?([^\.\[\]]+))(.*)$/
	// convert an identifier into the actual value that will be substituted
	var findByPath = function (path, data, top) {
		var identifiers = path.match(identifierIdentifier);
		if (!identifiers) {
			throw "Invalid identifier: " + path;
		}
		var key = identifiers[1] || identifiers[2];
		// For the first identifier, named keys are a shortcut to "0.key"
		if (top && !isFinite(key)) {
			data = data[0];
		}
		var value = data[key];
		// recurse as necessary
		return identifiers[3] ? findByPath(identifiers[3], value) : value;
	};
	
	// the actual format function
	var format = function (template, data) {
		// NOTE: other versions of this algorithm are in performance/parsing-algorithms.js
		// Generally, this version performs best on small-ish strings and a regex-based
		// versions performs best on very large strings. Since people will probably use
		// more complicated templating libraries for big strings, we use the small-string
		// optimized version here.
		
		var args = Array.prototype.slice.call(arguments, 1);

		var outputBuffer = "";
		var tokenBuffer = "";
		// true if we are currently buffering a token that will be replaced
		var bufferingToken = false;
		// true if we've encountered a specifier that will be replaced
		var specifierIsReplaced = false;
		// track the {identifier:specifier} replacement parts
		var identifier, specifier;

		// walk the template
		for (var i = 0, length = template.length; i < length; i++) {
			var current = template.charAt(i);

			if (bufferingToken) {
				// ":" designates end of identifier, start of specifier
				if (current === ":") {
					identifier = tokenBuffer;
					tokenBuffer = "";
					// if the first character of the specifier is "{", assume it is replaced
					if (template.charAt(i + 1) === "{") {
						specifierIsReplaced = true;
						i += 1;
					}
				}
				// end of token
				else if (current === "}") {
					// if we've already captured an identifier, the buffer contains the specifier
					// (see check for ":" above)
					if (identifier) {
						specifier = tokenBuffer;
					}
					else {
						identifier = tokenBuffer;
					}
					
					var foundValue = findByPath(identifier, args, true);
					// if a specifier is an identifier itself, do the replacement and
					// if we're dealing with a replaced specifier, we should end with a "}}"
					// so deal with the second "}"
					if (specifierIsReplaced) {
						specifier = findByPath(specifier, args, true);
						i += 1;
					}
					
					// format the value
					outputBuffer += formatValue(foundValue, specifier);
					
					// cleanup
					bufferingToken = false;
					specifierIsReplaced = false;
					specifier = identifier = null;
				}
				// non-special characters
				else {
					tokenBuffer += current;
				}
			}
			// when not buffering a token
			else if (current === "{") {
				// doubled up {{ is an escape sequence for {
				if (template.charAt(i + 1) === "{") {
					outputBuffer += current;
					i += 1;
				}
				// otherwise start buffering a new token
				else {
					tokenBuffer = "";
					bufferingToken = true;
				}
			}
			// doubled up }} is an escape sequence for }
			// TODO: what should happen when encountering a single "}"?
			else if (current === "}" && template.charAt(i + 1) === "}") {
				outputBuffer += "}";
				i += 1;
			}
			// non-special character
			else {
				outputBuffer += current;
			}
		}

		return outputBuffer;
	};
	
	var formatValue = function (value, specifier) {
		if (value == null) return ""; // can't use !value because NaN would stop here
		if (value.toFormat) return value.toFormat(specifier);
		if (typeof(value) === "number") return numberToFormat(value, specifier);
		return value.toString();
	};
	
	var numberToFormat = function (value, specifier) {
		if (!specifier) {
			return value.toString();
		}
		var formatters = specifier.match(/^([\+\-#0]*)(\d*)(?:\.(\d+))?(.*)$/);
		var flags     = formatters[1],
		    width     = formatters[2],
		    precision = formatters[3],
		    type      = formatters[4];
	
		var repeatCharacter = function (character, times) {
			var result = "";
			while (times--) {
				result += character;
			}
			return result;
		}
	
		var applyPrecision = function (result) {
			// only apply precision to numeric strings
			if (precision && (/^[\d\.]*$/).test(result)) {
				var afterDecimal = result.split(".")[1];
				var extraPrecision = precision - afterDecimal;
				if (isNaN(extraPrecision)) {
					extraPrecision = precision;
				}
				if (extraPrecision > 0) {
					if (result.indexOf(".") === -1) {
						result += ".";
					}
					for (; extraPrecision > 0; extraPrecision--) {
						result += "0";
					}
				}
			}
			return result;
		}
	
		var result = "";
		switch (type) {
			// signed decimal number
			case "d":
				result = Math.round(value - 0.5).toString(10);
				result = applyPrecision(result);
				break;
			// hex
			case "x":
				result = Math.round(value - 0.5).toString(16);
				if (~flags.indexOf("#")) {
					result = "0x" + result;
				}
				break;
			case "X":
				result = Math.round(value - 0.5).toString(16).toUpperCase();
				if (~flags.indexOf("#")) {
					result = "0X" + result;
				}
				break;
			// binary
			case "b":
				result = Math.round(value - 0.5).toString(2);
				break;
			// octal
			case "o":
				result = Math.round(value - 0.5).toString(8);
				if (~flags.indexOf("#")) {
					result = "0" + result;
				}
				break;
			// scientific notation (exponential)
			case "e":
			case "E":
				// FIXME: not sure if the precision specifier should apply here and how
				// FIXME: not sure how to behave for Infinity and NaN. Leaving it up to toExponential()
				result = value.toExponential().replace("e", " e");
				// # flag forces a decimal point (not sure if this is correct or if I am misinterpreting the proposal)
				if (~flags.indexOf("#")) {
					result = result.replace(/^(\d*)(\se)/, "$1.$2");
				}
				// must have at least two digits in exponent
				if ((/[+\-]\d$/).test(result)) {
					result = result.slice(0, -1) + "0" + result.slice(-1);
				}
				if (type === "E") {
					result = result.toUpperCase();
				}
				break;
			// normal or exponential notation, whichever is more appropriate for its magnitude
			case "g":
			case "G":
				result = value.toString(10)[type === "g" ? "toLowerCase" : "toUpperCase"]();
				// not quite clear on whether g/G ignores the precision specifier, but it seems like # should control this?
				if (~flags.indexOf("#")) {
					result = applyPrecision(result);
					// # flag forces a decimal point (not sure if this is correct or if I am misinterpreting the proposal)
					result = result.replace(/^(\d*)(\se|$)/i, "$1.$2");
				}
				break;
			// fixed point
			case "f":
			case "F":
				// proposal talks about INF and INFINITY, but not sure when each would be used :\
				// FIXME: not sure how this should behave in the absence of a precision
				result = value.toFixed(precision || 0);
				// # flag forces a decimal point (not sure if this is correct or if I am misinterpreting the proposal)
				if (!precision && ~flags.indexOf("#")) {
					result += ".";
				}
				result = result[type === "f" ? "toLowerCase" : "toUpperCase"]();
				break;
			case "s":
			default:
				result = value.toString();
				result = applyPrecision(result);
		}
	
		if (~flags.indexOf("+")) {
			if (value >= 0) {
				result = "+" + result;
			}
		}
	
		if (width && result.length < width) {
			// "-" flag is right-fill
			if (~flags.indexOf("-")) {
				result += repeatCharacter(" ", width - result.length);
			}
			else {
				var padding = repeatCharacter(~flags.indexOf("0") ? "0" : " ", width - result.length);
				if (~flags.indexOf("0") && (result[0] === "+" || result[0] === "-")) {
					result = result[0] + padding + result.slice(1);
				}
				else {
					result = padding + result;
				}
			}
		}
		// TODO: # flag
		return result;
	};
	
	// exports
	exports.format = format;
	
	// prototype modification
	String.prototype.parsing = function (data) {
		var args = [this].concat(Array.prototype.slice.call(arguments));
		return format.apply(null, args);
	};
	
	Number.prototype.toFormat = function (specifier) {
		return numberToFormat.call(null, this, specifier);
	};

})(typeof(exports) !== "undefined" ? exports : this);

Map = function(){
	this.map = new Object();
}

Map.prototype = {
		put : function(key,value){
			 this.map[key] = value;
		},
		get : function(key){
			return this.map[key];
		},
		getAll : function(){
			return this.map;
		},
		containsKey : function(key){
			return key in this.map;
		},
		containsValue : function(value){
			for(var i in this.map){
				if(this.map[i]== value) return true;
			}
			return false;
		},
		isEmpty : function(){
			return (this.size == 0); 
		},
		clear : function(){
			//this.map = new Array();
			for(var i in this.map){
				delete this.map[i];
			}
		},
		remove : function(key){
			delete this.map[key];
		},
		getKeys : function(){
			var keys = new Array();
			for(var i in this.map){
				keys.push(i);
			}
			return keys;
		},
		getValues : function(){
			var values = new Array();
			for(var i in this.map){
				values.push(this.map[i]);
			}
			return values;
		},
		size : function(){
			var count = 0;
			for(var i in this.map){
				count++;
			}
			return count;
		},
		arrayRemove : function(subMapName , arrayValue){
			var subMap = this.map[subMapName];
			subMap.splice($.inArray(arrayValue,subMap),1);
		}
}


var pageCommon = {
	msg : {
		pleaseEnter : "을(를) 입력하세요",
		pleaseSelect : "을(를) 선택하세요",
	}
};

var mydataCommon = {
	/* 공통 전용 프로퍼티 모음 */
	prop : {
		ajaxCount : 1,
		urlDir : '',
	},
	/* 공통 전용 통신함수 모음 패키지 */
	trn : {},
	/**
	 * @param {object} JSON OBJECT
	 * @param {function} [<b>paramJson.success</b>] 통신성공시 콜백 구현부 (이처럼 기존 ajax에서 제공하는 error 등등 콜백 구현부를 단위에서 정의할수 있다.)
	 * @description JQUERY AJAX 랩핑 함수
	 * @example
	 * <pre>
			var jsonObj = {
				url : pageCom.prop.contextPath + "/common/getMyBankListJson",
				data : {join_orgn_code : "1", asgn_pymn_acnt_no : "12345678"},
				success : function(res){
					var resultMap = res.resultMap;
					if(resultMap && resultMap.resp_gubn == "0"){
					}else{
						mydataCommon.msg.alert({msg : "본인명의 계좌만 등록가능합니다."});
					}
				}
			}
			mydataCommon.ajax(jsonObj);		
	 * </pre>
	 */
	ajax : function(jsonParam){
		
		//로딩바 처리
		var divLogingBarObj = $("#divLogingBar_gl");
		if(jsonParam.isShowLoading){
			//단위 화면 정의 로딩바 사용시는   
			if(jsonParam.loadingObj != null && jsonParam.loadingObj.length > 0){
				divLogingBarObj = jsonParam.loadingObj;
			}else{
				if(divLogingBarObj.length > 0){
					//
				}else{
					var htmlString = "";
					htmlString += '<div id="divLogingBar_gl" class="modal-dim loding on" style="background: rgb(0 0 0 / 0.2); display: none; ">';
					htmlString += '		<section class="modal-container" tabindex="0" role="dialog" style="';
					htmlString += '    background: transparent;';
					htmlString += '">';
					htmlString += '		<div class="modal-body">';
					htmlString += '			<div class="modal-body-container" style="';
					htmlString += '    background: transparent;';
					htmlString += '">';
					htmlString += '				<div class="loding-wrap" style="';
					htmlString += '    background: transparent;';
					htmlString += '">';
					htmlString += '					<p class="loding rotating"></p>';
					htmlString += '					';
					htmlString += '				</div>';
					htmlString += '			</div>';
					htmlString += '		</div>';
					htmlString += '		</section>';
					htmlString += '	</div>';
					htmlString += '';
					htmlString += '';
					//동적으로 삽입
					$("body").append(htmlString);
					divLogingBarObj = $("#divLogingBar_gl");
				}					
			}
		}
		
		var hideLogingScript = function(){
			//divLogingBarObj.fadeOut(2000);
			setTimeout(function(){
				divLogingBarObj.hide();
			}, jsonParam.minLodingTime || 200)
			//divLogingBarObj.fadeOut(2000);
		};
		
		var jsonObj = {
			url : jsonParam.url,
			type : jsonParam.type || "POST", 
			cache : jsonParam.cache || false,
			async : jsonParam.async || false,
			dataType : jsonParam.dataType || "json",
			contentType : jsonParam.contentType,
			data : jsonParam.data,
			timeout : jsonParam.timeout || (1000 * 60),// 디폴트 1븐
			beforeSend : function(jqXHR, settings){
		
				if(jsonParam.isShowLoading){
					divLogingBarObj.show();
				}
				
				if(typeof jsonParam.beforeSend === "function"){
					jsonParam.beforeSend(jqXHR, settings);
				}
			},
			success : function(res){
				if(jsonParam.isShowLoading){
					hideLogingScript();
				}
				if(typeof jsonParam.success === "function"){
					jsonParam.success(res);
				}
			},
			complete : function(jqXHR, textStatus){
				if(jsonParam.isShowLoading){
					hideLogingScript();
				}
				if(typeof jsonParam.complete === "function"){
					jsonParam.complete(jqXHR, textStatus);
				}		
			},
			error : function(jqXHR, textStatus, textErrorThrown){
				if(jsonParam.isShowLoading){
					hideLogingScript();
				}				
				if(typeof jsonParam.error === "function"){
					jsonParam.error(jqXHR, textStatus, textErrorThrown);
				}				
			}
		};
		
		//정의 되지 않은 옵션 제거
		if(jsonParam.contentType){
			
		}else{
			delete jsonObj.contentType;
		}
		
		$.ajax(jsonObj);
	},
	//=========================================================
	//ajax 호출하는 함수.
	//mydataCommon.ajax2('/annu/SAnn00100010006Ajax',{});
	//url : 필수, /annu/SAnn00100010006Ajax
	//param : 선택, {param1:'value1',param2:'value2'}
	//opt : 선택, {async:false,isSuccessCallbackDirect:true}
	//- opt.isSuccessCallbackDirect : 성공콜백함수 반환값 방식 선택 : false(기본값) data.resultMap 형식의 기본 포맷값 반환, true : 원시 data 콜백 결과값 반환
	//- opt.isOptionAppend : 선택, true(기본값)/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
	//successCallback : 선택, 처리 성공 후 콜백함수, 파라미터 : resultMap, param
	//errorCallback : 선택, 에러 시 콜백 처리함수, 파라미터 : jqXHR, textStatus, textErrorThrown
	//completeCallback : 선택, 최종 콜백 처리함수, 파라미터 : jqXHR, textStatus
	//=========================================================
	ajax2 : function(url,param,successCallback,opt,errorCallback,completeCallback){
		url = $.trim(url ? url : '');
		param = param ? param : {};
		opt = opt ? opt : {};
		if(!url){
			return;
		}
		var jsonObj = {
			url : pageCom.prop.contextPath	+ mydataCommon.prop.urlDir + url,
			type : 'POST',
			data : param,
			async : true,
			//cache : true,
			success : function(data) {
				if(opt && opt.isSuccessCallbackDirect){
					successCallback(data, param);
				} else {
					var resultMap = data.resultMap;
					mydataCommon.util.consoleOut(resultMap, mydataCommon.prop.urlDir + url + 
															'('+mydataCommon.prop.ajaxCount+')', param);
					mydataCommon.prop.ajaxCount++;
				
					$("#output").text(JSON.stringify(resultMap));
					successCallback(resultMap, param, mydataCommon);
				}
			},
			complete : function(jqXHR, textStatus) {
				if(completeCallback){
					completeCallback(jqXHR, textStatus);
				}
			},
			error : function(jqXHR, textStatus, textErrorThrown) {
				if(errorCallback) {
					errorCallback(jqXHR, textStatus, textErrorThrown);
				} else {
					if(pageCom.prop.isLocal) {
						console.error('===================='+mydataCommon.prop.urlDir+url+'=========================');
						console.error(
								'code:'+jqXHR.status+'\n'+
								'message:'+jqXHR.responseText+'\n'+
								'error:'+textErrorThrown);
					}
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
				}
			}
		}
		//사용자가 넘긴 옵션 확장.
		$.extend(mydataCommon.getAjax2AppendOption(opt), jsonObj, opt);
		mydataCommon.ajax(jsonObj);
	},
	getAjax2AppendOption : function(opt){
		//ajax2 함수 내부에서, 직접 조정 옵션을 기존 ajax 함수의 기본옵션에 어떻게 값을 append 할지 방법
		//반환값 : true(기존 기본 옵션값 유지 상태에서 부분속성 append) / false(기존 기본 옵션값을 삭제하고, 새로 append), 기본값 true
		//mydataCommon.getAjax2AppendOption(opt);
		return opt && opt.isOptionAppend===false ? false : true;
	},
	contentRedirectUrl: function($url, $param) {
    	
    	if ($param) {
    		
    		var formHtml = "<form name=\"redirectUrlFrm\" id=\"redirectUrlFrm\" method=\"post\" target=\"_self\" action=\"" + $url + "\">";
    		
    		for (var prop in $param) {
        		formHtml += "<input type=\"hidden\" name=\"" + prop + "\" value=\"" + $param[prop] + "\">";
    		}
    		
    		formHtml += "</form>";
    		
    		$(formHtml).appendTo('body').submit();
    		$('#redirectUrlFrm').remove();
    		
    	} else {
    		location.href = $url;
    	}
		
    },
	/* alert, confirm 등등 모음 패키지 */
	msg : {
		/**
		 * mydataCommon.msg.alert({ msg : "학습과정 변경시 기존 학습진도는<br>초기화 됩니다", checkBtnText : "예", callBackFn : function(isConfirm){}});
		 * checkBtnText : 디폴트 "확인"
		 * callBackFn : 필요시 확인 버튼 클릭후 동작할 스크립트 정의
		 */
		alert : function(paramJson){
			var confirmObj = $("#modal_alert");
			if(confirmObj.length > 0){
				
			}else{
				var htmlString = "";
				/*
				htmlString += '	<div id="mydataCommon_alert" class="modal-dim">';
				htmlString += '		<section class="modal-container" tabindex="0" role="dialog">';
				//htmlString += '			<button type="button" class="btn-close _close"><span>닫기</span></button>';
				//htmlString += '			<div class="modal-head">';
				//htmlString += '				<h1 class="head-title" data-text="title"></h1>';
				//htmlString += '			</div>';
				htmlString += '			<div class="modal-body">';
				htmlString += '				<div class="modal-body-container">';
				htmlString += '					<p class="txt-c text-16" data-html="msg"></p>';
				htmlString += '				</div>';
				htmlString += '			</div>';
				htmlString += '			<div class="modal-footer">';
				//htmlString += '				<button type="button" class="btn pop primary btn-gray _cancle"><span data-text="cancleBtnText">취소</span></button>';
				htmlString += '				<button type="button" class="btn pop primary _confirm"><span>변경</span></button>';
				htmlString += '			</div>			';
				htmlString += '		</section>';
				htmlString += '	</div>';
				$("body:eq(0)").append(htmlString);
				*/
				
				htmlString +='<article class="modal-popup popup-alert" id="modal_alert">';
				htmlString +='<div class="dimmed"></div>';
				htmlString +='<div class="modal-wrap">';  
				htmlString +='<div class="modal-header sr-only">';  
				htmlString +='<div class="modal-title">';  
				htmlString +='<h1 data-html="msghd"></h1>';  
				htmlString +='</div>';  
				htmlString +='</div>';								
				htmlString +='    <div class="modal-body">';
				htmlString +='        <p class="fs-md fw-m" data-html="msg"></p>';
				htmlString +='        <p class="fc-gray-dark mt10" data-html="msg2"></p>';
				htmlString +='    </div>';
				htmlString +='    <div class="modal-footer">';
				htmlString +='        <div class="btn-wrap no-gap">';                            
				htmlString +='            <button type="button" class="btn-footer navy _confirm">확인</button>';
				htmlString +='        </div>';
				htmlString +='    </div>';
				htmlString +='</div>';
				htmlString +='</article>';
				$("body:eq(0)").append(htmlString);
				
				confirmObj = $("#modal_alert");
			}
			
			if(paramJson.msg != null){
				paramJson.msg = paramJson.msg.replace(/\n/g, "<br>");	
			}else{
				paramJson.msg = "";
			}
			
			if(paramJson.msg2 != null){
				paramJson.msg2 = paramJson.msg2.replace(/\n/g, "<br>");	
			}else{
				paramJson.msg2 = "";
			}

			var checkBtnText = paramJson.checkBtnText || "확인";
			confirmObj.find("._confirm").text(checkBtnText);
			//메세지 및 타이틀 데이터 바인딩
			mydataCommon.setDataBinding({target : confirmObj, data : paramJson});
			//모달 방식 메세지 박스 보이기 처리
			confirmObj.addClass("is-open");
			
			//이벤트 바인딩
			$("#modal_alert ._confirm").off("click").on("click", function(){
				confirmObj.removeClass("is-open");
				if(typeof paramJson.callBackFn  === "function"){
					paramJson.callBackFn(true);
				}				
			});	
			
			
			//alert(paramJson.msg);
			//if(typeof paramJson.callBackFn  === "function"){
			//	paramJson.callBackFn();
			//}
		},
		/**
		 * mydataCommon.msg.confirm({title : "학습과정 변경", msg : "학습과정 변경시 기존 학습진도는<br>초기화 됩니다.<br>변경하시겠습니까?", callBackFn : function(isConfirm){}});
		 */
		confirm : function(paramJson){
			var confirmObj = $("#mydataCommon_confirm");
			if(confirmObj.length > 0){
				
			}else{
				var htmlString = "";
				/*
				htmlString += '	<div id="mydataCommon_confirm" class="modal-dim">';
				htmlString += '		<section class="modal-container" tabindex="0" role="dialog">';
				//htmlString += '			<button type="button" class="btn-close _close"><span>닫기</span></button>';
				htmlString += '			<div class="modal-head">';
				htmlString += '				<h1 class="head-title" data-text="title"></h1>';
				htmlString += '			</div>';
				htmlString += '			<div class="modal-body">';
				htmlString += '				<div class="modal-body-container">';
				htmlString += '					<p class="txt-c text-16" data-html="msg"></p>';
				htmlString += '				</div>';
				htmlString += '			</div>';
				htmlString += '			<div class="modal-footer">';
				htmlString += '				<button type="button" class="btn pop primary btn-gray _cancle"><span data-text="cancleBtnText">취소</span></button>';
				if(paramJson.confirmBtnHtml){
					htmlString += paramJson.confirmBtnHtml;
				}else{
					htmlString += '				<button type="button" class="btn pop primary"><span class="_confirm">확인</span></button>';
				}
				htmlString += '			</div>			';
				htmlString += '		</section>';
				htmlString += '	</div>';
				*/
				htmlString +='<article class="modal-popup popup-alert" id="mydataCommon_confirm">';
				htmlString +='<div class="dimmed"></div>';
				htmlString +='<div class="modal-wrap">';   
				htmlString +='<div class="modal-header sr-only">';  
				htmlString +='<div class="modal-title">';  
				htmlString +='<h1 data-html="msghd"></h1>';  
				htmlString +='</div>';  
				htmlString +='</div>';  
				htmlString +='    <div class="modal-body">';
				htmlString +='        <h3 data-html="msg"></h3>';
				htmlString +='        <p class="mt10" data-html="msg2"></p>';
				htmlString +='    </div>';
				htmlString +='    <div class="modal-footer">';
				htmlString +='        <div class="btn-wrap no-gap">';                            
				htmlString +='            <button type="button" class="btn-footer sm _cancle">취소</button>';
				htmlString +='            <button type="button" class="btn-footer navy _confirm">확인</button>';
				htmlString +='        </div>';
				htmlString +='    </div>';
				htmlString +='</div>';
				htmlString +='</article>';
				
				$("body:eq(0)").append(htmlString);
				
				confirmObj = $("#mydataCommon_confirm");
			}
			
			var cancleBtnText = paramJson.cancleBtnText || "취소";
			var confirmBtnText = paramJson.confirmBtnText || "확인";
			confirmObj.find("._cancle").text(cancleBtnText);
			if(paramJson.confirmBtnHtml == null){	
				confirmObj.find("._confirm").text(confirmBtnText);
			}	
			
			if(paramJson.msg != null){
				paramJson.msg = paramJson.msg.replace(/\n/g, "<br>");	
			}else{
				paramJson.msg = "";
			}
			
			if(paramJson.msg2 != null){
				paramJson.msg2 = paramJson.msg2.replace(/\n/g, "<br>");	
			}else{
				paramJson.msg2 = "";
			}
			
			//메세지 및 타이틀 데이터 바인딩
			mydataCommon.setDataBinding({target : confirmObj, data : paramJson});
			//모달 방식 메세지 박스 보이기 처리
			confirmObj.addClass("is-open");
			
			//이벤트 바인딩
			$("#mydataCommon_confirm ._cancle").off("click").on("click", function(){					
				confirmObj.removeClass("is-open");
				if(typeof paramJson.callBackFn  === "function"){
					paramJson.callBackFn(false);
				}					
			});	
			$("#mydataCommon_confirm ._confirm").off("click").on("click", function(){
				confirmObj.removeClass("is-open");
				if(typeof paramJson.callBackFn  === "function"){
					paramJson.callBackFn(true);
				}					
			});	
			$("#mydataCommon_confirm ._close").off("click").on("click", function(){
				confirmObj.removeClass("is-open");
			});	
		}
	},	
	
	/* 공통 진입부 함수 */
	init : function(){
		mydataCommon.eventBind();
	},
	/* 공통 이벤트 바인딩 함수 */
	eventBind : function(){
		//@copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		var $loader_box = $('#loader_box');
		
		$(window)
		.ajaxStart(() => $loader_box.show())
		.ajaxStop(() => $loader_box.hide())
		.ajaxError((evt, jqxhr, settings, err) => {
			$loader_box.hide();
		});
	},
	/* tab관련 모음 패키지 */
	tab : {
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 대상 Tab 래핑 div 요소
		 * @param {function} [<b>paramJson.moveTabCallBackFn=null</b>] tab이동시 실행할 콜백 구현부를 셋하여주며, 화면에서 사용자가 Tab이동시 해당 함수를 실행시켜준다.
		 * @param {number} [<b>paramJson.index</b>] 이동할 Tab index번호
		 * @returns {void}
		 * @description Tab을 이동시킨다.
		 * @example
		 * <pre>
			mydataCommon.tab.goTab({target : tabsAlltWrapObj, index : 0, moveTabCallBackFn : function(result){
				var iframeObj = result.currContentsObj.find("iframe");
				if(mydataCommon.util.isNull(iframeObj.attr("src"))){
					var pdfUrl = apiUrl+encodeURIComponent("https://file.funddoctor.co.kr:444/app/file_download.asp?memb_cd=7450&pfund_cd="+stk_code+"&file_gb=R3");
					if(result.tabIndex == 0){
						iframeObj.prop("src", pdfUrl);
					}else if(result.tabIndex == 1){
						iframeObj.attr("src", pdfUrl);
					}
				}
			}});
		 * </pre>
		 */	
		goTab : function(paramJson){
			//
			paramJson.target.data("moveTabCallBackFn", paramJson.moveTabCallBackFn);
			//
			if(!paramJson.initMode){
				paramJson.target.find(".sviewTabs li:eq("+paramJson.index+")").trigger("click");		
			}
		}
	},	
	/* 각종 유틸관련 모음 패키지 */
	util : {
		/**
		 * @copyright 
		 * @example mydataCommon.util.getCookie(cname);
		 */
		getCookie : function(cname) {
			var name = cname+"=";
			var ca = document.cookie.split(";");
			for(var i=0 ; i<ca.length ; i++){
				var c = ca[i];
				while(c.charAt(0)==' ')c=c.substring(1);
				if(c.indexOf(name) != -1)return c.substring(name.length,c.length);
			}
			return "";
		},
		/**
		 * @copyright 
		 * @example mydataCommon.util.setCookie(cname,cvalue,term);
		 */
		setCookie : function(cname,cvalue,expiredays) {
			var todayDate = new Date();
			todayDate = new Date(parseInt(todayDate.getTime()/86400000)*86400000+54000000);
			if(todayDate > new Date() ){
				expiredays = expiredays -1;
			}
			todayDate.setDate(todayDate.getDate() + expiredays);
			var expires = "expires="+todayDate.toGMTString();
			document.cookie = cname+"="+cvalue+"; path=/;" + expires;
		},
		/**
		 * @copyright 
		 * @example mydataCommon.util.clibBoard(data);
		 */
		clibBoard : function(param) {
			var inp = document.createElement("input");
			inp.setAttribute("id","copy");
			document.body.appendChild(inp);
			inp.value = param;
			inp.select();
			document.execCommand('Copy');
			document.body.removeChild(inp);
			mydataCommon.appBridge.openToast("계좌 번호를 복사 하였습니다.");
		},
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @example mydataCommon.util.isNull("");
		 */
		isNull : function(param) {
			var returnValue = false;
			if(typeof param == "string"){
				param = mydataCommon.util.nvl(param);
				if(param == "" || param == "null" || param == "undefined" || param == null || param == undefined){
					returnValue = true;
				}
			}else{
				if(typeof param == "undefined" || typeof param == "null" || param == null){
					returnValue = true;
				}
			}
			return returnValue;
		},
		//mydataCommon.util.nvl();
		nvl : function(paramOrg, changeStr) {
			var returnValue = "";
			var tempValue = "";
			if(typeof changeStr == "string"){
				tempValue = changeStr;
			}
			//console.log(typeof paramOrg)
			if(typeof paramOrg == "string"){
				if(paramOrg == "null" || paramOrg == "undefined" || paramOrg == null || paramOrg == undefined|| paramOrg == "" ){
					returnValue = tempValue;
				}else{
					returnValue = paramOrg.trim();
				}
			}else if(typeof paramOrg == "number"){
				if(paramOrg == "null" || paramOrg == "undefined" || paramOrg == null || paramOrg == undefined){
					returnValue = tempValue;
				}else{
					returnValue = (paramOrg+"").trim();
				}
			}else{
				if(typeof paramOrg == "undefined" || typeof paramOrg == "null" || paramOrg == null || paramOrg == undefined || paramOrg == "nvl"    || paramOrg == NaN || paramOrg == "NaN"){
					returnValue = tempValue;
				}else{
					try{
						if(typeof paramOrg === "object" && paramOrg.get){
							returnValue = $(paramOrg).val();							
						}else{
							if(typeof paramOrg === "object" && paramOrg.val){
								returnValue = paramOrg.val();
							}else{
								returnValue = paramOrg	
							}
						}
					}catch(e){
						returnValue = paramOrg;
						//console.log(e);
					}
				}
			}
			return returnValue;
		},
		lpad :  function(valueStr, character, digit) {
			valueStr += "";
		    if (!character || valueStr.length >= digit) {
		        return valueStr;
		    }
		 
		    var max = (digit - valueStr.length)/character.length;
		    for (var i = 0; i < max; i++) {
		        valueStr = character + valueStr;
		    }
	
		    return valueStr;
		},
		rpad :  function(valueStr, character, digit) {
			valueStr += "";
		    if (!character || valueStr.length >= digit) {
		        return valueStr;
		    }
		 
		    var max = (digit - valueStr.length)/character.length;
		    for (var i = 0; i < max; i++) {
		        valueStr =  valueStr + character;
		    }
	
		    return valueStr;
		},		
		isNumber : function(str) {
			str = $.trim(str);
			if(mydataCommon.util.isNull(str) || isNaN(str)){
				return false;
			}
			return true;
		},
		//파라미터로 넘어온 배열의 값을 중복배제(distinct)한 새로운 배열을 만들어 리턴한다.  
		getArrayByDistinct : function(paramArray){
			var uniq = paramArray.reduce(function(a, b){
				if(a.indexOf(b) < 0)
					a.push(b);
				return a;
			}, []);
			return uniq;
		},
		//array를 정렬 시켜준다.
		sort : function(paramArrayObj, key, isDesc){
			//배열타입
			if(key == null){
				if(isDesc){
					paramArrayObj.sort(function(a, b) { // 내림차순
					    return b - a;
					});					
				}else{
					/* 정상 동작 */
					paramArrayObj.sort(function(a, b) { // 오름차순
					    return a - b;
					});					
				}
			//오브젝트 타입(디폴트)
			}else{
				if(isDesc){
					paramArrayObj.sort(function(a, b) { // 내림차순
					    return a[key] > b[key] ? -1 : a[key] < b[key] ? 1 : 0;
					});				
				}else{
					paramArrayObj.sort(function(a, b) { // 오름차순
					    return a[key] < b[key] ? -1 : a[key] > b[key] ? 1 : 0;
					});					
				}				
			}
		
		},
		//이야기 맞게 소수점 절삭 (절삭시 의미없는 소수 0은 표기하지 않음 )
		roundNumber : function(num, scale){
			if(!("" + num).includes("e")){
				return +(Math.round(num + "e+" + scale) + "e-" + scale);
			}else{
				var arr = ("" + num).split("e");
				var sig = ""
				if(+arr[1] + scale > 0){
					sig = "+";
				}
				return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
			}
		},
		
		//모바일 여부 체크
		mobilecheck : function(){
		    if(navigator.userAgent.match(/Android/i)
		    || navigator.userAgent.match(/webOS/i)
		    || navigator.userAgent.match(/iPhone/i)
		    || navigator.userAgent.match(/iPad/i)
		    || navigator.userAgent.match(/iPod/i)
		    || navigator.userAgent.match(/Blackberry/i)
		    || navigator.userAgent.match(/Windows Phone/i)
		    ) return true;
		},
		/**
		 * @description 영문 한글에 따른 byte값으로 length를 리턴 (자리수 제약시 영문 한글 구분하여 제약할때 사용)
		 * @param paramStr
		 * @return {int}
		 */
		byteCheck : function(paramStr){
			paramStr = paramStr || "";
		    var codeByte = 0;
		    for(var idx = 0; idx < paramStr.length; idx++){
		        var oneChar = escape(paramStr.charAt(idx));
		        if(oneChar.length == 1){
		           codeByte ++; 
		        }else if(oneChar.indexOf("%u") != -1){
		            codeByte += 2;
		        }else if(oneChar.indexOf("%") != -1){
		            codeByte ++;
		        }
		    }
		    return codeByte;
		},
		/**
		 * @description 아라비아 숫자에 해당하는 한글표현으로 리턴한다.
		 * mydataCommon.util.numberToHangul({type:'1',val:'11111'});
		 * "1만1111원"
		 */
		numberToHangul : function(paramJson){
			if(paramJson.type == "1"){
				var num_value = paramJson.val + "";
				var num_length = num_value.length;				
				var unitCnt = Math.ceil(num_length / 4);//단위갯수
				var unitValueS = [];//단위별 값
				var num_value_code = mydataCommon.util.lpad(num_value, "0", unitCnt * 4);
				var fullNumber = "";
				var unit = new Array("", "만", "억", "조", "경", "해");
				for(var i=0; i<unitCnt; i++){
					var index = i * 4;
					unitValueS.push(num_value_code.substring(index, (index+4)));
					
				}
				for(var i=0; i<unitValueS.length; i++){
					if(Number(unitValueS[i]) > 0){
						fullNumber += Number(unitValueS[i]) + unit[(unitValueS.length-1) - i];	
					}
				}
				return (fullNumber == "" ? "0" : fullNumber) + "원";
			}
		},
		/**
		 * @description 엘리먼트의 특정 속성값을 리턴한다 옵션에따라 숫자로도 리턴
		 * @example
		 * var style1 = divObj1.attr("style").split(";");
		 * var width = mydataCommon.util.propParse({style : style1, prop : "width", isReturnNumber : true});
		 */
		propParse : function(paramJson){
			var returnValue = null;
			$(paramJson.style).each(function(){
				var propA = (this || "").split(":");
				if((propA[0] || "").trim().toLowerCase() == paramJson.prop){
					if(paramJson.isReturnNumber){
						returnValue = Number((propA[1] || "").replace(/[^0-9\.]/g, ""));	
					}else{
						returnValue = propA[1];
					}
				}
			});
			return returnValue;
		},
		//param값(숫자타입 문자든 number이든 을 무조건 number로 리턴한다.
		//mydataCommon.util.getNumber(str);
		getNumber : function(param){
			var retrunVal = 0;
			if(mydataCommon.util.isNumber(param)){
				if(typeof param === "number"){
					retrunVal = param;
				}
				if(typeof param === "string"){
					retrunVal = parseInt(param.replace(/[^0-9\.]/g, "") || "0");
				}			
			}
			if(typeof param === "string"){
				retrunVal = parseInt(param.replace(/[^0-9\.]/g, "") || "0");
			}			
			return retrunVal;
		},
		addComma: function(numberStr){
			if(numberStr == '' || numberStr == '0' || numberStr == 0) return numberStr;
			if(numberStr == 'undefined' || numberStr == null || numberStr == undefined) return '0';
			
		    	if (numberStr) {
		    		numberStr += '';
		    		numberStr = numberStr.substring(0, 1) == '0' ? numberStr.substring(1) : numberStr;
					var parts = numberStr.toString().split('.');
					parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					if(numberStr.indexOf('.')!==-1){
						parts[0] = parts[0]==='' ? '0' : parts[0];
					}
					return parts.join('.') == '' ? '0' : parts.join('.');
			    } else {
			    	return numberStr;
			    }
		},
		getPrice : function(numberStr, roundNum) {
			if(numberStr === '' || numberStr === '0' || numberStr === 0) return numberStr;
			if(numberStr === 'undefined' || numberStr === null || numberStr === undefined) return '0';
			
		    	if (numberStr) {
		    		if(roundNum) {
		    			numberStr = Number(Number(numberStr).toFixed(roundNum));		// 외화
		    		} else {
		    			//마이너스 금액에 대해서는 "-"문자를 삭제 ->"-"표시는 addComma 사용
		    			numberStr = mydataCommon.util.getNumber(numberStr);		// 원화
		    			numberStr += '';
		    		}
		    		//numberStr 		= numberStr.substring(0, 1) == '0' ? numberStr.substring(1):numberStr;
					var parts 		= numberStr.toString().split('.');
					parts[0] 		= parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					return parts.join('.') == '' ? '0' : parts.join('.');
			    } else {
			    	return numberStr;
			    }
		},
		addComma_fx: function(numberStr){
			if(numberStr == '' || numberStr == '0' || numberStr == 0) return numberStr;
			if(numberStr == 'undefined' || numberStr == null || numberStr == undefined) return '0';
			
		    	if (numberStr) {
		    		numberStr += '';
					var parts = numberStr.toString().split('.');
					parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					return parts.join('.') == '' ? '0' : parts.join('.');
			    } else {
			    	return numberStr;
			    }
		},
		consoleOut : function(body, name, param){
			//if(pageCom.prop.isLocal) {
			if(location.href.indexOf('local') > -1) {
				if(name) {
					console.group('============================='+name+'=====================================');
				}
				if(param) {
					if(param instanceof Object) {
						console.table(param);
					} else {
						console.info(param);
					}
				}
				if(body instanceof Object) {
					console.table(body);
				} else {
					console.info(body);
				}
				if(name) {
					console.groupEnd();
				}
			}
		},
		getBeforeDate : function(per, diffCnt){
			if ( per 	 == null || per 	== undefined ) return mydataCommon.util.getStrDate();
			if ( diffCnt == null || diffCnt == undefined ) return mydataCommon.util.getStrDate();
			
			var toDt = new Date();
			if ( per == 'D' ){
				toDt.setDate(toDt.getDate()-diffCnt);
			}else if ( per == 'M' ){
				toDt.setMonth(toDt.getMonth()-diffCnt);
			}else if ( per == 'Y' ){
				toDt.setFullYear(toDt.getFullYear()-diffCnt);
			}
			
			var strDate	= '' + toDt.getFullYear() 
			  + (toDt.getMonth() < 9 ? '0':'') + (toDt.getMonth() + 1) 
			  + (toDt.getDate() < 10 ? '0':'') + toDt.getDate();
			
			return strDate;
		},
		getFirstDay : function(str, seper){
			var strDate = '';
			if ( $.isEmptyObject(str) ){
				var toDt= new Date();
				var firstDate =new Date(toDt.getYear(), toDt.getMonth(), 1);
				strDate	= '' + toDt.getFullYear() 
				  + (firstDate.getMonth() < 9 ? '0':'') + (firstDate.getMonth()+1) 
				  + (firstDate.getDate()  < 9 ? '0':'') + firstDate.getDate();
			}else{
				if ( $.isEmptyObject(seper) ){
					seper = '.'; 
				}
				if ( str.length == 14 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12) + ':'
							+ str.substring(12,14);
				}else if ( str.length == 12 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12);
				}else if ( str.length == 10 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10);
				}else if ( str.length == 8 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8);
				}else if(str.length == 6){
					strDate = str.substring(0,4) + seper 
					+ str.substring(4,6) 

				}else{
					return str;
				}
			}
			return strDate;
		},
		getLastDay : function(str, seper){
			var strDate = '';
			if ( $.isEmptyObject(str) ){
				var toDt= new Date();
				var lastDate =new Date(toDt.getYear(), toDt.getMonth()+1, 0);
				strDate	= '' + toDt.getFullYear() 
				  + (lastDate.getMonth() < 9 ? '0':'') + (lastDate.getMonth()+1) 
				  + (lastDate.getDate()  < 9 ? '0':'') + lastDate.getDate();
			}else{
				if ( $.isEmptyObject(seper) ){
					seper = '.'; 
				}
				if ( str.length == 14 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12) + ':'
							+ str.substring(12,14);
				}else if ( str.length == 12 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12);
				}else if ( str.length == 10 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10);
				}else if ( str.length == 8 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8);
				}else if(str.length == 6){
					strDate = str.substring(0,4) + seper 
					+ str.substring(4,6) 

				}else{
					return str;
				}
			}
			return strDate;
		},
		getStrDate : function(str, seper){
			var strDate = '';
			if ( $.isEmptyObject(str) ){
				var toDt= new Date();
				strDate	= '' + toDt.getFullYear() 
				  + (toDt.getMonth() < 9 ? '0':'') + (toDt.getMonth() + 1) 
				  + (toDt.getDate() < 10 ? '0':'') + toDt.getDate();
			}else{
				if ( $.isEmptyObject(seper) ){
					seper = '.'; 
				}
				if ( str.length == 14 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12) + ':'
							+ str.substring(12,14);
				}else if ( str.length == 12 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10) + ':'
							+ str.substring(10,12);
				}else if ( str.length == 10 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8) + ' '
							+ str.substring(8,10);
				}else if ( str.length == 8 ){
					strDate = str.substring(0,4) + seper 
							+ str.substring(4,6) + seper
							+ str.substring(6,8);
				}else if(str.length == 6){
					strDate = str.substring(0,4) + seper 
					+ str.substring(4,6) 

				}else{
					return str;
				}
			}
			return strDate;
		},
		getStrTime : function(seper){
			//현재시간 문자열 반환 (hh:mi:ss)
			//seper : 시간 구분자, 기본은 빈값
			seper = seper==null && seper==undefined ? '' : seper;
			
			var now = new Date();
			var v_hour = mydataCommon.util.lpad(now.getHours(), '0', 2);
			var v_min = mydataCommon.util.lpad(now.getMinutes(), '0', 2);
			var v_sec = mydataCommon.util.lpad(now.getSeconds(), '0', 2);
			
			return v_hour + seper + v_min + seper + v_sec;
		},
		getRateSign : function(str){
			if ( parseFloat(str) == 0 ){
				return str;
			}else if ( parseFloat(str) > 0 ){
				return '<span style="color:red;">▲ ' + str + '%</span>'; 
			}else if ( parseFloat(str) < 0 ){
				return '<span style="color:blue;">▼ ' + str + '%</span>';
			}
		},
		getRateSign2 : function(str){
			if ( parseFloat(str) == 0 ){
				return str;
			}else if ( parseFloat(str) > 0 ){
				return '<span style="color:red;">+' + str + '</span>'; 
			}else if ( parseFloat(str) < 0 ){
				return '<span style="color:blue;">-' + str + '</span>';
			}
		},
		removeComma: function(numberStr) {
			if(numberStr == '' || numberStr == '0') return numberStr;
			if(numberStr == 'undefined') return '0';
			return (numberStr.replace(/\,/g,""));
		},
		chk_isEmpty : function(obj){
			if ( obj == null || obj == undefined ){
				return true;
			}else{
				if ( typeof(obj) == 'string' && obj == '' ){
					return true;
				}
			}
			return false;
		},
		replace : function(data){
			return data.replace(/&#40;/g,'(');
		},
		setData : function(key,value){
			if(window.localStorage){
				localStorage.setItem(key,value);
			}else{
				alert('미지원');
			}
		},
		getData : function(key){
			return localStorage.getItem(key);
		},
		setArrayData : function(key,arrayValue){
			if(window.localStorage){
				localStorage.setItem(key,JSON.stringify(arrayValue));
			}else{
				alert('미지원');
			}
		},		
		getArrayData : function(key){
			return JSON.parse(localStorage.getItem(key));
		},
		removeData : function(key){
			return localStorage.removeItem(key);
		},
		removeAllData : function(){
			return localStorage.clear();
		},
		getSimpleBanner : function(obj){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/common/SComBann001001Ajax",
					data : obj,
					async : true,
					success : function(res) {
						render(res);
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					},
			}
			
			mydataCommon.ajax(jsonObj);
			
			var render = function(res) {
				var rslt = res.resultMap;
				var localImg = '/resources/images/banners/banner_sample.png';
				
				if(rslt.resp_gubn !== "0") return;
				
				var g1 = rslt.g1;
				
				g1.forEach( function(item) {
					var bannerHtml = "";
					// 로컬에서는 이미지가 뜨지 않아 추가한 코드
					var imag_url = pageCom.prop.isLocal ? localImg : item.imag_url;
					var banr_exps_lctn_no = parseInt(item.banr_exps_lctn_no);
					
					$("[data-mcode]").map( function() {
						var mcode = parseInt( $(this).data("mcode") );
						
						if(mcode === banr_exps_lctn_no) { //rslt.banr_exps_lctn_no
							bannerHtml += '<section class="module-box type-gray" style="order:' + this.style.order + '">';
							bannerHtml += '    <h3 class="sr-only">배너</h3>';
							bannerHtml += '    <a href="' + item.banr_url + '">';
							bannerHtml += '        <img src="'+ imag_url +'" alt="" >';
							bannerHtml += '    </a>';
							bannerHtml += '</section>';
							
							$(this).after(bannerHtml);
							return false; // break;
						}
					});			
				})
			}
		},
		getSlideBanner : function(obj){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/common/SComBann001001Ajax",
					data : obj,
					async : true,
					success : function(res){
						var rslt = res.resultMap;
						if(rslt.resp_gubn == "0"){
							rslt.banr_exps_lctn_no													
							var tmpID = rslt.imag_url+"";
							if(tmpID.indexOf('.')>-1)tmpID = tmpID.substring(0,tmpID.indexOf('.'));
							var bannerHtml = '<article class="modal-popup bottomsheet no-handle" id="bottomsheet">';
							bannerHtml+=' <div class="dimmed"></div>';
							bannerHtml+='<div class="modal-wrap">';
							bannerHtml+='<div class="modal-body p0">';
							bannerHtml+='<img src="/resources/images/common/img_myd_001_0001_p003.png" alt="진입 이벤트 이미지">';
							//bannerHtml+='<img src="/resources/images/banner/'+rslt.imag_url+'" id="imgLnk"></div>';	
							bannerHtml+='</div>';
							bannerHtml+='<div class="modal-footer">';
							bannerHtml+='<div class="btn-wrap no-gap">';
							bannerHtml+='<button type="button" class="btn btn-footer btn-gray" id="'+tmpID+'">오늘 하루 동안 보지 않기</button>';
							bannerHtml+='<button type="button" class="btn btn-footer" id="sbClose">닫기</button>';
							bannerHtml+='</div>';
							bannerHtml+='</div>';
							bannerHtml+='</div>';
							bannerHtml+='</article>';						
								
							$("body").append(bannerHtml);
							
							var cookieData = document.cookie;
							if(cookieData.indexOf(tmpID+"=Y")<0)$("#bottomsheet").addClass("is-open"); 
							
							$("#imgLnk").off("click").on("click",function(){
								//alert("배너link="+rslt.banr_url);
							});
							
							$("#sbClose").off("click").on("click",function(){
								$("#bottomsheet").removeClass("is-open");
							});
							$("#"+tmpID).off("click").on("click",function(){
								mydataCommon.util.setCookie(tmpID,"Y",1);
								$("#bottomsheet").removeClass("is-open");
							});
						}
						mydataCommon.util.consoleOut(res.resultMap, "getBanner1");					
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
					
			}
			mydataCommon.ajax(jsonObj);
		},
		getRollingBanner: function(obj) {
	        var jsonObj = {
	            url: pageCom.prop.contextPath + "/common/SComBann001002Ajax",
	            data: obj,
	            async: true,
	            success: function(res) {
	                render(res);
	            },
	            error: function(e1, e2, e3) {
	                mydataCommon.msg.alert({
	                    msg: "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."
	                });
	            }
	        }

	        mydataCommon.ajax(jsonObj);

	        var render = function(res) {
	            var rslt = res.resultMap;
	            var outerElement = obj.elementId;
	            var innerElementId = '#swiper05';
	            var selecter = outerElement + ' ' + innerElementId;

	            if ($(outerElement).length === 0) {
	                mydataCommon.util.consoleOut('엘리먼트를 찾을 수 없습니다 롤링배너를 표시할 수 없습니다')
	                return;
	            }

	            if (rslt.resp_gubn !== '0') {
	                mydataCommon.util.consoleOut('롤링배너 : ' + rslt.resp_mesg)
	                return;
	            }

	            remakeList(rslt);

	            var htmlString = makeHtml(rslt, innerElementId);

	            $(outerElement).html(htmlString);

	            KW_MOBILE.guiEvent.swiper.runSwiper(selecter, true, 40);
	            onClickEventBindForBtn(selecter);
	        }

	        var remakeList = function(rslt) {
	            var list = rslt.g1;

	            list.forEach(function(item) {
	                var btn_cnt = parseInt(item.btn_cnt);
	                Array.from(Array(btn_cnt)).forEach(function(_, i) {
	                    if (item.btns === undefined)
	                        item.btns = [];

	                    item.btns[i] = {
	                        inpt_msg: item['th0' + (i + 1) + '_btn_inpt_msg'],
	                        url: item['th0' + (i + 1) + '_btn_url']
	                    }
	                });
	            });
	        }

	        var makeHtml = function(rslt, innerElementId) {
	            var defaultImg = '/resources/images/banners/banner_bnk02.png';
	            var htmlString = '';
	            var list = rslt.g1;
	            var swiperId = innerElementId.startsWith('#') ? innerElementId.replace('#', '') : innerElementId;

	            htmlString += '<div class="module-body">';
	            htmlString += '    <!-- swiper -->';
	            htmlString += '    <div class="swiper-container custom-swiper w-full px-padding2 mt20" id="' + swiperId + '">';
	            htmlString += '        <div class="swiper-wrapper">';

	            list.forEach(function(item, i) {
	                var img = pageCom.prop.isLocal ? defaultImg : item.imag_url;

	                htmlString += '<!-- Slide ' + (i + 1) + ' -->';
	                htmlString += '<div class="swiper-slide">';
	                htmlString += '    <h3>';
	                htmlString += item.myd_evnt_nm;
	                htmlString += '    </h3>';
	                htmlString += '    <p class="fc-gray-dark fs-md mb10 mt20">';
	                htmlString += item.myd_evnt_dscr;
	                htmlString += '    </p>';
	                htmlString += '    <a href="#;">';
	                htmlString += '        <img src="' + img + '" alt="">';
	                htmlString += '    </a>';
	                htmlString += '    <div class="btn-wrap flex-column footer">';

	                item.btns.forEach(function(btn, j) {
	                    htmlString += '        <button type="button" class="btn-module" data-url="' + btn.url + '">';
	                    htmlString += btn.inpt_msg;
	                    htmlString += '        </button>';
	                })

	                htmlString += '    </div>';
	                htmlString += '</div>';
	            });

	            htmlString += '        </div>';
	            htmlString += '        <div class="swiper-pagination"></div>';
	            htmlString += '    </div>';
	            htmlString += '</div>';

	            return htmlString;
	        }

	        var onClickEventBindForBtn = function(selecter) {
	            var $objArr = $(selecter).find('button');

	            $objArr.on('click', function(e) {
	                var url = e.target.dataset.url;
	                location.href = url;
	            });

	        }
	    }, // end getRollingBanner
		htmlDecode : function(txt){
			var result = '';
			if (txt) {
				result = $('<div />').html(txt).text();
			}
			return result;
		},
		//동적 생성된 개체에 사용
		//document 에 이벤트를 걸어서, 이벤트 적용 대상이 현시점에 없고 추후에 대상 객체가 등록되어도, 
		//객체가 추가 된 시점에 동작하도록, 이벤트를 감시 바인딩 시킴.
		//mydataCommon.util.eBind('click','#target',function(e, obj){ //todo });
		eBind : function(eventStr,targetStr,callbackFunc){
			if(eventStr && targetStr && callbackFunc){
				$(document).on(eventStr, targetStr, function(e) {
					$(document).off(eventStr, targetStr, e);
					
					callbackFunc(e, this);
				});	
			}
		},
		//input(text|number) 입력박스에, 키 입력시 앱 키패드 호출 하도록 클릭 이벤트 바인드 함수.
		//대상 다수 인풋박스들 이벤트 바인드 적용.
		//결과값 받을때 해당 결과값 글자길이(개수)만큼 입력박스 길이값 자동 조절.
		//입력박스 change 이벤트 시, 현재 글자 길이만큼, 인풋의 가로길이값 조정. 처음에 value 에 셋팅된 글자 개수만큼 길이값 초기화(trigger('change') 최초 호출)
		//* 인풋박스 조건
		//- readonly 속성을 줘야함(그래야 기본 키패드 안뜸)
		//- maxLength 속성값 선택값
		//- 클래스 지정되어야 하고, 클래스 그룹의 인풋박스 별로 id(결과값 받을때) 값이 있어야함(필수).
		//- 인풋박스 별로, data-keypad_type="" 설정. 설정 안되면 기본값은 0번.
		//- 인풋박스 별로, (선택) minWidth="20", 글자길이별 변경 시, 최소 가로길이 제한
		//- 인풋박스 별로, (선택) maxWidth="20", 글자길이별 변경 시, 최대 가로길이 제한
		//* 파라미터
		//- targetStr : 필수, 초기화 대상 jquery target string
		//mydataCommon.util.setInputKeypad('.targetClass');
		setInputKeypad : function(targetStr){
			var cstNumCharWidth = 10;		//숫자 문자열 한글자 가로길이 상수 (0~9)
			var cstCmaCharWidth = 10;		//콤마 문자열 한글자 가로길이 상수 (,)
			var cstInputMinWidth = 50;	//인풋박스 가로 최소 사이즈 제한.
			var cstInputMaxWidth = 200;	//인풋박스 가로 최대 사이즈 제한.
			targetStr = targetStr ? $.trim(targetStr) : null;
			var $targetObjs = targetStr ? $(targetStr) : null;
			if(targetStr){
				mydataCommon.util.eBind('click',targetStr,function(e, obj){
					var $item = $(obj);
					var stype = $item.attr('type') ? $item.attr('type') : '';
					var skeypadType = $item.data('keypad_type') ? $item.data('keypad_type') : '0';
					var smaxLength = $item.attr('maxLength') ? $item.attr('maxLength') : '50';
					var srId = $item.attr('id') ? $item.attr('id') : '';
					if(stype=='text' || stype=='number' && srId){
						var datas = {
							keypadType : skeypadType,
							keypadValue : $item.val(),
							maxLength : smaxLength,
							rId : srId
						};
						mydataCommon.appBridge.openNumKeypad(datas, "mydataCommon.util.setInputKeypadCallback");
					}
				});
				mydataCommon.util.eBind('change',targetStr,function(e, obj){
					//글자 길이에 따른 입력박스 자동 길이조정 적용.
					var $inputObj = $(obj);
					var inputMinWidth = $inputObj.attr('minWidth') ? Number($inputObj.attr('minWidth')) : cstInputMinWidth;
					var inputMaxWidth = $inputObj.attr('maxWidth') ? Number($inputObj.attr('maxWidth')) : cstInputMaxWidth;
					var inputWidth = inputMinWidth;			//인풋박스 최소 가로사이즈
					var inputMaxWidth = 0;
					var sval = $inputObj.val();
					var svalLen = sval ? sval.length : 0;
					var numCharLen = 0;				//숫자 문자열 개수
					var cmaCharLen = 0;				//콤마 문자열 개수
					
					if(svalLen > 0){
						//글자수 카운트
						//['0','1','2','3','4','5','6','7','8','9'].indexOf('111') : 숫자 글자 카운트.
						for(var i=0;i<svalLen;i++){
							var schar = sval.substring(i,i+1);
							if(schar==','){
								cmaCharLen++;
							}else{
								numCharLen++;
							}
						}
						
						//글자개수에 따른 인풋박스 가로 사이즈 구하기.
						//콤마사이즈와 숫자문자 사이즈 별개 지정.
						inputWidth = (cstNumCharWidth * numCharLen) + (cstCmaCharWidth * cmaCharLen);
					}
					
					inputWidth = Math.min(inputWidth,inputMaxWidth);	//최대 입력박스 길이 제한
					inputWidth = Math.max(inputWidth,inputMinWidth);	//최소 입력박스 길이 제한
					
					$inputObj.width(inputWidth);
				});
				setTimeout(function(){
					$targetObjs.trigger('change');
				},30);
			}
		},
		//mydataCommon.util.setInputKeypad 함수로 앱 키패드를 띄운 후, 입력 결과값을 받을 때 앱에서 호출하는, 콜백함수.
		setInputKeypadCallback : function(jsonString){
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;
			var $tObj = rId ? $(rId) : null;
			if(rId && $tObj){
				nVal = mydataCommon.util.addComma(nVal);
				$tObj.val(nVal);
				$tObj.trigger('change');
			}
		},
		//input(text|number) 입력박스에, 키 입력시 콤마를 자동으로 붙이고(text만),
		//가로 사이즈가 글자 개수에 따라서 길이가 자동으로 변환되도록 초기화 하는 함수.
		//targetStr : 필수, 초기화 대상 jquery target string
		//charWidth : 선택, 문자한개 가로값
		//inputMinWidth : 선택, 입력 가로 최소값
		//inputMaxWidth : 선택, 입력 가로 최대값
		//initCallback : 선택, 대상 입력박스들 초기화 콜백함수, function($objs){ //$objs:대상입력박스들 개발 초기화 처리 }
		//extraOption : 선택, 기타 옵션, {initMsec:220,triggerMsec:310} 객체.
		//- extraOption.initMsec : 선택, 초기화 시 지연 시간, 기본값 200 밀리 세컨드
		//- extraOption.triggerMsec : 선택, 최초 이벤트 호출 지연시간, 기본값 300 밀리 세컨드
		//- extraOption.initTextAlign : 선택, 최초 입력박스 텍스트 정렬, 기본값 right, none 시 적용안됨.
		//mydataCommon.util.setInputComma('#txtInput1,#txtInput2,#numInput1,#numInput2');
		//mydataCommon.util.setInputComma('#txtInput1,#txtInput2,#numInput1,#numInput2',
		//		null,null,null,function($objs){
		//	console.info('callback init : ',$objs.length)
		//	$objs.each(function(idx,el){
		//		var $el = $(el);
		//		if(el.id=='txtInput1'){
		//			$el.css('background-color','yellow');
		//		}
		//		console.info('callback init obj('+idx+') : ',el)
		//	});
		//});
		setInputComma : function(targetStr,charWidth,inputMinWidth,inputMaxWidth,initCallback,extraOption){
			targetStr = targetStr ? $.trim(targetStr) : null;
			//선택옵션 기본값 설정
			charWidth = charWidth ? Number(charWidth) : 10;
			inputMinWidth = inputMinWidth ? Number(inputMinWidth) : 50;
			inputMaxWidth = inputMaxWidth ? Number(inputMaxWidth) : 200;
			extraOption = extraOption ? extraOption : {};
			extraOption.initMsec = extraOption.initMsec ? Number(extraOption.initMsec) : 200;
			extraOption.triggerMsec = extraOption.triggerMsec ? Number(extraOption.triggerMsec) : 300;
			extraOption.initTextAlign = extraOption.initTextAlign ? extraOption.initTextAlign : 'right';
			if(targetStr){
				setTimeout(function(){
					var $targetObjs = $(targetStr);
					if($targetObjs.length){
						if(extraOption.initTextAlign!=='none'){
							$targetObjs.css({'text-align':extraOption.initTextAlign});
						}
						if(initCallback){
							initCallback($targetObjs);
						}
					}
				},extraOption.initMsec);
				mydataCommon.util.eBind('keyup',targetStr,function(e, obj){
					var $item = $(obj);
					var stype = $item.attr('type') ? $item.attr('type') : '';
					if(stype=='text' || stype=='number'){
						if(stype=='text'){
							var sval = obj.value;
							sval = sval.replaceAll(' ','');
							sval = sval.replaceAll('\t','');
							sval = sval.replaceAll(',','');
							//문자막기 정규식으로 입력막기.
							sval = sval.replace(/[^0-9\.]/g, "");
							//입력숫자값에 콤마 붙이기.
							sval = mydataCommon.util.addComma(sval);
							obj.value = sval;
						}
						//min-size, max-size, max-length, 입력박스 길이자동조절(입력시마다)
						var nwidth = 0;
						nwidth = obj.value.length * charWidth;
						nwidth = Math.max(nwidth,inputMinWidth);
						nwidth = Math.min(nwidth,inputMaxWidth);
						/*console.info('nwidth : ',nwidth);
						console.info('charWidth : ',charWidth);
						console.info('obj.value.length : ',obj.value.length);*/
						if(nwidth){
							$item.width(nwidth);
						}
					}
				});
				setTimeout(function(){
					//템플릿 설정 등으로, 초기화 시점이 달라서, 초기화 텀을 setTimeout 으로 줌.
					var $targetObjs = $(targetStr);
					$targetObjs.trigger('keyup');
				},extraOption.triggerMsec);
			}
		},
		/**
		 * 환경 프로파일 체크
		 */
		isLoc: pageCom.prop.profile === 'loc' || ['localhost', '127.0.0.1', 'local.kiwoom.com'].includes(location.hostname) || location.hostname.startsWith('192.168'),
		isDev: pageCom.prop.profile === 'dev' || 'mdd.kiwoom.com' === location.hostname,
		isPrd: pageCom.prop.profile === 'prd',
	},
	
	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 * 좌우 슬라이드 1타입 동작을 적용시켜주는 클래스 모음
	 */
	slideX : {
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 대상 document성 area 영역  ex> 팝업의 경우 팝업 영역 DIV가 대상이됨
		 * @param {jQueryObject} [<b>paramJson.handle</b>] 슬라이드의 핸들바 오브젝트
		 * @param {jQueryObject} [<b>paramJson.range</b>] 슬라이드의 움직이는 범위 오브젝트
		 * @param {jQueryObject} [<b>paramJson.rangeState=null</b>] 슬라이드의 움직인 레인지를 수평으로 표기할 오브젝트
		 * @param {array} [<b>paramJson.movePointArray=null</b>] X축 슬라이드시 움직이는 위치를 N등분하여 움직이도록하며, 움직이는 위치에 해당하는 array의 값을 callBackFn함수로 리턴하여 준다.
		 * @param {number} [<b>paramJson.setDefault=null</b>] 기본으로 movePointArray 해당하하는 움직일 index 위치를 지정
		 * @param {number} [<b>paramJson.min=null</b>] 최소 움직임 제한 값 
		 * @param {number} [<b>paramJson.max=null</b>] 최대 움직임 제한 값
		 * @param {number} [<b>paramJson.oneMovePointCnt=null</b>] movePointArray 배열 길이에 따른 슬라이드에서 움직일수 있는 포인트(위치)가 정해지는데 이때 필요시 한번에 움직일 포인트를 지정할수 있다 
		 * <pre>
		 * 		예를들어  movePointArray=11 일때 슬라이드에서 움직일수 있는 위치는 0~10 포인트 위치인데 해당 설정상태에서만 슬라이드를 움직이면 1~10 포인트 만큼 움직이는데 
		 * 		이때  oneMovePointCnt=2을 지정하였다면 움직일때마다 2포인트씩 움직이게된다. 
		 * </pre>
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 슬라이드 동작시 또는 동작이 끝날경우 값을 리턴받아 처리할수 있다. 
		 * @returns {x : range오브젝트기준 x축좌표값, percent : 100%기준 포인트의 위치 percent값, index : 배열의 index값, value : 배열의값, returnType : 콜백함수 리턴시 움지이는 시점의 콜백인지 슬라이드 동작 끝난시점 콜백인지 구분하여 준다."}
		 * @description 좌우 슬라이드 동작을 적용 시켜준다.
		 * @example
		 * <pre>
			mydataCommon.slideX.apply({
				target : $("#targTerm_popup_2"),
				handle : $("#targTerm_popup_2 .ui-slider-handle"),
				range : $("#targTerm_popup_2 .ui-slider"),
				movePointArray : ["1년 미만", "1년", "2년", "3년", "4년", "5년", "6년", "7년", "8년", "9년", "10년 이상"],
				callBackFn : function(resJson){
					var targTermPopupObj = $("#targTerm_popup_2");
					var labelObj = targTermPopupObj.find(".circle");
					var inputObj = targTermPopupObj.find("input[name=term]");			
					
					labelObj.text(resJson.value);
					inputObj.val(resJson.index);				
				}
			});
		 * </pre>
		 */		
		apply : function(paramJson){
			/*
			paramJson.target
			paramJson.handle
			paramJson.range
			paramJson.movePointArray
			paramJson.setDefault
			paramJson.callBackFn
			paramJson.min
			paramJson.max
			paramJson.oneMovePointCnt
			*/
			
			//$("#targTerm_popup_2 .ui-slider").off("touchstart").on("touchstart", function(e){
			paramJson.range.off("touchstart").on("touchstart", function(e){
				var targTermPopupObj = paramJson.target;//
				var sliderHandleObj = paramJson.handle;//
				var rangeObj = paramJson.range;//
				var rangeStateObj = paramJson.rangeState|| rangeObj.find(".ui-slider-range:eq(1)"); //프로젝트 특화된 요소
				var sliderHandleObjWidth = sliderHandleObj.width();
				var range = rangeObj.outerWidth();
				var movePointCnt = paramJson.movePointArray.length-1//10;//움직임 가능한 포인트 갯수
				var onePointWidth = range /movePointCnt;
				//한번에 움직이는 포인트 갯수 단위 옵션으로 조정 기능
				var onePointWidth2 = null;
				if(paramJson.oneMovePointCnt != null){
					onePointWidth2 = range /( movePointCnt / paramJson.oneMovePointCnt);
				}
				var pointNo = 0;
				var currX = e.originalEvent.touches[0].pageX;
				var seedLeft = rangeObj.offset().left;
				var moveX = null;
				var labelArray = paramJson.movePointArray;//
	
				//console.log("orgX : " + currX);
				
				var processFn = function(paramX){
					paramX = paramX - seedLeft;
					if(paramX < -1){
						paramX = 0;
					}
					if(paramX > range){
						paramX = range;
					}
					pointNo = Math.round(paramX / onePointWidth);
					
					//한번에 움지이는 포인트 갯수 단위 옵션으로 조정 기능
					if(paramJson.oneMovePointCnt != null){
						pointNo = Math.round(paramX / onePointWidth2);
						pointNo = pointNo * paramJson.oneMovePointCnt;
					}
					
					//옵션에 따른 min / max	제한
					if(paramJson.min != null && pointNo < paramJson.min){//min 제한
						pointNo = paramJson.min;
					}else if(paramJson.max != null && pointNo > paramJson.max){//max 제한
						pointNo = paramJson.max;
					}
					
					moveX = pointNo * onePointWidth;
						
					//최대 움직일수 있는거리를 약간 줄이는 로직
					//if(moveX == range){
					//	moveX -= sliderHandleObjWidth;
					//}
					//픽셀로 움직이기
					//sliderHandleObj.css({left : moveX});
					//퍼센트로 움직이기
					var percent = moveX / range * 100;
					sliderHandleObj.css({left : percent + "%"});
					if(rangeStateObj){
						rangeStateObj.css({width : percent + "%"});
					}
					
					if(typeof paramJson.callBackFn === "function"){
						paramJson.callBackFn({x : moveX, percent : percent, index : pointNo, value : labelArray[pointNo], returnType : "runTime"});
					}
				};
				
				//클릭위치 바로 이동
				processFn(currX);
	
				//움직임
				targTermPopupObj.off("touchmove").on("touchmove", function(e2){
					var currX2 = e2.originalEvent.touches[0].pageX;
					processFn(currX2);
				});
				
				//이벤트 클리어
				targTermPopupObj.off("touchend").on("touchend", function(e2){
					targTermPopupObj.off("touchend");
					targTermPopupObj.off("touchmove");
					if(typeof paramJson.callBackFn === "function"){
						paramJson.callBackFn({x : moveX, index : pointNo, value : labelArray[pointNo], returnType : "end"});
					}
				});
			});			
			
			if(paramJson.movePointArray){
				paramJson.target.data("movePointArray", paramJson.movePointArray);
				paramJson.target.data("handle", paramJson.handle);
				paramJson.target.data("range", paramJson.range);
			}
			
			if(paramJson.setDefault != null){
				var isVisible = true;
				if(!paramJson.target.is(":visible")){
					isVisible = false;
					paramJson.target.css("visibility", "hidden");
					paramJson.target.show();
				}
				
				var targTermPopupObj = paramJson.target;//
				var sliderHandleObj = paramJson.handle;//
				var rangeObj = paramJson.range;//
				var rangeStateObj = paramJson.rangeState|| rangeObj.find(".ui-slider-range:eq(1)"); //프로젝트 특화된 요소
				//var inputObj = targTermPopupObj.find("input[name=term]");
				var range = rangeObj.outerWidth();
				var movePointCnt = paramJson.movePointArray.length-1//10;//움직임 가능한 포인트 갯수
				var onePointWidth = range / movePointCnt;
				var pointNo = paramJson.setDefault;
				//var labelObj = targTermPopupObj.find(".circle");
				var labelArray = paramJson.movePointArray;//
				var moveX = pointNo * onePointWidth;
				//픽셀로 움직이기
				//sliderHandleObj.css({left : moveX});
				//퍼센트로 움직이기
				var percent = moveX / range * 100;
				sliderHandleObj.css({left : percent + "%"});
				if(rangeStateObj){
					rangeStateObj.css({width : percent + "%"});					
				}
				
				if(typeof paramJson.callBackFn === "function"){
					paramJson.target.data("callBackFn", paramJson.callBackFn);
					paramJson.callBackFn({x : moveX, percent : percent, index : pointNo, value : labelArray[pointNo], returnType : "default"});
				}
				
				if(!isVisible){
					paramJson.target.css("visibility", "");
					paramJson.target.hide();
				}
			}
		},
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] mydataCommon.slideX.apply 적용시 사용한 target 오브젝트
		 * @param {jQueryObject} [<b>paramJson.handle=null</b>] (처음 apply 이후에는 해당값 넘기지 않아도 됨) 슬라이드의 핸들바 오브젝트
		 * @param {jQueryObject} [<b>paramJson.range=null</b>] (처음 apply 이후에는 해당값 넘기지 않아도 됨) 슬라이드의 움직이는 범위 오브젝트
		 * @param {jQueryObject} [<b>paramJson.rangeState=null</b>] 슬라이드의 움직인 레인지를 수평으로 표기할 오브젝트
		 * @param {array} [<b>paramJson.movePointArray=null</b>] (처음 apply 이후에는 해당값 넘기지 않아도 됨) X축 슬라이드시 움직이는 위치를 N등분하여 움직이도록하며, 움직이는 위치에 해당하는 array의 값을 callBackFn함수로 리턴하여 준다. 
		 * @param {number} [<b>paramJson.setDefault=null</b>] 기본으로 movePointArray 해당하하는 움직일 index 위치를 지정
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 슬라이드 동작시 또는 동작이 끝날경우 값을 리턴받아 처리할수 있다. 
		 * @returns {x : range오브텍트기준 x축좌표값, index : 배열의 index값, value : 배열의값, returnType : 콜백함수 리턴시 움지이는 시점의 콜백인지 슬라이드 동작 끝난시점 콜백인지 구분하여 준다."}
		 * @description 좌우 슬라이드 동작을 적용 시켜준다.
		 * @example
		 * <pre>
			mydataCommon.slideX.set({
				target : $("#targTerm_popup_2"),
				setDefault : 3,
				callBackFn : function(resJson){
					var targTermPopupObj = $("#targTerm_popup_2");
					var labelObj = targTermPopupObj.find(".circle");
					var inputObj = targTermPopupObj.find("input[name=term]");			
					
					labelObj.text(resJson.value);
					inputObj.val(resJson.index);				
				}
			});
		 * </pre>
		 */	
		set : function(paramJson){
			var isVisible = true;
			if(!paramJson.target.is(":visible")){
				isVisible = false;
				paramJson.target.css("visibility", "hidden");
				paramJson.target.show();
			}
			
//			paramJson.movePointArray = paramJson.target.data("movePointArray");
//			paramJson.handle = paramJson.target.data("handle");
//			paramJson.range = paramJson.target.data("range");

			if(paramJson.movePointArray == null){
				paramJson.movePointArray = paramJson.target.data("movePointArray");
			}			
			if(paramJson.handle == null){
				paramJson.handle = paramJson.target.data("handle");
			}
			if(paramJson.range == null){
				paramJson.range = paramJson.target.data("range");
			}
			if(paramJson.callBackFn == null){
				paramJson.callBackFn = paramJson.target.data("callBackFn");
			}
			
			var targTermPopupObj = paramJson.target;//
			var sliderHandleObj = paramJson.handle;//
			var rangeObj = paramJson.range;//
			var rangeStateObj = paramJson.rangeState|| rangeObj.find(".ui-slider-range:eq(1)"); //프로젝트 특화된 요소
			//var inputObj = targTermPopupObj.find("input[name=term]");
			var range = rangeObj.outerWidth();
			var movePointCnt = paramJson.movePointArray.length-1//10;//움직임 가능한 포인트 갯수
			var onePointWidth = range / movePointCnt;
			var pointNo = isNaN(paramJson.setDefault) ? Number(paramJson.setDefault) : paramJson.setDefault;
			//var labelObj = targTermPopupObj.find(".circle");
			var labelArray = paramJson.movePointArray;//
			var moveX = pointNo * onePointWidth;
			//픽셀로 움직이기
			//sliderHandleObj.css({left : moveX});
			//퍼센트로 움직이기
			var percent = moveX / range * 100;
			sliderHandleObj.css({left : percent + "%"});
			if(rangeStateObj){
				rangeStateObj.css({width : percent + "%"});
			}
			
			if(typeof paramJson.callBackFn === "function"){
				paramJson.callBackFn({x : moveX, percent : percent, index : pointNo, value : labelArray[pointNo], returnType : "default"});
			}
			
			if(!isVisible){
				paramJson.target.css("visibility", "");
				paramJson.target.hide();
			}			
		}
	},
	
	
	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 * 상하 슬라이드 동작을 적용시켜주는 클래스 모음
	 */	
	slideY : {
		
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 상할 스크롤이 적용될 마크업이 포함된 대상 요소 ex> div, body 등등
		 * @param {jQueryObject} [<b>paramJson.scrollBody=null</b>] (해당값이 없을때는 target을 하위에 존재하는 "modal-body"를 찾는다) 상하 스크롤 css 기준 "overflow-y:auto" 적용된 대상요소 요소 ex> div 등등
		 * @param {jQueryObject} [<b>paramJson.firstRow=null</b>] (해당값이 없을때는 target을 하위에 존재하는 "ul li:eq(0)"을 찾는다) 슬라이드 동작될 첫번째 행요소
		 * @param {number} [<b>paramJson.selectValue=null</b>] 해당 값이 존재할경우 선택 처리하여 준다. (set 동작을 해준다 해당 기능 패키지는 별도의 set함수가 없음)
		 * @param {number} [<b>paramJson.dsp=null</b>] 슬라이드를 이용하여 조작시 변경된값을 동적으로 보여질 jquery Object
		 * @param {number} [<b>paramJson.seedRowCnt=null</b>] 아래 마크업 기준으로 li 태그중 유효값이 시작되는 값 외에 빈값의 시드갯수
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 상하 슬라이드 동작시 또는 동작이 끝날경우 값을 리턴받아 처리할수 있다. 
		 * @returns {index : 선택된행번호0부터시작, value : 선택된행의 text값, returnType : 콜백함수 리턴시 움지이는 시점의 콜백인지 슬라이드 동작 끝난시점 콜백인지 구분하여 준다.}
		 * @description 좌우 슬라이드 동작을 적용 시켜준다.
		 * @example
		 * <pre>

				예제 마크업
					<div class="modal-body">
						<div class="roll-date-wrap">
							<div class="active" style="pointer-events: none;">
								<dl>
									<dt>매월</dt>
									<dd>16</dd>
								</dl>
							</div>
							<div class="rolling">
								<ul>
									<li></li>
									<li></li>
									<li>1</li>
									<li>2</li>
									<li>3</li>
									....생략
									<li>26</li>
									<li>27</li>
									<li>28</li>			
									<li></li>
									<li></li>																	
								</ul>
							</div>
						</div>
					</div>				

				
				mydataCommon.slideY.apply({target : divModalPopObj, selectValue : (currMwObj.val() || ""), callBackFn : function(res){
					if(res.returnType == "end"){
						rowValue = res.value;
					}
				}});
				
				
				dsp
		 * </pre>
		 */		
		apply : function(paramJson){
			
			var divModalPopObj = paramJson.target;			
			var divModalBodyObj = paramJson.scrollBody || divModalPopObj.find(".modal-body");
			//var divModalBodyUlGroupObj = divModalPopObj.find("ul");
			var oneLiObj = paramJson.firstRow || divModalPopObj.find("ul li:eq(0)");
			var rowHeight = oneLiObj.outerHeight();
			//var activeWrapObj = divModalPopObj.find(".active dd");
			var activeDDObj = paramJson.dsp || divModalPopObj.find(".active dd");
			var seedRowCnt = paramJson.seedRowCnt || 2;
			var selectRowNo = 0;
			var selectRowNo_ = 0;
			
			//var selectValue = currMwObj.val() || "";
			var selectValue = paramJson.selectValue;
			if(!mydataCommon.util.isNull(selectValue)){
				divModalBodyObj.find("li").each(function(i){
					var thisObj3 = $(this);
					if(thisObj3.text().trim() == selectValue){
						selectRowNo = i - seedRowCnt;
						selectRowNo_ = i;
						activeDDObj.text(selectValue);
						return false;
					}
				});
			}
			
			//선택 위치로 이동
			divModalBodyObj.scrollTop(rowHeight * selectRowNo);	
			
			var sTp = 0;
			var before_sTp = 0;
			var tempval4 = 0;
			var currRowNo = 0;
			var isEnd = false;
			//시작
			divModalBodyObj.off("touchstart").on("touchstart", function(e){
				//console.log("진입");
				var interval_id_01 = divModalBodyObj.data("interval_id_01");
				var interval_id_02 = divModalBodyObj.data("interval_id_02");
				if(interval_id_01 != null){
					clearInterval(interval_id_01);
					interval_id_01 = null;		
					
				}
				if(interval_id_02 != null){
					clearInterval(interval_id_02);
					interval_id_02 = null;					
				}

				interval_id_02 = setInterval(function(){
					//console.log("interval_id_02");
					before_sTp = sTp;
				}, 50);
				divModalBodyObj.data("interval_id_01", interval_id_01);
				divModalBodyObj.data("interval_id_02", interval_id_02);
			});						
			
			//움직임
			divModalBodyObj.off("scroll").on("scroll", function(e){
				var thisObj2 = $(this);
				var rowCount = 31;
				sTp = thisObj2.scrollTop();
				var tttt = Math.ceil(sTp/rowHeight);
				currRowNo = tttt+seedRowCnt;

				//console.log("움직임 : " + currRowNo)
				
				var lable = divModalBodyObj.find("li:eq("+currRowNo+")").text();
				activeDDObj.text(lable);
				
				if(typeof paramJson.callBackFn === "function"){
					if(isEnd){
						paramJson.callBackFn({index : currRowNo, value : lable, returnType : "end"});
					}else{
						paramJson.callBackFn({index : currRowNo, value : lable, returnType : "runTime"});	
					}
					
				}	
				
			});
			
			//움직임 종료
			divModalBodyObj.off("touchend").on("touchend", function(){
				var interval_id_01 = divModalBodyObj.data("interval_id_01");
				var interval_id_02 = divModalBodyObj.data("interval_id_02");
				if(before_sTp == sTp){
					isEnd = true;
//					console.clear();
//					console.log("touchend 1");
					tempval4 = Math.ceil(divModalBodyObj.scrollTop() / rowHeight) * rowHeight;
					divModalBodyObj.animate({
						scrollTop : tempval4
					}, 200, function(){});
					
					clearInterval(interval_id_01);
					interval_id_01 = null;
					clearInterval(interval_id_02);
					interval_id_02 = null;
					
					divModalBodyObj.data("interval_id_01", interval_id_01);
					divModalBodyObj.data("interval_id_02", interval_id_02);					
					
					var lable = divModalBodyObj.find("li:eq("+currRowNo+")").text();
					//console.log("종료 : " + currRowNo)
					if(typeof paramJson.callBackFn === "function"){
						paramJson.callBackFn({index : currRowNo, value : lable, returnType : "end"});
					}					
					
				}else{
					//console.log("touchend 2");
					if(interval_id_01 == null){
						interval_id_01 = setInterval(function(){
//							console.clear();
//							console.log("touchend 2");
							if(before_sTp == sTp){
								isEnd = true;
								tempval4 = Math.ceil(divModalBodyObj.scrollTop() / rowHeight) * rowHeight;
								divModalBodyObj.animate({
									scrollTop : tempval4
								}, 150, function(){});
								
								clearInterval(interval_id_01);
								interval_id_01 = null;
								clearInterval(interval_id_02);
								interval_id_02 = null;
								
								divModalBodyObj.data("interval_id_01", interval_id_01);
								divModalBodyObj.data("interval_id_02", interval_id_02);
								
								var lable = divModalBodyObj.find("li:eq("+currRowNo+")").text();
								//console.log("시간차종료 : " + currRowNo)
								if(typeof paramJson.callBackFn === "function"){
									paramJson.callBackFn({index : currRowNo, value : lable, returnType : "end"});
								}								
							}
						}, 150);
						divModalBodyObj.data("interval_id_01", interval_id_01);
					}
				}
			});	
			
			//디폴트 동작
			if(typeof paramJson.callBackFn === "function"){
				paramJson.callBackFn({index : selectRowNo_, value : selectValue, returnType : "default"});
			}			
		}
	},
	/**
	 * input 요소에 number 포맷타입 기능을 적용시켜주는 패키지  
	 */
	inputTypeNumFormat : {
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 포맷이 적용되 대상 input 요소
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 슬라이드 동작시 또는 동작이 끝날경우 값을 리턴받아 처리할수 있다. 
		 * @returns {value : number값, simValue : 입력단위가 있을때 단위 만큼 절삭된값, format : 포맷값, obj : input요소, formatObj : 포맷input요소}
		 * @description 콤마, 원표기 프로젝트 표준 적용 input요소의 포맷 동작을 적용시켜준다. 기본적으로 "input type=text"(포맷요소) 와 "input type=number"(실제값요소) 이벤트에 따라 스위칭하여 보여지면서 처리된다. 
		 * 해당 실제 요소 아래 예제기준 mm_pdin_amt요소의 data-value 속성에 입력단위가 적용된경우를 대비하여 입력된값과 단위를 곱한 실제값을 보관하여 준다. 필요시 꺼내 사용하도록 한다.
		 * 또한 data-unit_value 를 별도로 관리해준다.  단위가 적용된경우 ex> 입력단위 10000(1만) 일경우  1만 넣어도 "10000"으로 관리되며, data-value는 단위를 곱한 논리유효값 data-unit_value는 타이핑된 숫자값(포팻값 아님)  
		 * 그외 기타 input요소 마크업 옵션
		 * 		data-is_use_zero_dsp="true" 일때 0표기 디폴트 0 표기 하지 않음
		 * 		data-unit_dp : 숫자 표기단위 디폴트 "원" 예) data-unit_dp="%"
		 * 		data-datatype : 입력가능한 숫자 데이터 타입 I=정수, D=소수 디폴트 D
		 * 		data-min_unit : 최소입력값
		 * 		data-min_value : 최대입력값
		 * @example
		 * <pre>
		 
		 	//마크업 예제
			<input name="mm_pdin_amt"  type="text" class="input-price" placeholder="" title="월납입액" value="100,000원" data-value="100000" data-unit_value="10" data-unit="10000" data-max_amt="10000000" data-min-amt="1000" data-maxlength="4">	 	
		 	
			//특정요소 적용 예제 : 숫자 콤마 및 포맷타입으로 입력되는프로젝트 표준 input요소 공통함수 적용 처리
			mydataCommon.inputTypeNumFormat.apply({
				target : $("#targPirce_popup_2 input[name=trgt_amt_format_temp]"),
				callBackFn : function(res){
					var inputObjName = res.obj[0].name;
					$(".dd_targPirce").text(res.format);
				}
			});
			
			//일괄설정 예제 : 숫자 콤마 및 포맷타입으로 입력되는프로젝트 표준 input요소 일괄 공통함수 적용 처리
			$("input.sview-number-format").each(function(){
				var thisObj = $(this);
				mydataCommon.inputTypeNumFormat.apply({
					formatObj : thisObj,
					callBackFn : function(res){
						var inputObjName = res.obj[0].name;
						
						if(inputObjName == "trgt_amt"){
							$(".dd_targPirce").text(res.format);
						}else if(inputObjName == "erdy_invt_amt"){
							$(".dd_erdy_invt_amt").text(res.format);
						}else if(inputObjName == "mm_pdin_amt"){
							$(".dd_mm_pdin_amt").text(res.format);
						}
					}
				});
			});
		 * </pre>
		 */
		apply : function(paramJson){
			//목표설정 금액 등등 콤마 및 포맷타입으로 입력되는 input 공통처리
			paramJson.target.off("focus").on("focus", function(){
				var amtObj = $(this);
				var targPirceObj = amtObj;
				var isAutoUseDelBtn = false;
				
				var deleteObj = amtObj.next(".btn-delete");
				if(isAutoUseDelBtn){
					if(deleteObj.length > 0){
						deleteObj.show();
					}					
				}
				
				var dataType = amtObj.data("datatype") || "D";
				
				//리얼타임 포맷처리 여부
				var isRealTimeFormat = true;
				//
				var length_org = 0;
				var cuserPos = 0;
				//숫자 포맷 표현
				var getFormatString = function(paramValue){
					paramValue += "";
					return paramValue.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				};
				//소수점 및 순수 숫자만 표현 
				var getReplaceOnlyNum = function(paramValue){
					paramValue += "";
					if(dataType == "I"){
						return paramValue.replace(/[^0-9]/g, "");
					}else{
						return paramValue.replace(/[^0-9\.]/g, "");	
					}
				};
				
				//값 스위칭(입력단위가 적용된 경우를 대비)  
				var currValue = amtObj.data("unit_value");
				if(currValue != null &&  currValue != 0){
					if(isRealTimeFormat){
						var tempValue7 = getFormatString(currValue);
						length_org = tempValue7.length;
						amtObj.val(tempValue7);						
					}else{
						amtObj.val(currValue);						
					}
				}else{
					amtObj.val("");
				}
				
				
				if(isRealTimeFormat){
					amtObj.off("keydown").on("keydown", function(){
						var thisObj = $(this);
						cuserPos = thisObj.get(0).selectionStart;
						//console.log("cuserPos : " + cuserPos);
					});
				}
				
				//max 길이 체크
				var maxlength = amtObj.data("maxlength");
				if(maxlength){
					amtObj.off("keyup").on("keyup", function(){
						var thisObj = $(this);
						var tempVal = thisObj.val();
						var tempValOlnyNum = getReplaceOnlyNum(tempVal); 
						//console.log("length_org : " + length_org);
						
						//제약조건 체크 및 처리
						var maxCheckValue = tempValOlnyNum;
						var isMaxCheck = false;
						if(tempValOlnyNum.length > Number(maxlength)){
							maxCheckValue = tempValOlnyNum.slice(0, maxlength);
							isMaxCheck = true;
						}
						
						// 값 대임
						if(isRealTimeFormat){
							thisObj.val(getFormatString(maxCheckValue));	
						}else{
							thisObj.val(maxCheckValue);
						}
						
						if(isRealTimeFormat){
							// 리얼타임 포맷 처리에 따른 포커스 위치값 이야기 맞게 유치
							var tempValFormat = getFormatString(maxCheckValue);
							var length_curr = tempValFormat.length;
							var isCuserPos = true;
							//console.log("length_curr : " + length_curr);
							if(length_org > length_curr){
								cuserPos -= (length_org - length_curr);
							}else if(length_org < length_curr){
								cuserPos += (length_curr - length_org);
							}else{
								isCuserPos = false;
							}
							
							//커서 위치 보존 처리
							if(isCuserPos || isMaxCheck){
								thisObj.get(0).selectionStart = cuserPos;
								thisObj.get(0).selectionEnd = cuserPos;							
							}
							length_org = length_curr;
						}
					});	
				}
				
				//삭제버튼 활성화
				if(isAutoUseDelBtn){
					if(deleteObj.length > 0){
						deleteObj.off("click").on("click", function(){
							amtObj.val("");
							amtObj.data("value", "");
							amtObj.data("unit_value", "");
						});
					}					
				}
				
				//별도의 팝업을 통하여 입력 받기
				mydataCommon.popInput.openBox({orgInput : amtObj, type : "number"});
				
				//목표설정 금액 등등 포맷타입으로 입력되는 input 공통처리
				amtObj.off("change, blur").on("change, blur", function(e){
					//var amtObj = $(this);
					var priceUnit = Number(amtObj.data("unit") || "1");
					var unit_dp = amtObj.data("unit_dp") || "원";
					var isUseZeroDsp = amtObj.data("is_use_zero_dsp") !=null ? true : false;
					var dataType2 = amtObj.data("datatype") || "D";
					
					var is_min_value = amtObj.data("min_value") != null ? true : false;
					var is_max_value = amtObj.data("max_value") != null ? true : false;
					var min_value = amtObj.data("min_value");
					var max_value = amtObj.data("max_value");
					
					//var amtObj = amtObj.prev();
					//var deleteObj = amtObj.next(".btn-delete");
					var currVal = amtObj.val();
					var currValByNumber = dataType2 == "I" ? Number(currVal.replace(/[^0-9]/g, "") || "") : Number(currVal.replace(/[^0-9\.]/g, "") || "");
					var unitVal = currValByNumber * priceUnit;
					
					if(is_min_value){
						if(unitVal < Number(min_value)){
							unitVal = Number(min_value);
							currValByNumber = Number(min_value / priceUnit);
						}
					}
					if(is_max_value){
						if(unitVal > Number(max_value)){
							unitVal = Number(max_value);
							currValByNumber = Number(max_value / priceUnit);
						}
					}
					
					var formatVal = "";
					if(unitVal > 0 || isUseZeroDsp){
						formatVal = (unitVal + "").replace(/\B(?=(\d{3})+(?!\d))/g, ",") + unit_dp;
					}else{
						unitVal = "";
						currValByNumber = "";
					}
					amtObj.val(formatVal);
					//단위가 존재하는 경우 입력된값과 단위를 곱한 실제값을 보관한다.
					amtObj.data("value", unitVal);
					amtObj.data("unit_value", currValByNumber);
					
					//이벤트 클리어
					amtObj.off("keyup");
					amtObj.off("change, blur");
					
					if(isAutoUseDelBtn){
						if(deleteObj.length > 0){
							//삭제버튼 비활성화인데  버튼을 클릭 이벤트를 발생시킬수 있도록 시간차를 준다.
							setTimeout(function(){
								deleteObj.off("click");
								deleteObj.hide();	
							}, 100);
						}						
					}

					//동작완료시 사용자 정의 콜백함수 실행
					if(typeof paramJson.callBackFn === "function"){
						paramJson.callBackFn({value : unitVal, simValue : currValByNumber, format : formatVal, obj : amtObj, formatObj : amtObj});
					}
					
					//아이폰 특성 ...;; 처리
					if($("#mydataCommon_input_Wrap ._confirm").length > 0){
						var conFirmBtnObj = $("#mydataCommon_input_Wrap ._confirm");
						if(conFirmBtnObj.length > 0){
							if(conFirmBtnObj.data("isClick")){
								$("#mydataCommon_input_Wrap ._confirm").trigger("click");	
							}
						}
					}
				});	
			});		
		},
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] mydataCommon.inputTypeNumFormat.apply기능이 적용된 input 요소
		 * @param {jQueryObject} [<b>paramJson.value</b>] 적용할 value
		 * @description   mydataCommon.inputTypeNumFormat.apply기능이 적용된 input 요소의 값을 set 하여준다.
		 * @example
		 * 		mydataCommon.inputTypeNumFormat.set({target : $("input[name=mm_pdin_amt_re]"), value : 10000});
		 */
		set : function(paramJson){
			
			var amtObj = paramJson.target;
			
			//var amtObj = $(this);
			var priceUnit = Number(amtObj.data("unit") || "1");
			var unit_dp = amtObj.data("unit_dp") || "원";
			var isUseZeroDsp = amtObj.data("is_use_zero_dsp") !=null ? true : false;
			var dataType2 = amtObj.data("datatype") || "D";
			//var amtObj = amtObj.prev();
			//var deleteObj = amtObj.next(".btn-delete");
			var currVal = paramJson.value; 
			var currValByNumber = dataType2 == "I" ? Number((currVal + "").replace(/[^0-9]/g, "") || "") : Number((currVal + "").replace(/[^0-9\.]/g, "") || "");
			var unitVal = currValByNumber;
			var formatVal = "";
			if(unitVal > 0 || isUseZeroDsp){
				formatVal = (unitVal + "").replace(/\B(?=(\d{3})+(?!\d))/g, ",") + unit_dp;
			}else{
				unitVal = "";
				currValByNumber = "";
			}
			amtObj.val(formatVal);
			//단위가 존재하는 경우 입력된값과 단위를 곱한 실제값을 보관한다.
			amtObj.data("value", unitVal);
			amtObj.data("unit_value", (currValByNumber / priceUnit));
		},
//		get : function(paramJson){
//			var amtObj = paramJson.target;
//			var returnVal = "";
//			if(paramJson.isUnitValue){
//				returnVal = amtObj.data("unit_value");	
//			}else{
//				returnVal = amtObj.data("value");	
//			}
//			return returnVal;
//		}
	},	
	
	/**
	 * 모바일 등등 키패드 제약등등을 회피하기위하여 팝업을 통한 input 받기 기능 모음  
	 */	
	popInput : {
		/**
		 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 적용되 대상 input 요소
		 * @param {boolean} [<b>paramJson.isUseDelBtn=true</b>] 삭제 버튼 사용여부 디폴트 사용
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 확인시 실행할 스크립트 (파라미터로 값을 리턴함) 
		 * @description 모바일 등등 키패드 제약등등을 회피하기위하여 팝업을 통한 input 받기 기능 적용  
		 * @example
		 * <pre>
		 	mydataCommon.popInput.apply({target : $("#targSet_popup_1 input[name=cust_inpr_cntn]")});
		 * </pre>
		 */			
		apply : function(paramJson){
			
			//안드로이드만 폰만 적용할수 있음(강제화 함 고객 요구사항)
			if(pageCom.prop.isANDROID){
				//목표설정 금액 등등 콤마 및 포맷타입으로 입력되는 input 공통처리
				paramJson.target.off("focus").on("focus", function(){
					var inputObj = $(this);
					//별도의 팝업을 통하여 입력 받기
					mydataCommon.popInput.openBox({orgInput : inputObj, isUseDelBtn : paramJson.isUseDelBtn});
				});					
			}
		},
		openBox : function(paramJson){
			
			//안드로이드만 폰만 적용할수 있음(강제화 함 고객 요구사항)
			if(pageCom.prop.isANDROID){
				var orgInputObj = paramJson.orgInput;
				var isUseDelBtn = paramJson.isUseDelBtn || true;
				var dyInputPopBoxObj = $("#mydataCommon_input_Wrap");
				if(dyInputPopBoxObj.length > 0){
					
				}else{
					var htmlString = "";
					htmlString += '	<div id="mydataCommon_input_Wrap" class="modal-dim" style="background-color: rgba(51,51,51,.9); outline: none;">';
					htmlString += '		<section class="modal-container" tabindex="0" role="dialog" style="top: 35%; outline: none;">';
					//htmlString += '			<button type="button" class="btn-close _close"><span>닫기</span></button>';
					//htmlString += '			<div class="modal-head">';
					//htmlString += '				<h1 class="head-title" data-text="title"></h1>';
					//htmlString += '			</div>';
					htmlString += '			<div class="modal-body" style="outline: none;">';
					htmlString += '				<div class="modal-body-container" style="outline: none;">';
					htmlString += '					<span class="input-area" style="outline: none;">';
					if(isUseDelBtn){
						htmlString += '						<button type="button" class="btn-delete" style="display : block;"><span>삭제</span></button>';					
					}

					htmlString += '					</span>';
					//htmlString += '					<p class="txt-c text-16" data-html="msg"></p>';
					htmlString += '				</div>';
					htmlString += '			</div>';
					htmlString += '			<div class="modal-footer" style="outline: none;">';
					//htmlString += '				<button type="button" class="btn pop primary btn-gray _cancle"><span data-text="cancleBtnText">취소</span></button>';
					htmlString += '				<button type="button" class="btn pop primary _confirm" style="outline: none;"><span style="outline: none;">확인</span></button>';
					htmlString += '			</div>			';
					htmlString += '		</section>';
					htmlString += '	</div>';
					$("body:eq(0)").append(htmlString);
					
					dyInputPopBoxObj = $("#mydataCommon_input_Wrap");
					
					var checkBtnText = paramJson.checkBtnText || "확인";
					dyInputPopBoxObj.find("._confirm").text(checkBtnText);
					//메세지 및 타이틀 데이터 바인딩
					mydataCommon.setDataBinding({target : dyInputPopBoxObj, data : paramJson});
					//모달 방식 메세지 박스 보이기 처리
					dyInputPopBoxObj.addClass("on");
					
					var inputWrapObj = dyInputPopBoxObj.find(".input-area");
					var amtCloneObj = orgInputObj.clone(true);
					var name = amtCloneObj.attr("name");
					amtCloneObj.prop(name + "_popInput");
					amtCloneObj.prop("id", "mydataCommon_input");
					if(paramJson.type == "number"){
						amtCloneObj.css({
							//"text-align" : "right",
							"border" : "1px solid #c2c2c2",
							"border-radius" : "0.3rem"
						});					
					}
					inputWrapObj.prepend(amtCloneObj);
					

					
					//필요정보 적역으로 담기
					dyInputPopBoxObj.data("orgInput", orgInputObj);
					
					//동작완료시 사용자 정의 콜백함수 실행
					if(typeof paramJson.callBackFn === "function"){
						dyInputPopBoxObj.data("callBackFn", paramJson.callBackFn);
					}
					
					
					//기타 값 구하기
					var orgData = orgInputObj.data() || {};			
					//값 대임
					if(orgData.value != null){
						amtCloneObj.val(orgData.value);
						amtCloneObj.data("value", orgData.value);
						amtCloneObj.data("unit_value", orgData.unit_value);						
					}else{
						amtCloneObj.val(orgInputObj.val());
					}
					amtCloneObj.css("outline", "none");
					//포커스 처리 중요!!!!
					if(paramJson.type == "number"){
						//커서 위치 끝으로 이동
						amtCloneObj.get(0).selectionStart = amtCloneObj.val().length;
						amtCloneObj.get(0).selectionEnd = amtCloneObj.val().length;
						
						amtCloneObj.attr("pattern", "\\d*");
						
						amtCloneObj.focus();
					}else{
						amtCloneObj.focus();
					}
					
					/*
					$("#mydataCommon_input_Wrap").off("click").on("click", function(){
						var thisObj = $(this);
						//백그라운드만 클릭한경우
						if(thisObj.hasClass("modal-dim")){
							$("#mydataCommon_input_Wrap ._confirm").trigger("click");
						}
					});
					*/
					if(isUseDelBtn){
						var deleteObj = dyInputPopBoxObj.find(".btn-delete");
						deleteObj.off("click").on("click", function(){
							//동적으로 생성된 input 요소
							var amtCloneObj2 = $("#mydataCommon_input");						
							//기타 값 구하기
							var cloneData = amtCloneObj2.data();		
							if(cloneData.value != null){
								amtCloneObj2.val("");
								amtCloneObj2.data("value", "");
								amtCloneObj2.data("unit_value", "");							
							}else{
								amtCloneObj2.val("");
							}
							amtCloneObj.focus();
						});	
					}
					
					//이벤트 바인딩
					var conFirmBtnObj = $("#mydataCommon_input_Wrap ._confirm");
					conFirmBtnObj.off("click").on("click", function(ee){
						//ee.preventDefault();
						//팝업 닫기
						dyInputPopBoxObj.removeClass("on");
							
						//동적으로 생성된 input 요소
						var amtCloneObj2 = $("#mydataCommon_input");
						//오리지날 input 요소
						var orgInput = dyInputPopBoxObj.data("orgInput");
						//기타 값 구하기
						var cloneData = amtCloneObj2.data();
							
						//값 대임
						if(cloneData.value != null){
							orgInput.val(amtCloneObj2.val());
							orgInput.data("value", cloneData.value);
							orgInput.data("unit_value", cloneData.unit_value);							
						}else{
							orgInput.val(amtCloneObj2.val());
						}

						
						//동작완료시 사용자 정의 콜백함수 실행
						var callBackFn = dyInputPopBoxObj.data("callBackFn");
						if(typeof callBackFn === "function"){
							callBackFn(amtCloneObj2.val());
						}
							
						//클리어
						conFirmBtnObj.off("click");
						amtCloneObj2.remove();
						dyInputPopBoxObj.remove();				
					});	
					
					//아이폰 특성 ...;; 처리
					conFirmBtnObj.off("touchstart").on("touchstart", function(){
						conFirmBtnObj.data("isClick", true);						
					});				
				}				
			}
		}
	},
	
	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 *  좌우 슬라이드 컨텐츠 넘김 기능을 적용시켜주는 클래스 모음
	 */	
	slide2X : {
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 슬라이드가 적용될 컨테이너 요소 보통 슬라이드 컨텐츠를 N개 랩핑하고 있는 요소
		 * @param {jQueryObject} [<b>paramJson.contentsByWidth=null</b>] 컨테이너 내부에서 슬라이드될 컨텐츠 한페이지의 넓이를 관장할 요소를, Jquery  selection한 N개의 슬라이드될 컨텐츠 집합 
		 * <pre>
		 * EX> $(".lesson-cont .title-quiz")  여기서 실제 컨텐츠 단위는 "lesson-cont"이지만 마크업이 넓이가 100% 라서  하위 컨텐츠의("title-quiz")  넓이에 따라  모바일화면보다 폭이 좁을경우 100% 쓰지 못할수가 있는데 
		 * 이를 mydataCommon.slide2X.apply 적용시 보이고 할당된 모바일 화면의 넓이 만큼 컨텐츠들의 넓이를 스태틱하게 고정한다.
		 * 컨텐츠 내용이 화면보다 넓을 경우는 해당 옵션을 사용하지 않아도 되지만 사용을 권장함
		 * </pre>
		 * @param {boolean} [<b>paramJson.isAutoSlide=null</b>] 자동 슬라이드 넘김 기능 활성화
		 * @param {boolean} [<b>paramJson.isReAutoSlide=null</b>] isAutoSlide=true 시 자동 슬라이드 동작하고 있을때 사용자가 UI를 통하여 슬라이딩 동작시 슬라이드 동작을 중지하는데 이때 자동으로 재시작 옵션
		 * @param {number} [<b>paramJson.oneContentsWidth=null</b>] 슬라이될 간격의 width 해당값이 없을때는 슬라이드 영역 wrap 넓이를 기준으로 사용함
		 * @param {number} [<b>paramJson.slideCount=null</b>] 슬라이드 컨텐츠 갯수 isAutoSlide=true 활성화시 필수 입력값
		 * @param {boolean} [<b>paramJson.isNotSlide=null</b>] 슬라이드 기능을 사용하지 않을때 단지 mydataCommon.slide2X.set 함수를 통하여 외부에서 컨텐츠 이동만 하고자할때 사용
		 * @param {function} [<b>paramJson.callBackFn=null</b>] 슬라이드 동작 완료후 실행될 콜백 함수
		 * <pre>
		 * {returnType : "end", index : 컨텐츠 0번째부터 순서값, isClick : 클릭이벤트여부, eventTarget : 컨텐츠중 이벤트를 발생시킨 요소(jQueryObject)}
		 * </pre>
		 * @description 적용될 곳의 넓이 전체를 컨텐츠 넓이 사이즈를 사용하는 방식
		 * @example
			mydataCommon.slide2X.apply({
				target :  slideContentsWrapObj,
				contentsByWidth : slideContentsWrapObj.find(".lesson-cont .title-quiz"),
				isNotSlide : true,
				callBackFn : function(resJson){
					//커스텀 코딩 추가
				}
			});	
		 */
		apply : function(paramJson){
			//paramJson.target
			//paramJson.slide
			paramJson.target.off("touchstart").on("touchstart", function(e){
				
				//슬라이드 중이라면 강제 중지
				var  autoSlide = false;
				var eventTargetObj = $(e.target);
				
				if(paramJson.target.data("timerid") != null){
					autoSlide = true;
					mydataCommon.slide2X.stopSlide(paramJson);
				}
				
				
				// var thisObj = $(this);
				// var oneLiObj = paramJson.slide;
				var oneContentsWidth = paramJson.oneContentsWidth || paramJson.target.width();// oneLiObj.outerWidth();
				var tempval4 = 0;
				var thisObj2 = $(this);
				var rowCount = 31;
				var firstPoint = thisObj2.scrollLeft();
				var movePointX = null;
				var touchX = e.originalEvent.changedTouches[0].screenX;
				var touchY = e.originalEvent.changedTouches[0].screenY;
				var movePointY = 0;
				var moveY = 0;
				var startTime = new Date;
				var isClick = false;
				//움직임
				paramJson.target.off("touchmove").on("touchmove", function(e2){
					var moveX = e2.originalEvent.changedTouches[0].screenX;
					moveY = e2.originalEvent.changedTouches[0].screenY;
					// console.log(e2.originalEvent.changedTouches[0].screenX)
					movePointX = touchX - moveX;
					movePointY = touchY - moveY;
					//console.log(movePointY)
					// console.log(touchX - moveX);
					thisObj2.scrollLeft(firstPoint + movePointX);
				});
				//
				paramJson.target.off("touchend").on("touchend", function(){
					// 외쪽 움직임
					var isLeft = true;
					var isHaf = true;
					var test5 = 0;
					var endTime = new Date();
					var runTime = endTime - startTime;
					//console.log(movePointX);
					var check3 = false;
					var contentsIndex = 0;
					//상하 스크롤등등 의도한 좌우 슬라이드 동작이 아닐수 있기에 최소한의 움직임 보장
					if(Math.abs(movePointX) > 20){
						if(firstPoint < paramJson.target.scrollLeft()){
							isLeft = true;
							if(runTime > 200){
								if((oneContentsWidth / 2) < movePointX){
									// isHaf = true;
									// test5 = 1;
								}else{
									isHaf = false;
									test5 = -1;
								}
							}
						}else{
							isLeft = false;
							if(runTime > 200){
								if((oneContentsWidth / 2) < Math.abs(movePointX)){
									// isHaf = true;
									// test5 = 1;
								}else{
									isHaf = false;
									test5 = 1;
								}
							}
						}
						
						if(firstPoint == thisObj2.scrollLeft()){
							isLeft = true;
						}
						
						if(isLeft){
							contentsIndex = (Math.ceil(paramJson.target.scrollLeft() / oneContentsWidth) + test5);
							tempval4 = contentsIndex * oneContentsWidth;
						}else{
							contentsIndex = (Math.floor(paramJson.target.scrollLeft() / oneContentsWidth) + test5);
							tempval4 = contentsIndex * oneContentsWidth;
						}
						paramJson.target.animate({
							scrollLeft : tempval4
						}, 200, function(){});
					}else{
						//최소한 못움직일경우 원복
						//oneContentsWidth - 3  처리는 디바이스 특성타서 안전하게 1 빼고 계산						
						if(firstPoint == thisObj2.scrollLeft()){
							contentsIndex = (Math.ceil(paramJson.target.scrollLeft() / (oneContentsWidth) ) + 0);
						}else{
							contentsIndex = (Math.floor(paramJson.target.scrollLeft() / (oneContentsWidth - 3) ) + 0);							
						}
						
						tempval4 = contentsIndex * oneContentsWidth;
						thisObj2.scrollLeft(tempval4);
						
						check3 = true;
						
						//상하 움직임이 없고 좌우 움직입도 없을때 클릭 이벤트라고 판단한다.
						if(Math.abs(movePointY) < 5 || moveY == 0){
							isClick = true;
						}	
					}
					
					paramJson.target.off("touchmove");
					paramJson.target.off("touchend");
					
					if(autoSlide){
						autoSlide = false;
						if(paramJson.isReAutoSlide || check3){
							//if(!isClick){
								paramJson.returnType = "reStart";
								paramJson.isNotStop = true;							
								mydataCommon.slide2X.autoSlide(paramJson);								
							//}
						}
					}else{
						if(!paramJson.isReAutoSlide){
							if(paramJson.target.data("timerid") != null){
								mydataCommon.slide2X.stopSlide(paramJson);
							}
						}
					}
					
					if(typeof paramJson.callBackFn === "function"){
						//console.log("contentsIndex :" + contentsIndex);
						paramJson.callBackFn({returnType : "end", index : contentsIndex, isClick : isClick, eventTarget : eventTargetObj});
					}
				});
			});	
			
			if(paramJson.contentsByWidth != null){
				if(paramJson.target.data("contentsByWidth") == null){
					paramJson.target.data("contentsByWidth", paramJson.contentsByWidth);
					var oneContentsWidth = paramJson.target.width();
					if(oneContentsWidth){
						paramJson.contentsByWidth.width(oneContentsWidth);	
					}
				}
			}			
			
			//슬라이드 기능을 사용하지 않을때 단지 mydataCommon.slide2X.set 함수를 통하여 외부에서 컨텐츠 이동만 하고자할때 사용
			if(paramJson.isNotSlide){
				paramJson.target.off("touchstart");
				paramJson.target.off("touchmove");
				paramJson.target.off("touchend");				
			}else{
				//자동 슬라이드 넘기 기능 활성화시
				if(paramJson.isAutoSlide){
					paramJson.returnType = "default";
					paramJson.isNotStop = true;
					mydataCommon.slide2X.autoSlide(paramJson);	
				}				
			}
		},
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 슬라이드가 적용될 컨테이너 요소 보통 슬라이드 컨텐츠를 N개 랩핑하고 있는 요소
		 * @description 자동 슬라이드 동작을 중지 한다.
		 * @example
				mydataCommon.slide2X.stopSlide({
					target :  $("#stustInvTp_popup_11 .swiper-container")
				});	
		 */
		stopSlide : function(paramJson){
			clearInterval(paramJson.target.data("timerid"));
			paramJson.target.data("timerid", null);
		},
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 슬라이드가 적용될 컨테이너 요소 보통 슬라이드 컨텐츠를 N개 랩핑하고 있는 요소
		 * @description 자동 슬라이드 동작을 실행 한다.
		 * @example
				mydataCommon.slide2X.autoSlide({
					target :  $("#stustInvTp_popup_11 .swiper-container")
				});	
		 */
		autoSlide : function(paramJson){
			if(paramJson.target.data("timerid") == null){
				if(paramJson.target.data("index") == null){
					paramJson.target.data("index", 0);	
				}
				if(paramJson.target.data("slideCount") == null){
					paramJson.target.data("slideCount", paramJson.slideCount);	
				}
				if(paramJson.target.data("isNext") == null){
					paramJson.target.data("isNext", true);	
				}
				
				clearInterval(paramJson.target.data("timerid"));
				paramJson.target.data("timerid", null);				
				
				paramJson.target.data("timerid", setInterval(function(){
					var index = paramJson.target.data("index") || 0;
					var slideCount = paramJson.target.data("slideCount") || 0;
					var isNotAnimate = false;
					if(paramJson.target.data("isNext")){
						index += 1;	
					}else{
						index -= 1;
					}
					
					if(index <= -1){
						paramJson.target.data("isNext", true);
						index += 1;
					}else if(index >= slideCount){
						//paramJson.target.data("isNext", false);
						//index -= 1;
						paramJson.target.data("isNext", true);
						index = 0;
						isNotAnimate = true;
					}
					
					mydataCommon.slide2X.set({
						target :  paramJson.target,
						index : index,
						returnType : "runTime",
						isNotStop : paramJson.isNotStop,
						isNotAnimate : isNotAnimate,
						callBackFn : paramJson.callBackFn
					});	
				}, 2000));
			}			
		},
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 슬라이드가 적용될 컨테이너 요소 보통 슬라이드 컨텐츠를 N개 랩핑하고 있는 요소
		 * @param {jQueryObject} [<b>paramJson.index</b>] 이동하고자하는 슬라이트 컨텐츠 index 번호 (좌측부터 0으로 시작되는 index)
		 * @param {jQueryObject} [<b>paramJson.isNotAnimate=false</b>] 이동시 에니메이션 효과 없음
		 * @description 슬라이드 컨텐츠 index 번로호 이동하여준다. (자동 슬라이드 넘김 기능 활성화 상태라면 자동중지됨)
		 * @example
				mydataCommon.slide2X.set({
					target :  $("#stustInvTp_popup_11 .swiper-container"),
					index : 3
				});	
		 */		
		set : function(paramJson){
			var oneContentsWidth = paramJson.target.width();// oneLiObj.outerWidth();
			var tempval4 = oneContentsWidth * paramJson.index;
			paramJson.target.data("index", paramJson.index);
			
			if(paramJson.target.data("contentsByWidth") != null){
				var contentsByWidth = paramJson.target.data("contentsByWidth");
				var oneContentsInnerWidth = paramJson.target.innerWidth();
				if(oneContentsInnerWidth){
					//픽스 사이즈 적용
					contentsByWidth.width(oneContentsInnerWidth);

					// 내부 컨텐츠의 패딩값이 존재할경우 패딩값 제외한 값만 부여
					var width = $(contentsByWidth.get(0)).width();
					var outerWidth = $(contentsByWidth.get(0)).outerWidth()
					if(width < outerWidth){
						var test = outerWidth - width;
						contentsByWidth.width(oneContentsInnerWidth - test);
					}					
				}
			}
			
			if(paramJson.isNotAnimate){
				//각 페이지 영역이 길어서 아래로 스크롤 된경으루 감안하여 디폴트 스크롤 상단처리
				paramJson.target.scrollTop(0);
				paramJson.target.scrollLeft(tempval4);
				if(typeof paramJson.callBackFn === "function"){
					paramJson.callBackFn({returnType : paramJson.returnType, index : paramJson.index});
				}				
			}else{
				//각 페이지 영역이 길어서 아래로 스크롤 된경으루 감안하여 디폴트 스크롤 상단처리
				paramJson.target.scrollTop(0);
				paramJson.target.animate({
					scrollLeft : tempval4
				}, 200, function(){
					if(typeof paramJson.callBackFn === "function"){
						paramJson.callBackFn({returnType : paramJson.returnType, index : paramJson.index});
					}		
				});				
			}
			
			if(paramJson.isNotStop == null){
				mydataCommon.slide2X.stopSlide(paramJson);	
			}
		}
	},
	
	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 * @param {object} JSON OBJECT
	 * @param {jQueryObject} [<b>paramJson.target</b>] 추출할 지역요소
	 * @param {boolean} [<b>paramJson.isReverseCamelCase=false</b>] "row_notInput" 타입으로 추출시 key명을 camel Case 추출할껀지 여부
	 * @returns {void}
	 * @description 파라미터로 넘겨온 해당 지역요소에 포함되는 input요소의 name을 key로하여 key/value 형태의 json 오브젝트를 만들어 리턴해준다. jquery.serializeArray() 함수와 비슷한 기능
	 * @example
	 * <pre>
	 * 		var data = pageCommon.makeJsonParam({target : $("#contentsBody")});
	 * </pre>
	 */	
	makeJsonParam : function(paramJson){
		var data = new Object();
		//
//		if(paramJson.type == "row_notInput"){
//			paramJson.target.find("td").each(function(){
//				var thisObj = $(this);
//				var thisVal = thisObj.text().trim();
//				if(thisObj.data().orgValue != null){
//					thisVal = thisObj.data().orgValue.trim();
//				}
//				if(paramJson.isReverseCamelCase){
//					data[pageCommon.reverseCamelCase(thisObj.attr("data-name"))] = thisVal;	
//				}else{
//					data[thisObj.attr("data-name")] = thisVal;
//				}
//			});
//		}else{
//			if(!paramJson.isNotserialize){
//				var formdata = paramJson.target.serializeArray();
//				$(formdata).each(function(index, obj){
//					var thisObj = $(obj);
//					if(thisObj.hasClass("calVal")){
//						data[obj.name] = obj.replace(/\//g, "").replace(/\-/g, "").replace(/\./g, "").trim();	
//					}else if(obj.name != "jsonFormAllData" && obj.name != "prevSearchCondition"){
//						data[obj.name] = obj.value.trim();	
//					}
//				});				
//			}else{
				paramJson.target.find("select, input, textarea, [data-text]").each(function(index, obj){
					var thisObj = $(obj);
					
					//if(obj.name || thisObj.data().name){
					if(obj.name){
						if(thisObj.hasClass("calVal")){
							data[obj.name] = thisObj.val().replace(/\//g, "").replace(/\-/g, "").replace(/\./g, "").trim();
						}else if(("" + obj.type).toUpperCase() == "RADIO"){
							if(thisObj.is(":checked")){
								var thisVal = obj.value.trim();
								if(thisObj.data().orgValue != null){
									thisVal = thisObj.data().orgValue.trim();
								}
								
								if(data[obj.name] == null){
									data[obj.name] = thisVal;	
								}else{
									if(typeof data[obj.name] === "object"){
										data[obj.name].push(thisVal);
									}else{
										var tempArray = new Array();
										tempArray.push(data[obj.name]);
										tempArray.push(thisVal);
										data[obj.name] = tempArray;
									}
								}
								
									
							}
						}else if(("" + obj.type).toUpperCase() == "CHECKBOX"){
							var thisVal = obj.value.trim();
							
							if(data[obj.name] == null){
								if(thisObj.is(":checked")){
									data[obj.name] = thisVal || "on";
								}
								//else{
								//	data[obj.name] = "";	
								//}
							}else{
								//다중 선택일경우 선택한 value들 삽입
								if(thisObj.is(":checked")){
									if(typeof data[obj.name] === "object"){
										data[obj.name].push(thisVal);
									}else{
										var tempArray = new Array();
										tempArray.push(data[obj.name]);
										tempArray.push(thisVal);
										data[obj.name] = tempArray;
									}							
								}
							}
						}else{
							var thisVal = obj.value.trim();
							if(thisObj.data().orgValue != null){
								thisVal = thisObj.data().orgValue.trim();
							}
							//
							if(thisObj.data().value != null){
								if(isNaN(thisObj.data().value)){
									thisVal = thisObj.data().value.trim();	
								}else{
									thisVal = thisObj.data().value	
								}
								// 넘버 포맷타입 적용 input 일경우 포맷값도 별도로 관리해줌
								data[obj.name+"_format_value"] = thisObj.val().trim();	
							}							
							
							if(data[obj.name] == null){
								data[obj.name] = thisVal;	
							}else{
								if(typeof data[obj.name] === "object"){
									data[obj.name].push(thisVal);
								}else{
									var tempArray = new Array();
									tempArray.push(data[obj.name]);
									tempArray.push(thisVal);
									data[obj.name] = tempArray;
								}
							}	
						}						
					}
//					else{
//						var keyName = thisObj.data("text") || "";
//						if(keyName != ""){
//							data[keyName] = thisObj.text();
//						}
//					}
				});				
//			}		
//		}
		return data;
	},	

	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 * @param {object} JSON OBJECT
	 * @param {jQueryObject} [<b>paramJson.target</b>] 추출할 지역요소
	 * @param {boolean} [<b>paramJson.isReverseCamelCase=false</b>] "row_notInput" 타입으로 추출시 key명을 camel Case 추출할껀지 여부
	 * @returns {void}
	 * @description 파라미터로 넘겨온 해당 지역요소에 포함되는 input요소의 name을 key로하여 key/value 형태의 json 오브젝트를 만들어 리턴해준다. jquery.serializeArray() 함수와 비슷한 기능
	 * @example
	 * <pre>
	 * 		var data = pageCommon.makeJsonParam({target : $("#contentsBody")});
	 * </pre>
	 */	
	makeSerialParam : function(paramJson){
		var data = new Array();	
		var paramidx = 0;
				paramJson.target.find("select, input, textarea, [data-text]").each(function(index, obj){
					var thisObj = $(obj);					
					if(obj.name){
						if(thisObj.hasClass("calVal")){
							data[paramidx++] = obj.name+"="+thisObj.val().replace(/\//g, "").replace(/\-/g, "").replace(/\./g, "").trim();
						}else if(("" + obj.type).toUpperCase() == "RADIO"){
							if(thisObj.is(":checked")){
								var thisVal = obj.value.trim();
								data[paramidx++] = obj.name+"="+encodeURIComponent(thisVal);
								/*
								if(thisObj.data().orgValue != null){
									thisVal = thisObj.data().orgValue.trim();
								}
								
								if(data[obj.name] == null){
									data[obj.name] = thisVal;	
								}else{
									if(typeof data[obj.name] === "object"){
										data[obj.name].push(thisVal);
									}else{
										var tempArray = new Array();
										tempArray.push(data[obj.name]);
										tempArray.push(thisVal);
										data[obj.name] = tempArray;
									}
								}
								*/
									
							}
						}else if(("" + obj.type).toUpperCase() == "CHECKBOX"){
							if(thisObj.is(":checked")){
								var thisVal = obj.value.trim();
								data[paramidx++] = obj.name+"="+encodeURIComponent(thisVal);
							}
							/*
							if(data[obj.name] == null){
								if(thisObj.is(":checked")){
									data[obj.name] = thisVal || "on";
								}
								//else{
								//	data[obj.name] = "";	
								//}
							}else{
								//다중 선택일경우 선택한 value들 삽입
								if(thisObj.is(":checked")){
									if(typeof data[obj.name] === "object"){
										data[obj.name].push(thisVal);
									}else{
										var tempArray = new Array();
										tempArray.push(data[obj.name]);
										tempArray.push(thisVal);
										data[obj.name] = tempArray;
									}							
								}
							}
							*/
						}else{
							var thisVal = obj.value.trim();
							data[paramidx++] = obj.name+"="+encodeURIComponent(thisVal);
							/*
							if(thisObj.data().orgValue != null){
								thisVal = thisObj.data().orgValue.trim();
							}
							//
							if(thisObj.data().value != null){
								if(isNaN(thisObj.data().value)){
									thisVal = thisObj.data().value.trim();	
								}else{
									thisVal = thisObj.data().value	
								}
								// 넘버 포맷타입 적용 input 일경우 포맷값도 별도로 관리해줌
								data[obj.name+"_format_value"] = thisObj.val().trim();	
							}							
							
							if(data[obj.name] == null){
								data[obj.name] = thisVal;	
							}else{
								if(typeof data[obj.name] === "object"){
									data[obj.name].push(thisVal);
								}else{
									var tempArray = new Array();
									tempArray.push(data[obj.name]);
									tempArray.push(thisVal);
									data[obj.name] = tempArray;
								}
							}	*/
						}						
					}				
				});
		return data.join('&');
	},	
	/**
	 * @copyright 윤성민 로직 차용시는 표기 부탁 드립니다.
	 * @param {object} JSON OBJECT
	 * @param {jQueryObject} [<b>paramJson.target</b>] 적용할 대상 지역 요소
	 * @param {boject} [<b>paramJson.data</b>] key/value 구성된 JSON 데이터
	 * @param {boolean} [<b>paramJson.isNotBindDataMakeInput=false</b>] 해당 옵션 부여시 매칭 안되는 result된 데이터 컬럼명에 대하여 해당영에서 hidden으로 input요소를 만들어 준다
	 * @param {boolean} [<b>paramJson.isNotCalFormat</b>] 날짜타입 포맷 처리 여부
	 * @returns {void}
	 * @description 한건의 json 데이터를 던져주면 해당 key명으로 name값 부여되 였는 input, select, textarea 요소에 데이터를 바인딩하여 준다.
	 * @example
	 * <pre>
	 * mydataCommon.setDataBinding({target : $("#mainForm .group_area"), data : dataS});
	 * </pre>
	 */	
	setDataBinding : function(paramJson){
		//선행 클리어
		//if(!paramJson.isNotClear){
		//	mydataCommon.formReset(paramJson.target);	
		//}
		//
		for(var key in paramJson.data){
			var reverseCameCaseName = null;
			if(paramJson.isNotReverseCamelCase == null || paramJson.isNotReverseCamelCase){
				reverseCameCaseName =  key;	
			}else{
				reverseCameCaseName =  mydataCommon.reverseCamelCase(key);
			}
			var tempObj = paramJson.target.find("[name="+reverseCameCaseName+"], [data-text="+reverseCameCaseName+"], [data-html="+reverseCameCaseName+"]");
			if(tempObj.length === 1){
				var tmepElement = tempObj.get(0); 
				//input, select 등등 name 속성으로 가지는 일반적인 입력 요소일때
				if(tmepElement.name){
					//
					if(tmepElement.type && (tmepElement.type.toLocaleLowerCase() == "checkbox" || tmepElement.type.toLocaleLowerCase() == "radio")){
						if(tempObj.val() == paramJson.data[key]){
							tempObj.prop("checked", true);
						}else{
							tempObj.prop("checked", false);
						}
					}else{
						if(tempObj.hasClass("val") && !tempObj.is(":visible")){
							tempObj.val(paramJson.data[key]);
							tempObj.closest(".groupWrap").find(".label").val(paramJson.data[key]);
						}else{
							tempObj.val(paramJson.data[key]);
						}
							
					}
				}else{//★★★그밖의 커스텀 요소 span div 등등 name 속성으로 가질수없는 요소에 값을 바인딩하고자 할때 사용되는 요소
					if(tempObj.attr("data-text") == reverseCameCaseName){
						tempObj.text(paramJson.data[key]);
					}else if(tempObj.attr("data-html") == reverseCameCaseName){
						tempObj.html(paramJson.data[key]);
					}
				}
			}else if(tempObj.length > 1){
				//라디오 박스 등등 구룹화 되여있는 요소
				tempObj.each(function(){
					var tempObj2 = $(this);
					if(tempObj2.val() == paramJson.data[key]){
						tempObj2.prop("checked", true);
						return false;
					}else{
						tempObj2.prop("checked", false);
					}
				});
			}else{
				//해당 옵션 부여시 매칭 안되는 result된 데이터 컬럼명에 대하여 해당영에서 hidden으로 input요소를 만들어 준다
				if(paramJson.isNotBindDataMakeInput){
					var inputObj = $(document.createElement("input"));
					inputObj.prop("name", reverseCameCaseName);
					inputObj.prop("type", "hidden");
					inputObj.val(paramJson.data[key]);
					paramJson.target.prepend(inputObj);
				}
			}	
		}
		//
		//날짜타입 포맷 처리
		if(!paramJson.isNotCalFormat){
			paramJson.target.find(".calVal").each(function(){
				var dateObj = $(this);
				dateObj.val(dateObj.val().format("####-##-##"));
			});			
		}
		//	
	},
	/**
	 * @param {jQueryObject} 대상 지역 selector
	 * @returns {void}
	 * @description target에 포함되여 있는 input, select, textare를 초기화한다...초기화 제외하고 싶을때는 해당 요소에 notReset클래스를 부여한다.
	 * @example
	 * <pre>
	 * mydataCommon.formReset($("#mainForm"));mydataCommon.formReset($("#mainForm"));
	 * </pre>
	 */	
	formReset : function(targetForm){
		targetForm.find("input, select, textarea").each(function(){
			var thisObj = $(this);
			if(this.type && (this.type.toLocaleLowerCase() == "radio" || this.type.toLocaleLowerCase() == "checkbox")){
				//체크박스, 라디오박스 제외
			}else{
				if(!thisObj.hasClass("notReset")){
					thisObj.val("");
					if(thisObj.data().orgValue){
						delete thisObj.data().orgValue;
					}								
				}				
			}
		});
	},	
	formReset2 : function(targetForm){
		targetForm.find("input, select, textarea").each(function(){
			var thisObj = $(this);
			if(this.type && (this.type.toLocaleLowerCase() == "radio" || this.type.toLocaleLowerCase() == "checkbox")){
				if(!thisObj.hasClass("notReset")){
					thisObj.prop("checked",false);
				}
			}else{
				if(!thisObj.hasClass("notReset")){
					thisObj.val("");
					if(thisObj.data().orgValue){
						delete thisObj.data().orgValue;
					}								
				}				
			}
		});
	},	
	/* 정합성관련(validation) 모음 패키지 */	
	vald : {
		/**
		 * @param {object} JSON OBJECT
		 * @param {jQueryObject} [<b>paramJson.target</b>] 일괄 정합성 검사할 특정 레이아웃 지역 요소
		 * @param {boolean} [<b>paramJson.is_disabled_check=false</b>] disabled된 요소의 정합성 검사 여부 (디폴트 제외)
		 * @param {boolean} [<b>paramJson.is_only_msg=false</b>] "title, placeholder 또는 data-validation_msg" 메세지 만을 이용하여 메시징 처리 (기본은 title, placeholder 또는 data-validation_msg값과 조합하여 메시징 처리함)
		 * @param {boolean} [<b>paramJson.isNotMsg=false</b>] 정합성 결과 리턴타입이 boolean이 아닌 {isSuccess : 성공여부boolean, msgArray : 메세지 배열, firstObj : 위배된 첫번째 오브젝트} 타입
		 * @returns {void}
		 * @description 규약에의한 입력값 일괄 정합성 검사 및 경고 메세지 처리 (data-validation_msg 값 우선)
		 * <pre>
		 * 정합성 타입 옵션 
		 *		input, select, textarea 등등 입력 받는 요소에 해당 class를 부여하고 해당함수를 사용하면 정합성 검사및 메세지 처리함
		 *		1. 
		 *			메세지 처리를 위하여 해당 요소에 커스텀 속성 "data-validation_msg"을 추가하여 해당 메세지를 정의한다. 없을시 title, placeholder 순서대로 우선하여 메세지에 이용한다.
		 *    	2.
		 *    		 notNull 처리된 엘리먼트 input type=text 입력요소 는 디폴트로 "을(를) 입력하세요" 메세지처리하고 라디오, 체크박스, 선택박스의경우는 디폴트"을(를) 선택하세요" 메세지 처리한다.
		 *    		이때 입력요소이지만 data-msgType="select"를 부여하면 디폴트"을(를) 선택하세요" 메세지 처리한다.
		 *		ex : <input name="join_orgn_orcd" class="notNull"  type="text" title="은행" data-msgType="select">
		 *		3. 해당 요소에 data-target_id 값이 존재하면 정합성 위배시 첫번째 요소를 리턴하거나 디폴트로 해당 요소 위치로 이동처리하는데 만약 정합성 요소가 hidden된 요소이거나 할때 대시하여 이동할 요소의 ID값
		 *		ex : <input name="join_orgn_orcd" class="notNull"  type="hidden" title="은행" data-target_id="div_investPeriod">
		 *		4. 기타
		 *			data-is_value_type="true" 속성은  radio 타입일때 radio구룹중 하나를 선택해야하며, 선택된 값이 존재해야 하는 유효성 체그 radio타입은 디폴트로 radio구룹중 체크 여부만 따짐
		 *		class 종류
		 *			notNullCode : 팝업 타입의 필드에서 코드를 검색하지 않고 텍스트로 입력만한경우
		 *			notNull : 일반적인 not null 검사
		 *			groupWrap : 구룹화 하여 정합성 검사할 대상에 대하여 랩핑한다 예를들어 check박스 구룹 등등 (구룹중 하나만 입력되여 있으면 될경우) 
		 * </pre>
		 * @example
		 * <pre>
		 *		if(mydataCommon.validation({target : $("#contentsBody")})){
		 *			return false;
		 *		}
		 *
		 *
		 *		// 양석열 추가.
		 *		// 첫번째 미입력 값을 바로 팝업 시키기 위해 수정.
		 *		if(mydataCommon.validation({target : $("#contentsBody"), is_only_msg : true, immedtAlertPop:true})){
		 *			return false;
		 *		}

		 * </pre>
		 */	
		validation : function(paramJson){
			var isNotSuccess = false;
			var allMsgArray = [];
			var firstObj = null;
			var is_disabled_check = paramJson.is_disabled_check || false;
			var separatorStr = "\"";
			var separatorEnd = "\"";
			var immedtAlertPop = paramJson.immedtAlertPop !="" ?paramJson.immedtAlertPop:false; //notnull 체크시 미입력 팝업 시키기 위해 paramjson 추가(양석열)
			//
			var groupCheckScript = function(groupObj, isCheckedType){
				var allCheck = true;
				//예를 들어 같은 구룹의 check 박스가 하나도 선택되지 않은 경우이다.
				groupObj.each(function(){
					var tempThis2 = $(this);
					if(isCheckedType){
						if(tempThis2.is(":checked")){
							allCheck = false;
						}						
					}else{
						if(tempThis2.is(":checked") && !mydataCommon.util.isNull(tempThis2.val())){
							allCheck = false;
						}
					}
				});
				return allCheck;
			};
			//
			var addMsgScript = function(thisMsg, paramThisObj){
				isNotSuccess = true;
				allMsgArray.push(thisMsg);
				//
				if(!firstObj){
					
					if(paramThisObj != null && paramThisObj.data("target_id") != null){
						firstObj = $("#" + paramThisObj.data("target_id"));
					}else{
						firstObj = paramThisObj;	
					}
					
					
				}
				//console.log(paramThisObj);
			};		
			//
			//not null 룰이 적용된 input 요소 등등을 일괄 검색하여 해당 요소에 값이 존재하는지 여부를 판단하여 알림메세지 처리한다.
			//paramJson.target.find(".notNull").each(function(){
			
			var targetObj = null;
			if(paramJson.is_all_input){
				try{
					targetObj = paramJson.target.find("input[name]:");	
				}catch(e){
					targetObj = paramJson.target;
				}
				
			}else{
				targetObj = paramJson.target.find(".notNull");
			}
			
			targetObj.each(function(){
				var tempThis = $(this);
				paramJson.is_only_msg = paramJson.is_only_msg || tempThis.data().is_only_msg;
				
				//
				if(!is_disabled_check){
					if(tempThis.prop("disabled")){
						return true;
					}
				}
				
				//radio 등등 구룹으 정합성 검사시는 구룹중 하나의 요소에 정합성 검사 클래스를 부여함
				if(this.type &&  this.type.toLocaleLowerCase() == "checkbox"){
					var groupObj = paramJson.target.find("[name="+ this.name +"]");
					var allCheck = groupCheckScript(groupObj, true);
					if(allCheck){
						var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title") || tempThis.attr("placeholder");
						var tempMsg = paramJson.is_only_msg ? thisMsg : "\"" + thisMsg + "\" 을(를) 선택 하십시오!";
						
						addMsgScript(tempMsg, $(groupObj.get(0)));
						if(immedtAlertPop) return false;
					}
				}else if(this.type && this.type.toLocaleLowerCase() == "radio"){
					//radio 등등 구룹으 정합성 검사시는 구룹중 하나의 요소에 정합성 검사 클래스를 부여함
					//var groupObj = tempThis.closest(".groupWrap").find("[type="+ this.type.toLocaleLowerCase() +"]");
					var groupObj = paramJson.target.find("[name="+ this.name +"]");
					var is_value_type = $(groupObj.get(0)).data("is_value_type") != null ? false : true;
					var allCheck = groupCheckScript(groupObj, is_value_type);
					if(allCheck){
						var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title") || tempThis.attr("placeholder");
						var tempMsg = paramJson.is_only_msg ? thisMsg : "\"" + thisMsg + "\" 을(를) 선택 하십시오!";
						addMsgScript(tempMsg, $(groupObj.get(0)));
						if(immedtAlertPop) return false;
					}
				}else{
					if(mydataCommon.util.isNull(tempThis.val())){
						//커스텀 tag인 캘린더일때는 예외 처리
						if(tempThis.hasClass("groupWrap")){
							//
						}else{
							//
							//일반 케이스
							//
							var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title") || tempThis.attr("placeholder");
							var msgType = tempThis.attr("data-msgType");
							var tempMsg = "";
							//
							if(this.nodeName.toLocaleLowerCase() == "select" || msgType == "select"){
								tempMsg = paramJson.is_only_msg ? thisMsg : separatorStr + thisMsg + separatorEnd + pageCommon.msg.pleaseSelect;
							}else{
								tempMsg = paramJson.is_only_msg ? thisMsg : separatorStr + thisMsg + separatorEnd + pageCommon.msg.pleaseEnter;
							}
							//일반케이스에서 구룹으로 정합성 체크할경우
							if(tempThis.closest(".groupWrap").length > 0){
								var groupObj = tempThis.closest(".groupWrap").find("input, select, textarea");
								
								var allCheck = groupCheckScript(groupObj, false);
								if(allCheck){
									//var tempObj_ = groupObj.not("[readonly = readonly]").eq(0)
									var tempObj_ = null;
									groupObj.not("[readonly = readonly]").each(function(){
										var tempMemObj = $(this);
										if(tempMemObj.is(":visible")){
											tempObj_ = tempMemObj;
											return false;
										}
									});
									addMsgScript(tempMsg, tempObj_);
									if(immedtAlertPop) return false;
								}
							}else{
								addMsgScript(tempMsg, tempThis);	
								if(immedtAlertPop) return false;
							}

						}
					}
				}
			});
			
			
			
			/*
			 * 
			 * 
			 * 
			 * ***************************************************************************************************************
			 *  일단 notNull 재약만 공통으로 지원함 필요시 아래 로직중 활성화 하여 이야기 맞게 사용해야함
			 * *************************************************************************************************************** 
			 * 
			 * 
			 * 
			 * 
			//min Length 룰이 적용된 input 요소 등등을 일괄 검색하여 해당 요소에 값이 존재하는지 여부를 판단하여 알림메세지 처리한다.
			paramJson.target.find(".minLength").each(function(){
				var tempThis = $(this);
				//
				if(!is_disabled_check){
					if(tempThis.prop("disabled")){
						return true;
					}
				}
				//
				//radio 등등 구룹으 정합성 검사시는 구룹중 하나의 요소에 정합성 검사 클래스를 부여함
				if(this.type && (this.type.toLocaleLowerCase() == "radio" || this.type.toLocaleLowerCase() == "checkbox")){
					//
				}else{
					//if(mydataCommon.util.isNull(tempThis.val())){
					if(tempThis.closest(".groupWrap").length > 0){
						var groupObj = tempThis.closest(".groupWrap").find(".minLength");
						var msgS = [];
						var msgV = [];
						var firstObj = null;
						//
						var checkB = true;
						//
						if(!tempThis.data("validation_skip")){
							
							//
							groupObj.each(function(i){
								var tempThis_ = $(this);
								tempThis_.data("validation_skip", true);
								var tempValue = mydataCommon.util.nvl(tempThis_.val()).trim();
								var minLengthVal = Number(tempThis_.attr("min"));
								if(i === 0){
									firstObj = tempThis_;
								}
								if(minLengthVal > 0){
									if(minLengthVal > tempValue.toString().length){
										//
										// 구룹 케이스
										//
										var thisMsg = tempThis_.attr("data-validation_msg") || tempThis.attr("title");
										msgS.push(thisMsg);
										msgV.push(minLengthVal);
									}else{
										checkB = false;
										return false;
									}
								}
							});
							//
							if(checkB){
								var tempMsg_ = pageCommon.msg.pleaseMinSize.replace("@", "\"" + msgV.join(", ") + "\"");
								var tempMsg = "\"" + msgS.join(", ") + "\"" + tempMsg_;
								addMsgScript(tempMsg, firstObj);
							}						
						}
						//
					}else{
						if(!tempThis.data("validation_skip")){
							var tempValue = mydataCommon.util.nvl(tempThis.val()).trim();
							var minLengthVal = Number(tempThis.attr("min"));
							if(minLengthVal > 0){
								if(minLengthVal > tempValue.toString().length){
									//
									//일반 케이스
									//
									var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
									var tempMsg_ = pageCommon.msg.pleaseMinSize.replace("@", "\"" + minLengthVal + "\"");
									var tempMsg = paramJson.is_only_msg ? thisMsg : separatorStr + thisMsg + separatorEnd +tempMsg_;
									addMsgScript(tempMsg, tempThis);
								}					
							}	
						}
					}
				}
			});		
			paramJson.target.find(".minLength").each(function(){
				var tempThis = $(this);
				tempThis.data("validation_skip", false);
			});
			//
			//max value 룰이 적용된 input 요소 등등을 일괄 검색하여 해당 요소에 값이 존재하는지 여부를 판단하여 알림메세지 처리한다.
			paramJson.target.find(".maxVal").each(function(){
				var tempThis = $(this);
				//
				if(!is_disabled_check){
					if(tempThis.prop("disabled")){
						return true;
					}
				}
				//
				//radio 등등 구룹으 정합성 검사시는 구룹중 하나의 요소에 정합성 검사 클래스를 부여함
				if(this.type && (this.type.toLocaleLowerCase() == "radio" || this.type.toLocaleLowerCase() == "checkbox")){
					//
				}else{
					//if(mydataCommon.util.isNull(tempThis.val())){
					if(tempThis.closest(".groupWrap").length > 0){
						var groupObj = tempThis.closest(".groupWrap").find(".minLength");
						var msgS = [];
						var msgV = [];
						var firstObj = null;
						//
						var checkB = true;
						//
						if(!tempThis.data("validation_skip")){
							
							//
							groupObj.each(function(i){
								var tempThis_ = $(this);
								tempThis_.data("validation_skip", true);
								var tempValue = mydataCommon.util.nvl(tempThis_.val()).trim();
								var minLengthVal = Number(tempThis_.attr("min"));
								if(i === 0){
									firstObj = tempThis_;
								}
								if(minLengthVal > 0){
									if(minLengthVal > tempValue.toString().length){
										//
										// 구룹 케이스
										//
										var thisMsg = tempThis_.attr("data-validation_msg") || tempThis.attr("title");
										msgS.push(thisMsg);
										msgV.push(minLengthVal);
									}else{
										checkB = false;
										return false;
									}
								}
							});
							//
							if(checkB){
								var tempMsg_ = pageCommon.msg.pleaseMinSize.replace("@", "\"" + msgV.join(", ") + "\"");
								var tempMsg = "\"" + msgS.join(", ") + "\"" + tempMsg_;
								addMsgScript(tempMsg, firstObj);
							}						
						}
						//
					}else{
						if(!tempThis.data("validation_skip")){
							var tempValue = mydataCommon.util.nvl(tempThis.val()).trim();
							var maxVal = Number(tempThis.attr("max"));
							if(maxVal > 0){
								if(maxVal < Number(tempValue)){
									//
									//일반 케이스
									//
									var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
									var tempMsg_ = pageCommon.msg.pleaseMaxValue.replace("@", "\"" + maxVal + "\"");
									var tempMsg = paramJson.is_only_msg ? thisMsg : separatorStr + thisMsg + separatorEnd +tempMsg_;
									addMsgScript(tempMsg, tempThis);
								}					
							}	
						}
					}
				}
			});				
			//
			//
			//팝업을 통하여 값을 세팅하는 요소일경우 화면에 보이는 input요소에는 값이 존재하지만 팝업 검색을 통하여 코드검색하지 않을경우임을 체크한다.
			paramJson.target.find(".notNullCode").each(function(){
				var tempThis = $(this);
				//
				if(mydataCommon.util.isNull(tempThis.val())){
					var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
					if(tempThis.hasClass("val")){
						var labelObj = tempThis.closest(".groupWrap").find(".label");
						if(!mydataCommon.util.isNull(labelObj.val())){
							//정합성 위배시 사용할 메세지를 사용하는 케이스	
							var tempMsg = paramJson.is_only_msg ? thisMsg : "\"" + thisMsg + "\" 을(를) 검색 하십시오!";
							addMsgScript(tempMsg, labelObj);
							
						}
					}				
				}
			});		
			//
			//
			//멀티 notNull 대상 요소의 notNull 여부가 같지 않을때 경고
			paramJson.target.find(".notNullMulti").each(function(){
				var groupObj = $(this);
				var allCheck = false;
				var firstCheck = null;
				var fristObj = null;
				groupObj.find("input, select, textarea").each(function(i){
					var tempThis = $(this);
					//
					if(fristObj == null){
						if(mydataCommon.util.isNull(tempThis.val())){
							fristObj = tempThis;
						}					
					}
					//
					if(i === 0){
						firstCheck = mydataCommon.util.isNull(tempThis.val());	
					}else{
						if(firstCheck != mydataCommon.util.isNull(tempThis.val())){
							var thisMsg = fristObj.attr("data-validation_msg") || fristObj.attr("title");
							//	
							var tempMsg = paramJson.is_only_msg ? thisMsg : "\"" + thisMsg + "\""+pageCommon.msg.pleaseEnter;
							addMsgScript(tempMsg, fristObj);
						}
					}
				});
			});
			//
			//
			//날짜 입력값 정합성 체크(기존 awpUtil.js checkDateg함수 롤 적용)
			var checkDateThis = function(target){
				var validformat = /^\d{4}\-\d{2}\-\d{2}$/; // Basic check for format validity
				var returnval = false;
				var val = $.trim(target.val());
				if(val.length > 0){
					if(validformat.test(val)){
						var yearfield = val.split("-")[0];
						var monthfield = val.split("-")[1];
						var dayfield = val.split("-")[2];
						var dayobj = new Date(yearfield, monthfield - 1, dayfield);
						if((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield)){
							returnval = false;
						}else{
							returnval = true;
						}
					}
				}else{
					returnval = true;
				}
				return returnval;
			}
			//
			// 캘린더 타입의 입력값 정합성 체크
			paramJson.target.find(".calVal").each(function(){
				var tempThis = $(this);
				//
				if(!is_disabled_check){
					if(tempThis.prop("disabled")){
						return true;
					}
				}
				//
				var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
				if(!mydataCommon.util.isNull(tempThis.val())){
					if(!checkDateThis(tempThis)){
						var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
						var tempMsg = paramJson.is_only_msg ? thisMsg : "[" + thisMsg + "] " + msg("quality.anal.tanklorry.alert5");
						addMsgScript(tempMsg, tempThis);
					}else{
						// 날짜 기간일때 시작일 종료일 정합성 체크
						if(tempThis.closest(".groupWrap")){
							var calObj = tempThis.closest(".groupWrap").find(".calVal");
							var thisMsg = tempThis.attr("data-validation_msg") || tempThis.attr("title");
							//해당 요소중 시작일 요소만 대상으로 정합성 검사한다.
							if(calObj.length > 1 && $(calObj[0]).get(0) == tempThis.get(0)){
								var fromObj = $(calObj[0]);
								var toObj = $(calObj[1]);
								var fromVal = fromObj.val().replace(/\//g, "").replace(/\-/g, "").replace(/\./g, "").format("####-##-##");
								var toVal = toObj.val().replace(/\//g, "").replace(/\-/g, "").replace(/\./g, "").format("####-##-##");
								var fromDate = new Date(fromVal);
								var toDate = new Date(toVal);
								var validation_cal = tempThis.attr("data-validation_cal");
								//
								// 시작일이 종료일보다 클때
								if(fromDate > toDate){
									var tempMsg = paramJson.is_only_msg ? thisMsg : msg("quality.anal.common.alert.MSG0000206");
									addMsgScript(tempMsg, fromObj);
								//기타 룰 체크 (아직 요건 없음으로 구현 X)
								}else if(validation_cal != null){
									//
									//
									//
									var validation_cal_val_month = Number(validation_cal.replace("M", ""));
									if(validation_cal.indexOf("M") > -1){
										toDate.setMonth(toDate.getMonth() - validation_cal_val_month);
										if(fromDate < toDate){
											var tempMsg = paramJson.is_only_msg ? thisMsg : "\"" + thisMsg + "\"" + pageCommon.msg.pleaseMonth.replace("@", "\"" + validation_cal_val_month + "\"");
											addMsgScript(tempMsg, fromObj);
										}
									}else if(validation_cal.indexOf("D") > -1){
										//
									}
									//
									//
									//
								}
							}
						}
					}
				}
			});	
			*/
			//
			
			if(isNotSuccess){
				if(paramJson.isNotMsg){
					
				}else{
					mydataCommon.msg.alert({msg : allMsgArray.join("\n"), callBackFn : function(){
						//디폴트 위치 이동
						if(firstObj != null){
							firstObj[0].scrollIntoView();	
							firstObj[0].focus();
						}
					}});					
				}
			}
			if(paramJson.isNotMsg){
				return {isSuccess : !isNotSuccess, msgArray : allMsgArray, firstObj : firstObj};
			}else{
				return isNotSuccess;	
			}
			
		},		
		
		
	},
	/* 단위 공통 */
	unit : {

		appSetupNotice : function(){
			mydataCommon.msg.confirm({msg : "모바일 영웅문S를 설치합니다.", callBackFn : function(isConfirm){
				if(isConfirm){
					if(pageCom.prop.isANDROID){
						document.location.href = "market://details?id=com.linkzen.app";	
					}else{
						document.location.href = "itms-apps//itunes.apple.com/app/id387842606?mt=8";						
					}
				}
			}});	
		}
	},
	appBridge : {
		openNumKeypad2 : function(targetId,maxLength,keypadType,returnId,callbackFuncName){
			//targetId : 필수, '#target'
			//maxLength : 필수
			//keypadType : 선택, 기본값('2')
			//returnId : 선택, 결과값 셋팅 객체 지정 문자열, 기본값(targetId)
			//callbackFuncName : 선택, 기본값("pageUnit.fn.callback_getKeypadResult")
			//mydataCommon.appBridge.openNumKeypad2('cur_age',3);
			targetId = targetId ? $.trim(targetId) : '';
			if(targetId && maxLength){
				targetId = targetId.replace('#','');
				maxLength = maxLength ? parseInt(maxLength) : 0;
				returnId = returnId ? returnId : targetId;
				keypadType = keypadType ? keypadType : '2';
				callbackFuncName = callbackFuncName ? callbackFuncName : "pageUnit.fn.callback_getKeypadResult";
				mydataCommon.util.eBind('click','#'+targetId,function(e, obj){
					var datas = {keypadType:keypadType,keypadValue:$(obj).val(),maxLength:maxLength,rId:returnId};
					mydataCommon.appBridge.openNumKeypad(datas,callbackFuncName);
				});
			}
		},
		openNumKeypad : function(datas,callbackFunction){
			/*키패드타입(0:일반, 1:Sign(음수, 소수 표현),2:비밀번호(00, 000 없음), 3:소수, 8:소수(부호추가)*/
			//var strSigning = {"keypadType" : keypadType,"keypadValue":keypadValue,"maxLength":maxLength,"rId":returnId};
			var obj = {command : "getNumberKeyPad" , param:datas ,callback: callbackFunction};
			var data = JSON.stringify(obj);
			if (!mydataCommon.util.isLoc) {
				if(pageCom.prop.isIPHONE)
				{
					data = encodeURIComponent(data);
					//window.location = "iTransKeyS:"+obj;//handleOpenURL
					window.location = "mydata://"+data
				}
				else if(pageCom.prop.isANDROID)
				{	
					//window.MTranskey.setKey(data);
					document.location.href = "mydata://"+data
				}
			}
		},
		scrapping : function(datas, callbackFunction){
			/*
			 * OID 정보
				1001: 통합연금포털
				2001: 진료받은내용
			 * */
			//var strSigning = {"keypadType" : keypadType,"keypadValue":keypadValue,"maxLength":maxLength,"rId":returnId};
			var obj = {command : "getMultiScraping" , param:datas ,callback: callbackFunction};
			var data = JSON.stringify(obj);
			if(pageCom.prop.isIPHONE)
			{
				data = encodeURIComponent(data);
				window.location = "mydata://"+data
			}
			else if(pageCom.prop.isANDROID)
			{
				document.location.href = "mydata://"+data
			}
		},
		
		webviewReq : function(paramJson){
			//command  : 웹뷰함수호출명
			//viewId   : MTS 화면번호
			//urlMapId : 연결시킬url(MtsViewIDUrl.prop에 정의 필요)
			//viewType : 화면,전창(full, 화면아이디고정:325),반창(half, 화면아이디고정:326)
			//popClose : 반창일 경우 닫기 여부(true, false)
			//callback : 콜백함수명
			//strPopupTitle	: 전창팝업일때 타이틀
			//strJongmokCode : 종목코드
			//strOpenIpgeumAcntNum : 입금 계좌번호
			//strOpenchulgeumAcntNum : 출금 계좌번호
			//strOpenOrgnCode : 기관코드

			//예) 	mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"m0703", callback:"callback_callMoveView", viewType:"half"});
			//      =>반창열기, m0703 url, 반창인경우 화면 아이디 고정(325)
			//예) 	mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
			//		=> 닫기버튼 클릭시 반창닫힘

			var command 	= paramJson.command;
			var viewId 		= paramJson.viewId;
			var urlMapId 	= paramJson.urlMapId;
			var viewType 	= paramJson.viewType;
			var popClose    = paramJson.popClose;
			var callback	= paramJson.callback;
			
			
			var strPopupTitle	= paramJson.strPopupTitle;
			var strJongmokCode	= paramJson.strJongmokCode;
			var strOpenIpgeumAcntNum	= paramJson.strOpenIpgeumAcntNum;
			var strOpenchulgeumAcntNum	= paramJson.strOpenchulgeumAcntNum;
			var strOpenOrgnCode	= paramJson.strOpenOrgnCode;
			
    		
			//앱요청으로 인해 callback변수에 공백처리
			if(callback == undefined || callback == null){
				callback ="";
				
				if(popClose){
					callback = "callback_"+command; // 수정예정
				}
				
			}
			if(strPopupTitle == undefined || strPopupTitle == null) strPopupTitle = "";
			if(strOpenIpgeumAcntNum == undefined || strOpenIpgeumAcntNum == null) strOpenIpgeumAcntNum = "";
			if(strOpenchulgeumAcntNum == undefined || strOpenchulgeumAcntNum == null) strOpenchulgeumAcntNum = "";
			if(strOpenOrgnCode == undefined || strOpenOrgnCode == null) strOpenOrgnCode = "";

			if(viewId==""|| viewId == undefined || viewId == null){
				if(viewType==""|| viewType == undefined || viewType == null){
					if(urlMapId=="MY0101") viewId="316"
					else if (urlMapId=="BANK0101") viewId="317"
					else if (urlMapId=="INVE0101") viewId="318"
					else if (urlMapId=="LOAN0101") viewId="319"
					else if (urlMapId=="CRED0101") viewId="320"
					else if (urlMapId=="INSU0101") viewId="321"
					else if (urlMapId=="ANNU0101") viewId="322"
					else if (urlMapId=="CARD0101") viewId="323"
					else if (urlMapId=="RECO0101") viewId="324"
						
					else if (urlMapId=="AUTH0101") viewId="327"
					else if (urlMapId=="AUTH0301") viewId="389"
					else if (urlMapId=="AUTH0401") viewId="390"	
					else if (urlMapId=="AUTH0201") viewId="391"	
					else if (urlMapId=="AUTH0501") viewId="392"	
					else if (urlMapId=="AUTH0302") viewId="393"	
					else if (urlMapId=="AUTH0302") viewId="394"	
					else viewId="325"	

				}else{
					viewId="325"
				}
			}
					
			var obj = {
				command:command,
				param: {
				},
				callback: callback
			}
			
			if(popClose) {
				obj.param.value="ClosePopup"
				obj.param.data=1 // data가 있어야지 콜백함수 호출가능.
				
			}else{
				obj.param.strMenuID = viewId;
				obj.param.strSendViewData = urlMapId;
				obj.param.bAddStack = "0";
				
				obj.param.strPopupTitle = strPopupTitle;
				obj.param.strJongmokCode = strJongmokCode;
				obj.param.strOpenIpgeumAcntNum = strOpenIpgeumAcntNum;
				obj.param.strOpenchulgeumAcntNum = strOpenchulgeumAcntNum;
				obj.param.strOpenOrgnCode = strOpenOrgnCode;
			}
			
			var strObj = JSON.stringify(obj)
			
			//local 개발구분
	    	var isLocalGb = mydataCommon.util.isLoc;
	    	if(isLocalGb){
	    		if(popClose){
	    			history.back();
	    		}else{
	    			var data = {
	    					urlMapId : urlMapId
	    			}
					mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/common/localTestView",data);
	    		}
	    	}else{
	    		if(pageCom.prop.isANDROID){
					document.location.href  = "mydata://"+strObj; 
				}else{
					window.location= "mydata://"+strObj;      
				}
	    	}
		},
		openToast : function(msg){
			var strSigning = {"strToastMsg" : msg};
			var obj = {command : "callToast" , param:strSigning ,callback:''};
			var data = JSON.stringify(obj);		
			if(pageCom.prop.isIPHONE)
			{
				//data = encodeURIComponent(data);			
				window.location = "mydata://"+data
			}
			else if(pageCom.prop.isANDROID)
			{
				document.location.href = "mydata://"+data
			}
		},
		// 스마트알림(push)신청을 위한 기기정보
		// mydataCommon.appBridge.getPushData();
		// mydataCommon.appBridge.getPushData('callback_getPushData');	//기기정보수신 콜백함수명 문자열
		// 기본 기기정보수신 콜백함수 : function callback_getPushData(jsonString){ console.info('callback_getPushData : ',jsonString); }
		getPushData : function(callbackFuncName){
			//local 개발구분
	    	var isLocalGb = mydataCommon.util.isLoc;
	    	if(!isLocalGb){
				callbackFuncName = callbackFuncName ? callbackFuncName : 'callback_getPushData';
				var obj = {	command: "getPushData", param: {}, callback: callbackFuncName };
				var data = JSON.stringify(obj);
				if(pageCom.prop.isIPHONE)
				{
				   window.location = "mydata://"+data
				}
				else if(pageCom.prop.isANDROID)
				{
					document.location.href = "mydata://"+data
				}
			}
		},
		// 앱간 이동 (앱<->앱) 이동 함수
		callApptoapp : function(paramJson){
			// strAppcode : 매체 코드([영웅문SG Android=AG, IOS=AA], [자산관리 Android=IG, IOS=IA])
			// strMenuid : 화면번호
			// strJongmokCode : 종목코드(없을 시 "" 빈값)
			// strLoginType : 시세 또는 인증서 로그인 타입 구분 (마이데이터의 경우 항상 “Y” 값)
			
			var strAppcode;
			var strMenuid	= paramJson.strMenuid;
			//종목코드도 받아오도록 변경
			var strJongmokCode = mydataCommon.util.nvl(paramJson.strJongmokCode,"");
			
			if(pageCom.prop.isIPHONE)
				strAppcode = "AA";
			else if(pageCom.prop.isANDROID)
				strAppcode = "AG";
		
			var obj = { command: "callApptoapp", param: { strAppcode: strAppcode, strMenuid:strMenuid, strJongmokCode:strJongmokCode, strLoginType:"Y" }, callback:'' }
			var data = JSON.stringify(obj);
			
			if(pageCom.prop.isIPHONE)
			{
			   window.location = "mydata://"+data
			}
			else if(pageCom.prop.isANDROID)
			{
				document.location.href = "mydata://"+data
			}
		}
	},
	/* 페이지 관련 함수 모음 패키지 */
	page : {
		getParamData : function() {
			//해당 페이지 객체 속성에 pageUnit.prop.v_storageKeyName = '스티리지저장키값'; 값이 정의 되어 있어야함.
			//파라미터 데이터 읽어오기 (로컬스토리지에서 읽어옴) - ajax 호출 등 넘기는 파라미터 객체.
			//mydataCommon.page.getParamData()
			var v_storageKeyName = pageUnit.prop.v_storageKeyName;
			if(v_storageKeyName){
				var data = mydataCommon.util.getArrayData(v_storageKeyName);
				data = data ? data : {};
				//엑세스 시간, 로컬스토리지에 기록
				var v_datestr = mydataCommon.util.getStrDate();
				var v_datetime = mydataCommon.util.getStrDate(v_datestr,'-')+' '+mydataCommon.util.getStrTime(':');
				var v_key = v_storageKeyName+'_accesstime';
				mydataCommon.util.setData(v_key,v_datetime);
				return data;
			} else {
				return null;
			}
		},
		getSubParamData : function(ukey) {
			//하위키값에 해당하는 데이터 반환.
			//mydataCommon.page.getSubParamData()
			var result = {};
			var rootData = mydataCommon.page.getParamData();
			rootData = rootData ? rootData : {};
			var v_key = ukey ? ukey : (pageUnit.prop.v_storageSubKeyName ? pageUnit.prop.v_storageSubKeyName : pageUnit.prop.v_id);
			if(v_key){
				result = rootData[v_key] ? rootData[v_key] : {};
			}
			return result;
		},
		setParamData : function(paramData,isOverwrite) {
			//해당 페이지 객체 속성에 pageUnit.prop.v_storageKeyName = '스티리지저장키값'; 값이 정의 되어 있어야함.
			//파라미터 데이터 설정 (로컬스토리지에 설정)
			//isOverwrite : 기존 로컬스토리지 값 덮어쓸지 옵션, 선택, true/false(Default:false)
			//var pageParam = mydataCommon.page.getParamData();
			//mydataCommon.page.setParamData(pageParam);
			//mydataCommon.page.setParamData({name1:'value1'});
			if(pageUnit.prop.v_storageKeyName){
				var data = paramData ? paramData :{};
				var oldData = mydataCommon.page.getParamData();
				isOverwrite = isOverwrite===null || isOverwrite===undefined ? false : isOverwrite;
				if(!isOverwrite){
					$.extend(true,oldData,data);
					data = oldData;
				}
				mydataCommon.util.setArrayData(pageUnit.prop.v_storageKeyName,data);
				return data;
			} else {
				return null;
			}
		},
		setSubParamData : function(paramData,ukey,isOverwrite) {
			//현재 넘어온 데이터를, 루트 객체의 하위 객체 데이터로 설정해서 저장처리.
			//paramData : 필수, 저장할 데이터 객체
			//ukey : 선택, 사용자 키값, 생략 시 기본 페이지 서브 키값.
			//isOverwrite : 기존 데이터 삭제해서 새로 덮어쓸기(true), 기존 데이터 유지 상태에서 덮어쓸지(false)
			//var pageParam = mydataCommon.page.getSubParamData();
			//mydataCommon.page.setSubParamData(pageParam);
			var result = {};
			var rootData = mydataCommon.page.getParamData();
			rootData = rootData ? rootData : {};
			var v_key = ukey ? ukey : (pageUnit.prop.v_storageSubKeyName ? pageUnit.prop.v_storageSubKeyName : pageUnit.prop.v_id);
			if(v_key){
				rootData[v_key] = paramData ? paramData : {};
				mydataCommon.page.setParamData(rootData,isOverwrite);
			}
		},
		clearParamData : function() {
			//header.jsp 등에서, 페이지 로딩시에 한번만, 오래된 (사용한지 한시간 지난 로컬스토리지 항목들 삭제)
			//mydataCommon.page.clearParamData();
			var v_len = localStorage.length;
			for(var i=0;i<v_len;i++){
				var v_key = localStorage.key(i);
				if(v_key && v_key.indexOf('_accesstime')!=-1){
					var v_accesstime = mydataCommon.util.getData(v_key);
					var v_datestr = mydataCommon.util.getStrDate();
					var v_nowtime = mydataCommon.util.getStrDate(v_datestr,'-')+' '+mydataCommon.util.getStrTime(':');
					if(v_accesstime){
						//최근 접근 시간이 40분 이상 지났으면 해당 항목 삭제.
						var v_diff_min = Math.floor(((new Date) - (new Date(v_accesstime))) / 1000 / 60);
						if(v_diff_min > 40){
							var v_key2 = v_key.replaceAll('_accesstime','');
							localStorage.removeItem(v_key);
							localStorage.removeItem(v_key2);
						}
					}
				}
			}
		}
	},
	//카드 공통
	//dayGb: datepicker.getDay() 구분값
	calendar: {
		getDay : function(dayGb) {
			var gbToKoreanDay = "";
			if($datepicker === null){
				if(dayGb=="1") gbToKoreanDay="월"
					else if(dayGb=="2") gbToKoreanDay="화"
					else if(dayGb=="3") gbToKoreanDay="수"
					else if(dayGb=="4") gbToKoreanDay="목"
					else if(dayGb=="5") gbToKoreanDay="금"
					else if(dayGb=="6") gbToKoreanDay="토"
					else if(dayGb=="0") gbToKoreanDay="일"

			}else{
				var gbToKoreanDay = $datepicker.datepicker.language.ko.daysShort[dayGb];
			}
				
			return gbToKoreanDay;
			
			
		}

	},
	calendar2: {
		/**
		 * 거래내역 기간 선택 버튼 공통 초기화 함수
		 * 
		 * id: 지정한 div의 id로, div안쪽에 기간선택 영역이 생성 됨. 예) #month_cal
		 * callback: 버튼이 선택되었을 때, strt_dt, end_dt가 넘어온다. 두 값을 받아서 ajax 요청 등 사용자가 작성한다.
		 *           init시 1개월로 최초 1회 자동 실행된다.
		 *           1, 3, 6, 12개월 버튼 및 달력 UI에서 월 클릭 시에 다음 콜백함수가 실행되어 strt_dt, end_dt 값을 받는다.
		 * 호출 예
		 * mydataCommon.calendar2.init('#month_cal', function (strt_dt, end_dt, idx) {
				pageUnit.trn_param.strt_dt = strt_dt;
				pageUnit.trn_param.end_dt = end_dt;
				
				pageUnit.trn.ajax_call('S2');
			});
		 */
		init: function(id, callback) {
			ao_html(id, 'month_cal_tmpl');
			
			var {_prop, _datePickerInit} = mydataCommon.calendar2;
			
			var $btnWrap = $(id + ' > div:eq(0) > div');
			var $calWrap = $(id + ' > div:eq(1)');
			
			$btnWrap.off('change').on('change', function () {
				var $this = $(this);
				var idx = $this.index(); _prop.idx = idx;
				var length = $btnWrap.length;
				if (idx < length - 1) {
					$calWrap.addClass('d-none');
					var m = $this.children('input').data('m');
					_prop.strt_dt = mydataCommon.util.getBeforeDate('M', m);
					_prop.end_dt = mydataCommon.util.getStrDate();
					if (callback) callback(_prop.strt_dt, _prop.end_dt, _prop.idx);
				} else $calWrap.removeClass('d-none');
				
			}).eq(0).change();
			
			_datePickerInit($calWrap.children('input'), callback);
			
		},
		_datePickerInit: function($sel, callback) {
			var {_prop, date_to_yyyyMMdd} = mydataCommon.calendar2;
            $sel.datepicker({ 
                language: 'ko',
                autoClose: true,
                navTitles: {
                    days: 'yyyy<i>년</i>, MM ',
                    months: 'yyyy',
                    years: 'yyyy'
                },
                view: 'months',
                minView: 'months',
                dateFormat: 'yyyy.mm',
                onSelect: function(v, date, o) {
                	if (!date) return;
                	
                	_prop.strt_dt = date_to_yyyyMMdd(date);
                	
                	var end_dt = new Date(date.getFullYear(), date.getMonth() + 1, 0);
                	_prop.end_dt = date_to_yyyyMMdd(end_dt);

                	if (callback) callback(_prop.strt_dt, _prop.end_dt, _prop.idx);
                }
            });
        },
        _prop: {}
		,date_to_yyyyMMdd: function (date = new Date()) {
			return date.getFullYear() +
			mydataCommon.util.lpad((date.getMonth() + 1), '0', 2) +
			mydataCommon.util.lpad(date.getDate(), '0', 2);
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		getChartAppendOption : function(directOptions){
			//차트 함수 내부에서, 직접 조정 옵션을 기존 차트 기본옵션에 어떻게 값을 append 할지 방법
			//반환값 : true(기존 기본 옵션값 유지 상태에서 부분속성 append) / false(기존 기본 옵션값을 삭제하고, 새로 append), 기본값 true
			//mydataCommon.design.getChartAppendOption(directOptions);
			return directOptions && directOptions.userSetOptionAppend===false ? false : true;
		}
		
		, chartPie : function(chartId,data,height,innerSize,colors,directOptions) {
			//(처리내용) 파이차트, 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartPie(chartId,data,height,innerSize,colors,directOptions);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [['국내주식', 14],['해외주식', 74],['현금성자산', 10],['금융상품', 5],['랩/ISA/신탁', 5],['기타', 2]]
			//height : 선택, 높이값, 기본값 160
			//innerSize : 선택, 기본값 50
			//colors : 선택, 항목별 색상 배열, 기본값 - ['#ffcc40', '#eb6c9c', '#f39262', '#6dc98d', '#9583c5', '#6083e8']
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//- directOptions.userSetIsSimpleSeries : 선택, true/false, series 속성을 단순하게 innerSize 와 data 속성만 표기 여부(기본 false)
			//- directOptions.userSetIsPlotOptions : 선택, true/false, plotOptions 속성에 일련의 속성셋을 설정(기본 false)
			//- directOptions.userSetTooltipFormat : 선택, 문자열, tooltip 속성 설정, 샘플 - '<br>{point.y:,.0f}원</br>'
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				colors = colors ? colors : ['#ffcc40', '#eb6c9c', '#f39262', '#6dc98d', '#9583c5', '#6083e8'];
				height = height ? Number(height) : 160;
				innerSize = innerSize ? Number(innerSize) : 50;
				//차트 옵션 설정(옵션)
				var chartOption = {
	                colors: colors,
	                chart: {
	                    height: height
	                },
	                series: [{
	                    innerSize: innerSize+'%',
	                    showInLegend: false, 
	                    states:{
	                        hover:{enabled:false}, 
	                        inactive:false
	                    },
	                    data: data
	                }]
		        };
				if(directOptions && directOptions.userSetIsSimpleSeries){
					chartOption.series = [{
	                    innerSize: innerSize+'%',                   
	                    data: data,
	                }];
					delete directOptions.userSetIsSimpleSeries;
				}
				if(directOptions && directOptions.userSetIsPlotOptions){
					chartOption.plotOptions = {
	                    pie: {
	                        center: ['50%', '90%'],
	                        size: '160%',
	                        startAngle: -90,
	                        endAngle: 90,
	                        states: {
	                            hover: {enabled:true},
	                            inactive: true
	                        }
	                    }
	                };
					delete directOptions.userSetIsPlotOptions;
				}
				if(directOptions && directOptions.userSetTooltipFormat){
					chartOption.tooltip = {
	                    enabled: true,
	                    pointFormat: directOptions.userSetTooltipFormat
	                };
					delete directOptions.userSetTooltipFormat;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.pie
		            ,chartOption
		        ));
			}
			return result;
		}
		
		, chartGuage : function(chartId,data,width,height,paneBorderWidth,plotBorderWidth,plotBorderColor,directOptions) {
			//(처리내용) Gauge 차트(달성율), 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartGuage(chartId,data);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [30]
			//width : 선택, 높이값, 기본값 80
			//height : 선택, 높이값, 기본값 80
			//paneBorderWidth : 선택, 높이값, 기본값 11
			//plotBorderWidth : 선택, 높이값, 기본값 11
			//plotBorderColor : 선택, 높이값, 기본값 '#e22d72'
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				width = width ? Number(width) : 80;
				height = height ? Number(height) : 80;
				paneBorderWidth = paneBorderWidth ? Number(paneBorderWidth) : 11;
				plotBorderWidth = plotBorderWidth ? Number(plotBorderWidth) : 11;
				plotBorderColor = plotBorderColor ? plotBorderColor : '#e22d72';
				//차트 옵션 설정(옵션)
				var chartOption = {
	                chart: { width: width, height: height },
	                pane: {
	                    background: { borderWidth: paneBorderWidth }
	                },
	                plotOptions: {
	                    solidgauge: {
	                        borderWidth: plotBorderWidth,
	                        borderColor: plotBorderColor
	                    }
	                },
	                series: [{
	                    data: data,
	                    dataLabels: { enabled: false }
	                }]
		        };
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.solidgauge
		            ,chartOption
		        ));
			}
			return result;
		}

		, chartGuage2 : function(chartId,data,height,borderColor,directOptions) {
			//(처리내용) Gauge 차트(달성율 - 하프게이지), 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartGuage2(chartId,data);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [55]
			//height : 선택, 높이값, 기본값 200
			//borderColor : 선택, 선색, 기본값 '#343582'
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 200;
				borderColor = borderColor ? borderColor : '#343582';
				//차트 옵션 설정(옵션)
				var chartOption = {
                    chart: { height: height },
                    pane: {
                        center: ['50%', '90%'],
                        size: '160%',
                        startAngle: -90,
                        endAngle: 90
                    },
                    plotOptions: {
                        solidgauge: { 
                            borderColor: borderColor
                        }
                    },
                    series: [{
                        data: data,
                        dataLabels: { enabled: false }
                    }]
                };
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.solidgauge
		            ,chartOption
		        ));
			}
			return result;
		}
		
		, chartColumnStack : function(chartId,data,cate,height,directOptions) {
			//(처리내용) Column Stack 차트, 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartColumnStack(chartId,data,cate);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - 
			//[
			// { name: '국내주식', data: [5,3,2], color: '#ffcc40', index: 7 },
			// { name: '해외주식', data: [3,5,5], color: '#eb6c9c', index: 6 },
			// { name: '펀드', data: [3,5,4], color: '#f39262', index: 5 },
			// { name: '현금성자산', data: [3,2,4], color: '#6dc98d', index: 4 },
			// { name: '금융상품', data: [3,5,5], color: '#9583c5', index: 3 },
			// { name: '랩·ISA·신탁', data: [3,5,4], color: '#6083e8', index: 2 },
			// { name: '기타', data: [3,2,4], color: '#5ebdcd', index: 1 }
			//]
			//cate : 필수, 차트데이터, 형식 - ['2021.01', '2021.02', '2021.03']
			//※ data 내부의 data 배열의 항목 개수와, cate 의 항목 개수는 일치해야함
			//height : 선택, 높이값, 기본값 220
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data && cate){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 220;
				//차트 옵션 설정(옵션)
				var chartOption = {
					chart: {
	                    height: height
	                },
	                xAxis: {
	                    categories: cate,
	                },
	                yAxis:{
	                    gridLineWidth: 1, 
	                    enable:true, 
	                    visible: true, 
	                    title: { text: null },
	                    min:0,
						max:100,
						tickInterval:10,
	                    labels:{ formatter: function() {return this.value+'%';} },
	                },
	                plotOptions:{
						series:{stacking:'percent'}
					},
	                series: data,
	                legend: {
	                    enabled: true,
	                    reversed: true,
	                    symbolWidth: 10,
	                    symbolHeight: 10,
	                    symbolRadius: 0,
	                    itemStyle: {'color': '#666666', 'font-size': 10}
	                }
		        };
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
					KW_MOBILE.highcharts.types.stackedColumn
		            ,chartOption
		        ));
			}
			return result;
		}

		, chartColumn : function(chartId,data,height,labelFormat,pointWidth,directOptions) {
			//(처리내용) Column 차트 (싱글형), 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartColumn(chartId,data);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - 
			//[
			//{name : "김키움님", y: 783, color:"#f096b8"},
            //{name : "30대 평균", y: 685, color:"#cccccc"},
            //{name : "전국민", y: 736, color:"#cccccc"},
            //]
			//※ data 내부의 data 배열의 항목 개수와, cate 의 항목 개수는 일치해야함
			//height : 선택, 높이값, 기본값 없음
			//labelFormat : 선택, 제목 포맷, 기본값 없음, sample : '{point.y}점'
			//pointWidth : 선택, 선굵기, 기본값 없음
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//- directOptions.userSetIsScroll : 선택, true/false  //컬럼이 4개 이상일 경우 스크롤 영역 생성
			//- directOptions.userSetScrollWidth : 선택, 숫자, 기본값 30, 차트 길이에 더하는 상수
			//- directOptions.userSetPoliLines : 선택, 가이드라인 표기, {value:'8',text:'금리평균 8%'}
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : null;
				//차트 옵션 설정(옵션)
				var chartOption = {         
					series: data
		        };
				if(height){
					$.extend(true,chartOption,{
						chart: {
							height: height
						}
					});
				}
				//컬럼이 4개 이상일 경우 스크롤 영역 생성
				if(directOptions && directOptions.userSetIsScroll){
					directOptions.userSetScrollWidth = directOptions.userSetScrollWidth || directOptions.userSetScrollWidth===0 ? 
							Number(directOptions.userSetScrollWidth) : 30;
					
					var chartOpt = {
                        marginLeft: 0,
                        marginRight: 0,
                        events: {
                            load: function(){
                                var barCnt = this.pointCount;//컬럼 개수
                                //컬럼이 4개 이상일 경우 스크롤 영역 생성
                                if(barCnt>3) {
                                    $("#"+chartId).parent(".chart-wrapper").wrap("<div class='chart-wrapper-full' style='height:200px'></div>");
                                    this.setSize((barCnt*2)*($(window).width()/8.5),this.chartHeight);
                                    $("#"+chartId).width(this.chartWidth + directOptions.userSetScrollWidth);
                                }
                            }
                        }
                    };
					if(height){
						chartOpt.height = height;
					}
					$.extend(chartOption,{
						chart:chartOpt
					});
					delete directOptions.userSetIsScroll;		//사용자 속성삭제
					delete directOptions.userSetScrollWidth;	//사용자 속성삭제
				}
				if(labelFormat){
					$.extend(chartOption,{
						series: [{
							dataLabels: { 
		                        enabled: true,
		                        format: labelFormat
		                    },
	                        data: data
	                    }]
					});
				} else {
					$.extend(chartOption,{
						series: [{
							dataLabels: { enabled: true },
	                        data: data
	                    }]
					});
				}
				if(pointWidth){
					$.extend(true,chartOption,{
	          			plotOptions:{
	                        column:{
	                            pointWidth: pointWidth
	                        }
	                    }
	          		});
				}
				//경계선
				if(directOptions && directOptions.userSetPoliLines){
					var yAxisOpt = {
						min:0,
                        visible: true, 
                        plotLines: [{
                            value: directOptions.userSetPoliLines.value, //'8'
                            color: '#ddd',
                            width: 1,
                            zIndex: 10,
                            dashStyle: 'shortdash',
                            label: {
                                text: directOptions.userSetPoliLines.text, //'금리평균 8%'
                                y: -8,
                                style:{'color':'#999','font-size':'10px'}
                            }
                        }]	//평균선
					};
					chartOption.yAxis = chartOption.yAxis ? chartOption.yAxis : {};
					$.extend(chartOption.yAxis,yAxisOpt);
					delete directOptions.userSetPoliLines;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
					KW_MOBILE.highcharts.types.column
		            ,chartOption
		        ));
			}
			return result;
		}
		
		, chartColumn2 : function(chartId,data,cate,height,directOptions) {
			//(처리내용) Column 차트 (비교형/멀티), 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartColumn2(chartId,data,cate);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - 
			//[
			//{name: '전체가입자', data: [3000, 2500], color: '#cccccc'}, 
			//{name: '김키움', data: [250, 100], color: '#f096b8'}
			//]
			//cate : 필수, 차트데이터, 형식 - ['IRP가입자', '개인연금']
			//※ data 내부의 data 배열의 항목 개수와, cate 의 항목 개수는 일치해야함
			//height : 선택, 높이값, 기본값 212
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//- directOptions.userSetColumnFormat : 선택, 기본값 없음, 샘플 - '{y}%'
			//- directOptions.userSetColumnPointWidth : 선택, 기본값 없음, 샘플 - 18
			//- directOptions.userSetColumnAllowOverlap : 선택, 기본값 없음, 샘플 - true/false
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data && cate){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 212;
				//차트 옵션 설정(옵션)
				var chartOption = {         
		            chart: {
		                height: height
		            },           
		            xAxis: {
		                categories: cate
		            },
		            series: data,
		            plotOptions: { 
		                column: { 
		                    dataLabels: { 
		                        enabled: true, 
		                        format:'{point.y:,.0f}' //천단위 표시
		                    },
		                    grouping: true
		                } 
		            },
		            legend: {
		                enabled: true,
		                symbolWidth: 10,
		                symbolHeight: 10,
		                symbolRadius: 0,
		                itemStyle: {'color': '#666666', 'font-size': 10}
		            }
		        };
				if(directOptions && directOptions.userSetColumnPointWidth){
					chartOption.plotOptions.column.pointWidth = Number(directOptions.userSetColumnPointWidth);
					delete directOptions.userSetColumnPointWidth;
				}
				if(directOptions && directOptions.userSetColumnFormat){
					chartOption.plotOptions.column.dataLabels.format = directOptions.userSetColumnFormat;
					delete directOptions.userSetColumnFormat;
				}
				if(directOptions && directOptions.userSetColumnAllowOverlap){
					chartOption.plotOptions.column.dataLabels.allowOverlap = directOptions.userSetColumnAllowOverlap;
					delete directOptions.userSetColumnAllowOverlap;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
					KW_MOBILE.highcharts.types.column
		            ,chartOption
		        ));
			}
			return result;
		}

		, chartStackedBar : function(chartId,data,cate,height,yTickInterval,directOptions) {
			//(처리내용) Bar차트 - Stack, 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartStackedBar(chartId,data,cate);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [
			//{ name: '암보험', data: [5,3], color: '#eb6c9c', index: 5 },
			//{ name: '종신보험', data: [2,2], color: '#f39262', index: 4 },
			//{ name: '저축보험', data: [3,4], color: '#8da7ee', index: 3 },
			//{ name: '실손보험', data: [3,4], color: '#ffcc40', index: 2 },
			//{ name: '운전자보험', data: [3,4], color: '#6dc98d', index: 1 }
			//]
			//cate : 필수, 차트데이터, 형식 - ['보험가입수', '월보험료']
			//height : 선택, 높이값, 기본값 200
			//yTickInterval : 선택, y축 간격, 기본값 없음 (sample : 50)
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//- directOptions.yLabelTitle : 선택, 타이틀 문자열, sample - '펀드 투자 스타일'
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data && cate){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 200;
				//차트 옵션 설정(옵션)
				var chartOption = {
                    chart: {
                        height: height
                    },
                    xAxis: {
                        categories: cate
                    },
                    yAxis: {
                        labels:{ formatter: function() {return this.value+'%';} }
                    	//, tickInterval : 50	/* option */
                    	//, title: { text: '펀드 투자 스타일' }
                    },
                    series: data,
                    legend: {
                        enabled: true,
                        reversed: true,
                        symbolWidth: 10,
                        symbolHeight: 10,
                        symbolRadius: 0,
                        itemStyle: {'color': '#666666', 'font-size': 10}
                    }
                };
				if(yTickInterval){
					chartOption.yAxis.tickInterval = Number(yTickInterval);
				}
				if(directOptions && directOptions.yLabelTitle){
					chartOption.yAxis.title = { text: directOptions.yLabelTitle };
					delete directOptions.yLabelTitle;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.stackedBar
		            ,chartOption
		        ));
			}
			return result;
		}

		, chartLine : function(chartId,data,cate,height,directOptions) {
			//(처리내용) Line차트 - line, 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartLine(chartId,data,cate);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [20300,21300,22300,23300,24300,30000]
			//cate : 필수, 카테고리 데이터, 형식 - [ "2021.03", "2021.07", "2021.09", "2021.11", "2022.01", "2022.03" ]
			//height : 선택, 높이값, 기본값 300
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//- directOptions.userSetDataFormat : 선택, 출력 데이터 포맷 문자열, 샘플 - '{point.y:,.0f}'
			//- directOptions.userSetYAxisType1 : 선택, true/false, 기본 false, yAxis 특정 설정값 적용
			//- directOptions.userSetSeriesType1 : 선택, true/false, 기본 false, series 특정 설정값 적용
			
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data && cate){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 300;
				//차트 옵션 설정(옵션)
				var chartOption = {                    
                    chart: {
                        height: height
                    },
                    xAxis:{
                        categories: cate
                    },                                        
                    yAxis: [
                        { labels:{ formatter: function() {return mydataCommon.util.addComma(this.value)+'만원'} }, title: { text: '' } }
                    ],
                    series: [
                        { 
                            marker: { enabled: false }, 
                            data: data
                        }
                    ]                    
                };
				if(directOptions && directOptions.userSetDataFormat){
					$.each(chartOption.series,function(idx,el){
						el.dataLabels = {
	                        enabled: true,
	                        format:directOptions.userSetDataFormat
	                    };
					});
					delete directOptions.userSetDataFormat;
				}
				if(directOptions && directOptions.userSetYAxisType1){
					chartOption.yAxis = [
					    { labels:{ formatter: function() {return mydataCommon.util.addComma(this.value)} }, title: { text: '' } }
	                ];
					delete directOptions.userSetYAxisType1;
				}
				if(directOptions && directOptions.userSetSeriesType1){
					chartOption.series = [
	                    { 
	                        dataLabels: { enabled: true }, 
	                        fillOpacity: 0,
	                        data: data
	                    }
	                ];
					delete directOptions.userSetSeriesType1;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.area
		            ,chartOption
		        ));
			}
			return result;
		}
		
		, chartLineColumn : function(chartId,data,cate,height,directOptions) {
			//(처리내용) Line차트 : line + column, 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartLineColumn(chartId,data);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [
			//{ name: '평가금액', type: 'column', yAxis: 0, data: [100000, 70000, 25000], color: 'skyblue' },
			//{ name: '수익률', type: 'line', yAxis: 1, data: [14.72, 4.49, 9.24], color: 'red' }
			//]
			//cate : 필수, ['키움증권(종합위탁)', '키움증권(WMA)', 'KB투자증권(종합)']
			//height : 선택, 높이값, 기본값 300
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 300;
				//차트 옵션 설정(옵션)
				var chartOption = {
                    chart: {
                        height: height,
                        zoomType: 'xy'
                    }, 
                    xAxis: {
                        categories: cate,
                        labels: {
                            style: {
                                fontSize: '10px'
                            }
                        }
                    },
                    yAxis: [
                        { labels: { formatter: function() { return this.value; } }, title: { text: null }, lineWidth: 1, gridLineDashStyle: 'longdash'},
                        { labels: { format: '{value}' }, title: { text: null }, lineWidth: 1, opposite: true, gridLineDashStyle: 'longdash' }
                    ],
                    series: data,
                    plotOptions: {                       
                        column: {
                            dataLabels: {
                                enabled: true, 
                                formatter: function () { return this.y ; } 
                            }
                        },
                        line: {
                            dataLabels: { 
                                enabled: true, 
                                formatter: function () { return  this.y +'%'; }
                            }
                        }
                    }
                };
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.area
		            ,chartOption
		        ));
			}
			return result;
		},
		
		chartGuage3 : function(chartId,data,width,height,colors,labelFormat,directOptions) {
			//(처리내용) Gauge 차트 (기타), 선택옵션들 null 넘기면 기본값 셋팅됨.
			//(호출방법) var chartObj = mydataCommon.design.chartGuage3(chartId,data);
			//(반환값   ) 차트객체
			//(파라미터)
			//chartId : 필수, 차트영역 아이디 명 문자열
			//data : 필수, 차트데이터, 형식 - [?]
			//width : 선택, 넒이값, 기본값 없음
			//height : 선택, 높이값, 기본값 90
			//colors : 선택, 색상배열, 기본값 ['#8da7ee']
			//labelFormat : 선택, 넒이값, 기본값 없음, ex)'<div class="text-center">상환비율</br>' + opt.data + '%</div>'
			//directOptions : 선택, {'colors':['#ffcc40']}, 기타 차트 옵션 설정. 필요한 부분 설정 json 객체로 넘기면, 최우선 순위로 적용.
			//- directOptions.userSetOptionAppend : 선택, true/false, 옵션을 append 하는 방식(true - 기존값 유지하면서 부분 속성 적용, false - 기존값 삭제한 후 속성 적용)
			//(주의사항) 아래 차트 초기화 코드를, 최초 한번만 호출해 주시면 됩니다. (차트 여러개 시 여러번 호출하지 않고, 페이지 로딩 시 한번만 호출)
			//Highcharts.setOptions(KW_MOBILE.highcharts.general);
			var result = null;
			chartId = $.trim(chartId);
			if(chartId && data){
				//차트 옵션 설정(주요옵션)
				height = height ? Number(height) : 90;
				colors = colors ? colors : ['#8da7ee'];
				//차트 옵션 설정(옵션)
				var chartOption = {
					credits : {
						enabled : false
					},
					tooltip : {
						enabled : false
					},
					title : {
						text : null
					},
					exporting : {
						enabled : false
					},
					colors : colors,
					chart : {
						type : 'solidgauge',
						margin : [ 5, 5, 5, 5 ],
						/*width : 90,*/
						height : height,
					},
					pane : {
						center : [ '50%', '50%' ],
						size : '100%',
						startAngle : 0,
						endAngle : 360,
						background : {
							backgroundColor : '#EEE',
							borderWidth : 0,
							innerRadius : '50%',
							outerRadius : '100%',
							shape : 'arc'
						}
					},
					yAxis : {
						min : 0,
						max : 100,
						lineWidth : 0,
						tickWidth : 0,
						minorTickInterval : null,
						tickAmount : 2,
						title : null,
						labels : {
							enabled : false
						}
					},
					plotOptions : {
						solidgauge : {
							innerRadius : '50%',
							dataLabels : {
								y : -20,
								borderWidth : 0,
								useHTML : true
							}
						}
					},
					series : [ {
						name : 'Speed',
						data : data,
						dataLabels : {
							format : '<div class="text-center">' + '</div>'
						}
					} ]
				};
				if(width){
					chartOption.width = Number(width);
				}
				if(labelFormat){
					chartOption.series.dataLabels.format = labelFormat;
				}
				if(directOptions){
					$.extend(mydataCommon.design.getChartAppendOption(directOptions),chartOption,directOptions);
				}
				//차트생성
				result = new Highcharts.Chart(chartId, Highcharts.merge (
		            KW_MOBILE.highcharts.types.solidgauge
		            ,chartOption
		        ));
			}
			return result;
		}
		
	}
};

$(document).ready(function() {
	mydataCommon.init();
});
