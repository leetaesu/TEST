//퇴직연금
var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010003View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	trn_param : {
		strt_dt : "", //시작일자
		end_dt : "", // 종료 일자
		next_page_base_val : null,
		trade_cont_gubn : "N",
		trade_next_data : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP2010_Q03 : () => {
				return new Promise( (resolve, reject) => {
					var param = pageUnit.fn.get_param();
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100030002Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2010_Q04 : exdata => {
				var param = pageUnit.fn.get_param();
				exdata.XMP2010_Q03.g1.forEach( row => {
					param.irp_type_tp = row.irp_type_tp;
					var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn00100030003Ajax",
						data : param,
						async : false,
						success : pageUnit.fn.set_operating_product_info,
						error : (e1, e2, e3) => {
							mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg +"[XMP2010_Q04]"});							
						}
					}
					mydataCommon.ajax(jsonObj);
				});
				KW_MOBILE.guiEvent.accordion.init();
				KW_MOBILE.guiEvent.detailBox.init('');
			},
			XMP2010_U02 : () => {
				return new Promise( (resolve, reject) => {		
					mydataCommon.calendar2.init('#month_cal', (strt_dt, end_dt) => {
						var param = pageUnit.fn.get_param();
						pageUnit.trn_param.strt_dt = strt_dt;
						pageUnit.trn_param.end_dt = end_dt;
						param.strt_dt = strt_dt;
						param.end_dt = end_dt;
						param.next_page_base_val = pageUnit.trn_param.next_page_base_val;
						var jsonObj = {
								url : pageCom.prop.contextPath + "/annu/SAnn00100030001Ajax",
								data : param,
								async : true,
								success : resolve,
								error :reject
						}
						mydataCommon.ajax(jsonObj);
					});
				});
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;
		//IRP 상세조회(운용, 계좌정보)
		try{
			var XMP2010_Q03 = await ajax_call.XMP2010_Q03();
			pageUnit.fn.set_info(XMP2010_Q03);
			await ajax_call.XMP2010_Q04(XMP2010_Q03);
			var XMP2010_U02 = await ajax_call.XMP2010_U02();
			pageUnit.fn.set_section_irp_trade(XMP2010_U02);
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}finally{
			pageUnit.eventBind();
		}
	},
	// 단위 이벤트 바인딩 함수
	eventBind : () => {
		$(".sub-prev").off("click").on("click", () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		//오픈뱅킹 이동
		$(document).on("click", "#deposit", () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"352"});
		});
		$(document).on("click", "#acnt_no", () => {
			var param = mydataCommon.page.getSubParamData('VAnn0010001View');
			mydataCommon.util.clibBoard(param.acnt_no);
		});
		//추천 리스트 이동
		$('#goReco').on('click', () =>{
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0101", callback:"callback_callMoveView"});	
		});
		//메인 IRP 계좌 더 불러오기
		$(document).on("click", "#more_trade", function(){
			pageUnit.fn.more_trade_info();
		});
	},
	fn : {	
		//상단 상세 정보 setting
		set_info : data => {
			var output = data.XMP2010_Q03;
			output.acnt_no = pageUnit.fn.get_param().acnt_no;
			ao_html('info','info_tmpl',output);
			ao_html('acnt_info','acnt_info_tmpl',output);
		},
		set_operating_product_info : data => {
			var output = data.XMP2010_Q04;
			ao_append("#tab_panel01", "mng_product_tmpl", output);
			if(output.cont_gubn == 'Y'){
				$('#more_product_one_time_'+output.irp_type_tp).show();
			}else{
				$('#more_product_one_time_'+output.irp_type_tp).hide();
			}
		},
		//개인연금
		set_section_irp_trade : data => {
			var output = data.XMP2010_U02;
			ao_html('trade_info','trade_info_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_trade_info').show();
				pageUnit.trn_param.next_page_base_val = output.next_page_base_val;
				pageUnit.trn_param.trade_cont_gubn = output.cont_gubn;
				pageUnit.trn_param.trade_next_data = output.next_data;
			}else{
				$('#more_trade_info').hide();
			}
		},
		more_item : (irp_type_tp, cont_gubn, next_data) => {
			var param = pageUnit.fn.get_param();
			param.irp_type_tp = irp_type_tp;
			param.cont_gubn = mydataCommon.util.nvl(cont_gubn, $('#cont_gubn'+irp_type_tp).val());
			param.next_data = mydataCommon.util.nvl(next_data, $('#next_data'+irp_type_tp).val());
			var jsonObj = {
					url : pageCom.prop.contextPath + "/annu/SAnn00100030003Ajax",
					data : param,
					async : true,
					success : data => {
						var output = data.XMP2010_Q04;
						ao_append("#irp_each_list_"+output.irp_type_tp,'irp_each_list_tmpl', output);
						$("#more_product_one_time_"+output.irp_type_tp).hide();
						if(output.cont_gubn == 'Y'){
							$('#more_product_'+output.irp_type_tp).show();
							$('#cont_gubn'+irp_type_tp).val(output.cont_gubn);
							$('#next_data'+irp_type_tp).val(output.next_data);
						}else{
							$('#more_product_'+output.irp_type_tp).hide();
						}
						KW_MOBILE.guiEvent.detailBox.init('');
					},
					error : (e1, e2, e3) => {
						mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg + "["+e1+"]"});							
					}
				}
				mydataCommon.ajax(jsonObj);
		},
		more_trade_info : () => {
			var param = pageUnit.fn.get_param();
			param.strt_dt = pageUnit.trn_param.strt_dt;
			param.end_dt = pageUnit.trn_param.end_dt;
			param.next_page_base_val = pageUnit.trn_param.next_page_base_val;
			param.cont_gubn = pageUnit.trn_param.trade_cont_gubn;
			param.next_data = pageUnit.trn_param.trade_next_data;
			var jsonObj = {
					url : pageCom.prop.contextPath + "/annu/SAnn00100030001Ajax",
					data : param,
					async : true,
					success : data => {
						var output = data.XMP2010_U02;
						ao_append("#trade_info_next_data","trade_info_next_data_tmpl", output);
						if(output.cont_gubn == 'Y'){
							$('#more_trade_info').show();
							pageUnit.trn_param.next_page_base_val = output.next_page_base_val;
							pageUnit.trn_param.trade_cont_gubn = output.cont_gubn;
							pageUnit.trn_param.trade_next_data = output.next_data;
						}else{
							$('#more_trade_info').hide();
						}
					},
					error : (e1, e2, e3) => {
						mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg + "["+e1+"]"});					
					}
				}
				mydataCommon.ajax(jsonObj);
		},
		get_param : () => {return mydataCommon.page.getSubParamData('VAnn0010001View');}
	},
};

$(document).ready( () => {
	pageUnit.init();
});

