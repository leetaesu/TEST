var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0040001P001PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
		
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		KW_MOBILE.guiEvent.popup.openPop('#modal_full-popup');
	},
	eventBind : function() {
		$('.modal-close').on('click',function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		$(document).on("click", "#my_invest", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"COM0107", callback:"callback_callMoveView",viewType:"full"});
		});
	},
	fn : {		
		
	},
	
};

$(document).ready(function(){
	pageUnit.init();
});



