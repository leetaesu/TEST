var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P040PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
		
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		var now_time = mydataCommon.util.getStrTime();
		if(now_time >= '090000' && now_time <= '195959'){
			$('#oper_time').show();
			$('#not_oper_time').hide();
			
			$('#oper_confirm').show();
			$('#not_oper_confirm').hide();
		}else{
			$('#oper_time').hide();
			$('#not_oper_time').show();
			
			$('#oper_confirm').hide();
			$('#not_oper_confirm').show();
		}
	},
	eventBind : function() {
		$('.sub-close').on('click',function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		$(document).on("click", "#cancel", function() {
			KW_MOBILE.guiEvent.popup.closePop('#bottomsheet');
		});
	
		$(document).on("click", "#oper_confirm", function() {
			document.location.href 	= 'https://www.moneykiwoom.com';
		});

		$(document).on("click", "#not_oper_confirm", function() {
			document.location.href 	= 'https://consult.kiwoomap.com/channel/kiwoomannuity';
		});
	},
	fn : {		
		
	},
	
};

$(document).ready(function(){
	pageUnit.init();
});



