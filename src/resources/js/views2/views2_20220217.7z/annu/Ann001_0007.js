//개인연금 상세 페이지
var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010007View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : '',
		cont_gubn : 'N',
		next_data : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP2015_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var param = pageUnit.fn.get_param();
					param.cont_gubn = pageUnit.prop.cont_gubn;
					param.next_data = pageUnit.prop.next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010007001Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;		
		try{
			var XMP2015_Q01 = await ajax_call.XMP2015_Q01();
			pageUnit.fn.set_section_personal(XMP2015_Q01);
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}finally{
			pageUnit.eventBind();
		}
	},
	// 단위 이벤트 바인딩 함수
	eventBind : () => {
		$(".sub-prev").off("click").on("click", () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		// 오픈뱅킹 이동
		$(document).on("click", "#deposit", () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"352"});
		});
		//계좌번호 복사
		$(document).on("click", "#acnt_no", () => {
			var param = mydataCommon.page.getSubParamData('VAnn0010001View');
			mydataCommon.util.clibBoard(param.acnt_no);
		});
		//추천 리스트 이동
		$('#goReco').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0101", callback:"callback_callMoveView"});	
		});
		//더 많은 상품 불러오기
		$(document).on("click", "#more_item", function() {
			pageUnit.trn.ajax_call.XMP2015_Q01()
			.then(data => {
				pageUnit.fn.set_section_personal_more(data);
			})
			.catch((e)=>{
				mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+e+"]"});	
			});
		});
	},
	fn : {		
		//개인연금
		set_section_personal : data => {
			var output = data.XMP2015_Q01;
			var param = pageUnit.fn.get_param();
			output.acnt_no = param.acnt_no;
			output.acnt_remna = mydataCommon.util.getPrice(output.acnt_remna);
			ao_html('info','info_tmpl', output);
			ao_html('tab_panel01','list_info_tmpl', output);
			ao_html('acnt_info','acnt_info_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_product').css('display','block');
			}else{
				$('#more_product').css('display','none');
			}
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			KW_MOBILE.guiEvent.accordion.init('#tab_panel01');
			KW_MOBILE.guiEvent.detailBox.init('');
		},
		set_section_personal_more : data => {
			var output = data.XMP2015_Q01;
			ao_append('list_info_next_data','list_info_next_data_tmpl', output);
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			if(output.cont_gubn == 'Y'){
				$('#more_product').css('display','block');
			}else{
				$('#more_product').css('display','none');
			}
			KW_MOBILE.guiEvent.detailBox.init('');
		},
		get_param : () => {return mydataCommon.page.getSubParamData('VAnn0010001View');}
	},
	
};

$(document).ready(() => {
	pageUnit.init();
});



