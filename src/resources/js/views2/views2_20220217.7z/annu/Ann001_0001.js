var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		anty_yn : "", 
		peop_anty_yn : "",
		alimi_item_tp :"",  // 알리 : 알림이 항목구분
		myd_inds_tp : "",
		selected_tab : '5', //선택된 탭 값(국민연금 포함하기(직접입력 5 , 계산하기 6))
		v_id : "VAnn0010001View",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : 'insu',
		personal_cont_gubn : 'N',
		personal_next_data : '',
		ps_cont_gubn : 'N',
		ps_next_data : '',
		irp_cont_gubn : 'N',
		irp_next_data : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	trn_param : {
		alimi_seq : "" ,	// 알림 : 구분코드 (06:연금)
		age: 0, // 나의 연금 자산은? 연령(처음은 0, 그 뒤로는 setting 된 값)
		amt_sum : 0, //현재 모은 연금
		peop_anty_recv_amt : 0 //국민연금수령금액
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			/* ######################서비스 체크##################### */
			XMH1007_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0040001P0010001Ajax",
							data : {},
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			myInfoSearch : () => {
				//내 정보 검색
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010000Ajax",
							data : {},
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			allSearch : async () => {
				//모든 메인 정보
				try{
					//상단 요약 정보
					var XMP2003_Q01 = await pageUnit.trn.ajax_call.XMP2003_Q01();
					pageUnit.fn.set_section_total(XMP2003_Q01);
					//개인 연금
					var XMP2001_Q01 = await pageUnit.trn.ajax_call.XMP2001_Q01();
					pageUnit.fn.set_section_personal(XMP2001_Q01);
					//연금 저축 보험
					var XMP2001_Q04 = await pageUnit.trn.ajax_call.XMP2001_Q04();
					pageUnit.fn.set_section_ps(XMP2001_Q04);
					//IRP(퇴직 연금)
					var XMP2001_Q02 = await pageUnit.trn.ajax_call.XMP2001_Q02();
					pageUnit.fn.set_section_irp(XMP2001_Q02);
					// 나의 연금 자산은?
					var XMP2030_Q01 = await pageUnit.trn.ajax_call.XMP2030_Q01();
					pageUnit.fn.set_section_my_ps_wealth(XMP2030_Q01);
					// 개인연금 기관조회
					var output = await pageUnit.trn.ajax_call.XMP2001_Q05();
					pageUnit.trn.ajax_call.XMP2001_Q06(output.XMP2001_Q05.g1);
					//01:공통(MY), 02:뱅킹, 03:투자, 04:대출, 05:보험, 06:연금, 07:신용, 08:카드
					pageCom.loadNoti.init('#notiPlace', "06", {isTest : false});
				}catch(e){
					pageUnit.fn.errorMessage(e);
				}
			},
			XMP2003_Q01 : () => {
				//전체 요약 정보
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010005Ajax",
							data : {},
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2001_Q01 : () => {
				//개인 연금
				return new Promise( (resolve, reject) => {
					var param = {};
					param.cont_gubn = pageUnit.prop.personal_cont_gubn;
					param.next_data = pageUnit.prop.personal_next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010002Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2001_Q04 : () => {
				//연금 저축 보험
				return new Promise( (resolve, reject) => {
					var param = {};
					param.cont_gubn = pageUnit.prop.ps_cont_gubn;
					param.next_data = pageUnit.prop.ps_next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010009Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2001_Q02 : () => {
				//퇴직연금
				return new Promise( (resolve, reject) => {
					var param = {};
					param.cont_gubn = pageUnit.prop.irp_cont_gubn;
					param.next_data = pageUnit.prop.irp_next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010003Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2030_Q01 : () => {
				//나의 연금 자산은?
				var param	 = {
						age			: pageUnit.trn_param.age
				};
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010012Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2001_Q05 : () => {
				//개인 연금 기관 조회
				var param = pageUnit.fn.get_param();
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010010Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2001_Q06 : orgn_list => {
				//금융사별 보기
				orgn_list.forEach( row => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn00100010011Ajax",
							data : {"orgn_code":row.orgn_code},
							async : false,
							success : data => {
								var output = data.XMP2001_Q06;
								ao_append("#tab_panel02", "finance_list_tmpl", output);
								if(output.cont_gubn == 'Y'){
									$('#more_product_one_time_'+output.orgn_code).show();
								}else{
									$('#more_product_one_time_'+output.orgn_code).hide();
								}
							},
							error : (e1, e2, e3) => {
								pageUnit.fn.errorMessage(e1);							
							}
						}
						mydataCommon.ajax(jsonObj);
				});
				KW_MOBILE.guiEvent.accordion.init('#tab_panel02');
			},
			XMP4020_Q01 : () => {
				//노후 생활비 알아보기 - 예상 연금 수령액 확인하기 - 개인연금월납입액 계산
				// data 넘겨줘야 될듯
				var param = {};
				param.pers_anty_evlt_amt = pageUnit.trn_param.amt_sum;
				param.anty_recv_age = $('#anty_recv_age > option:selected').val();
				param.anty_recv_term = $('#anty_recv_term > option:selected').val();
				if($('#errt > option:selected').val() == ""){
					//직접 입력이면
					param.errt = $('#custom_input').val();
				}else{
					param.errt = $('#errt > option:selected').val();	
				}

				if($('#ns_ps_gb > option:selected').val() == "0"){
					//국민 연금 수령금액이 미포함이면
					param.peop_anty_recv_amt = 0;
				}else{
					param.peop_anty_recv_amt = pageUnit.trn_param.peop_anty_recv_amt;
				}
				param.life_cost_tp = $('input:radio[name="rdo"]:checked').val();
				
				var pageParam = pageUnit.fn.get_param();
				pageParam = param;
				mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
				
				var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn00100010018Ajax",
						data : param,
						async : true,
						success : pageUnit.fn.set_section_ps_month_payment,
						error : (e1, e2, e3) => {
							pageUnit.fn.errorMessage(e1);							
						},
				}
				mydataCommon.ajax(jsonObj);
			},
			XMP4020_Q03 : () => {
				//국민연금 월수령액 등록내역조회
				var param = pageUnit.fn.get_param();
				var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn00100010025Ajax",
						data : param,
						async : true,
						success : pageUnit.fn.set_section_nation_ps_month_receipt,
						error : (e1, e2, e3) => {
							pageUnit.fn.errorMessage(e1);							
						}
				}
				mydataCommon.ajax(jsonObj);	
			},
			XMP1001_U01 : () => {
				//화면 리로드
				var jsonObj = {
						url : pageCom.prop.contextPath+ "/annu/UAnn00100010002Ajax",
						async : true,
						success : pageUnit.fn.set_section_reload,
						error : (e1, e2, e3) => {
							pageUnit.fn.errorMessage(e1);							
						}
					}
					mydataCommon.ajax(jsonObj);
			},
			XMT1001_U02 : () => {
				var jsonObj = {
						url : pageCom.prop.contextPath	+ "/annu/UAnn00100010004Ajax",
						data : pageUnit.trn_param,
						async : true,
						success : pageUnit.fn.set_section_psnAlilm_reload,
						error : (e1, e2, e3) => {
							pageUnit.fn.errorMessage(e1);							
						}
					}
					mydataCommon.ajax(jsonObj);
			},
			XMP4001_Q01 : () => {
				// 노후자금 진단
				var param = mydataCommon.makeJsonParam({
					target : $("#inputRetireFunds")
				});
				var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn00100010006Ajax",
						data : param,
						async : true,
						success : pageUnit.fn.set_old_age_funds,
						error : (e1, e2, e3) => {
							pageUnit.fn.errorMessage(e1);							
						},
				}
				mydataCommon.ajax(jsonObj);
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;
		try{
			var output = await ajax_call.XMH1007_Q01();
			/*if(output.XMH1007_Q01.resp_gubn == '0'){
				
			}else{
				var myInfo = await pageUnit.trn.ajax_call("myInfoSearch");
				pageUnit.fn.set_section_myinfo_gb(myInfo);
			}*/
			//임시 처리
			var myInfo = await ajax_call.myInfoSearch();
			pageUnit.fn.set_section_myinfo_gb(myInfo);
		}catch(e){
			pageUnit.fn.errorMessage(e);
		}finally{
			pageUnit.eventBind();
			mydataCommon.util.removeAllData();
			// 연금 펀드투자 패턴진단 연금 펀드상품을 보유한 고객에 한하여 노출
			$('#ps_fund_pattern').hide();
			//다른 페이지로 이동한 section 우선 숨겨둠
			$('#invest_ps').hide();
		}
	},
	// 단위 이벤트 바인딩 함수
	eventBind : () => {
		$("#tab_05").on("click", function(){
			pageUnit.prop.selected_tab = '5';
		});	
    	$("#tab_06").on("click", function() {
    		pageUnit.prop.selected_tab = '6';
		});
		$('.noti-box-close').off('click').on('click', function() {
			mydataCommon.msg.confirm({
				msg : "이 알림 내용을 삭제하면 다시 보이지 않습니다.",
				callBackFn : (isConfirm) => {
				if(isConfirm){      
					pageUnit.trn.ajax_call.XMT1001_U02();
				}
		    }});
		});		
		// 알림상품 이동 링크
		$(document).on("click", "#msg_cntn", function() {
		// ANNU0102 :국민연금 화면
		// ANNU0103 :퇴직연금 화면
		// ANNU0104 :개인연금 화면
			var urlMapId = "ANNU0103";
			if("IV" == pageUnit.prop.myd_inds_tp && (pageUnit.prop.alimi_item_tp == "17" || pageUnit.prop.alimi_item_tp == "25")){
				urlMapId = "ANNU0104";
			}
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId: urlMapId, callback:"callback_callMoveView"});
		});
		// AO 템플릿사용시 해당 이벤트 바인드 사용해야함.
		$(document).on("click", ".icon-refresh", function() {
			pageUnit.trn.ajax_call.XMP1001_U01();
		});
		// 나의노후자금진단 계산하기 버튼
		$(document).on("click", "#calRetireFundBtn", function() {
			if(!mydataCommon.vald.validation({target : $("#inputRetireFunds"),is_only_msg : true, immedtAlertPop : true})){
				pageUnit.trn.ajax_call.XMP4001_Q01();
			}
		});
		// 나의노후자금진단 초기화
		$(document).on("click", "#resetRetireFundBtn", function() {
			mydataCommon.formReset2($("#inputRetireFunds"));
		});
		// 연금 세액공제 시뮬레이션 버튼
		$('#calReduceTax').off('click').on('click', function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P09", callback:"callback_callMoveView", viewType:"full", strPopupTitle:"연금세액공제 시뮬레이션"});
		});
		// 연금 포트폴리오 비교하기
		$(document).on("click", "#compare_portfolio", function() {
			var pageParam = pageUnit.fn.get_param();
			pageParam.age = pageUnit.trn_param.age;
			mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P011", callback:"callback_callMoveView",viewType:"full"});
		});
		// 연금저축보험 알아보기
		$('#ps_more').on("click", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P040", callback:"callback_callMoveView",viewType:"full"});
		});
		// 퇴직연금 세제혜택 버튼
		$(document).on("click", "#irp_detail_btn", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU01P03", callback:"callback_callMoveView",viewType:"full"});
		});
		// 개인연금 세제혜택 버튼
		$(document).on("click", "#psn_detail_btn", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU01P04", callback:"callback_callMoveView",viewType:"full"});
		});
		// 나의노후자금 계산하기 후 "내게 맞는 연금 상품 알아보기" 버튼 클릭
		//펀드추천 김상민과장님 담당??
		$(document).on("click", "#goAnnu0105", function() {
			var pageParam = pageUnit.fn.get_param();
			pageParam.result_retAge = $("#result_retAge").text();
			pageParam.nd_ps_sav_amt = $("#nd_ps_sav_amt").text();
			mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0105", callback:"callback_callMoveView",viewType:"full"});
		});
		// 추천 연금 상품보기에서 버튼 클릭
		$(document).on("click", "#goAnnu0105_2", function() {
			mydataCommon.util.removeAllData();
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0105", callback:"callback_callMoveView",viewType:"full"});
		});
		//나의 노후 생활비 자세히 보기
		$(document).on("click", "#goAnnu0101P020", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P020", callback:"callback_callMoveView",viewType:"full"});
		});
		// 추천 연금 상품보기에서 버튼 클릭
		$(document).on("click", "#goAnnu0101P030", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P030", callback:"callback_callMoveView",viewType:"full"});
		});
		// 개인연금 세제혜택 버튼
		$(document).on("click", "#psn_join_btn", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"920"});
		});
		//나의 연금 자산은? 나이대
		$(document).on("change", "#avgAge", function() {
			pageUnit.trn_param.age = $(this).val();
			pageUnit.trn.ajax_call.XMP2030_Q01()
			.then(data =>{
	        	pageUnit.fn.set_section_my_ps_wealth(data);
	        })
	        .catch(e => {
	        	pageUnit.fn.errorMessage(e);
	        });
		});
		// 자산 연결하기
		$(document).on("click", ".icon-connect", function() {
			pageUnit.fn.set_psnConnect();
		});
		$(document).on("change", "#errt", function() {
			if($(this).val() == ''){
				$('#custom_input').css('display','inline-block');
			}else{
				$('#custom_input').css('display','none');
			}
		});
		//국민연금 포함, 미포함
		$(document).on("change", "#ns_ps_gb", function() {
			var obj = $(this).val();
			if(obj == '0'){ //미포함
				$('#not_include_ns_area').show();
				$('#ns_ps_gb_area').hide();
			}else if(obj =='1'){//포함 직접입력
				$('#not_include_ns_area').hide();
				$('#ns_ps_gb_area').show();
				pageUnit.trn.ajax_call.XMP4020_Q03();
			}
		});
		$('input:radio[name="rdo"]').on('click',function() {
			pageUnit.trn.ajax_call.XMP4020_Q01();
		});
		//노후 생활비 알아보기 - 예상 연금 수령액 확인하기 - 개인연금월납입액 계산
		$(document).on("click", "#confirm_expect_pesion", function() {
			pageUnit.trn.ajax_call.XMP4020_Q01();
		});
		//국민연금 월수령액 등록
		$('#apply_ns').on('click', function() {
			var param = {};
			//여기 클로저 개념쓰면 좋을듯
			if(pageUnit.prop.selected_tab == '5'){
				if($('#anty_mm_recv_amt').val().trim() == ''){
					mydataCommon.msg.alert({ msg : "월 수령액을 입력해 주세요."});
					return;
				}
				param.anty_calc_tp = '1';
				param.anty_mm_recv_amt = $('#anty_mm_recv_amt').val();
			}else{
				var incm_amt = $('#incm_amt').val();
				if(incm_amt.trim() == ''){
					mydataCommon.msg.alert({ msg : "월 평균 소득금액을 입력해 주세요."});
					return;
				}else if(!(incm_amt.trim() >=320000 && incm_amt.trim() <=5020000)){
					mydataCommon.msg.alert({ msg : "소득금액은 32만원 ~ 502만원까지 입력해 주세요."});
					return;
				}
				param.anty_calc_tp = '2';
				param.anty_join_term = $('#anty_join_term > option:selected').val();
				param.incm_amt = $('#incm_amt').val();
			}
			//XMP4020_U04
			//정상 등록 후 재 조회
			var jsonObj = {
					url : pageCom.prop.contextPath + "/annu/SAnn00100010026Ajax",
					data : param,
					async : true,
					success : pageUnit.fn.set_month_ms_reg,
					error : e => {
						pageUnit.fn.errorMessage(e);
					}
			}
			mydataCommon.ajax(jsonObj);
		});
		//메인 개인연금 계좌 더 불러오기
		$(document).on("click", "#more_personal", function() {
			pageUnit.trn.ajax_call.XMP2001_Q01()
			.then(data => {
				pageUnit.fn.set_section_personal_more(data);
			})
			.catch(e => {
				pageUnit.fn.errorMessage(e);
	        });
		});
		//메인 연금저축 계좌 더 불러오기
		$(document).on("click", "#more_ps", function() {
			pageUnit.trn.ajax_call.XMP2001_Q04()
			.then(data => {
				pageUnit.fn.set_section_ps_more(data);
			})
			.catch(e => {
				pageUnit.fn.errorMessage(e);
	        });
		});
		//메인 IRP 계좌 더 불러오기
		$(document).on("click", "#more_irp", function() {
			pageUnit.trn.ajax_call.XMP2001_Q02()
			.then(data => {
				pageUnit.fn.set_section_irp_more(data);
			})
			.catch(e => {
				pageUnit.fn.errorMessage(e);
	        });
		});
	},
	fn : {
		more_item : (orgn_code, cont_gubn, next_data) => {
			var param = {};
			param.orgn_code = orgn_code;
			param.cont_gubn = mydataCommon.util.nvl(cont_gubn, $('#cont_gubn'+orgn_code).val());
			param.next_data = mydataCommon.util.nvl(next_data, $('#next_data'+orgn_code).val());
			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/annu/SAnn00100010011Ajax",
					data : param,
					async : false,
					success : data => {
						var output = data.XMP2001_Q06;
						ao_append("#finance_each_list_"+output.orgn_code,'finance_each_list_tmpl', output);
						$("#more_product_one_time_"+output.orgn_code).hide();
						if(output.cont_gubn == 'Y'){
							$('#more_product_'+output.orgn_code).show();
							$('#cont_gubn'+orgn_code).val(output.cont_gubn);
							$('#next_data'+orgn_code).val(output.next_data);
						}else{
							$('#more_product_'+output.orgn_code).hide();
						}
					},
					error : (e1, e2, e3) => {
						pageUnit.fn.errorMessage(e1);							
					}
				}
				mydataCommon.ajax(jsonObj);
		},
		callback_getKeypadResult : (jsonString) => {
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;
			if(rId == "month_nd_amt" || rId == "tot_yr_salary_amt" ||rId == "ps_sav_paid_amt" || rId == "ret_ps_irp_paid_amt" ){  
				nVal = mydataCommon.util.addComma( nVal );
			}		
			if(rId == "ret_age" && nVal <= $("#cur_age").val()){
				mydataCommon.msg.alert({msg : "현재 나이는 은퇴예상연령보다 작아야 계산이 가능합니다.다시 입력해주세요."});
				return;
			}
			
			$("#"+rId).val(nVal);
			pageUnit.fn.checkNull(); 
		},
		set_ntnConnect : () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P06", callback:"callback_callMoveView"});
		},
		set_psnConnect : () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"callback_callMoveView"});
		},
		set_section_myinfo_gb : data => {
			var output = data.resultMap;
			pageUnit.prop.peop_anty_yn = output.peop_anty_yn;
			pageUnit.prop.anty_yn = output.anty_yn;
			if (output.anty_yn == "Y") {
				$("#myinfo_noconnect").hide();
				$("#set_section_total").show();
				$("#set_section_alim").show();
				$('#my_ps_wealth').show();
				$('#set_section_gubn').show();
				$("#personal_pay_card").show();
				$("#pension_saving_pay_card").show();
				$("#irp_pay_card").show();
				//$('#invest_ps').show();
				$('#old_age_living_expense').show();
				$("#myinfo_connect").css("display", "block");
				pageUnit.trn.ajax_call.allSearch();
			} else {
				$("#myinfo_noconnect").show();
				$("#set_section_total").hide();
				$("#set_section_alim").hide();
				$('#my_ps_wealth').hide();
				$('#set_section_gubn').hide();
				$("#personal_pay_card").hide();
				$("#pension_saving_pay_card").hide();
				$("#irp_pay_card").hide();
				//$('#invest_ps').hide();
				$('#old_age_living_expense').hide();
				$("#myinfo_connect").css("display", "none");
			}
		},
		//미사용인듯
		set_section_personal_finance_gb : function(data){
			ao_html('tab_panel02','set_section_personal_finance_ins_g1_tmpl', data);
			KW_MOBILE.guiEvent.accordion.init('#tab_panel02');
		},
		// 상단 전체요약정보
		set_section_total : data => {
			var output = data.XMP2003_Q01;
			pageUnit.trn_param.amt_sum = output.amt_sum;
			output.amt_sum = mydataCommon.util.addComma(output.amt_sum);
			ao_html('#set_section_total', output);
			ao_html('#set_section_my_total_ps', output);
			//국민 연금 select 박스는 초기화
			$('#ns_ps_gb').val(0);
			$('#ns_ps_gb option:eq(0)').attr('selected', 'selected');
		},
		// 개인연금
		set_section_personal : data => {
			var output = data.XMP2001_Q01;
			if(output.resp_gubn == '1'){
				$('#personal_pay_card').hide();
			}else{
				ao_html('personal_pay_card','personal_info_tmpl', output);
				pageUnit.prop.personal_cont_gubn = output.cont_gubn;
				pageUnit.prop.personal_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#personal_more_item').show();
				}else{
					$('#personal_more_item').hide();
				}
				KW_MOBILE.guiEvent.accordion.init('#personal_pay_card');	
			}
		},
		// 개인연금 더보기
		set_section_personal_more : data => {
			var output = data.XMP2001_Q01;
			if(output.resp_gubn == '1'){
				$('#personal_pay_card').hide();
			}else{
				ao_append('personal_next_data','personal_next_data_tmpl', output);
				pageUnit.prop.personal_cont_gubn = output.cont_gubn;
				pageUnit.prop.personal_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#personal_more_item').show();
				}else{
					$('#personal_more_item').hide();
				}
			}
		},
		// 연금저축 보험 조회
		set_section_ps : data => {
			var output = data.XMP2001_Q04;
			if(output.resp_gubn == '1'){
				$('#pension_saving_pay_card').hide();
			}else{
				ao_html('pension_saving_pay_card','ps_info_tmpl', output);
				pageUnit.prop.ps_cont_gubn = output.cont_gubn;
				pageUnit.prop.ps_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#ps_more_item').show();
				}else{
					$('#ps_more_item').hide();
				}
				KW_MOBILE.guiEvent.accordion.init('#pension_saving_pay_card');	
			}
		},
		// 연금저축 보험 조회 더보기
		set_section_ps_more : data => {
			var output = data.XMP2001_Q04;
			if(output.resp_gubn == '1'){
				$('#pension_saving_pay_card').hide();
			}else{
				ao_append('ps_next_data','ps_next_data_tmpl', output);
				pageUnit.prop.ps_cont_gubn = output.cont_gubn;
				pageUnit.prop.ps_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#ps_more_item').show();
				}else{
					$('#ps_more_item').hide();
				}
			}
		},
		// 퇴직연금(irp) 조회
		set_section_irp : data => {
			var output = data.XMP2001_Q02;
			if(output.resp_gubn == '1'){
				$('#irp_pay_card').hide();
			}else{
				ao_html('irp_pay_card','irp_info_tmpl', output);
				pageUnit.prop.irp_cont_gubn = output.cont_gubn;
				pageUnit.prop.irp_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#irp_more_item').show();
				}else{
					$('#irp_more_item').hide();
				}
				KW_MOBILE.guiEvent.accordion.init('#irp_pay_card');	
			}
		},
		// 퇴직연금(irp) 조회 더보기
		set_section_irp_more : data => {
			var output = data.XMP2001_Q02;
			if(output.resp_gubn == '1'){
				$('#irp_pay_card').hide();
			}else{
				ao_append('irp_next_data','irp_next_data_tmpl', output);
				pageUnit.prop.irp_cont_gubn = output.cont_gubn;
				pageUnit.prop.irp_next_data = output.next_data;
				if(output.cont_gubn == 'Y'){
					$('#irp_more_item').show();
				}else{
					$('#irp_more_item').hide();
				}	
			}
		},
		set_section_my_ps_wealth : data => {
			var output = data.XMP2030_Q01;
			pageUnit.trn_param.age = output.age;
			ao_html('my_ps_wealth','set_my_ps_wealth_tmpl', output);
			$('#avgAge > option[value='+output.age+']').attr('selected',true);
			KW_MOBILE.guiEvent.toolTip.init('');
			var chartColumnStack = new Highcharts.Chart('chart-column-stack', Highcharts.merge (
		            KW_MOBILE.highcharts.types.column,
		            {
		                chart: {
		                    height: 220,
		                    min: -0.25//yAxis 위치를 안쪽으로 변경하면서 첫번째 컬럼과 간격 조정
		                },
		                xAxis: {
		                    categories: ['나', '연령 평균']
		                },
		                yAxis: {
		                    gridLineWidth: 1,
		                    visible: true,
		                    labels: {
		                        enabled: true,
		                        style: { fontSize: '10px' }
		                    },
		                    stackLabels: {
		                        enabled: true,
		                        formatter: function(){
		                            return mydataCommon.util.addComma(this.total)+'만원';
		                        },
		                        verticalAlign: 'top',
		                        y: 3,
		                        x: 0,
		                        style: { fontSize: '12px' },
		                        crop: false,//crop,overflow max값이 컬럼과 겹치는 현상 방지
		                        overflow: 'none'
		                    }
		                },
		                plotOptions: {
		                    column: {
		                        stacking:'normal',
		                        dataLabels: { enabled: false },
		                        borderWidth: 0
		                    },
		                    series: {
		                        groupPadding: 0.9
		                    }
		                },
		                series: [
		                    { name: '개인연금', data: [Number(output.anty_pay_tota),Number(output.avg_anty_pay_tota)], color: '#66cccc', index: 1 },
		                    { name: '연금보험', data: [Number(output.pain_insr_amt),Number(output.avg_pain_insr_amt)], color: '#66ccff', index: 2 },
		                    { name: '퇴직연금(IRP)', data: [Number(output.irp_evlt_amt),Number(output.avg_irp_evlt_amt)], color: '#6666cc', index: 3 }
		                    
		                ],
		                legend: {
		                    enabled: false,
		                    reversed: true
		                }
		            }
		        ));
		},
		set_section_ps_month_payment : data => {
			var output = data.XMP4020_Q01;
			if(output.resp_gubn == '0'){
				$('#my_age_area').css('display','block');
				$('#recoProduct').css('display','block');
				var selected_value = $('input:radio[name="rdo"]:checked').val();
				if(selected_value == "1"){
					//최소형 선택 했을 경우
					output.life_style = '최소형';
					output.life_cost = 1500000;
					output.life_cost_display = 150;
				}else if(selected_value == "2"){
					//적정형 선택 했을 경우
					output.life_style = '적정형';
					output.life_cost = 2300000;
					output.life_cost_display = 230;
				}else{
					//풍족형 선택했을 경우
					output.life_style = '풍족형';
					output.life_cost = 3000000;
					output.life_cost_display = 300;
				}
				output.dfrn_amt = mydataCommon.util.addComma(output.dfrn_amt);
				if(Number(output.anty_recv_alowa) > output.life_cost){
					output.life_explain = `${output.life_style} 생활비 월 <span>${output.life_cost_display}</span>만원보다<br>매월 <span>${output.dfrn_amt}</span>원 더 수령 가능해요.`;
				}else if(Number(data.anty_recv_alowa) < data.life_cost){
					output.life_explain = `${output.life_style} 생활비 월 <span>${output.life_cost_display}</span>만원보다<br>매월 <span>${output.dfrn_amt}</span>원이 부족해요.`;
				}else{
					output.life_explain = `${output.life_style} 생활비 월 <span>${output.life_cost_display}</span>만원보다<br>매월 <span>${output.dfrn_amt}</span>원만큼<br>수령 가능해요.`;
				}
				output.anty_recv_alowa = mydataCommon.util.addComma(output.anty_recv_alowa);
				output.mm_pdin_amt = mydataCommon.util.addComma(output.mm_pdin_amt);
				output.selected_age = $('#anty_recv_age > option:selected').val();
				if($('#errt > option:selected').val() == ""){
					output.errt = $('#custom_input').val();
				}else{
					output.errt = $('#errt > option:selected').val();
				}
				ao_html('old_age_living_expense_area','old_age_living_expense_area_tmpl', output);
				$('#life_explain').append(output.life_explain);
			}
		},set_month_ms_reg : data => {
			var output = data.XMP4020_U04;
			if(output.resp_gubn == '0'){
				pageUnit.trn.ajax_call.XMP4020_Q03();
				KW_MOBILE.guiEvent.popup.closePop('#modal_popup2');
			}
		}
		,
		set_section_nation_ps_month_receipt : data => {
			var output = data.XMP4020_Q03;
			if(output.incl_yn == 'Y'){
				//국민연금 수령액
				pageUnit.trn_param.peop_anty_recv_amt = output.anty_mm_recv_amt;
				if(output.anty_calc_tp == '1'){
					$('#tab_05').trigger('click');
					$('#anty_mm_recv_amt').val(output.anty_mm_recv_amt);
					output.anty_mm_recv_amt = mydataCommon.util.addComma(output.anty_mm_recv_amt);
				}else{
					$('#tab_06').trigger('click');
					$('#incm_amt').val(output.incm_amt);
					output.incm_amt = mydataCommon.util.addComma(output.incm_amt);
					$('#anty_join_term > option[value='+output.anty_join_term+']').attr('selected',true);
				}
			}
			ao_html('ns_month_anty_mm_recv_amt','ns_month_anty_mm_recv_amt_tmpl', output);
		},
		set_section_alim : data => {
			 var outData = data.resultMap;
			 if(outData.msg_cntn != ""){
				 $("#alim_box").show();
				 $("#msg_cntn").text(outData.msg_cntn);
				 
				pageUnit.trn_param.alimi_seq = outData.alimi_seq;
				pageUnit.prop.alimi_item_tp = outData.alimi_item_tp;
				pageUnit.prop.myd_inds_tp = outData.myd_inds_tp;
				
			 }else{
				 $("#alim_box").hide();
			 }
		}
		,
		set_section_reload : data => {
			 var outData = data.XMP1001_U01;
			 if(outData.resp_gubn == "0"){
				mydataCommon.msg.alert({msg : "연결된 자산 정보를 업데이트 하였습니다."});
				pageUnit.trn.ajax_call.allSearch();
			 }
			 else mydataCommon.msg.alert({msg : outData.resp_mesg});
						
		},
		set_section_psnAlilm_reload : data => {
			var outData = data.XMT1001_U02;
			if(outData.resp_gubn == '0'){
				$("#alim_box").hide();
			}
		},
		// 노후 자금 진단
		set_old_age_funds : data => {
			var output = data.XMP4001_Q01;
			if(output.resp_gubn == '0'){
				output.nd_ps_sav_amt = mydataCommon.util.addComma(output.nd_ps_sav_amt);
				output.at_ret_nd_ret_amt = mydataCommon.util.addComma(output.at_ret_nd_ret_amt);
				output.at_cur_nd_ret_spot_amt = mydataCommon.util.addComma(output.at_cur_nd_ret_spot_amt);
				ao_html('checkRetireMoney','checkRetireMoney_tmpl', output);
				KW_MOBILE.guiEvent.popup.openPop('#modal_popup');
			}
		},
		// 개인연금, 개인IRP 상세화면이동
		popDetail : (param1, param2, param3) => {
			var urlMapId = "";
			if(param3 =="1"){
				var pageParam = pageUnit.fn.get_param();
				pageParam.orgn_code = param1;
				pageParam.acnt_no = param2;
				urlMapId = "ANNU0107";
				mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
			}
			else if(param3 =="2"){
				// 2차 추가
				//sub key로 임시 변환
				var v_storageKeyName = pageUnit.prop.v_storageKeyName;
				pageParam = mydataCommon.page.getSubParamData('VIns0010002View');
				pageUnit.prop.v_storageKeyName = pageUnit.prop.v_storageSubKeyName;
				pageParam.orgn_code = param1;
				pageParam.insr_cntr_no = param2;
				urlMapId = "INSU0102"
				mydataCommon.page.setSubParamData(pageParam,'VIns0010002View');
				//저장 후 다시 복구
				pageUnit.prop.v_storageKeyName = v_storageKeyName;
			}
			else if(param3 == "3"){ 
				var pageParam = pageUnit.fn.get_param();
				pageParam.orgn_code = param1;
				pageParam.acnt_no = param2;
				urlMapId = "ANNU0103"
				mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
			};
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:urlMapId, callback:"callback_callMoveView", viewType:"full"});
		},
		// 모두보기 이동(사용 안함)
		btn_AllSee : gds_tp => {
			var pageParam = pageUnit.fn.get_param();
			pageParam.gds_tp = gds_tp;
			mydataCommon.page.setSubParamData(pageParam,'VAnn0010001View');
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU01P02", callback:"callback_callMoveView", viewType:"full"});
		},
		// 연금 현황 보러가기
		btn_see_ps : () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P100", callback:"callback_callMoveView", viewType:"full"});
		},
		get_param : () => {return mydataCommon.page.getSubParamData('VAnn0010001View');}
		,
		errorMessage : e => {
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}
	},
};
$(document).ready(() => {
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
	pageUnit.init();
    // 펀드 투자패턴 진단 (추후 작업)
    //KW_MOBILE.guiEvent.swiper.runSwiper('#swiper03', false);
    
    // 연금펀드 투자패턴 진단 차트(추후 작업)
   /* var chartColumn = new Highcharts.Chart('chart-column', Highcharts.merge (
            KW_MOBILE.highcharts.types.column,
            {   
                chart: {
                    height: 210,
                    marginBottom: 68,
                },
                xAxis: {
                    min: -0.25//yAxis 위치를 안쪽으로 변경하면서 첫번째 컬럼과 간격 조정
                },
                yAxis: {
                    gridLineWidth: 1,
                    enable:true,
                    visible: true,
                    min:0,
                    max:100,
                    tickInterval:20,
                    visible: true,
                    labels:{
                        style: { fontSize: '10px' }
                    },
                },
                plotOptions: {
                    column: {
                        pointWidth: 13,
                    }
                },
                series: [{
                    dataLabels: {
                        enabled: true,
                        format: '{point.y}%'
                    },
                    data: [
                        {name : '유럽채권', y: 74, color:'#6666cc'},
                        {name : '국내채권', y: 10, color:'#d1d6e8'},
                        {name : '국내우량채권', y: 5, color:'#d1d6e8'},
                        {name : '일본채권', y: 5, color:'#d1d6e8'},
                        {name : '기타', y: 6, color:'#d1d6e8'},
                    ]
                }]
            }
        ));*/
});