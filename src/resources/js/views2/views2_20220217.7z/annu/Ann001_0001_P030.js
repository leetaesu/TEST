var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P030PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : 'reco',
		cont_gubn : 'N',
		next_data : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP4021_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var param = {};
					param.now_age = $('#now_age').val();
					param.ret_expc_age = $('#expect_retire_age > option:selected').val();
					param.cont_gubn = pageUnit.prop.cont_gubn;
					param.next_data = pageUnit.prop.next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0300001Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : () => {
		pageUnit.eventBind();
	},
	eventBind : () => {
		$('#search').on('click',() => {
			if(mydataCommon.util.isNull($('#now_age').val())){
				mydataCommon.msg.alert({ msg : "현재 나이를 입력해주세요."});
				return;
			}
			pageUnit.trn.ajax_call.XMP4021_Q01()
			.then(data => {
				pageUnit.fn.set_result(data);
			})
			.catch((e)=>{
				mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});	
			});
		});
		
		// 나의노후자금진단 초기화
		$(document).on("click", "#reset", () => {
			$('#now_age').val("");
			$("#expect_retire_age > option:eq(0)").prop('selected',true);
		});
		
		$('.sub-close').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		$('#confirm').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		//더 많은 상품 불러오기
		$(document).on("click", "#more_item", () => {
			pageUnit.trn.ajax_call.XMP4021_Q01()
			.then(data => {
				pageUnit.fn.set_result_more(data);
			})
			.catch((e)=>{
				mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});		
			});
		});
	},
	fn : {		
		set_result : data => {
			var output = data.XMP4021_Q01;
			output.selected_age = $('#expect_retire_age > option:selected').val();
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			ao_html('single_info','single_info_tmpl', output);
			ao_html('list_info','list_info_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_product').css('display','block');
			}else{
				$('#more_product').css('display','none');
			}
		},
		set_result_more : data => {
			var output = data.XMP4021_Q01;
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			ao_append('list_info','list_info_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_product').css('display','block');
			}else{
				$('#more_product').css('display','none');
			}
		},
		popDetail : stk_code => {
			//sub key로 임시 변환
			var v_storageKeyName = pageUnit.prop.v_storageKeyName;
			pageUnit.prop.v_storageKeyName = pageUnit.prop.v_storageSubKeyName;
			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			param.stk_code = stk_code;
			mydataCommon.page.setSubParamData(param,'VReco0010001View');
			//저장 후 다시 복구
			pageUnit.prop.v_storageKeyName = v_storageKeyName;
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0201", callback:"callback_callMoveView",viewType:"full"});
		}
	},
	
};

$(document).ready(() => {
	pageUnit.init();
});



