var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P020PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP4030_Q01 : anty_recv_tp => {
				var param = pageUnit.fn.get_param();
				param.anty_recv_tp = anty_recv_tp;
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0200001Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
						}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : () => {
		var ajax_call = pageUnit.trn.ajax_call;
		try{
			['1','2'].forEach( async row => {
				var XMP4030_Q01 = await ajax_call.XMP4030_Q01(row);
				row == 1 ? pageUnit.fn.set_result1(XMP4030_Q01): pageUnit.fn.set_result2(XMP4030_Q01);
			});	
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}finally{
			pageUnit.eventBind();	
		}
	},
	eventBind : () => {
		$('.sub-close').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		// 추천 연금 상품보기에서 버튼 클릭
		$(document).on("click", "#goAnnu0105", () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0105", callback:"callback_callMoveView",viewType:"full"});
		});
		// 내게맞는생애주기상품
		$(document).on("click", "#goAnnu0101P030", () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"ANNU0101P030", callback:"callback_callMoveView",viewType:"full"});
		});
	},
	fn : {		
		set_result1 : data => {
			var output = data.XMP4030_Q01;
			ao_html('info1','info1_tmpl', output);
			//pageUnit.fn.draw_chart('chart-column-stack1',output);
		},
		set_result2 : data => {
			var output = data.XMP4030_Q01;
			ao_html('info2','info2_tmpl', output);
			//pageUnit.fn.draw_chart('chart-column-stack2',output);
		},
		draw_chart : (id, output) => {
	        var chartColumnStack1 = new Highcharts.Chart(id, Highcharts.merge (
	            KW_MOBILE.highcharts.types.column,
	            {
	                chart: {
	                    height: 220
	                },
	                xAxis: {
	                    categories: [output.g1[0].anty_recv_strt_age+'세~'+output.g1[0].anty_recv_end_age+'세', output.g1[1].anty_recv_strt_age+'세~'+output.g1[1].anty_recv_end_age+'세']
	                },
	                yAxis: {
	                    gridLineWidth: 1,
	                    visible: true,
	                    labels: {
	                        enabled: false,
	                        style: { fontSize: '0' }
	                    },
	                    stackLabels: {
	                        enabled: true,
	                        //format: '월230만원',
	                        formatter: function(){
	                            return '월'+mydataCommon.util.addComma(this.total)+'원';
	                        },
	                        verticalAlign: 'top',
	                        y: 0,
	                        x: 0,
	                        style: { fontSize: '12px' },
	                        crop: false,//crop,overflow max값이 컬럼과 겹치는 현상 방지
	                        overflow: 'none'
	                    },
	                    maxPadding: 0
	                },
	                plotOptions: {
	                    column: {
	                        stacking:'normal',
	                        pointPadding: 0.25,
	                        pointWidth: 60,
	                        dataLabels: {
	                            enabled: true,
	                            formatter: function(){
		                            return mydataCommon.util.addComma(this.y)+'원';
		                        },
	                            align: 'center',
	                            color: '#fff',
	                            style: {
	                                fontSize: '9px',
	                                textOutline: false
	                            },
	                            verticalAlign: 'middle',
	                            y: 0
	                        },
	                        borderWidth: 0
	                    },
	                    series: {
	                        pointPadding: 0.8,
	                        groupPadding: 0.8
	                    }
	                },
	                series: [
	                    { name: '개인연금(기존)', data: [Number(output.g1[0].pers_anty_recv_amt),Number(output.g1[1].pers_anty_recv_amt)], color: '#6666cc', index: 3 },
	                    { name: '개인연금(추가)', data: [Number(output.g1[0].pers_anty_add_recv_amt),Number(output.g1[1].pers_anty_add_recv_amt)], color: '#66cccc', index: 2 },
	                    { name: '국민연금', data: [Number(output.g1[0].peop_anty_recv_amt),Number(output.g1[1].peop_anty_recv_amt)], color: '#fe74a2', index: 1 }
	                ],
	                legend: {
	                    enabled: false,
	                    reversed: true
	                }
	            }
	        ));
		},
		get_param : () => {return mydataCommon.page.getSubParamData('VAnn0010001View');}
	},
};
$(document).ready(() => {
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
	pageUnit.init();	
});