var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P011PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : 'reco',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {		
			XMP3001_Q01 : () => {
				var param = pageUnit.fn.get_param();
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0110001Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP3001_Q02 : () => {
				var param = pageUnit.fn.get_param();
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0110002Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP3002_Q01 : invt_gds_kind_tp => {
				var param = pageUnit.fn.get_param();
				param.invt_gds_kind_tp = invt_gds_kind_tp;
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0110003Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;
		//개인연금포트폴리오비중조회
		try{
			var XMP3001_Q01 = await ajax_call.XMP3001_Q01();
			pageUnit.fn.set_section_personal_pension_stat(XMP3001_Q01);
			var XMP3001_Q02 = await ajax_call.XMP3001_Q02();
			pageUnit.fn.set_section_personal_irp_stat(XMP3001_Q02);
			var XMP3002_Q01_401 = await ajax_call.XMP3002_Q01('401');
			pageUnit.fn.set_section_age_set1(XMP3002_Q01_401);
			var XMP3002_Q01_413 = await ajax_call.XMP3002_Q01('413');
			pageUnit.fn.set_section_age_set2(XMP3002_Q01_413);
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}finally{
			pageUnit.eventBind();
		}
	},
	eventBind : () => {
		$('.sub-close').on('click',() => {
			pageUnit.fn.popClose();
		});
		$(".btn-footer").off("click").on("click", () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
	},
	fn : {		
		popClose : () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		},
		popDetail : (stk_code, gubn) => {
			//ETF와 펀드 구분해서 다르게 보내줘야함
			if(gubn == '002'){
				var datas = { strMenuid:"ID_Menu2_Hyeonjaega",strJongmokCode:stk_code };
				mydataCommon.appBridge.callApptoapp(datas);
			}else{
				//sub key로 임시 변환
				var v_storageKeyName = pageUnit.prop.v_storageKeyName;
				pageUnit.prop.v_storageKeyName = pageUnit.prop.v_storageSubKeyName;
				var param = mydataCommon.page.getSubParamData('VReco0010001View');
				param.stk_code = stk_code;
				mydataCommon.page.setSubParamData(param,'VReco0010001View');
				//저장 후 다시 복구
				pageUnit.prop.v_storageKeyName = v_storageKeyName;
				mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0201", callback:"callback_callMoveView",viewType:"full"});	
			}
		},
		//개인연금 포트폴리오 비중
		set_section_personal_pension_stat : data => {
			var output = data.XMP3001_Q01;
			var param = pageUnit.fn.get_param();
			output.cur_age = param.age+"대";
			ao_html('personal_portfolio','personal_portfolio_tmpl', output);
			pageUnit.fn.draw_chart('chart-pie01_1',[{name:output.g1[0].invt_gds_kind_nm, y: Number(output.g1[0].pers_anty_wght) == 0 ? null : Number(output.g1[0].pers_anty_wght)},{name: output.g1[1].invt_gds_kind_nm, y: Number(output.g1[1].pers_anty_wght) == 0 ? null : Number(output.g1[1].pers_anty_wght)},{name: output.g1[2].invt_gds_kind_nm, y: Number(output.g1[2].pers_anty_wght) == 0 ? null : Number(output.g1[2].pers_anty_wght)},{name: output.g1[3].invt_gds_kind_nm, y: Number(output.g1[3].pers_anty_wght) == 0 ? null : Number(output.g1[3].pers_anty_wght)}]);
			pageUnit.fn.draw_chart('chart-pie01_2',[{name:output.g1[0].invt_gds_kind_nm, y: Number(output.g1[0].avg_anty_wght) == 0 ? null : Number(output.g1[0].avg_anty_wght)},{name: output.g1[1].invt_gds_kind_nm, y: Number(output.g1[1].avg_anty_wght) == 0 ? null : Number(output.g1[1].avg_anty_wght)},{name: output.g1[2].invt_gds_kind_nm, y: Number(output.g1[2].avg_anty_wght) == 0 ? null : Number(output.g1[2].avg_anty_wght)},{name: output.g1[3].invt_gds_kind_nm, y: Number(output.g1[3].avg_anty_wght) == 0 ? null : Number(output.g1[3].avg_anty_wght)}]);
			$('#cur_age2').text(param.age+"세");
		},
		//개인 irp 포트폴리오 비중
		set_section_personal_irp_stat : data => {
			var param = pageUnit.fn.get_param();
			var output = data.XMP3001_Q02;
			output.cur_age = param.age+"대";
			ao_html('irp_personal_portfolio','irp_personal_portfolio_tmpl', output);
			pageUnit.fn.draw_chart('chart-pie01_3',[{name:output.g1[0].irp_type_nm, y: Number(output.g1[0].pers_anty_wght) == 0 ? null : Number(output.g1[0].pers_anty_wght)},{name: output.g1[1].irp_type_nm, y: Number(output.g1[1].pers_anty_wght) == 0 ? null : Number(output.g1[1].pers_anty_wght)}]);
			pageUnit.fn.draw_chart('chart-pie01_4',[{name:output.g1[0].irp_type_nm, y: Number(output.g1[0].avg_anty_wght) == 0 ? null : Number(output.g1[0].avg_anty_wght)},{name: output.g1[1].irp_type_nm, y: Number(output.g1[1].avg_anty_wght) == 0 ? null : Number(output.g1[1].avg_anty_wght)}]);
		},
		//연령대연금투자종목조회
		set_section_age_set1: data => {
			var output = data.XMP3002_Q01;
			ao_html('age_set1','age_set1_tmpl', output);
		},
		set_section_age_set2 : data => {
			var output = data.XMP3002_Q01;
			ao_html('age_set2','age_set2_tmpl', output);
		},
		get_param : () => {return mydataCommon.page.getSubParamData('VAnn0010001View');}
		,
		draw_chart : (id, data) => {
			var chartPie = new Highcharts.Chart(id, Highcharts.merge (                
		            KW_MOBILE.highcharts.types.pie,                
		            {
		                colors: ['#66ccff','#fe74a2','#ff9933','#6666cc'],
		                chart: {
		                    height: 160
		                },
		                title: {
		                    text: null  
		                },     
		                navigation: {
		                    buttonOptions: {
		                        enabled: true
		                    }
		                },                    
		                plotOptions: {
		                    pie: {
		                        allowPointSelect: true,
		                        borderWidth: 0,
		                        dataLabels: { 
		                            enabled: true,
		                            format: '{point.y}',
		                            distance: -30,
		                            color: '#ffffff',
		                            style: {
		                                fontSize: '14px',
		                                textOutline: false
		                            }                                
		                        }                            
		                    }
		                },
		                series:[{
		                    innerSize: '0',                        
		                    states:{
		                        hover: {enabled:false}, 
		                        inactive: false
		                    },
		                    data: data
		                }]
		            }
		        ));
		}
	},
	
};

$(document).ready(() => {
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
	pageUnit.init();
});



