var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P100PopView",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call :{
			XMP2031_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn0010001P100Ajax",
						data : {},
						async : true,
						success : resolve,
						error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP2031_Q02 : () => {
				return new Promise( (resolve, reject) => {
					var jsonObj = {
						url : pageCom.prop.contextPath + "/annu/SAnn0010001P101Ajax",
						data : {},
						async : true,
						success : resolve,
						error : reject
					}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;
		try{
			//나의 연금자산 구성현황조회
			var XMP2031_Q01 = await ajax_call.XMP2031_Q01();
			pageUnit.fn.set_section_pension_stat(XMP2031_Q01);
			var XMP2031_Q02 = await ajax_call.XMP2031_Q02();
			pageUnit.fn.set_section_balance_chg(XMP2031_Q02);
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});
		}
	},
	fn : {		
		popClose : () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		},
		//나의 연금 현황
		set_section_pension_stat : data => {
			var output = data.XMP2031_Q01;
			ao_html('#set_section_pension_stat', output);
			ao_html('#set_section_pension_stat2', output);
			var chartStack = new Highcharts.Chart('chart-stack', Highcharts.merge (
		            KW_MOBILE.highcharts.types.stackedBar,
		            {
		                chart: {
		                    height: 150
		                },
		                xAxis: {
		                    enable: false,
		                    visible: false
		                },
		                yAxis: {
		                    labels:{ formatter: function() {return this.value+'%';} }
		                },
		                plotOptions: {
		                    column: {
		                        pointWidth: 40
		                    },
		                    series: {
		                        pointPadding: 0.8,
		                        groupPadding: 0.8
		                    }
		                },
		                series: [
		                    { name: '개인연금(펀드/ETF)', data: [Number(output.pers_anty_wght)], color: '#fe74a2', index: 4 },
		                    { name: '연금(저축)보험', data: [Number(output.anty_insr_wght)], color: '#ff9933', index: 3 },
		                    { name: 'IRP', data: [Number(output.irp_wght)], color: '#66ccff', index: 2 },
		                    { name: '기타', data: [Number(output.etc_wght)], color: '#d1d6e8', index: 1 }
		                ],
		                legend: {
		                    enabled: false,
		                    reversed: true
		                }
		            }
		        ));
			
		},
		set_section_balance_chg : data => {
			var output = data.XMP2031_Q02;
			if(output.resp_gubn == '0'){
				ao_html('#set_section_balance_chg3m', output);
				// 3개월 변동 추이
		        var chartColumnStack = new Highcharts.Chart('chart-column-stack', Highcharts.merge (
		            KW_MOBILE.highcharts.types.column,
		            {
		                chart: {
		                    height: 220
		                },
		                xAxis: {
		                    categories: [mydataCommon.util.getStrDate(output.g1[0].base_yymm),
		                                 mydataCommon.util.getStrDate(output.g1[1].base_yymm),
		                                 mydataCommon.util.getStrDate(output.g1[2].base_yymm)],
		                    min: -0.25//yAxis 위치를 안쪽으로 변경하면서 첫번째 컬럼과 간격 조정
		                },
		                yAxis:{
		                    gridLineWidth: 1,
		                    visible: true,
		                    labels: {
		                        enabled: true,
		                        style: { fontSize: '10px' }
		                    }
		                },
		                plotOptions:{
		                    column: {
		                        stacking:'normal',
		                        dataLabels: { enabled: false },
		                        borderWidth: 0
		                    },
		                    series: {
		                        groupPadding: 0.9
		                    }
		                },
		                series: [
		                    { name: '개인연금(펀드/ETF)', data: [Number(output.g1[0].pers_anty_evlt_amt),Number(output.g1[1].pers_anty_evlt_amt),Number(output.g1[2].pers_anty_evlt_amt)], color: '#fe74a2', index: 4 },
		                    { name: '연금(저축)보험', data: [Number(output.g1[0].anty_insr_pdin_amt),Number(output.g1[1].anty_insr_pdin_amt),Number(output.g1[2].anty_insr_pdin_amt)], color: '#ff9933', index: 3 },
		                    { name: 'IRP', data: [Number(output.g1[0].irp_evlt_amt),Number(output.g1[1].irp_evlt_amt),Number(output.g1[2].irp_evlt_amt)], color: '#66ccff', index: 2 },
		                    { name: '기타', data: [Number(output.g1[0].etc_amt),Number(output.g1[1].etc_amt),Number(output.g1[2].etc_amt)], color: '#d1d6e8', index: 1 }
		                ],
		                legend: {
		                    enabled: false,
		                    reversed: true
		                }
		            }
		        ));
			}
			
		},
	},
	
};

$(document).ready(() => {
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
	pageUnit.init();
});



