var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010005View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : 'reco',
		cont_gubn : 'N',
		next_data : '',
		common_err_msg : '오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP4010_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var param = {};
					param.cont_gubn = pageUnit.prop.cont_gubn;
					param.next_data = pageUnit.prop.next_data;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010005001Ajax",
							data : param,
							async : true,
							success : resolve,
							error : reject
					}
					mydataCommon.ajax(jsonObj);	
				});
			}
		}
	},
	// 단위 진입부 함수
	init : async () => {
		var ajax_call = pageUnit.trn.ajax_call;
		try{
			var XMP4010_Q01 = await ajax_call.XMP4010_Q01();
			pageUnit.fn.set_result(XMP4010_Q01);
		}catch(e){
			mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});	
		}finally{
			pageUnit.eventBind();	
		}
	},
	// 단위 이벤트 바인딩 함수
	eventBind : () => {
		$(".sub-prev").off("click").on("click", () => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});	
		$("#goReco").off("click").on("click", () => {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0101", callback:"callback_callMoveView"});
		});	
		//더 많은 상품 불러오기
		$(document).on("click", "#more_item", function(){
			pageUnit.trn.ajax_call.XMP4010_Q01()
			.then(data =>{
				pageUnit.fn.set_result_more(data);
			})
			.catch((e)=>{
				mydataCommon.msg.alert({msg : pageUnit.prop.common_err_msg+"["+e+"]"});	
			});
		});
	},
	fn : {		
		set_result : data => {
			var output = data.XMP4010_Q01;
			//투자성향 데이터 1 : 공격투자형   2: 적극투자형  3:위험중립형 4:안정추구형 5:안정형
			if(output.invt_prpn_tp =="1") output.invt_prpn_tp = "공격투자형";
			else if(output.invt_prpn_tp =="2") output.invt_prpn_tp = "적극투자형";
			else if(output.invt_prpn_tp =="3") output.invt_prpn_tp = "위험중립형";
			else if(output.invt_prpn_tp =="4") output.invt_prpn_tp = "안정추구형";
			else if(output.invt_prpn_tp =="5") output.invt_prpn_tp = "안정형";
			ao_html('SingleInfo','SingleInfo_tmpl', output);
			var param = mydataCommon.page.getSubParamData('VAnn0010001View');
			if(param.result_retAge && param.nd_ps_sav_amt){
				$('#display_area').css('display','block');
				$('#result_retAge').text(param.result_retAge);
				$("#nd_ps_sav_amt").text(param.nd_ps_sav_amt);
			}
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			ao_html('ListInfo','ListInfo_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_item').css('display','block');
			}else{
				$('#more_item').css('display','none');
			}
		},
		set_result_more : data => {
			var output = data.XMP4010_Q01;
			
			pageUnit.prop.cont_gubn = output.cont_gubn;
			pageUnit.prop.next_data = output.next_data;
			ao_append('ListInfo','ListInfo_tmpl', output);
			if(output.cont_gubn == 'Y'){
				$('#more_item').css('display','block');
			}else{
				$('#more_item').css('display','none');
			}
		},
		conf_TujaTend : () => {
			mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/bank/VBank0010003P003Pop");
		},
		popDetail : stk_code => {
			//sub key로 임시 변환
			var v_storageKeyName = pageUnit.prop.v_storageKeyName;
			pageUnit.prop.v_storageKeyName = pageUnit.prop.v_storageSubKeyName;
			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			param.stk_code = stk_code;
			mydataCommon.page.setSubParamData(param,'VReco0010001View');
			//저장 후 다시 복구
			pageUnit.prop.v_storageKeyName = v_storageKeyName;
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0201", callback:"callback_callMoveView",viewType:"full"});
		}
	},
	
};

$(document).ready(() => {
	pageUnit.init();
});