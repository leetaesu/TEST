var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VAnn0010001P009View",
		// 로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'annu',
		v_storageSubKeyName : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : {
			XMP4005_Q01 : () => {
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0090001Ajax",
							data : {},
							async : true,
							success : resolve,
							error : reject,
					}
					mydataCommon.ajax(jsonObj);
				});
			},
			XMP4005_Q02 : () => {
				return new Promise( (resolve, reject) => {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/annu/SAnn0010001P0090002Ajax",
							data : {},
							async : true,
							success : resolve,
							error : reject,
					}
					mydataCommon.ajax(jsonObj);
				});
			}
		}
	},
	// 단위 진입부 함수
	init : () => {
		pageUnit.eventBind();
	},
	eventBind : () => {
		//급여 소득 계산하기
		$('#calSalaryIncome').on('click',function(){
			if(!mydataCommon.vald.validation({target : $("#tab_panel01"),is_only_msg : true, immedtAlertPop : true})){
				pageUnit.trn.ajax_call.XMP4005_Q01()
				.then( data =>{
					pageUnit.fn.set_section_search1(data);
				})
				.catch((e)=>{
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+e+"]"});	
				});
			}
		});
		//종합 소득금액 계산하기
		$('#calGlobalIncome').on('click',function(){
			if(!mydataCommon.vald.validation({target : $("#tab_panel02"),is_only_msg : true, immedtAlertPop : true})){
				pageUnit.trn.ajax_call.XMP4005_Q02()
				.then( data =>{
					pageUnit.fn.set_section_search2(data);
				})
				.catch((e)=>{
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다.["+e+"]"});	
				});
			};
		});
		$('.sub-close').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		$('#confirm').on('click',() => {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		$('#popConfirm').on('click',() => {
			KW_MOBILE.guiEvent.popup.closePop('#bottomsheet')
		});
		$('#resetSalaryIncome').on('click',function(){
			mydataCommon.formReset2($("#tab_panel01"));
		});
		$('#resetGlobalIncome').on('click',function(){
			mydataCommon.formReset2($("#tab_panel02"));
		});
	},
	fn : {		
		callback_getKeypadResult : (jsonString) => {
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;
			if(rId == "ovrl_incm_amt" || rId == "ps_sav_paid_amt" ||rId == "ret_ps_irp_paid_amt" || rId == "tot_yr_salary_amt" ){  
				nVal = mydataCommon.util.addComma( nVal );
			}
			$("#"+rId).val(nVal);
			pageUnit.fn.checkNull(); 
		},
		set_section_search1 : data => {
			var output = data.XMP4005_Q01;
			output.ps_sav_ded_amt = mydataCommon.util.getPrice(output.ps_sav_ded_amt);
			output.ret_ps_irp_ded_amt = mydataCommon.util.getPrice(output.ret_ps_irp_ded_amt);
			output.tot_deduct_amt = mydataCommon.util.getPrice(output.tot_deduct_amt);
			output.tot_saving_tax_amt = mydataCommon.util.getPrice(output.tot_saving_tax_amt);
			output.tax_ded_lmt_amt = mydataCommon.util.getPrice(output.tax_ded_lmt_amt);
			output.tot_deduct_lmt_amt = mydataCommon.util.getPrice(output.tot_deduct_lmt_amt);

			ao_html('section','set_section_tmpl', output);
		},
		set_section_search2 : data => {
			var output = data.XMP4005_Q02;
			output.ps_sav_ded_amt = mydataCommon.util.getPrice(output.ps_sav_ded_amt);
			output.ret_ps_irp_ded_amt = mydataCommon.util.getPrice(output.ret_ps_irp_ded_amt);
			output.tot_deduct_amt = mydataCommon.util.getPrice(output.tot_deduct_amt);
			output.tot_saving_tax_amt = mydataCommon.util.getPrice(output.tot_saving_tax_amt);
			output.tax_ded_lmt_amt = mydataCommon.util.getPrice(output.tax_ded_lmt_amt);
			output.tot_deduct_lmt_amt = mydataCommon.util.getPrice(output.tot_deduct_lmt_amt);

			ao_html('section','set_section_tmpl', output);
		} 
	},
};

$(document).ready(() => {
	pageUnit.init();
});



