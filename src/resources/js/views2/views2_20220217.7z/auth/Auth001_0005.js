var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		process : 0 ,
		div : 0,
		cnt : [0,0,0,0,0,0,0],		
		subCnt : [0,0,0,0,0,0,0],
		rCnt : [0,0,0,0,0,0,0],
		map 	  : null,
		selCd : '',
		selCd2 : '',
		selNm : '',
		selNm2 : '',
		aStep : '',
		paCnt : 0,
		step4 : null,
		sData : null,
		info_cntn_list : '',
		inds_tp_list : '',
		id : '',
		info_cntn_list2 : '',
		inds_tp_list2 : '',
		info_cntn_key : '',
		datas : [],
		tps : [],
		pubNum : '',
		initCnt : 0
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(activeArea){
			var tp = activeArea.substring(5,7);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth00100010001Ajax",
					data : {"inds_tp":tp,"sply_tp":"02"},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							
							$.each(resultMap.g1,function(idx,item){
								item.tp = item.inds_tp;
							});
							console.log(resultMap.g1.length);
							if(tp =='00'){
								$("#areaComp").find('span').text(resultMap.g1.length);
							}							
							var obj = $("#"+activeArea).children();
							$("#"+activeArea).append('<script id="'+activeArea+'Template" type="text/x-jquery-tmpl">');			
							$("#"+activeArea+"Template").append(obj);							
							$("#"+activeArea+"Template").tmpl(resultMap.g1).appendTo("#"+activeArea);
							$("#"+activeArea).css("display","");
							
							
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getMainOrgList : function(activeArea){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth00100010002Ajax",
					data : '',
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							$.each(resultMap.g1,function(idx,item){
								$("#step1 [id='"+item.myd_orgn_code+"']").prop("checked",true);
							});
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getAgree : function(data){
			console.log('getAgree')
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth00100030001Ajax",
					data : {multi_org_code:data},
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){				
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.prop.info_cntn_list='';
							pageUnit.prop.inds_tp_list='';
							var obj = $("#info_list").children();
							$("#info_list").append('<script id="infoListTemplate" type="text/x-jquery-tmpl">');			
							$("#infoListTemplate").append(obj);							
							$("#infoListTemplate").tmpl(resultMap.g1).appendTo("#info_list");														

							$.each(resultMap.g1,function(idx,item){
								 pageUnit.prop.info_cntn_list+=(idx==0?"":"|")+mydataCommon.util.replace(item.info_cntn);				 
								 pageUnit.prop.inds_tp_list+=(idx==0?"":"|")+mydataCommon.util.replace(item.inds_tp);
							});
							pageUnit.prop.selNm = resultMap.tot_org_nm;
							$("#company_info").text(mydataCommon.util.replace(resultMap.tot_org_nm));
							$("#company_info2").text(mydataCommon.util.replace(resultMap.tot_org_nm));
							//$('article').removeClass("is-open");
							//$("#step2").addClass("is-open");
							
							$("#step1").css('display','none').next().css('display','');
							
							console.log('pageUnit.prop.info_cntn_lis='+pageUnit.prop.info_cntn_list);
							console.log('pageUnit.prop.inds_tp_list='+pageUnit.prop.inds_tp_list);
																				
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getAgree_0 : function(){			
			console.log('getAgree_0')
			var data = mydataCommon.util.getData("multi_org_code");
			mydataCommon.util.removeData("multi_org_code");
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth00100030000Ajax",
					data : {multi_org_code:pageUnit.prop.selCd},
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){				
						var resultMap = res.resultMap;	
						var obj = $("#info_list_0").children();
						$("#info_list_0").append('<script id="infoList0Template" type="text/x-jquery-tmpl">');			
						$("#infoList0Template").append(obj);
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#infoList0Template").tmpl(resultMap.g1).appendTo("#info_list_0");
							$("#step2").css('display','none').next().css('display','');							
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree_0 : function(data){		
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030000Ajax",
					data : {multi_org_code:data},
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree : function(){
			$("#inds_tp_list").val(pageUnit.prop.inds_tp_list);
			$("#info_cntn_list").val(pageUnit.prop.info_cntn_list);
			$("#multi_org_code").val(pageUnit.prop.selCd);
			$("#multi_orgn_nm").val(pageUnit.prop.selNm);
			var data = mydataCommon.makeSerialParam({target : $("body")});
			console.log('pageUnit.prop.inds_tp_list=>'+pageUnit.prop.inds_tp_list);
			console.log('pageUnit.prop.info_cntn_list=>'+pageUnit.prop.info_cntn_list);
			console.log('pageUnit.prop.selCd='+pageUnit.prop.selCd);
			console.log('pageUnit.prop.selNm='+pageUnit.prop.selNm);
			console.log('setAgree');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030001Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							 pageUnit.prop.aStep = "1";
							 //$('article').removeClass("is-open");
							 //$('#step2_1').addClass("is-open"); //표준제공동의서
							 $('#step2').css('display','none');
							 $('#step2_1').css('display','');
							 //$("#loading").addClass("is-open");
							
							//통합인증 모듈 호출
							try{
							//pageUnit.prop.sData = resultMap;
							
							
							/*
							var strSigning = {strSigning : resultMap};
							var obj = {command : "getCertMydataSign" , param:strSigning ,callback: "pageUnit.fn.callback_getCertMydataSign"};
							console.log("결과결과결과결과결과결과결과결과결과결과결과결과결과결과결과결과결과");
							console.log(JSON.stringify(obj));														
							*/
							/*
							var totCnt = resultMap.length;
							pageUnit.prop.process = 100%totCnt;
							pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
							console.log(JSON.stringify(resultMap));
							console.log('pageUnit.prop.process start='+pageUnit.prop.process);
							console.log('pageUnit.prop.div start='+pageUnit.prop.div);
							//console.log("11111="+JSON.stringify(obj));
							//console.log("22222="+encodeURIComponent(JSON.stringify(obj)));
							*/
							
							/*
							var authData = JSON.stringify(obj);
							console.log(authData);
							if(pageCom.prop.isIPHONE)
							{
							   authData = encodeURIComponent(authData);
							   window.location = "mydata://"+authData;
							}
							else if(pageCom.prop.isANDROID)
							{
							   document.location.href = "mydata://"+authData;
							}
							*/
							
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//보험
							
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//은행
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//금투  ,
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//보험
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//할부금융
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D1AAFO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//카드
							//인증 결과라 치고!!!
							//pageUnit.trn.sendTo(data);
							
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//은행,증권 부산은행 유화증권
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//보험
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//은행
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//은행
							
							/*
							$(data.signedDataList).each(function(idx,item){								
								data.signedDataList[idx].caOrg = data.caOrg;
								console.log(JSON.stringify(data.signedDataList[idx]));
								setTimeout(function(){pageUnit.trn.sendTo(data.signedDataList[idx]);},idx*1000);
							});
							*/
							
							
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree1 : function(cd,nm){			
			$("#multi_org_code").val(cd);
			$("#multi_orgn_nm").val(nm);
			var data = mydataCommon.makeSerialParam({target : $("body")});
			console.log('setAgree1')
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010017Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							 
							$('article').removeClass("is-open");
							 $('#step2_1').css("display","none");
							 $('#step4_2').css("display","none");
							 //$('#step2_2').addClass("is-open");
							 $('#step2_2').css("display","");
							//alert('인증서리스트 호출 시작');
							var obj = {command : "getSendCertData" ,callback: "pageUnit.fn.callback_getSendCertData"};
							var data = JSON.stringify(obj);
							if(pageCom.prop.isIPHONE)
							{
								data = encodeURIComponent(data);
								//window.location = "iTransKeyS:"+obj;//handleOpenURL
								window.location = "mydata://"+data
							}
							else if(pageCom.prop.isANDROID)
							{	
								//window.MTranskey.setKey(data);
								document.location.href = "mydata://"+data
							}
							
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree2 : function(){
			var data = mydataCommon.makeSerialParam({target : $("#step2_3")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030003Ajax",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							 if(pageUnit.prop.aStep == "1"){
								 pageUnit.trn.setAgree_1();
							 }else{
								 pageUnit.trn.setAgree_2();
							 }							  
							//pageUnit.fn.callCertMydataSign(pageUnit.prop.sData);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree_1 : function(){			
			var data = mydataCommon.makeSerialParam({target : $("body")});
			console.log('pageUnit.prop.inds_tp_list=>'+pageUnit.prop.inds_tp_list);
			console.log('pageUnit.prop.info_cntn_list=>'+pageUnit.prop.info_cntn_list);
			console.log('pageUnit.prop.selCd='+pageUnit.prop.selCd);
			console.log('pageUnit.prop.selNm='+pageUnit.prop.selNm);
			console.log('setAgree');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030005Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap2 && resultMap2 == "scss"){							
							//통합인증 모듈 호출
							try{
								pageUnit.prop.sData = resultMap;
								pageUnit.fn.callCertMydataSign(resultMap);
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree_3 : function(){//사설인증
			var data = mydataCommon.makeSerialParam({target : $("body")});
			console.log('pageUnit.prop.inds_tp_list=>'+pageUnit.prop.inds_tp_list);
			console.log('pageUnit.prop.info_cntn_list=>'+pageUnit.prop.info_cntn_list);
			console.log('pageUnit.prop.selCd='+pageUnit.prop.selCd);
			console.log('pageUnit.prop.selNm='+pageUnit.prop.selNm);
			console.log('setAgree');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth00100019998View",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){							
							//통합인증 모듈 호출
							alert('resultMap.sign_aos_app_scheme_url='+resultMap.sign_aos_app_scheme_url);
							try{
								if(pageCom.prop.isIPHONE)
								{
								   window.location = resultMap.sign_ios_app_scheme_url;
								}
								else if(pageCom.prop.isANDROID)
								{
								   document.location.href = resultMap.sign_aos_app_scheme_url;
								}
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree_4 : function(){//사설인증 결과
			var data = null;
			if(pageUnit.prop.aStep == "1"){
				 data = mydataCommon.makeSerialParam({target : $("body")});
			}else{
				var dataAry = new Array();	
				var paramidx = 0;
								
				$.each(pageUnit.prop.datas,function(idx,item){
					dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
					console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
				});								
				dataAry[paramidx++] = "pri_tp="+$("#pri_tp").val();				
				data = dataAry.join("&");
			}
						
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth00100019997View",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							if(pageUnit.prop.aStep == "1"){
								var datas = [];
								$.each($("#step1 [id^='area_'] input:checked"),function(idx,item){
									 datas.push($(this).val());									
								});
								pageUnit.trn.sendTo2(datas);
							}else{
								pageUnit.trn.sendToRslt2(resultMap);
							}
							
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		sendTo : function(Obj){
			console.log('sendTo'); 
			//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"코스콤"}');
			//console.log(data);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100040001Ajax",
					contentType : "application/json",
					data : JSON.stringify(Obj),
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#loading").addClass("is-open");
							var tp = resultMap.prcs.substring(0,2);
							var myd_orgn_code = resultMap.prcs.substring(2,12);
							var myd_orgn_Nm = mydataCommon.util.replace(resultMap.prcs.substring(12));
							console.log('tp='+tp+','+myd_orgn_Nm);
							pageUnit.prop.initCnt = 0;							
							if(tp == '01'){								
								pageUnit.trn.contact01(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '02'){
								pageUnit.trn.contact02(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '03'){								
								pageUnit.trn.contact03(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '04'){
								pageUnit.trn.contact04(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '05'){
								pageUnit.trn.contact05(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '06'){
								pageUnit.trn.contact06(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '07'){
								pageUnit.trn.contact07(myd_orgn_code,myd_orgn_Nm);
							}
														
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		sendTo2 : function(datas){
			
			var aryData = datas;
			for(var i in aryData){
				var dataSplit = aryData[i].split("|");
				var myd_orgn_code = dataSplit[0];
				var tp = dataSplit[1];
				var myd_orgn_Nm = mydataCommon.util.replace(dataSplit[2]);
				var totCnt = aryData.length;
				pageUnit.prop.process = 100%totCnt;
				pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
				$("#step1").css("display","none");
				$("#step2_2").css("display","none");				
				$("#loading").addClass("is-open");
				pageUnit.prop.initCnt = 0;
				if(tp == '01'){								
					pageUnit.trn.contact01(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '02'){
					pageUnit.trn.contact02(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '03'){								
					pageUnit.trn.contact03(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '04'){
					pageUnit.trn.contact04(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '05'){
					pageUnit.trn.contact05(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '06'){
					pageUnit.trn.contact06(myd_orgn_code,myd_orgn_Nm);
				}else if(tp == '07'){
					pageUnit.trn.contact07(myd_orgn_code,myd_orgn_Nm);
				}	
			}
		},
		contact01 : function(org_code,gdsNm){
			console.log('은행-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060101Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						/*
						resultMap.bnk_001 = [
						                     {
						                         "gvl_uniq_id": "C35shkim00_authIA__0063071224082403279__",
						                         "resp_mesg": "조회가 완료되었습니다",
						                         "out_count": "0002",
						                         "cont_gubn": "N",
						                         "next_data": "",
						                         "resp_code": "100000",
						                         "g1": [
						                             {
						                                 "acnt_tp": "101",
						                                 "gds_nm": "종합계좌",
						                                 "acnt_no": "1029373",
						                                 "frst_join_dt": "20210111",
						                                 "send_rqst_yn": "Y",
						                                 "tmst": "0",
						                                 "acnt_stat_tp": "201"
						                             },
						                             {
						                                 "acnt_tp": "101",
						                                 "gds_nm": "개인계좌",
						                                 "acnt_no": "112233445566",
						                                 "frst_join_dt": "20210111",
						                                 "send_rqst_yn": "Y",
						                                 "tmst": "0",
						                                 "acnt_stat_tp": "201"
						                             }
						                         ],
						                         "next_page_base_val": "",
						                         "resp_gubn": "0"
						                     }
						                 ];
						
						resultMap.irp_001 = {
						        "gvl_uniq_id": "C35shkim00_authIA__3662998724082403812__",
						        "resp_mesg": "[1]건 조회가 완료되었습니다",
						        "cont_gubn": "N",
						        "next_data": "",
						        "resp_code": "100000",
						        "g1": [
						            {
						                "irp_gds_nm": "개인형퇴직연금&#40;IRP)",
						                "acnt_no": "265879213468",
						                "send_rqst_yn": "Y",
						                "tmst": "0"
						            },
						            {
						                "irp_gds_nm": "괴인형퇴직연금",
						                "acnt_no": "00009989",
						                "send_rqst_yn": "Y",
						                "tmst": "0"
						            }
						        ],
						        "qry_cnt": "0002",
						        "resp_gubn": "0"
						    };
						*/
						var bnk_001 = resultMap.bnk_001;
						var irp_001 = resultMap.irp_001;
						pageUnit.prop.subCnt[0] = 0;
						if( (bnk_001 && bnk_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("bnk");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_bnk_").remove();
							var tmp_bnk = pageUnit.prop.tps["bnk"].clone(true);							
							var obj = $("#bnk"); obj.show();							
							var bod_main_clone = tmp_bnk;
														
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
														
							
							pageUnit.prop.cnt[0]++;
							
							if(pageUnit.prop.cnt[0] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[0];
							bod_main_clone.attr("id",atr_id);							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							
							//var card_body_list = bod_main_clone.find("div.card-body").children(":eq(0)");
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							//bod_main_clone.find("#b_list_sub").remove();
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(bnk_001 , function(idx,item){
								$.each(bnk_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('bnk001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.acnt_no+"|"+item1.acnt_tp+"|"+item1.acnt_sqno+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.fc_acnt_yn+"|"+item1.mns_engg_yn+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('p:eq(1)').text(item1.acnt_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[0]);
								});
							});
							
							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));								
								addDivObj.find('p:eq(1)').text(item1.acnt_no);
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(++pageUnit.prop.subCnt[0]);
							});							

							
							$("#bnk").find('div.fold-body').append(bod_main_clone);
							
						}else{							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(bnk_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact02 : function(org_code,gdsNm){
			console.log('카드-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060201Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
					var resultMap = res.resultMap;
					
					var crd_001 = resultMap.crd_001;					
					
					console.log('start11');
					console.log(resultMap);
					console.log('end11');
					pageUnit.prop.subCnt[1] = 0;
					if( (crd_001 && crd_001[0].resp_gubn) == "0" ){
						
						var subMap = pageUnit.prop.map.get("crd");
						subMap.put(org_code,[gdsNm]);												
						
						$("#list_main_crd_").remove();
						var tmp_crd = pageUnit.prop.tps["crd"].clone(true);							
						var obj = $("#crd"); obj.show();							
						var bod_main_clone = tmp_crd;
						
						if(pageUnit.prop.initCnt == 0){
							obj.addClass("pt30");
							++pageUnit.prop.initCnt;
						}
						
						bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
						bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
						var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
						
						pageUnit.prop.cnt[1]++;
						
						if(pageUnit.prop.cnt[1] > 1){
							bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
						}
						
						var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[1];
						bod_main_clone.attr("id",atr_id);
						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
						var card_body_list = bod_main_clone.children('dl:eq(1)');
						//bod_main_clone.find("#c_list_sub").remove();
						bod_main_clone.children('dl:eq(1)').remove();
						$.each(crd_001 , function(idx,item){
							$.each(crd_001[idx].g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.card_no).val('crd001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.card_nm)+"|"+item1.card_no+"|"+item1.card_id+"|"+item1.send_rqst_yn+"|"+item1.card_memb_tp+"|"+item1.card_kind_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.card_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.card_nm));								
								addDivObj.find('p:eq(1)').text(item1.card_no);
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(++pageUnit.prop.subCnt[1]);
							});
						});
						
						if(pageUnit.prop.subCnt[1] > 0){
							var addDivObj = card_body_list.clone();									
							addDivObj.find('input:checkbox').attr("id","point").prop("checked",true).prop("disabled",true).val('crd001');
							addDivObj.find('label').find('p:eq(0)').text("선택한 카드사의 포인트 정보 , 청구 정보, 대출 정보가 있을 경우 함께 전송됩니다");								
							//addDivObj.find('span:eq(1)').text(item1.card_no);
							bod_main_clone.append(addDivObj.show());
						}
						
						console.log(bod_main_clone);						
						$("#crd").find('div.fold-body').append(bod_main_clone);
					}else{						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						$("#loading").find('p.err-msg').text(crd_001[0].resp_mesg);
					}
					
					pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact03 : function(org_code,gdsNm){
			console.log('금투-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060301Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						
						
						
						
						
						
						var sec_001 = resultMap.sec_001;
						var irp_001 = resultMap.irp_001;
						/*
						if(sec_001[0].resp_gubn != '0'){
							resultMap.sec_001 = [
							                     {
							                         "gvl_uniq_id": "C35shkim00_authIA__0063071224082403279__",
							                         "resp_mesg": "조회가 완료되었습니다",
							                         "out_count": "0001",
							                         "cont_gubn": "N",
							                         "next_data": "",
							                         "resp_code": "100000",
							                         "g1": [
							                             {
							                                 "acnt_tp": "102",
							                                 "acnt_nm": "종합계좌",
							                                 "acnt_no": "1234567890",
							                                 "frst_join_dt": "20210111",
							                                 "send_rqst_yn": "Y",
							                                 "tmst": "0",
							                                 "acnt_stat_tp": "201"
							                             }
							                         ],
							                         "next_page_base_val": "",
							                         "resp_gubn": "0"
							                     }
							                 ];
							sec_001 = resultMap.sec_001;
						}
						
						
						
						if(irp_001.resp_gubn != '0'){
							resultMap.irp_001 = {
							        "gvl_uniq_id": "C35shkim00_authIA__3662998724082403812__",
							        "resp_mesg": "[1]건 조회가 완료되었습니다",
							        "cont_gubn": "N",
							        "next_data": "",
							        "resp_code": "100000",
							        "g1": [
							            {
							                "irp_gds_nm": "울랄라퇴직연금&#40;IRP)",
							                "acnt_no": "9999999999",
							                "send_rqst_yn": "Y",
							                "tmst": "0"
							            }
							        ],
							        "qry_cnt": "0001",
							        "resp_gubn": "0"
							    };
							irp_001 = resultMap.irp_001;
						}
						*/
						pageUnit.prop.subCnt[2] = 0;
						if( (sec_001 && sec_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("sec");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_sec_").remove();
							var tmp_sec = pageUnit.prop.tps["sec"].clone(true);							
							var obj = $("#sec"); obj.show();							
							var bod_main_clone = tmp_sec;
							
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
							
							pageUnit.prop.cnt[2]++;
							
							if(pageUnit.prop.cnt[2] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[2];
							bod_main_clone.attr("id",atr_id);
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							//bod_main_clone.find("#s_list_sub").remove();
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(sec_001 , function(idx,item){
								$.each(sec_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('sec001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.acnt_nm)+"|"+item1.acnt_no+"|"+item1.open_dt+"|"+item1.send_rqst_yn+"|"+item1.acnt_tp+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_nm));								
									addDivObj.find('p:eq(1)').text(item1.acnt_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());

									acntCnt.text(++pageUnit.prop.subCnt[2]);
								});
							});

							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));								
								addDivObj.find('p:eq(1)').text(item1.acnt_no);
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(++pageUnit.prop.subCnt[2]);
							});
							console.log(bod_main_clone);
							
							$("#sec").find('div.fold-body').append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sec_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact04 : function(org_code,gdsNm){
			console.log('보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060401Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;

						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var ins_001 = resultMap.ins_001;
						var ins_008 = resultMap.ins_008;						
						var irp_001 = resultMap.irp_001;
						
						pageUnit.prop.subCnt[3] = 0;
						if( (ins_001 && ins_001[0].resp_gubn == "0") || (ins_008 && ins_008[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("ins");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_ins_").remove();
							var tmp_ins = pageUnit.prop.tps["ins"].clone(true);							
							var obj = $("#ins"); obj.show();							
							var bod_main_clone = tmp_ins;
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
							pageUnit.prop.cnt[3]++;
							
							if(pageUnit.prop.cnt[3] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[3];
							bod_main_clone.attr("id",atr_id);
							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(ins_001 , function(idx,item){
								$.each(ins_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('ins001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.send_rqst_yn+"|"+item1.insr_kind_tp+"|"+mydataCommon.util.replace(item1.insr_kind_tp_nm)+"|"+item1.cntr_stat_tp+"|"+mydataCommon.util.replace(item1.cntr_stat_tp_nm)+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('p:eq(1)').text(item1.insr_cntr_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[3]);
								});
							});
							
							$.each(ins_008 , function(idx,item){
								$.each(ins_008[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('ins008'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.acnt_type_tp+"|"+item1.acnt_stat_tp+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('p:eq(1)').text(item1.insr_cntr_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[3]);
								});
							});						
							
							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));								
								addDivObj.find('p:eq(1)').text(item1.acnt_no);
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(++pageUnit.prop.subCnt[3]);
							});
														
							console.log(bod_main_clone);							
							$("#ins").find('div.fold-body').append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ins_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact05 : function(org_code,gdsNm){
			console.log('전금-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060501Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
																		
						var ele_001 = resultMap.ele_001;
						var ele_101 = resultMap.ele_101;
						pageUnit.prop.subCnt[4] = 0;
						if( (ele_001 && ele_001[0].resp_gubn == "0") || (ele_101 && ele_101[0].resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("ele");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_ele_").remove();
							var tmp_bnk = pageUnit.prop.tps["ele"].clone(true);							
							var obj = $("#ele"); obj.show();							
							var bod_main_clone = tmp_bnk;
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}							
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
							
							pageUnit.prop.cnt[4]++;
							
							if(pageUnit.prop.cnt[4] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[4];
							bod_main_clone.attr("id",atr_id);
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
														
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(ele_001 , function(idx,item){
								$.each(ele_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.fob_id).val('ele001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.fob_nm)+"|"+item1.fob_id+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.auto_chrg_rgst_yn+"|"+item1.crnc_code+"|"+item1.fob_limit+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.fob_id).find('p:eq(0)').text(mydataCommon.util.replace(item1.fob_nm));								
									addDivObj.find('p:eq(1)').text(item1.fob_id);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[4]);
								});
							});
							
							$.each(ele_101 , function(idx,item){
								$.each(ele_101[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.efnc_acct_id).val('ele101'+"|"+org_code+"|"+item1.efnc_orgn_acct_id+"|"+item1.efnc_acct_id+"|"+item1.send_rqst_yn+"|"+item1.join_dt+"|"+item1.frst_join_dt+"|"+item1.setl_means_rgst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.efnc_acct_id).find('p:eq(0)').text(mydataCommon.util.replace(item1.efnc_acct_id));								
									addDivObj.find('p:eq(1)').text(item1.efnc_orgn_acct_id);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[4]);
								});
							});						

							
							$("#ele").find('div.fold-body').append(bod_main_clone);
							
						}else{							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ele_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact06 : function(org_code,gdsNm){
			console.log('할부금융-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060601Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						var rnt_001 = resultMap.rnt_001;
						
						console.log(resultMap);
						console.log('end11');
						pageUnit.prop.subCnt[5] = 0;
						if( (rnt_001 && rnt_001[0].resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("rnt");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_rnt_").remove();
							var tmp_rnt = pageUnit.prop.tps["rnt"].clone(true);							
							var obj = $("#rnt"); obj.show();							
							var bod_main_clone = tmp_rnt;
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}							
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
							pageUnit.prop.cnt[5]++;

							if(pageUnit.prop.cnt[5] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[5];
							bod_main_clone.attr("id",atr_id);
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(rnt_001 , function(idx,item){
								$.each(rnt_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('rnt001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.acnt_no+"|"+item1.sqno+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.acnt_tp+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('p:eq(1)').text(item1.acnt_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[5]);
								});
							});														
														
							console.log(bod_main_clone);							
							$("#rnt").find('div.fold-body').append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(rnt_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact07 : function(org_code,gdsNm){
			console.log('보증보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060701Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						var sin_001 = resultMap.sin_001;
						
						console.log(resultMap);
						console.log('end11');
						pageUnit.prop.subCnt[6] = 0;
						if( (sin_001 && sin_001[0].resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("sin");
							subMap.put(org_code,[gdsNm]);
							
							$("#list_main_sin_").remove();
							var tmp_rnt = pageUnit.prop.tps["sin"].clone(true);							
							var obj = $("#sin"); obj.show();							
							var bod_main_clone = tmp_rnt;
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}							
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('div').find('p').text(gdsNm);
							bod_main_clone.find('dl.c-head').find('div.gds_nm').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							var acntCnt = bod_main_clone.find('dl.c-head').find('p.fs-default').children('span:eq(1)');
							pageUnit.prop.cnt[6]++;

							if(pageUnit.prop.cnt[6] > 1){
								bod_main_clone.find('dl:eq(0)').addClass("border-top").addClass("mt20").addClass("pt15");
							}
							
							var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[6];
							bod_main_clone.attr("id",atr_id);
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main_clone.children('dl:eq(1)');
							bod_main_clone.children('dl:eq(1)').remove();
							$.each(sin_001 , function(idx,item){
								$.each(sin_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('sin001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.send_rqst_yn+"|"+item1.insr_kind_tp+"|"+item1.grin_cntr_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('p:eq(1)').text(item1.insr_cntr_no);
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main_clone.append(addDivObj.show());
									acntCnt.text(++pageUnit.prop.subCnt[6]);
								});
							});														
														
							console.log(bod_main_clone);							
							$("#sin").find('div.fold-body').append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sin_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		goStep4 : function(){
			var data = mydataCommon.makeSerialParam({target : $("#step3")});
			console.log('goStep4');
			console.log(data);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0010007Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						pageUnit.fn.setAgreeData();
						var resultMap = res.resultMap;	
						var resultMap2 = res.resultMap2;
						pageUnit.prop.selCd2 = res.multi_org_cd;
						
						
						if(resultMap && resultMap.resp_gubn =="0"){
							pageUnit.prop.info_cntn_list2='';
							pageUnit.prop.inds_tp_list2='';
							var obj = $("#info_list2").children();
							$("#info_list2").append('<script id="infoList2Template" type="text/x-jquery-tmpl">');			
							$("#infoList2Template").append(obj);							
							$("#infoList2Template").tmpl(resultMap.g1).appendTo("#info_list2");														

							$.each(resultMap.g1,function(idx,item){
								 pageUnit.prop.info_cntn_list2+=(idx==0?"":"|")+mydataCommon.util.replace(item.info_cntn);				 
								 pageUnit.prop.inds_tp_list2+=(idx==0?"":"|")+mydataCommon.util.replace(item.inds_tp);
							});
							var tot_org_nm = mydataCommon.util.replace(resultMap.tot_org_nm);
							pageUnit.prop.selNm2 = tot_org_nm;
							$("#company_info3").text(tot_org_nm);
							$("#company_info4_2").text(tot_org_nm);
							/*
							$('article').removeClass("is-open");
							$("#step4_0").addClass("is-open");
							*/
							$("#step3").css("display","none");
							$("#step4_0").css("display","");
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
						if(resultMap2 && resultMap2.resp_gubn=="0"){						
							//pageUnit.fn.setAgreeView();
							pageUnit.prop.info_cntn_key='';
							$.each(resultMap2.g1,function(idx,item){
								 pageUnit.prop.info_cntn_key+=(idx==0?"":"|")+mydataCommon.util.replace(item.info_cntn_key);
							});
							
							var gds_prchs_infr_acyn = resultMap2.gds_prchs_infr_acyn;
							if(gds_prchs_infr_acyn == "Y"){ 
								$("#gds_prchs_infr_acyn_id").show();
								$("input:radio[name='gds_prchs_infr_acyn']").prop("disabled",false);
							}
							$("#gds_cntn").text(resultMap2.gds_cntn);
							var fran_nm_infr_acyn = resultMap2.fran_nm_infr_acyn;
							if(fran_nm_infr_acyn == "Y"){ 
								$("#fran_nm_infr_acyn_id").show();
								$("input:radio[name='fran_nm_infr_acyn']").prop("disabled",false);
							}
							$("#fran_cntn").text(resultMap2.fran_cntn);
							var rmrk_acyn = resultMap2.rmrk_acyn;
							if(rmrk_acyn == "Y") {
								$("#rmrk_acyn_id").show();
								$("input:radio[name='rmrk_acyn']").prop("disabled",false);
							}
							$("#rmrk_cntn").text(resultMap2.rmrk_cntn);
							
							var obj = $("#info_list3").children();
							$("#info_list3").append('<script id="infoList3Template" type="text/x-jquery-tmpl">');			
							$("#infoList3Template").append(obj);							
							$("#infoList3Template").tmpl(resultMap2.g1).appendTo("#info_list3");
						}else{
							mydataCommon.msg.alert({msg : resultMap2.resp_mesg});
						}
						
						
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goStep5 : function(){
			//var gds_body_list = $("#step4").find('p');
			//alert(gds_body_list.data("info"));
			var dataAry = new Array();	
			var paramidx = 0;
			/*
			$.each($("#step4").find('[data-info]'),function(idx,obj){			
				if($(this).data("info") != null && $(this).data("info") != ""){
					dataAry[paramidx++] = "org_code="+encodeURIComponent($(this).data("info"));
				}
			});
			*/						
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});	
			dataAry[paramidx++] = "multi_orgn_code="+encodeURIComponent(pageUnit.prop.selCd2);
			dataAry[paramidx++] = "multi_orgn_nm="+encodeURIComponent(pageUnit.prop.selNm2);
			dataAry[paramidx++] = "info_cntn_list2="+encodeURIComponent(pageUnit.prop.info_cntn_list2);
			dataAry[paramidx++] = "inds_tp_list2="+encodeURIComponent(pageUnit.prop.inds_tp_list2);
			dataAry[paramidx++] = "info_cntn_key="+encodeURIComponent(pageUnit.prop.info_cntn_key);
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "cnt="+cnt;
			
			var data = dataAry.join("&");
			console.log('goStep5');
			console.log(data);

			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030002Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap2 && resultMap2 == "scss"){
							pageUnit.prop.aStep = "2";
							//$("#loading").addClass("is-open");														
							pageUnit.prop.sData = resultMap;
							$('article').removeClass("is-open");
							$('#step4_0').css("display","none"); //표준제공동의서 step4_2
							$('#step4_2').css("display",""); //표준제공동의서 step4_2
							//통합인증 모듈 호출
							try{
//							
//							var strSigning = {strSigning : resultMap};
//							var obj = {command : "getCertMydataSign" , param:strSigning ,callback: "pageUnit.fn.callback_getCertMydataSign"};
//							console.log(JSON.stringify(obj));														
//							
//							var totCnt = resultMap.length;
//							pageUnit.prop.process = 100%totCnt;
//							pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
//							console.log(JSON.stringify(resultMap));
//							console.log('pageUnit.prop.process start='+pageUnit.prop.process);
//							console.log('pageUnit.prop.div start='+pageUnit.prop.div);
//							
//							
//							var authData = JSON.stringify(obj);
//							console.log(authData);
//							if(pageCom.prop.isIPHONE)
//							{
//							   authData = encodeURIComponent(authData);
//							   window.location = "mydata://"+authData;
//							}
//							else if(pageCom.prop.isANDROID)
//							{							   
//							   document.location.href = "mydata://"+authData;
//							}
							
							
							
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//은행
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//금투  ,{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//보험
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//할부금융
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D1AAFO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//카드
							//인증 결과라 치고!!!
							//pageUnit.trn.sendTo(data);
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//은행,증권 부산은행 유화증권
							
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"B1AAAR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//은행
							//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAII0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"koscom"}');//은행
							
							/*
							$(data.signedDataList).each(function(idx,item){								
								data.signedDataList[idx].caOrg = data.caOrg;
								console.log(JSON.stringify(data.signedDataList[idx]));
								setTimeout(function(){pageUnit.trn.sendToRslt(data.signedDataList[idx]);},idx*1000);
							});						
							*/
							
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		setAgree_2 : function(){			
			var dataAry = new Array();	
			var paramidx = 0;
							
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});				
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "cnt="+cnt;
			
			var data = dataAry.join("&");
			console.log('goStep5');
			console.log(data);

			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030006Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap2 && resultMap2 == "scss"){							
							//통합인증 모듈 호출
							try{
								pageUnit.prop.sData = resultMap;
								pageUnit.fn.callCertMydataSign(resultMap);							
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		setAgree_5 : function(){			
			var dataAry = new Array();	
			var paramidx = 0;
							
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});				
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "pri_tp="+$("#pri_tp").val();
			dataAry[paramidx++] = "cnt="+cnt;
			
			var data = dataAry.join("&");
			console.log(data);

			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth00100019996View",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							//통합인증 모듈 호출
							try{
								//통합인증 모듈 호출2
								alert('resultMap.sign_aos_app_scheme_url2='+resultMap.sign_aos_app_scheme_url);							
								if(pageCom.prop.isIPHONE)
								{
								   window.location = resultMap.sign_ios_app_scheme_url;
								}
								else if(pageCom.prop.isANDROID)
								{
								   document.location.href = resultMap.sign_aos_app_scheme_url;
								}								
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		sendToRslt : function(Obj){
			console.log('sendToRslt'); 
			//var data = JSON.parse('{ "signedDataList" : [{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},{"orgCode":"D3AADO0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"코스콤"}');
			//console.log(data);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100040001Ajax",
					contentType : "application/json",
					data : JSON.stringify(Obj),
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#loading").addClass("is-open");
							var tp = resultMap.prcs.substring(0,2);
							var myd_orgn_code = resultMap.prcs.substring(2,12);
							var myd_orgn_Nm = mydataCommon.util.replace(resultMap.prcs.substring(12));
							console.log('tp='+tp+','+myd_orgn_Nm);
							pageUnit.prop.initCnt = 0;
							if(tp == '01'){
								pageUnit.trn.contact01Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '02'){
								pageUnit.trn.contact02Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '03'){							
								pageUnit.trn.contact03Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '04'){
								pageUnit.trn.contact04Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '05'){
								pageUnit.trn.contact05Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '06'){
								pageUnit.trn.contact06Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '07'){
								pageUnit.trn.contact07Rslt(myd_orgn_code,myd_orgn_Nm);
							}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		sendToRslt2 : function(resultMap){
			if( (resultMap && resultMap.resp_gubn) == "0"  ){
				var totCnt = resultMap.g1.length;
				pageUnit.prop.process = 100%totCnt;
				pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;

				$.each(resultMap && resultMap.g1 , function(idx1,item1){
					var rslt = item1.prcs;
					var tp = rslt.substring(0,2);
					var myd_orgn_code = rslt.substring(2,12);
					var myd_orgn_Nm = mydataCommon.util.replace(rslt.substring(12));					
					$("#step2_2").css("display","none");				
					$("#loading").addClass("is-open");
					pageUnit.prop.initCnt = 0;
					if(tp == '01'){
						pageUnit.trn.contact01Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '02'){
						pageUnit.trn.contact02Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '03'){							
						pageUnit.trn.contact03Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '04'){
						pageUnit.trn.contact04Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '05'){
						pageUnit.trn.contact05Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '06'){
						pageUnit.trn.contact06Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '07'){
						pageUnit.trn.contact07Rslt(myd_orgn_code,myd_orgn_Nm);
					}
				});			
			}else{
				mydataCommon.msg.alert({msg : resultMap.resp_mesg});
			}
									
		},
		contact01Rslt : function(org_code,gdsNm){
			console.log('은행-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150001Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var bnk_007 = resultMap.bnk_007;
						var irp_007 = resultMap.irp_007;

						if( (bnk_007 && bnk_007.resp_gubn) == "0" || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#bnk_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');		
							$.each(bnk_007 && bnk_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[0]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[0]);
							});

							console.log(bod_main_clone);
							$("#bnk_lst_").remove();
							//$("#bnk_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(bnk_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact02Rslt : function(org_code,gdsNm){
			console.log('카드-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150002Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
					var resultMap = res.resultMap;
					
					var crd_007 = resultMap.crd_007;
					
					console.log('start11');
					console.log(resultMap);
					console.log('end11');

					if( (crd_007 && crd_007.resp_gubn) == "0" ){
						var obj = $("#crd_007"); obj.show();
						var head_main = obj.children('div');
						if(pageUnit.prop.initCnt == 0){
							obj.addClass("pt30");
							++pageUnit.prop.initCnt;
						}
						var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						var	bod_main_clone = obj.find('div.card-body');
						$.each(crd_007 && crd_007.g1 , function(idx1,item1){
							pageUnit.prop.rCnt[1]++;
							var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
							var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[1];
							addDivObj.attr("id",atr_id);
							addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.card_nm));
							addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.card_kind_nm));
							bod_main_clone.append(addDivObj.show());
							acntCnt.text(pageUnit.prop.rCnt[1]);
						});

						console.log(bod_main_clone);
						$("#crd_lst_").remove();
						//$("#crd_007").append(bod_main_clone);
					}else{						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						$("#loading").find('p.err-msg').text(crd_007.resp_mesg);
					}
					
					pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact03Rslt : function(org_code,gdsNm){
			console.log('금투-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150003Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
												
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var sec_007 = resultMap.sec_007;
						var irp_007 = resultMap.irp_007;

						if( (sec_007 && sec_007.resp_gubn) == "0" || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#sec_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							//head_main.find('dt').find('p').text(gdsNm);
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');					
							$.each(sec_007 && sec_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');								
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[2]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[2]);
							});

							console.log(bod_main_clone);
							$("#sec_lst_").remove();
							//$("#sec_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sec_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact04Rslt : function(org_code,gdsNm){
			console.log('보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150004Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;

						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var ins_007 = resultMap.ins_007;
						var ins_008 = resultMap.ins_008;						
						var irp_007 = resultMap.irp_007;
						
						if( (ins_007 && ins_007.resp_gubn) == "0" || (ins_008 && ins_008.resp_gubn) == "0" || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#ins_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(ins_007 && ins_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.insr_kind_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});
							
							$.each(ins_008 && ins_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.loan_gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});

							console.log(bod_main_clone);
							$("#ins_lst_").remove();
							//$("#ins_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ins_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact05Rslt : function(org_code,gdsNm){
			console.log('전금-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150006Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var ele_007 = resultMap.ele_007;
						var ele_008 = resultMap.ele_008;

						if( (ele_007 && ele_007.resp_gubn) == "0" || (ele_008 && ele_008.resp_gubn == "0") ){
							var obj = $("#ele_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');		
							$.each(ele_007 && ele_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[4];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.fob_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.fob_id));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[4]);
							});


							$.each(ele_008 && ele_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[4];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.efnc_acct_id));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.efnc_orgn_acct_id));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[4]);
							});

							console.log(bod_main_clone);
							$("#ele_lst_").remove();
							//$("#ele_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ele_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact06Rslt : function(org_code,gdsNm){
			console.log('할부금융-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150005Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						var rnt_007 = resultMap.rnt_007;
						
						console.log(resultMap);
						console.log('end11');
						if( (rnt_007 && rnt_007.resp_gubn) == "0" ){
							var obj = $("#rnt_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(rnt_007 && rnt_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[5]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[5];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.myd_gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[5]);
							});

							console.log(bod_main_clone);
							$("#rnt_lst_").remove();
							//$("#rnt_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(rnt_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact07Rslt : function(org_code,gdsNm){
			console.log('보증보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150007Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						var sin_007 = resultMap.sin_007;
						
						console.log(resultMap);
						console.log('end11');
						if( (sin_007 && sin_007.resp_gubn) == "0" ){
							var obj = $("#sin_007"); obj.show();
							var head_main = obj.children('div');
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(sin_007 && sin_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[6]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[6];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.insr_cntr_no));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[6]);
							});

							console.log(bod_main_clone);
							$("#sin_lst_").remove();
							//$("#sin_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sin_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		goto_newAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"475"});
		},
		goto_getAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"446"});
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind(); 
		pageUnit.prop.map = new Map();
		pageUnit.prop.map.put("bnk",new Map());
		pageUnit.prop.map.put("sec",new Map());
		pageUnit.prop.map.put("ins",new Map());
		pageUnit.prop.map.put("crd",new Map());
		pageUnit.prop.map.put("rnt",new Map());
		pageUnit.prop.map.put("ele",new Map());
		pageUnit.prop.map.put("sin",new Map());
		
		pageUnit.prop.step4 = $("#step4").clone(true);
		
		pageUnit.prop.tps["bnk"] = $("#list_main_bnk_").clone(true);
		pageUnit.prop.tps["sec"] = $("#list_main_sec_").clone(true);
		pageUnit.prop.tps["ins"] = $("#list_main_ins_").clone(true);
		pageUnit.prop.tps["crd"] = $("#list_main_crd_").clone(true);
		pageUnit.prop.tps["rnt"] = $("#list_main_rnt_").clone(true);
		pageUnit.prop.tps["ele"] = $("#list_main_ele_").clone(true);
		pageUnit.prop.tps["sin"] = $("#list_main_sin_").clone(true);
		
        $("#selectItem a").each(function(idx,item){        	
        	setTimeout(function(){
        		pageUnit.trn.getList($(item).attr("area-controls"));        		
        	},idx*300);        	        	

        });
       
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#selectItem a").off("click").on("click", function() {
			 $(this).addClass('navy').siblings().removeClass('navy');
       });
		
		$("#next").off("click").on("click", function(){
			pageUnit.fn.next();
		})
		/*
		$("#chk_8").off("click").on("click", function(){
			pageUnit.fn.checkAll(this);
		});
		*/
		$($('#step2_3 ul.check-list').find('input:checkbox')).off("click").on("click", function(){
			var thisObj = $(this);
			//thisObj.is(":checked")?thisObj.val("Y"):thisObj.val("N");
			$("#"+thisObj.attr("id") ).prop("checked",false);
			
			var id = thisObj.attr("id").substring(4,6);
			pageUnit.prop.id = id;					
			$('#tab_'+id).css("display","");			
			$("#step2_4").addClass("is-open");
			
			pageUnit.fn.clickChk();
		});

		$("#agre_chk").off("click").on("click", function(){
			$("#chk_"+pageUnit.prop.id ).prop("checked",true).val("Y");		
			$('#tab_'+pageUnit.prop.id).css('display','none');	
			$("#step2_4").removeClass('is-open');
			$("#step2_3").css("display","");								
			pageUnit.fn.clickChk();
		});
		/*
		$("#step2_4 [id^='tab_']").off("click").on("click", function(){
			var id  = $(this).attr("id");
			pageUnit.prop.id = id.substring(4,6);
			$('#tab_'+pageUnit.prop.id).addClass('is-selected').siblings().removeClass('is-selected');			
			$('#' + $('#tab_'+pageUnit.prop.id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');
		});
		
		$($('#step2_3 ul.check-list').find('a.icon-link')).off("click").on("click", function(){
			var id = $(this).attr("id");
			//var li  =$("#modal_agree_full-popup").find('div.modal-body').find('li');
			pageUnit.prop.id = id;
			$('#tab_'+id).addClass('is-selected').siblings().removeClass('is-selected');			
			$('#' + $('#tab_'+id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');			
			$("#step2_4").addClass("is-open");
		});
		*/
		/*
		$("#pubAuthList").find("a.sub-link").off("click").on("click",function(idx,item){
			alert(idx);
			$('#step2_3 ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',false);
			});
			
			 //$('article').removeClass("is-open");
			 $('#step2_2').css("display","none");	
			 $('#step2_3').css("display","");	
		});
		*/
		/*
		$("#pubAuthList").off("click").on("click",function(idx,item){
			
			$('#step2_3 ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',false);
			});
			
			 //$('article').removeClass("is-open");
			 $('#step2_2').css("display","none");	
			 $('#step2_3').css("display","");	
			 
			//pageUnit.fn.callCertMydataSign(pageUnit.prop.sData);
		});
		*/
		/*
		$("#Payco").off("click").on("click",function(){
			if(pageUnit.prop.aStep == "1"){
				$("#pri_tp").val($(this).attr("id"));
				pageUnit.trn.setAgree_3();		
			}else{
				//pageUnit.trn.setAgree_4();
			}
		});
		*/
		$("#priAuth a.sub-link").off("click").on("click",function(){
			$("#pri_tp").val($(this).attr("id"));
			if(pageUnit.prop.aStep == "1"){				
				pageUnit.trn.setAgree_3();		
			}else{
				pageUnit.trn.setAgree_5();
			}
		});
		$("#setRqst").off("click").on("click",function(){//임시
			pageUnit.trn.setAgree_4();
		});
				
		/*
		$("#Naver").off("click").on("click",function(){// 임시 테스트
			pageUnit.trn.setAgree_4();
		});
		*/
		$("input:radio[name='use_agree']").off("click").on("click",function(e){
			if($(this).val()=="Y"){
				pageUnit.trn.setAgree_0(pageUnit.prop.selCd);
				$("#agreerqst").prop("disabled",false);
			}else{
				 mydataCommon.msg.confirm({msg : "거부 권리 및 불이익 안내",msg2 : "개인(신용)정보 수집·이용에 관한 동의를 거부 하실 수 있습니다.다만  수집·이용에 관한 동의는 본인 신용정보 통합조회 서비스 이용을 위한 필수적인 사항이므로 동의 거부하실 경우 서비스 이용이 제한될 수 있습니다.", callBackFn : function(isConfirm){
				      if(isConfirm){
				    	  $("#agreerqst").prop("disabled",true);
				      }else{
				    	  $('input:radio[name="'+e.target.name+'"][value="Y"]').prop("checked",true);
				    	  pageUnit.trn.setAgree_0(pageUnit.prop.selCd);
				    	  $("#agreerqst").prop("disabled",false);
				      }
			     }});
			}
		});
		$("input:radio[name='use_agree2']").off("click").on("click",function(e){
			if($(this).val()=="Y"){
				//pageUnit.trn.setAgree_0(pageUnit.prop.selCd);
				$("#agreerqst2").prop("disabled",false);
			}else{
				 mydataCommon.msg.confirm({msg : "거부 권리 및 불이익 안내",msg2 : "개인(신용)정보 수집·이용에 관한 동의를 거부 하실 수 있습니다.다만  수집·이용에 관한 동의는 본인 신용정보 통합조회 서비스 이용을 위한 필수적인 사항이므로 동의 거부하실 경우 서비스 이용이 제한될 수 있습니다.", callBackFn : function(isConfirm){
				      if(isConfirm){
				    	  $("#agreerqst2").prop("disabled",true);
				      }else{
				    	  $('input:radio[name="'+e.target.name+'"][value="Y"]').prop("checked",true);
				    	  //pageUnit.trn.setAgree_0(pageUnit.prop.selCd);
				    	  $("#agreerqst2").prop("disabled",false);
				      }
			     }});
			}
		});
		
		$("#agreerqst2").off("click").on("click", function() {
			 //$('article').removeClass("is-open");
			 //$('#step4_2').addClass("is-open");			
			pageUnit.trn.goStep5();
		});
		
		$("#agree_dt").off("click").on("click", function() {
			//mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0104", callback:"", viewType:"half"});
			//mydataCommon.util.setData("multi_org_code",pageUnit.prop.selCd)
			pageUnit.trn.getAgree_0();
			//location.href="/auth/VAuth0010002Pop";
		});
		$("#agree_view2").off("click").on("click", function() {
			$('article').removeClass("is-open");	
			$("#step4_0").css("display","none");
			$("#step4_1").css("display","");
			
			
		});
		$("#step2_4 .modal-close").off("click").on("click", function() {
			$('article').removeClass("is-open");	
			$("#step2_3").css("display","");			
		});
		
		$("#step2_0 .sub-close").off("click").on("click", function() {
			$(this).closest('div').css('display','none').prev().css('display','');
		});
		$("#step4_1 .sub-close").off("click").on("click", function() {
			$("#step4_1").css("display","none");
			$("#step4_0").css("display","");
		});
		
		 $("#send").off("click").on("click", function() {
			
			 pageUnit.prop.selCd="";
			 var cp1 = 0;
			 var cp2 = 0;
			 var datas = [];
			 $.each($("#step1 [id^='area_'] input:checked"),function(idx,item){
				 if($(this).data("actk")=="02"){
					 cp1++;
					 datas.push($(this).val());
				 }
				 else {
					 cp2++;
					 pageUnit.prop.selCd+=(idx==0?"":",")+$(this).val().substring(0,10);
				 }			 
			 });
			 console.log("pageUnit.prop.selCd="+pageUnit.prop.selCd);

			 if(cp1 > 0 && cp2 > 0){
				 mydataCommon.msg.alert({msg : "신규기관과 기존 연결 기관은 동시에 연결 할 수 없습니다."});	
			 }else{
				 if(cp1 > 0){					 
					 pageUnit.trn.sendTo2(datas);
				 }else {
					 pageUnit.trn.getAgree(pageUnit.prop.selCd);
				 }
			 }
         });
		
		 $("#agreerqst").off("click").off("click").on("click", function() {
			// $('article').removeClass("is-open");
			// $('#step2_1').addClass("is-open");
			 pageUnit.trn.setAgree();			
         });
		 
		 $("#step2_1_prev").off("click").on("click", function() {
			 $('article').removeClass("is-open");
			 //$('#step2').addClass("is-open");
			 $('#step2_1').css("display","none");
			 $('#step2').css("display","");
	     });
		 
		 $("#step4_2_prev , #step4_2_back").off("click").off("click").on("click", function() {
			 $('article').removeClass("is-open");			 
			 $('#step4_2').css("display","none");			
			 $('#step4_0').css("display","");
	     });
		 
		 $("#step2_1_prc").off("click").off("click").on("click", function() {
			 pageUnit.trn.setAgree1(pageUnit.prop.selCd ,pageUnit.prop.selNm);		
		 });
		 
		 $("#step4_2_prc").off("click").off("click").on("click", function() {
			 pageUnit.trn.setAgree1(pageUnit.prop.selCd2 ,pageUnit.prop.selNm2);		
		 });
		
		 $("#go_step4").off("click").off("click").on("click", function() {			 
			pageUnit.trn.goStep4();			
         });
		 
		 $("#go_step5").off("click").off("click").on("click", function() {
			 pageUnit.trn.goStep5();
			
         });
		 
		 $("#goto_my").off("click").on("click",function(){
			 mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"MY0101", callback:"", viewType:""});
		 });
		 
		 $("#goto_0101").off("click").on("click",function(){
			  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"", viewType:""});
		 });
		 
		 $("#goto_0301").off("click").on("click",function(){
			  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0301", callback:"", viewType:""});
		 });
		 
		 $("#mnSel").off("click").on("click",function(){
			  pageUnit.trn.getMainOrgList();
		 });

		 
		 $("button.sub-prev").off("click").on("click",function(){
			 var id = $(this).parents('div.sub').attr("id");
			 if(id =="step1"){
				 //location.href = pageCom.prop.contextPath + "/auth/VAuth0010001View";
				 mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
			 }else if(id =="step3"){
				 mydataCommon.msg.confirm({msg : "금융기관 연결을 취소 하시겠습니까?",msg2 : "금융 기관 연결이 완료되지 않았습니다. 다음에 연결 시 처음부터 다시 진행하셔야 합니다.", callBackFn : function(isConfirm){
				      if(isConfirm){      
				    	  mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"callback_callMoveView" ,popClose:true});
				      }
			     }});
			 }else if(id =="step5"){
				 location.href = pageCom.prop.contextPath + "/auth/VAuth0010002View";
			 }else if(id == "step2"){	
				 $('#step2').css("display","none");
				 $('#step1').css("display","");
			 }else if(id == "step2_1"){
				 $('article').removeClass("is-open");
				 //$('#step2').addClass("is-open");
				 $('#step2_1').css("display","none");
				 $('#step2').css("display","");
			 }else if(id == "step2_2"){
				 //$('article').removeClass("is-open");
				 $("#step2_2").css("display","none");
				 if(pageUnit.prop.aStep == "1"){
					 //$('#step2_1').addClass("is-open");
					 $("#step2_1").css("display","");
				 }else{
					 //$('#step4_2').addClass("is-open");
					 $("#step4_2").css("display","");
				 }				 				
			 }else if(id == "step2_3"){
				 //$('article').removeClass("is-open");
				 //$('#step2_2').addClass("is-open");
				 $('#step2_3').css("display","none");
				 $('#step2_2').css("display","");
			 }else if(id == "step4_0"){
				 $('article').removeClass("is-open");
				 $('#step3').addClass("is-open");
			 }else if(id == "step4_2"){
				 $('article').removeClass("is-open");
				 $('#step4_0').addClass("is-open");	
			 }
			 else{			 
				 var cnt = id.substring(4,5);
				 var prev = Number(id.substring(4,5))-1;
				 $("#"+id).removeClass("is-open");
				 $("#step"+prev).addClass("is-open");
			 }
		 });
	
		 $(document).on('click','#pubAuthList a.sub-link',function(idx,item){
			 pageUnit.prop.pubNum = $(this).data("num");
			 $('#step2_3 ul.check-list').find('input:checkbox').each(function(){
					var thisObj = $(this); 
					thisObj.prop('checked',false);
				});
				
				 //$('article').removeClass("is-open");
				 $('#step2_2').css("display","none");	
				 $('#step2_3').css("display","");	
				 
		 });
		 
		 $("#newAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_newAuth();
         });
		 $("#getAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_getAuth();
         });
		 
		 $(document).on('click','[id^="list_main"] input[type=checkbox]',function(idx){
			
			 
			 var id = $(this).closest('div.list_temp').attr('id');//
			 var isChecked =$("#"+id+ " input:checked");			 
			 var checkedLen = isChecked.length;
			 var subCnt = $("#"+id).find('p.fs-default');
			 
			 
			 subCnt.children('span:eq(0)').text(checkedLen);
			 
			 console.log("id="+id);
			 var idSplit = id.split("_");
			 var subMap = pageUnit.prop.map.get(idSplit[2]);console.log("subMap===>"+id+","+subMap);
			 var orgSplit = $(this).val().split("|");console.log("orgSplit[1]="+orgSplit[1]);
			 var orgArray = subMap.get(orgSplit[1]);
			 if($(this).is(":checked")){				
				 orgArray.push($(this).val());				 
			 }else{
				 subMap.arrayRemove(orgSplit[1],$(this).val());
			 }
			 pageUnit.fn.toCntChk($(this));
			 console.log('subMap='+subMap.size()+"*"+subMap.get(orgSplit[1]));			 			
			 			
		 });
		 
		
		 $(document).on('click','#step1 [id^="area_"] input[type=checkbox]',function(idx){
			 var tabId = $(this).closest('div.btn-wrap').attr('id');			
			 var chkLen = $("#"+tabId+ " input:checked").length;
			 console.log('chkLen='+chkLen);
			 var chk = $("#"+tabId).parents("div.module-box");
			 $.each(chk,function(){
				 pageUnit.prop.paCnt = chk.find("input:checkbox:checked").length;
			 });
			 console.log('pageUnit.prop.paCnt='+pageUnit.prop.paCnt);
			 
			 var tabObj = $("#"+tabId).prev().find('p').children('span');
			 if(chkLen > 0){
				 tabObj.text(chkLen);
				 pageUnit.prop.paCnt+=chkLen;				 
			 }else{				 
				 tabObj.text("0");
			 }
			 
			 if(pageUnit.prop.paCnt > 0){
				 $("#send").attr("disabled",false);
			 }else{
				 $("#send").attr("disabled",true);
			 }			
		 });		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		callback_getSendCertData : function(cData){
			//alert(JSON.stringify(cData));
			var obj = $("#pubAuthList").children();
			$("#pubAuthList").append('<script id="pubAuthListTemplate" type="text/x-jquery-tmpl">');			
			$("#pubAuthListTemplate").append(obj);
			
			$.each(cData.CertData,function(i,item){
				item.idx = i;
			});
			
			$("#pubAuthListTemplate").tmpl(cData.CertData).appendTo("#pubAuthList");
		},
		toCntChk : function(obj){
			 if($("#step3 input:checked").length > 200 && obj.is(":checked")){
				mydataCommon.msg.confirm({msg : "계좌(상품) 전제를 연결하시겠습니까?",msg2 : "선택하신 계좌(상품)이 [200]개를 초과하여 현재 조회된 모든 계좌(상품)을 연결합니다.", callBackFn : function(isConfirm){
			      if(isConfirm){
			    	  $('#step3').find('input:checkbox').each(function(){
							var thisObj = $(this);
							var id = $(this).closest('div.list_temp').attr('id');
							if($("#"+id).is(":visible")){
								if(!thisObj.is(":checked")){
									 var idSplit = id.split("_");
									 var subMap = pageUnit.prop.map.get(idSplit[2]);
									 var orgSplit = $(this).val().split("|");
									 var orgArray = subMap.get(orgSplit[1]);
									 orgArray.push($(this).val());
									 thisObj.prop('checked',true);
									 console.log('subMap='+subMap.size()+"*"+subMap.get(orgSplit[1]));
								}
							}
							 var isChecked =$("#"+id+ " input:checked");			 
							 var checkedLen = isChecked.length;
							 var subCnt = $("#"+id).find('dl.c-head').find('p.fs-default');
			
							 subCnt.children('span:eq(0)').text(checkedLen);							
						});
			    	  $("#go_step4").attr("disabled",false);
			      }else{
			    	  $("#go_step4").attr("disabled",true);
			      }
			    }});
			}else if($("#step3 input:checked").length > 0 && $("#step3 input:checked").length <= 200 ){$("#go_step4").attr("disabled",false);}
			 else {$("#go_step4").attr("disabled",true);}
		},
		/*
		checkAll : function(Obj){
			$('#step2_3 ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',$(Obj).is(":checked"));
				$(Obj).is(":checked")?thisObj.val("Y"):thisObj.val("N");
			});
			pageUnit.fn.clickChk();
		},*/		
		clickChk : function(){			
			($("#step2_3 [id^='chk_0']:checked").length)==3?($("#next").prop("disabled",false)):($("#next").prop("disabled",true));						
		},
		next : function(){
			pageUnit.trn.setAgree2();
			/*
			var isSuccess = !mydataCommon.vald.validation({target : $("#step2_3 ul.check-list"),immedtAlertPop:true});
			if(isSuccess){
				pageUnit.trn.setAgree2();				
			}
			*/
		},		
		callCertMydataSign : function(resultMap){
			
			var strSigning = {strSigning : resultMap , index:pageUnit.prop.pubNum};
			var obj = {command : "getCertMydataSign" , param:strSigning ,callback: "pageUnit.fn.callback_getCertMydataSign"};
			var totCnt = resultMap.length;
			pageUnit.prop.process = 100%totCnt;
			pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;			
			var authData = JSON.stringify(obj);
			if(pageCom.prop.isIPHONE)
			{
			   authData = encodeURIComponent(authData);
			   window.location = "mydata://"+authData;
			}
			else if(pageCom.prop.isANDROID)
			{
			   document.location.href = "mydata://"+authData;
			}
			
			/*
			var totCnt = resultMap.length;
			pageUnit.prop.process = 100%totCnt;
			pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
			console.log(JSON.stringify(resultMap));
			console.log('pageUnit.prop.process start='+pageUnit.prop.process);
			console.log('pageUnit.prop.div start='+pageUnit.prop.div);
			var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAER0000","signedPersonInfoReq":"signeddata1","signedConsent":"signeddata2"},{"orgCode":"C1AACS0000","signedPersonInfoReq":"signeddata11","signedConsent":"signeddata12"},{"orgCode":"C1AACT0000","signedPersonInfoReq":"signeddata11","signedConsent":"signeddata12"}] , "caOrg":"SignKorea"}');//은행 {"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},,{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}
			pageUnit.fn.callback_getCertMydataSign(data);
			*/
			
		},
		callback_getCertMydataSign : function(obj){
			var data = obj;			
			if(pageUnit.prop.aStep == "1"){
				
				$(data.signedDataList).each(function(idx,item){								
					data.signedDataList[idx].caOrg = data.caOrg;
					//alert(JSON.stringify(data.signedDataList[idx]);
					console.log(JSON.stringify(data.signedDataList[idx]));
					setTimeout(function(){pageUnit.trn.sendTo(data.signedDataList[idx]);},idx*100);
				});
				
			}else if(pageUnit.prop.aStep == "2"){
				$(data.signedDataList).each(function(idx,item){								
					data.signedDataList[idx].caOrg = data.caOrg;
					console.log(JSON.stringify(data.signedDataList[idx]));
					setTimeout(function(){pageUnit.trn.sendToRslt(data.signedDataList[idx]);},idx*100);
				});
			}
		},
		progressChk : function(){
			console.log('process='+pageUnit.prop.process);
			$("#loading").find('p.fc-orange').text(pageUnit.prop.process+"%");
			if(pageUnit.prop.process == 100) {
				$("#loading").find('p.fc-orange').text("0%");
				pageUnit.prop.div = 0;
				pageUnit.prop.process = 0;
				
				$('article').removeClass("is-open");
				//$('#step3').addClass("is-open");
				
				$('#step2_3').css("display","none");
				$('#step3').css("display","");
				var totCnt = pageUnit.prop.cnt[0]+pageUnit.prop.cnt[1]+pageUnit.prop.cnt[2]+pageUnit.prop.cnt[3]+pageUnit.prop.cnt[4]+pageUnit.prop.cnt[5]+pageUnit.prop.cnt[6];
				$("#totCnt").text(totCnt);
				
				var obj = $('#step3 input[type=checkbox]');
				var cnt = 0;
				var tmpId = '';
				$.each(obj,function(idx){					
					 var id = $(this).closest('section.module-box').attr('id');
					 if(tmpId!='' && tmpId!=id){
						 cnt = 0;
					 }		 					 
					 var subMap = pageUnit.prop.map.get(id);					 
					 var orgSplit = $(this).val().split("|");
					 var orgArray = subMap.get(orgSplit[1]);					 
					 if($(this).is(":checked")){
						 orgArray.push($(this).val());
						 $("#go_step4").prop("disabled",false);
						 cnt++;
					 }
					 $("#"+id).find("dl.c-head").find('span:eq(0)').text(cnt);
					 console.log("orgArrayorgArray=>"+orgArray);
					 tmpId = id;					 
				});
				
			}
		},
		progressChk2 : function(){
			console.log('process='+pageUnit.prop.process);
			$("#loading").find('p.fc-orange').text(pageUnit.prop.process+"%");
			if(pageUnit.prop.process == 100) {
				$("#loading").find('p.fc-orange').text("0%");
				pageUnit.prop.div = 0;
				pageUnit.prop.process = 0;
				$('article').removeClass("is-open");
				$('#step2_3').css("display","none");
				$('#step5').css("display","");
			}
		},
		setAgreeData : function(){		
			var mainMap = pageUnit.prop.map;			
			var keys = mainMap.getKeys();
			 console.log(keys);
			 pageUnit.prop.datas=[];
			 for(var i in keys){
				 var subMap = mainMap.get(keys[i]);
				 var orgCodes = subMap.getKeys();				
				 if(orgCodes.length > 0){
					 console.log("최초="+keys[i]);
					 for(var z in orgCodes){				
						 var gdsList = subMap.get(orgCodes[z]);
						 var orgNm = gdsList[0];						 						
						 for(var o=0 ; o< gdsList.length-1;o++){						
							 var gdsListSplit = gdsList[o+1].split("|");
							 pageUnit.prop.datas.push(gdsListSplit[1]+"|"+keys[i]+"|"+gdsListSplit[0]+"|"+gdsListSplit[2]+"|"+gdsListSplit[3]+"|"+orgNm+(gdsListSplit[0]=="bnk001"?"|"+gdsListSplit[4]+"|"+gdsListSplit[5]:gdsListSplit[0]=="rnt001"?"|"+gdsListSplit[4]:""));
							 console.log(gdsListSplit[1]+"|"+keys[i]+"|"+gdsListSplit[0]+"|"+gdsListSplit[2]+"|"+gdsListSplit[3]+"|"+orgNm+(gdsListSplit[0]=="bnk001"?"|"+gdsListSplit[4]:""));
						 }						
					 }		
				 }
			 }
		}
	}
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});