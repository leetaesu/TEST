var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		pop_tp : mydataCommon.util.getData("svc_tp1"),
		pop_gb : mydataCommon.util.getData("lopopgb")
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {		
		getPInfo : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth0010021View",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;	
						var resp_gubn = res.resp_gubn;
						if(resultMap && resp_gubn == "0"){
							//console.log(JSON.stringify(resultMap));
							//$("#rslt").append(resultMap.exprCntn);
						    var content = resultMap.exprCntn;
							$("#rslt").html($("#rslt").html(content).text());
							
							$('article').removeClass("is-open");
							$("#step1").css("display","none");
							$("#step2").css("display","");
							
							if(res.wtListMap && res.wtListMap.resp_gubn =='0'){
								var obj = $("#wtd_list").children();
								$("#wtd_list").append('<script id="wtdListTemplate" type="text/x-jquery-tmpl">');			
								$("#wtdListTemplate").append(obj);							
								$("#wtdListTemplate").tmpl(res.wtListMap.g1).appendTo("#wtd_list");
							}
							
							if(res.jhListMap && res.jhListMap.resp_gubn =='0'){
								var obj = $("#jhd_list").children();
								$("#jhd_list").append('<script id="jhdListTemplate" type="text/x-jquery-tmpl">');			
								$("#jhdListTemplate").append(obj);							
								$("#jhdListTemplate").tmpl(res.jhListMap.g1).appendTo("#jhd_list");
							}
							
						}else{
							mydataCommon.msg.alert({msg : res.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();		
		if(pageUnit.prop.pop_tp == '0'){
			$('article').removeClass("is-open");
			$("#step1").css("display","");
		}else if(pageUnit.prop.pop_tp == '9'){
			pageUnit.trn.getPInfo();
		}else{			
			$('article').removeClass("is-open");
			$("#step1").css("display","none");
			//$("#"+pageUnit.prop.pop_tp+"_l").css("display","");
			$("#"+pageUnit.prop.pop_tp+"_l").addClass("is-open");
		}
		
		//pageUnit.fn.set_data();
	},
	
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		// 단위 전용 함수 모음 패키지
		/*
		$(".btn-footer").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
		});
		*/
		
		$("#step2 .btn-footer").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
		});
		
		$('#step1 .btn-footer , button.sub-close').off("click").on("click", function(){
			
			var id = $(this).closest('div.page-wrapper').attr("id");
			if(id == "wtlist" || id =="jhlist"){
				$("#"+id).css("display","none");
				$("#step2").css("display","");
			}else{
				if(pageUnit.prop.pop_gb == "p"){
					mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
				}else if(pageUnit.prop.pop_gb == "l"){
					history.back(-1);
				}
			}			
		});	
		
		$("button.cfm , button.modal-close").off("click").on("click", function(){
			var id = $(this).closest('article').prop("id");
			if(id.indexOf("_d")>-1){
				var subs = id.substring(0,4);
				$('article').removeClass("is-open");
				$('#'+subs+"_l").addClass("is-open");
			}else{
				if(pageUnit.prop.pop_gb == "p"){
					mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
				}else if(pageUnit.prop.pop_gb == "l"){
					history.back(-1);
				}
				/*
				var subs = id.substring(0,2);
				$('article').removeClass("is-open");
				$('#'+subs).css("display","");
				//$('#step1').addClass("is-open");
				$("#step1").css("display","");
				*/
			}
		});		
		
		$("article button.sm").off("click").on("click", function(){
			$('article').removeClass("is-open");
			if($(this).closest('article').prop("id") == "s6_4_l"){
				$(this).closest('article').find('li').each(function(){
					 if($(this).hasClass("is-selected") == true){					 
						 $("#"+$("#"+$(this).attr("id")).attr("area2")+"_l").addClass("is-open");
					 }
				});				
			}else{
				$('#'+$(this).prop("id")+"_l").addClass("is-open");
			}
			
		});
		
		$(document).on('click','#pop01',function(){
			$("#step2").css("display","none");
			$("#wtlist").css("display","");
		 });
		
		$(document).on('click','#pop02',function(){
			$("#step2").css("display","none");
			$("#jhlist").css("display","");
		 });			
	},
	fn : {		
		set_data : function(){
			$('#tab'+pageUnit.prop.pop_tp).css('display','block').siblings().css('display','none');
			mydataCommon.util.setData("apop","");
		}
	},
	
};

$(document).ready(function(){
	pageUnit.init();
});
window.onload = function(){
}



