var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		infr_wst_yn : "N",
		process : 0,
		div		:0
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		cncl : function(inst_tp){
			//var data = mydataCommon.makeJsonParam({target : $("body")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0030003Ajax",
					data : {"myd_orgn_code":inst_tp,"infr_wst_yn":pageUnit.prop.infr_wst_yn},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							pageUnit.fn.progressChk();
							
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg , callBackFn : function(){
								$("article").removeClass("is-open");
								$('#subMain').css("display","");
							}});
							
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		}
		
	},
	// 단위 진입부 함수
	init : function(){	
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
				
		$("input:radio[name='infr_wst_yn']").off("click").on("click",function(){
			var rdo = $(this);
			if(rdo.is(":checked") && rdo.val()=="Y"){
				mydataCommon.msg.alert({msg : "기존 정보 삭제 요청 시 24시간 내 재 연결이 제한됩니다" , msg2 : "금융기관 연결 해지 시 선택하신 금융기관의 재 연결은 (고객정보 삭제 소요시간) 이후에 연결 가능 합니다."});
			};
			pageUnit.prop.infr_wst_yn = rdo.val();
		});
		
		$("#prcCncl").off("click").on("click",function(){
			var totCnt = 1;			
			var data = localStorage.getItem("org_cd");
			$('#subMain').css("display","none");
			if(data.indexOf("[") > -1){
				$("#loading").addClass("is-open");				
				var ary = JSON.parse(data);		
				totCnt = ary.length;
				pageUnit.prop.process = 100%totCnt;
				pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;

				$.each(ary,function(idx,item){
					setTimeout(function(){pageUnit.trn.cncl(item);},idx*300);
				});				
			}else{
				$("#loading").addClass("is-open");
				pageUnit.prop.process = 100%totCnt;
				pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
				pageUnit.trn.cncl(data);
			}
			
			 $("#goto_my").off("click").on("click",function(){
				  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"MY0101", callback:"callback_callMoveView", viewType:""});
			 });
			
		});

		$(".sub-close").off("click").on("click",function(){
			//mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"callback_callMoveView" ,popClose:true});
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0301", callback:"", viewType:""});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		removeLocalStorage : function(key){
			localStorage.removeItem(key);
		},
		progressChk : function(){
			console.log('process='+pageUnit.prop.process);
			$("#loading").find('p.fc-orange').text(pageUnit.prop.process+"%");
			if(pageUnit.prop.process == 100) {
				$("#loading").find('p.fc-orange').text("0%");
				pageUnit.prop.div = 0;
				pageUnit.prop.process = 0;			
				$('#loading').removeClass("is-open");
				
				if(pageUnit.prop.infr_wst_yn == "Y" ){
					$("#rslt_txt").html("금융기관을 재 연결을 원하실 경우<br/>24시간(고객정보 삭제 소요시간)<br/>이후에 연결 가능 합니다.");
				}				
				$('#rslt').css("display","");			
				
				
			}
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
