

var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		svc_tp : localStorage.getItem("svc_tp")
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
//			동의폐기 I:10 O:0 폐기서비스구분 : 1:자동차시세,2:보험분석조회,3:진료내역조회,4:국민연금조회,5:신용관리,6:대출한도조회
			if(exeType == 'UpdtXmh1009u02'){
				var jsonObj = {
					data : 	{"svc_tp" : pageUnit.prop.svc_tp},
					url : pageCom.prop.contextPath + "/auth/UAuth0050002001Ajax",
					async : false,
					success : pageUnit.fn.set_section,
					error : pageUnit.fn.set_section_error
				}
				mydataCommon.ajax(jsonObj);	
			}
		},
		getAgreeInfo : function(){
			localStorage.setItem("lopopgb","l");
			location.href=pageCom.prop.contextPath +"/auth/VAuth0050003View";
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();	
		$('article').removeClass("is-open");		
		$("#s"+pageUnit.prop.svc_tp).css("display","");
		$("#step1").css("display","");
	},
	
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		// 단위 전용 함수 모음 패키지
		$(".sub-prev").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
		});	
		
		$("#step1 .btn-footer").off("click").on("click", function(){
			var name = "";
			if($("#s1").is(":visible")){
				name="[자동차 시세 조회]";
			}else if($("#s5").is(":visible")){
				name="[신용관리]";
			}else if($("#s6").is(":visible")){
				name="[대출한도비교]";
			}
			mydataCommon.msg.confirm({
				msg : name+" 서비스 동의를 철회하시겠습니까?",
				msg2 : "본 서비스와 관련된 모든 정보가 삭제되며,복구 할 수 없습니다.",
				callBackFn : function(isConfirm){
				if(isConfirm){      
					pageUnit.trn.ajax_call("UpdtXmh1009u02");
				}
		    }});
		});	
		
		$("#step2 .btn-footer").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
		});	
		
		$("#btnCncl").off("click").on("click", function(){
			KW_MOBILE.guiEvent.popup.closePop('#modal_alert')
		});	
		
		
		/*
		$("#s6 .icon-link").off("click").on("click", function(){
			$('article').removeClass("is-open");
			$('#'+$(this).prop("id")+"_l").addClass("is-open");
		});
		*/
		
		$("#step1 div.module-box a.confirm-link").off("click").on("click", function(){
			/*
			$('article').removeClass("is-open");
			$("#step1").css("display","none");
			$('#'+$(this).prop("id")+"_l").addClass("is-open");
			*/
			localStorage.setItem("svc_tp1",$(this).prop("id"));
			pageUnit.trn.getAgreeInfo();
		});
		
		
		
		$("#step1 button.modal-prev").off("click").on("click", function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"callback_callMoveView" ,popClose:true});
		});
				
	},
	fn : {		
		set_section : function(data){
			var outData = data.resultMap;
			mydataCommon.msg.alert({msg : outData.resp_mesg});
			localStorage.setItem("svc_tp","");
		},
		set_section_error : function(data){
			mydataCommon.util.log(['Auth001_0005.js :: req_error ----------> ', data]);
		},
	},
	
};

$(document).ready(function(){
	pageUnit.init();
});
window.onload = function(){
}



