var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		data : '',
		datas : [],
		process : 0 ,
		div : 0,
		cnt : [0,0,0,0,0,0,0],		
		subCnt : [0,0,0,0,0,0,0],// bnk crd sec ins rnt
		rCnt : [0,0,0,0,0,0,0],
		map 	  : null,
		argeData : [],
		aStep : '',
		selCd2 : '',
		id : '',
		info_cntn_list2 : '',
		inds_tp_list2 : '',
		selNm2 : '',
		info_cntn_key : '',
		sData:'',
		pubNum: '',
		initCnt : 0
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(inst_tp){			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0030003Ajax",
					data : {"orgn_code":pageUnit.prop.data},//pageUnit.prop.data 'A1AAER0000'
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView(resultMap);						
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree1 : function(cd,nm){			
			$("#multi_org_code").val(cd);
			$("#multi_orgn_nm").val(nm);
			var data = mydataCommon.makeSerialParam({target : $("body")});
			console.log('setAgree1')
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010017Ajax",
					data : data,
					async : true,					
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							 $('article').removeClass("is-open");
							 $('#step4_2').css("display","none");
							 $('#step4_3').css("display","");
							 var obj = {command : "getSendCertData" ,callback: "pageUnit.fn.callback_getSendCertData"};
								var data = JSON.stringify(obj);
								if(pageCom.prop.isIPHONE)
								{
									data = encodeURIComponent(data);
									//window.location = "iTransKeyS:"+obj;//handleOpenURL
									window.location = "mydata://"+data
								}
								else if(pageCom.prop.isANDROID)
								{	
									//window.MTranskey.setKey(data);
									document.location.href = "mydata://"+data
								}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setAgree2 : function(){
			var data = mydataCommon.makeSerialParam({target : $("#step4_4")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030003Ajax",
					data : data,
					async : false,					
					success : function(res){
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){							
								 pageUnit.trn.setAgree_2();
							//pageUnit.fn.callCertMydataSign(pageUnit.prop.sData);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		contact01 : function(org_code,gdsNm){
			console.log('은행-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060101Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					success : function(res){
						var resultMap = res.resultMap;

						var bnk_001 = resultMap.bnk_001;
						var irp_001 = resultMap.irp_001;
						pageUnit.prop.subCnt[0] = 0;
						if( (bnk_001 && bnk_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0" ) ){
							var subMap = pageUnit.prop.map.get("bnk");
							subMap.put(org_code,[gdsNm]);
							var obj = $("#bnk");
							obj.show();
							var bod_main = obj.children('div.card-box');
							//var bod_main_clone = bod_main.clone(); 						
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);							
							//var acntCnt = bod_main_clone.find('div.card-head').find('p.font-12').children('span:eq(1)');
							
							pageUnit.prop.cnt[0]++;
							//var atr_id = ""+bod_main_clone.attr("id")+pageUnit.prop.cnt[0];
							//bod_main_clone.attr("id",atr_id);							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");
							//bod_main_clone.find("#b_list_sub").remove();
							$.each(bnk_001 , function(idx,item){
								$.each(bnk_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('bnk001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.acnt_no+"|"+item1.acnt_tp+"|"+item1.sqno+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.fc_acnt_yn+"|"+item1.mns_engg_yn+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(1)').text("("+item1.acnt_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
									//acntCnt.text(++pageUnit.prop.subCnt[0]);
								});
							});
							
							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(1)').text("("+item1.acnt_no+")");
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main.find("div.card-body").append(addDivObj.show());
								//acntCnt.text(++pageUnit.prop.subCnt[0]);
							});
							
							bod_main.find("div.card-body").children("dl:eq(0)").remove();
							//$("#bnk").find('div.fold-body').append(bod_main_clone);
							
						}else{							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(bnk_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact02 : function(org_code,gdsNm){
			console.log('카드-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060201Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
					var resultMap = res.resultMap;
					
					var crd_001 = resultMap.crd_001;

					pageUnit.prop.subCnt[1] = 0;
					if( (crd_001 && crd_001[0].resp_gubn == "0") ){
						var subMap = pageUnit.prop.map.get("crd");
						subMap.put(org_code,[gdsNm]);
						
						var obj = $("#crd");
						obj.show();
						if(pageUnit.prop.initCnt == 0){
							obj.addClass("pt30");
							++pageUnit.prop.initCnt;
						}
						
						var bod_main = obj.children('div.card-box');					
						bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
						bod_main.find('div.card-head').find('h3').text(gdsNm);						
						
						pageUnit.prop.cnt[1]++;
						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
						var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");
						
						$.each(crd_001 , function(idx,item){
							$.each(crd_001[idx].g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.card_no).val('crd001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.card_nm)+"|"+item1.card_no+"|"+item1.card_id+"|"+item1.send_rqst_yn+"|"+item1.card_memb_tp+"|"+item1.card_kind_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.card_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.card_nm));
								addDivObj.find('label').find('p:eq(1)').text("("+item1.card_no+")");
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main.find("div.card-body").append(addDivObj.show());
							});
						});
						
						if(pageUnit.prop.subCnt[1] > 0){
							var addDivObj = card_body_list.clone();									
							addDivObj.find('input:checkbox').attr("id","point").prop("checked",true).prop("disabled",true).val('crd001');
							addDivObj.find('label').find('p:eq(0)').text("선택한 카드사의 포인트 정보 , 청구 정보, 대출 정보가 있을 경우 함께 전송됩니다");								
							//addDivObj.find('span:eq(1)').text(item1.card_no);
							bod_main_clone.append(addDivObj.show());
						}
						
						bod_main.find("div.card-body").children("dl:eq(0)").remove();
					}else{						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						$("#loading").find('p.err-msg').text(crd_001[0].resp_mesg);
					}
					
					pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact03 : function(org_code,gdsNm){
			console.log('금투-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060301Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;

						var sec_001 = resultMap.sec_001;
						var irp_001 = resultMap.irp_001;

						pageUnit.prop.subCnt[2] = 0;
						if( (sec_001 && sec_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("sec");
							subMap.put(org_code,[gdsNm]);
							
							var obj = $("#sec"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var bod_main = obj.children('div.card-box'); 						
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);
							
							pageUnit.prop.cnt[2]++;							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");
							$.each(sec_001 , function(idx,item){
								$.each(sec_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('sec001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.acnt_nm)+"|"+item1.acnt_no+"|"+item1.open_dt+"|"+item1.send_rqst_yn+"|"+item1.acnt_tp+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_nm));
									addDivObj.find('label').find('p:eq(1)').text("("+item1.acnt_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});

							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));
								addDivObj.find('label').find('p:eq(1)').text("("+item1.acnt_no+")");
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								bod_main.find("div.card-body").append(addDivObj.show());
							});
							bod_main.find("div.card-body").children("dl:eq(0)").remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sec_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact04 : function(org_code,gdsNm){
			console.log('보험-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060401Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;

						var ins_001 = resultMap.ins_001;
						var ins_008 = resultMap.ins_008;						
						var irp_001 = resultMap.irp_001;
						
						pageUnit.prop.subCnt[3] = 0;
						if( (ins_001 && ins_001[0].resp_gubn == "0") || (ins_008 && ins_008[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
							var subMap = pageUnit.prop.map.get("ins");
							subMap.put(org_code,[gdsNm]);
							var obj = $("#ins"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var bod_main = obj.children('div.card-box');
							
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);
														
							pageUnit.prop.cnt[3]++;
							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");

							$.each(ins_001 , function(idx,item){
								$.each(ins_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('ins001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.send_rqst_yn+"|"+item1.insr_kind_tp+"|"+mydataCommon.util.replace(item1.insr_kind_tp_nm)+"|"+item1.cntr_stat_tp+"|"+mydataCommon.util.replace(item1.cntr_stat_tp_nm)+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
									addDivObj.find('label').find('p:eq(1)').text("("+item1.insr_cntr_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});
							
							$.each(ins_008 , function(idx,item){
								$.each(ins_008[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('ins008'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.acnt_type_tp+"|"+item1.acnt_stat_tp+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));								
									addDivObj.find('label').find('p:eq(1)').text("("+item1.insr_cntr_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});						
							
							$.each(irp_001 && irp_001.g1 , function(idx1,item1){
								var addDivObj = card_body_list.clone();									
								addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('irp001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.irp_gds_nm)+"|"+item1.acnt_no+"|"+item1.send_rqst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);						
								addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.irp_gds_nm));
								addDivObj.find('label').find('p:eq(1)').text("("+item1.acnt_no+")");
								if("Y"==item1.send_rqst_yn){									
									addDivObj.children('dd').children('p').text("연결됨");
								}
								
								bod_main.find("div.card-body").append(addDivObj.show());
							});

							bod_main.find("div.card-body").children("dl:eq(0)").remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ins_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact05 : function(org_code,gdsNm){
			console.log('전금-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060501Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;

						var ele_001 = resultMap.ele_001;
						var ele_101 = resultMap.ele_101;
						
						pageUnit.prop.subCnt[4] = 0;
						if( (ele_001 && ele_001[0].resp_gubn == "0") || (ele_101 && ele_101[0].resp_gubn == "0")  ){
							var subMap = pageUnit.prop.map.get("ele");
							subMap.put(org_code,[gdsNm]);
							var obj = $("#ele"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var bod_main = obj.children('div.card-box');
							
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);
														
							pageUnit.prop.cnt[4]++;
							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");

							$.each(ele_001 , function(idx,item){
								$.each(ele_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.fob_id).val('ele001'+"|"+org_code+"|"+item1.fob_id+"|"+mydataCommon.util.replace(item1.fob_nm)+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.auto_chrg_rgst_yn+"|"+item1.crnc_code+"|"+item1.fob_limit+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);									
									addDivObj.find('label').attr('for',""+org_code+item1.fob_id).find('p:eq(0)').text(mydataCommon.util.replace(item1.fob_nm));
									addDivObj.find('p:eq(1)').text("("+item1.fob_id+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});
							
							$.each(ele_101 , function(idx,item){
								$.each(ele_101[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.efnc_acct_id).val('ele101'+"|"+org_code+"|"+item1.efnc_orgn_acct_id+"|"+item1.efnc_acct_id+"|"+item1.send_rqst_yn+"|"+item1.join_dt+"|"+item1.frst_join_dt+"|"+item1.setl_means_rgst_yn+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.efnc_acct_id).find('p:eq(0)').text(mydataCommon.util.replace(item1.efnc_acct_id));								
									addDivObj.find('p:eq(1)').text("("+item1.efnc_orgn_acct_id+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});

							bod_main.find("div.card-body").children("dl:eq(0)").remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ele_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact06 : function(org_code,gdsNm){
			console.log('할부금융-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060601Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;
						
						var rnt_001 = resultMap.rnt_001;

						pageUnit.prop.subCnt[5] = 0;
						if( (rnt_001 && rnt_001[0].resp_gubn) == "0" ){
							var subMap = pageUnit.prop.map.get("rnt");
							subMap.put(org_code,[gdsNm]);
							var obj = $("#rnt");
							obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var bod_main = obj.children('div.card-box');
 						
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);
							
							pageUnit.prop.cnt[5]++;							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");

							$.each(rnt_001 , function(idx,item){
								$.each(rnt_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.acnt_no).val('rnt001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.acnt_no+"|"+item1.sqno+"|"+item1.frst_join_dt+"|"+item1.send_rqst_yn+"|"+item1.acnt_tp+"|"+item1.acnt_stat_tp+"|"+item1.tmst).prop("checked",item1.send_rqst_yn=="Y"?true:false);
									addDivObj.find('label').attr('for',""+org_code+item1.acnt_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));	
									addDivObj.find('label').find('p:eq(1)').text("("+item1.acnt_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});

							bod_main.find("div.card-body").children("dl:eq(0)").remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(rnt_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact07 : function(org_code,gdsNm){
			console.log('보증보험-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100060701Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;
						
						var sin_001 = resultMap.sin_001;

						pageUnit.prop.subCnt[6] = 0;
						if( (sin_001 && sin_001[0].resp_gubn) == "0" ){
							var subMap = pageUnit.prop.map.get("sin");
							subMap.put(org_code,[gdsNm]);
							var obj = $("#sin");
							obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var bod_main = obj.children('div.card-box');
 						
							bod_main.find('div.card-head').find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							bod_main.find('div.card-head').find('h3').text(gdsNm);
							
							pageUnit.prop.cnt[6]++;							
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;	
							var card_body_list = bod_main.find("div.card-body").children("dl:eq(0)");

							$.each(sin_001 , function(idx,item){
								$.each(sin_001[idx].g1 , function(idx1,item1){
									var addDivObj = card_body_list.clone();
									addDivObj.find('input:checkbox').attr("id",""+org_code+item1.insr_cntr_no).val('sin001'+"|"+org_code+"|"+mydataCommon.util.replace(item1.gds_nm)+"|"+item1.insr_cntr_no+"|"+item1.send_rqst_yn+"|"+item1.insr_kind_tp+"|"+item1.grin_cntr_stat_tp+"|"+item1.tmst);
									addDivObj.find('label').attr('for',""+org_code+item1.insr_cntr_no).find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));	
									addDivObj.find('p:eq(1)').text("("+item1.insr_cntr_no+")");
									if("Y"==item1.send_rqst_yn){									
										addDivObj.children('dd').children('p').text("연결됨");
									}
									bod_main.find("div.card-body").append(addDivObj.show());
								});
							});

							bod_main.find("div.card-body").children("dl:eq(0)").remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sin_001[0].resp_mesg);
						}
						
						pageUnit.fn.progressChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		goStep4 : function(){
			var data = mydataCommon.makeSerialParam({target : $("#step3")});
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0010007Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
							
						var resultMap = res.resultMap;	
						var resultMap2 = res.resultMap2;
						if(resultMap && resultMap.resp_gubn =="0"){
							try{
							pageUnit.prop.selCd2 = res.multi_org_cd;
							pageUnit.fn.setAgreeData();
							pageUnit.prop.info_cntn_list2='';
							pageUnit.prop.inds_tp_list2='';
							var obj = $("#info_list2").children();
							$("#info_list2").append('<script id="infoList2Template" type="text/x-jquery-tmpl">');			
							$("#infoList2Template").append(obj);							
							$("#infoList2Template").tmpl(resultMap.g1).appendTo("#info_list2");														

							$.each(resultMap.g1,function(idx,item){
								 pageUnit.prop.info_cntn_list2+=(idx==0?"":"|")+mydataCommon.util.replace(item.info_cntn);				 
								 pageUnit.prop.inds_tp_list2+=(idx==0?"":"|")+mydataCommon.util.replace(item.inds_tp);
							});
							pageUnit.prop.selNm2 = resultMap.tot_org_nm;
							$("#company_info3").text(resultMap.tot_org_nm);
							$("#company_info4_2").text(resultMap.tot_org_nm);
							$('article').removeClass("is-open");
							//$("#step4_0").addClass("is-open");
							$("#step3").css("display","none");
							$("#step4_0").css("display","");
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
						
						if(resultMap2 && resultMap2.resp_gubn=="0"){
							pageUnit.prop.info_cntn_key='';
							$.each(resultMap2.g1,function(idx,item){
								 pageUnit.prop.info_cntn_key+=(idx==0?"":"|")+mydataCommon.util.replace(item.info_cntn_key);
							});
							
							var gds_prchs_infr_acyn = resultMap2.gds_prchs_infr_acyn;
							if(gds_prchs_infr_acyn == "Y"){ 
								$("#gds_prchs_infr_acyn_id").show();
								$("input:radio[name='gds_prchs_infr_acyn']").prop("disabled",false);
							}
							$("#gds_cntn").text(resultMap2.gds_cntn);
							var fran_nm_infr_acyn = resultMap2.fran_nm_infr_acyn;
							if(fran_nm_infr_acyn == "Y"){ 
								$("#fran_nm_infr_acyn_id").show();
								$("input:radio[name='fran_nm_infr_acyn']").prop("disabled",false);
							}
							$("#fran_cntn").text(resultMap2.fran_cntn);
							var rmrk_acyn = resultMap2.rmrk_acyn;
							if(rmrk_acyn == "Y") {
								$("#rmrk_acyn_id").show();
								$("input:radio[name='rmrk_acyn']").prop("disabled",false);
							}
							$("#rmrk_cntn").text(resultMap2.rmrk_cntn);
							
							var obj = $("#info_list3").children();
							$("#info_list3").append('<script id="infoList3Template" type="text/x-jquery-tmpl">');			
							$("#infoList3Template").append(obj);							
							$("#infoList3Template").tmpl(resultMap2.g1).appendTo("#info_list3");
						}else{
							mydataCommon.msg.alert({msg : resultMap2.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goStep5 : function(){			
			var paramidx = 0;	
			var dataAry = new Array();			
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});	
			dataAry[paramidx++] = "multi_orgn_code="+encodeURIComponent(pageUnit.prop.selCd2);
			dataAry[paramidx++] = "multi_orgn_nm="+encodeURIComponent(pageUnit.prop.selNm2);
			dataAry[paramidx++] = "info_cntn_list2="+encodeURIComponent(pageUnit.prop.info_cntn_list2);
			dataAry[paramidx++] = "inds_tp_list2="+encodeURIComponent(pageUnit.prop.inds_tp_list2);
			dataAry[paramidx++] = "info_cntn_key="+encodeURIComponent(pageUnit.prop.info_cntn_key);
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "cnt="+cnt;
						
			var data = dataAry.join("&");

			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030002Ajax",
					data : data,
					async : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap2 && resultMap2 == "scss"){
							pageUnit.prop.aStep = "2";							
							pageUnit.prop.sData = resultMap;
							$('article').removeClass("is-open");
							$('#step4_0').css("display","none");
							$('#step4_2').css("display","");
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		setAgree_2 : function(){			
			var dataAry = new Array();	
			var paramidx = 0;
							
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});				
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "cnt="+cnt;
			
			var data = dataAry.join("&");
			console.log('goStep5');
			console.log(data);

			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100030006Ajax",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						var resultMap2 = res.resultMap2;	
						var resultMap = res.resultMap;	
						if(resultMap2 && resultMap2 == "scss"){							
							//통합인증 모듈 호출
							try{
								pageUnit.prop.sData = resultMap;
								pageUnit.fn.callCertMydataSign(resultMap);							
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		setAgree_4 : function(){//사설인증 결과
			var dataAry = new Array();	
			var paramidx = 0;
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});	
			dataAry[paramidx++] = "pri_tp="+$("#pri_tp").val();
			var data = dataAry.join("&");
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth00100019997View",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){
						
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.sendToRslt2(resultMap);														
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}						
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},		
		setAgree_5 : function(){			
			var dataAry = new Array();	
			var paramidx = 0;
							
			$.each(pageUnit.prop.datas,function(idx,item){
				dataAry[paramidx++] = "org_code="+encodeURIComponent(pageUnit.prop.datas[idx]);
				console.log('pageUnit.prop.datas[idx]===>'+pageUnit.prop.datas[idx])
			});				
			dataAry[paramidx++] = "rglr_send_yn="+encodeURIComponent($("input:radio[name='rglr_send_yn']:checked").val());
			dataAry[paramidx++] = "end_dt="+$("select[name='end_dt']").val();
			if($("#rmrk_acyn_id").is(":visible")){
				dataAry[paramidx++] = "rmrk_acyn="+$("input:radio[name='rmrk_acyn']:checked").val();
			}
			if($("#fran_nm_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "fran_nm_infr_acyn="+$("input:radio[name='fran_nm_infr_acyn']:checked").val();
			}
			if($("#gds_prchs_infr_acyn_id").is(":visible")){
				dataAry[paramidx++] = "gds_prchs_infr_acyn="+$("input:radio[name='gds_prchs_infr_acyn']:checked").val();
			}
			var cnt = 0;
			$.each(pageUnit.prop.subCnt,function(idx,item){
				cnt+=item;
			})
			dataAry[paramidx++] = "pri_tp="+$("#pri_tp").val();
			dataAry[paramidx++] = "cnt="+cnt;
			
			var data = dataAry.join("&");
			console.log(data);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth00100019996View",
					data : data,
					async : true,					
					//cache : true,
					beforeSend : function(){
						
					},
					success : function(res){	
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							//통합인증 모듈 호출
							try{
								//통합인증 모듈 호출2
								alert('resultMap.sign_aos_app_scheme_url2='+resultMap.sign_aos_app_scheme_url);							
								if(pageCom.prop.isIPHONE)
								{
								   window.location = resultMap.sign_ios_app_scheme_url;
								}
								else if(pageCom.prop.isANDROID)
								{
								   document.location.href = resultMap.sign_aos_app_scheme_url;
								}								
							}catch(e){alert(e);}
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);		
				
		},
		sendToRslt : function(Obj){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100040001Ajax",
					contentType : "application/json",
					data : JSON.stringify(Obj),
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#loading").addClass("is-open");
							var tp = resultMap.prcs.substring(0,2);
							var myd_orgn_code = resultMap.prcs.substring(2,12);
							var myd_orgn_Nm = mydataCommon.util.replace(resultMap.prcs.substring(12));
							if(tp == '01'){
								pageUnit.trn.contact01Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '02'){
								pageUnit.trn.contact02Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '03'){							
								pageUnit.trn.contact03Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '04'){
								pageUnit.trn.contact04Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '05'){
								pageUnit.trn.contact05Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '06'){
								pageUnit.trn.contact06Rslt(myd_orgn_code,myd_orgn_Nm);
							}else if(tp == '07'){
								pageUnit.trn.contact07Rslt(myd_orgn_code,myd_orgn_Nm);
							}						
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},		
		sendToRslt2 : function(resultMap){
			if( (resultMap && resultMap.resp_gubn) == "0"  ){
				var totCnt = resultMap.g1.length;
				pageUnit.prop.process = 100%totCnt;
				pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
				
				$.each(resultMap && resultMap.g1 , function(idx1,item1){
					var rslt = item1.prcs;
					var tp = rslt.substring(0,2);
					var myd_orgn_code = rslt.substring(2,12);
					var myd_orgn_Nm = mydataCommon.util.replace(rslt.substring(12));					
					$("#step4_3").css("display","none");				
					$("#loading").addClass("is-open");
					pageUnit.prop.initCnt = 0;
					if(tp == '01'){
						pageUnit.trn.contact01Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '02'){
						pageUnit.trn.contact02Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '03'){							
						pageUnit.trn.contact03Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '04'){
						pageUnit.trn.contact04Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '05'){
						pageUnit.trn.contact05Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '06'){
						pageUnit.trn.contact06Rslt(myd_orgn_code,myd_orgn_Nm);
					}else if(tp == '07'){
						pageUnit.trn.contact07Rslt(myd_orgn_code,myd_orgn_Nm);
					}
				});
			}else{
				mydataCommon.msg.alert({msg : resultMap.resp_mesg});
			}
		},
		contact01Rslt : function(org_code,gdsNm){
			console.log('은행-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150001Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					success : function(res){
						var resultMap = res.resultMap;

						var bnk_007 = resultMap.bnk_007;
						var irp_007 = resultMap.irp_007;

						if( (bnk_007 && bnk_007.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#bnk_007"); obj.show();
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');		
							$.each(bnk_007 && bnk_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[0]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[0]);
							});

							$("#bnk_lst_").remove();
							//$("#bnk_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(bnk_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact02Rslt : function(org_code,gdsNm){
			console.log('카드-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150002Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
					var resultMap = res.resultMap;
					
					var crd_007 = resultMap.crd_007;

					if( (crd_007 && crd_007.resp_gubn == "0") ){
						var obj = $("#crd_007"); obj.show();
						if(pageUnit.prop.initCnt == 0){
							obj.addClass("pt30");
							++pageUnit.prop.initCnt;
						}
						var head_main = obj.children('div');
						
						var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						var	bod_main_clone = obj.find('div.card-body');
						$.each(crd_007 && crd_007.g1 , function(idx1,item1){
							pageUnit.prop.rCnt[1]++;
							var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
							var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[1];
							addDivObj.attr("id",atr_id);
							addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.card_nm));
							addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.card_kind_nm));
							bod_main_clone.append(addDivObj.show());
							acntCnt.text(pageUnit.prop.rCnt[1]);
						});

						$("#crd_lst_").remove();
						//$("#crd_007").append(bod_main_clone);
					}else{						
						pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						$("#loading").find('p.err-msg').text(crd_007.resp_mesg);
					}
					
					pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact03Rslt : function(org_code,gdsNm){
			console.log('금투-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150003Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;

						var sec_007 = resultMap.sec_007;
						var irp_007 = resultMap.irp_007;

						if( (sec_007 && sec_007.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#sec_007"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(sec_007 && sec_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');								
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[2]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[2]);
							});

							$("#sec_lst_").remove();
							//$("#sec_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sec_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact04Rslt : function(org_code,gdsNm){
			console.log('보험-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150004Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					success : function(res){
						var resultMap = res.resultMap;

						var ins_007 = resultMap.ins_007;
						var ins_008 = resultMap.ins_008;						
						var irp_007 = resultMap.irp_007;
						
						pageUnit.prop.subCnt[3] = 0;
						if( (ins_007 && ins_007.resp_gubn == "0") || (ins_008 && ins_008.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#ins_007"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(ins_007 && ins_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.insr_kind_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});
							
							$.each(ins_008 && ins_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.loan_gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[3]);
							});

							$("#ins_lst_").remove();
							//$("#ins_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ins_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact05Rslt : function(org_code,gdsNm){
			console.log('전금-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150006Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					success : function(res){
						var resultMap = res.resultMap;

						var ele_007 = resultMap.ele_007;
						var ele_008 = resultMap.ele_008;
						
						pageUnit.prop.subCnt[4] = 0;
						if( (ele_007 && ele_007.resp_gubn == "0") || (ele_008 && ele_008.resp_gubn == "0") ){
							var obj = $("#ele_007"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(ele_007 && ele_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.fob_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.fob_id));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[4]);
							});
							
							$.each(ele_008 && ele_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[4];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.efnc_acct_id));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.efnc_orgn_acct_id));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[4]);
							});

							$("#ele_lst_").remove();
							//$("#ele_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(ele_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact06Rslt : function(org_code,gdsNm){
			console.log('할부금융-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150005Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;
						
						var rnt_007 = resultMap.rnt_007;

						if( (rnt_007 && rnt_007.resp_gubn) == "0" ){
							var obj = $("#rnt_007"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(rnt_007 && rnt_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[5]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[5];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.myd_gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[5]);
							});


							$("#rnt_lst_").remove();
							//$("#rnt_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(rnt_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact07Rslt : function(org_code,gdsNm){
			console.log('보증보험-001');
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150007Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					success : function(res){
						var resultMap = res.resultMap;
						
						var sin_007 = resultMap.sin_007;

						if( (sin_007 && sin_007.resp_gubn) == "0" ){
							var obj = $("#sin_007"); obj.show();
							if(pageUnit.prop.initCnt == 0){
								obj.addClass("pt30");
								++pageUnit.prop.initCnt;
							}
							var head_main = obj.children('div');
							
							var acntCnt = head_main.find('div.card-head').find('span:eq(1)');
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							var	bod_main_clone = obj.find('div.card-body');
							$.each(rnt_007 && rnt_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[6]++;
								var addDivObj = bod_main_clone.find('dl:eq(0)').clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[6];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.insr_cntr_no));
								bod_main_clone.append(addDivObj.show());
								acntCnt.text(pageUnit.prop.rCnt[6]);
							});

							$("#ele_lst_").remove();
							//$("#sin_007").append(bod_main_clone);
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
							$("#loading").find('p.err-msg').text(sin_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		goPri : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0102", callback:"callback_callMoveView",viewType:"full"});
		},
		goto_newAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"475"});
		},
		goto_getAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"446"});
		}
		
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.prop.map = new Map();
		pageUnit.prop.map.put("bnk",new Map());
		pageUnit.prop.map.put("sec",new Map());
		pageUnit.prop.map.put("ins",new Map());
		pageUnit.prop.map.put("crd",new Map());
		pageUnit.prop.map.put("rnt",new Map());
		pageUnit.prop.map.put("ele",new Map());
		pageUnit.prop.map.put("sin",new Map());
		
		pageUnit.prop.data = mydataCommon.util.getData("org_cd");
		pageUnit.eventBind();
		pageUnit.trn.getList();		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#next").off("click").on("click", function(){
			pageUnit.fn.next();
		})
		
		$("#chk_8").off("click").on("click", function(){
			pageUnit.fn.checkAll(this);
		});
		
		$('#step4_4 ul.check-list').find('input:checkbox').off("click").on("click", function(){
			var thisObj = $(this);
			//thisObj.is(":checked")?thisObj.val("Y"):thisObj.val("N");
			$("#"+thisObj.attr("id") ).prop("checked",false);
			
			var id = thisObj.attr("id").substring(4,6);
			pageUnit.prop.id = id;
			$('#tab_'+id).addClass('is-selected').siblings().removeClass('is-selected');			
			$('#' + $('#tab_'+id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');			
			
			$("#step4_4").css("display","none");
			$("#step4_5").addClass("is-open");
			
			pageUnit.fn.clickChk();
			
		});
		
		$("#agre_chk").off("click").on("click", function(){
			pageUnit.prop.id= $('#tab_'+pageUnit.prop.id).attr("tp");
			$("#chk_"+pageUnit.prop.id ).prop("checked",true).val("Y");		
			if(pageUnit.prop.id =="08"){
				pageUnit.prop.id = "06";
			}else{
				pageUnit.prop.id = $('#tab_'+pageUnit.prop.id).next().attr("tp");	
			}
			$('#tab_'+pageUnit.prop.id).addClass('is-selected').siblings().removeClass('is-selected');			
			$('#' + $('#tab_'+pageUnit.prop.id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');
											
			pageUnit.fn.clickChk();
		});
		/*
		$("#step4_4 [id^='chk_0']").off("click").on("click", function(){
			pageUnit.fn.clickChk();
		});
		*/
		$("#ind_apnd").off("click").on("click",function(){
			pageUnit.trn.goPri();
		});
		
		$("#tot_apnd").off("click").on("click",function(){
			pageUnit.fn.sendTo();
		});		
		
		$("#agree_view2").off("click").on("click", function() {
			$('article').removeClass("is-open");	
			$("#step4_0").css("display","none");
			$("#step4_1").css("display","");
			
		});
		$("#step4_1 .sub-close").off("click").on("click", function() {
			$('article').removeClass("is-open");
			$("#step4_1").css("display","none");
			$("#step4_0").css("display","");			
		});
		$("input:radio[name='use_agree2']").off("click").on("click",function(e){
			if($(this).val()=="Y"){
				$("#agreerqst2").prop("disabled",false);
			}else{
				 mydataCommon.msg.confirm({msg : "거부 권리 및 불이익 안내",msg2 : "개인(신용)정보 수집·이용에 관한 동의를 거부 하실 수 있습니다.다만  수집·이용에 관한 동의는 본인 신용정보 통합조회 서비스 이용을 위한 필수적인 사항이므로 동의 거부하실 경우 서비스 이용이 제한될 수 있습니다.", callBackFn : function(isConfirm){
				      if(isConfirm){
				    	  $("#agreerqst2").prop("disabled",true);
				      }else{
				    	  $('input:radio[name="'+e.target.name+'"][value="Y"]').prop("checked",true);
				    	  $("#agreerqst2").prop("disabled",false);
				      }
			     }});
			}
		});
		
		$("#priAuth a.sub-link").off("click").on("click",function(){
			$("#pri_tp").val($(this).attr("id"));
			pageUnit.trn.setAgree_5();
		});
		
		$("#setRqst").off("click").on("click",function(){//임시
			pageUnit.trn.setAgree_4();
		});
		
		$("#agreerqst2").off("click").on("click", function() {			
			pageUnit.trn.goStep5();
		});
		
		$("#go_step4").off("click").on("click", function() {
			 pageUnit.trn.goStep4();			
        });
		
		 $("#go_step5").off("click").on("click", function() {
			 pageUnit.trn.goStep5();
			
         });
		 
		 $("#goto_my").off("click").on("click",function(){
			  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"MY0101", callback:"", viewType:""});
		 });
		 
		 $("#step4_2_prc").off("click").off("click").on("click", function() {
			 pageUnit.trn.setAgree1(pageUnit.prop.selCd2 ,pageUnit.prop.selNm2);		
		 });
		 
		 $("#step4_5 .modal-close").off("click").on("click", function() {
				$('article').removeClass("is-open");			
				$("#step4_4").css("display","");	
			});
		 
		 $("#step4_5 [id^='tab_']").off("click").on("click", function(){
				var id  = $(this).attr("id");
				pageUnit.prop.id = id.substring(4,6);
				$('#tab_'+pageUnit.prop.id).addClass('is-selected').siblings().removeClass('is-selected');			
				$('#' + $('#tab_'+pageUnit.prop.id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');
		 });
		/*	
		$($('#step4_4 ul.check-list').find('a.icon-link')).off("click").on("click", function(){
			var id = $(this).attr("id");
			pageUnit.prop.id = id;
			$('#tab_'+id).addClass('is-selected').siblings().removeClass('is-selected');			
			$('#' + $('#tab_'+id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');			
			$("#step4_5").addClass("is-open");
		});
		*/
		
		
		 
		 $("#step4_2_prev").off("click").off("click").on("click", function() {
			 $('article').removeClass("is-open");
			 $('#step4_2').css("display","none");
			 $('#step4_0').css("display","");	
		 });	
		 $("button.sub-prev").off().on("click",function(){
			 var id = $(this).closest('div.page-wrapper').attr("id");
			 if(id =="step2"){
				 mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"" ,popClose:true});
			 }else if(id =="step3"){
				 mydataCommon.msg.confirm({msg : "금융기관 연결을 취소 하시겠습니까?",msg2 : "금융 기관 연결이 완료되지 않았습니다. 다음에 연결 시 처음부터 다시 진행하셔야 합니다.", callBackFn : function(isConfirm){
				      if(isConfirm){
				    	  mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"" ,popClose:true});
				      }
			     }});
			 }else if(id =="step5"){
				 mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"" ,popClose:true});
			 }else if(id == "step4_0"){
				 $('article').removeClass("is-open");
				 $('#step4_0').css("display","none");
				 $('#step3').css("display","");
			 }else if(id == "step4_2"){
				 $('#step4_2').css("display","none");
				 $('#step4_0').css("display","");	
			 }else if(id == "step4_3"){
				 $('article').removeClass("is-open");
				 $('#step4_3').css("display","none");	
				 $('#step4_2').css("display","");	
			 }else if(id == "step4_4"){
				 $('article').removeClass("is-open");
				 $('#step4_4').css("display","none");
				 $('#step4_3').css("display","");	
			 }
			 else{			 
				 var cnt = id.substring(4,5);
				 var prev = Number(id.substring(4,5))-1;
				 $("#"+id).removeClass("is-open");
				 $("#step"+prev).addClass("is-open");
			 }
		 });
		 
		 $("#newAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_newAuth();
         });
		 $("#getAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_getAuth();
         });
		 
		 $(document).on('click','#pubAuthList a.sub-link',function(idx,item){
			 pageUnit.prop.pubNum = $(this).data("num");
			 $('#step4_4 ul.check-list').find('input:checkbox').each(function(){
					var thisObj = $(this); 
					thisObj.prop('checked',false);
				});
				
				 //$('article').removeClass("is-open");
				 $('#step4_3').css("display","none");	
				 $('#step4_4').css("display","");	
				 
		 });
		 
		$(document).on('click','#step3 input[type=checkbox]',function(idx){
			
			 var id = $(this).closest('section').attr('id');
			 var isChecked =$("#"+id+ " input:checked");			 
			 var checkedLen = isChecked.length;
			 //var subCnt = $("#"+id).find('div.card-head').find('p.font-12');
			 //subCnt.children('span:eq(0)').text(checkedLen);

			 var idSplit = id.split("_");
			 var subMap = pageUnit.prop.map.get(id);
			 var orgSplit = $(this).val().split("|");
			 var orgArray = subMap.get(orgSplit[1]);
			 if($(this).is(":checked")){				
				 orgArray.push($(this).val());
			 }else{
				 subMap.arrayRemove(orgSplit[1],$(this).val());
			 }
			 pageUnit.fn.toCntChk($(this));			
		 });
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		callback_getSendCertData : function(cData){
			//alert(JSON.stringify(cData));
			var obj = $("#pubAuthList").children();
			$("#pubAuthList").append('<script id="pubAuthListTemplate" type="text/x-jquery-tmpl">');			
			$("#pubAuthListTemplate").append(obj);
			
			$.each(cData.CertData,function(i,item){
				item.idx = i;
			});
			
			$("#pubAuthListTemplate").tmpl(cData.CertData).appendTo("#pubAuthList");
		},
		toCntChk : function(obj){
			 if($("#step3 input:checked").length > 200 && obj.is(":checked")){
				mydataCommon.msg.confirm({msg : "계좌(상품) 전제를 연결하시겠습니까?",msg2 : "선택하신 계좌(상품)이 [200]개를 초과하여 현재 조회된 모든 계좌(상품)을 연결합니다.", callBackFn : function(isConfirm){
			      if(isConfirm){
			    	  $('#step3').find('input:checkbox').each(function(){
							var thisObj = $(this); 							
							var id= $(this).closest('section').attr('id');
							if($("#"+id).is(":visible")){
								if(!thisObj.is(":checked")){
									 //var idSplit = id.split("_");
									 var subMap = pageUnit.prop.map.get(id);
									 var orgSplit = $(this).val().split("|");
									 var orgArray = subMap.get(orgSplit[1]);
									 orgArray.push($(this).val());
									 thisObj.prop('checked',true);
									 console.log('subMap='+subMap.size()+"*"+subMap.get(orgSplit[1]));
								}
							}
							 var isChecked =$("#"+id+ " input:checked");			 
							 var checkedLen = isChecked.length;
							 var subCnt = $("#"+id).find('div.card-head').find('p.font-12');
			
							 subCnt.children('span:eq(0)').text(checkedLen);							
						});
			    	  $("#go_step4").attr("disabled",false);
			      }else{
			    	  $("#go_step4").attr("disabled",true);
			      }
			    }});
			}else if($("#step3 input:checked").length > 0 && $("#step3 input:checked").length <= 200 ){$("#go_step4").attr("disabled",false);}
			 else {$("#go_step4").attr("disabled",true);}
		},/*
		checkAll : function(Obj){
			$('#step4_4 ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',$(Obj).is(":checked"));
				$(Obj).is(":checked")?thisObj.val("Y"):thisObj.val("N");
			});
			pageUnit.fn.clickChk();
		},*/		
		clickChk : function(){			
			($("#step4_4 [id^='chk_0']:checked").length)==3?($("#next").prop("disabled",false)):($("#next").prop("disabled",true));						
		},
		next : function(){
			pageUnit.trn.setAgree2();
			/*
			var isSuccess = !mydataCommon.vald.validation({target : $("#step4_4 ul.check-list"),immedtAlertPop:true});
			if(isSuccess){
				pageUnit.trn.setAgree2();				
			}
			*/
		},
		callCertMydataSign : function(resultMap){
			
			var strSigning = {strSigning : resultMap, index:pageUnit.prop.pubNum};
			var obj = {command : "getCertMydataSign" , param:strSigning ,callback: "pageUnit.fn.callback_getCertMydataSign"};
			
			var totCnt = resultMap.length;
			pageUnit.prop.process = 100%totCnt;
			pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;						
			var authData = JSON.stringify(obj);
			console.log(authData);
			if(pageCom.prop.isIPHONE)
			{
			   authData = encodeURIComponent(authData);
			   window.location = "mydata://"+authData;
			}
			else if(pageCom.prop.isANDROID)
			{
			   document.location.href = "mydata://"+authData;
			}
			
			/*  
			var totCnt = resultMap.length;
			pageUnit.prop.process = 100%totCnt;
			pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
			console.log(JSON.stringify(resultMap));
			console.log('pageUnit.prop.process start='+pageUnit.prop.process);
			console.log('pageUnit.prop.div start='+pageUnit.prop.div);
			var data = JSON.parse('{ "signedDataList" : [{"orgCode":"A1AAER0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}] , "caOrg":"SignKorea"}');//은행 {"orgCode":"C1AACN0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"},,{"orgCode":"C1AABR0000","signedPersonInfoReq":"서명값1","signedConsent":"서명값2"}
			pageUnit.fn.callback_getCertMydataSign(data);
			*/
		},
		callback_getCertMydataSign : function(obj){
			var data = obj;
			$(data.signedDataList).each(function(idx,item){								
				data.signedDataList[idx].caOrg = data.caOrg;
				setTimeout(function(){pageUnit.trn.sendToRslt(data.signedDataList[idx]);},idx*100);
			});
		},
		dataView : function(resultMap){
			var obj = $('#step2 section');
			//if(pageUnit.prop.cnt == 0) obj.addClass("no-border");
			var data = pageUnit.prop.data;
			obj.children('h2').find('span').text(data.substring(data.lastIndexOf("|")+1));
			obj.children('p:eq(0)').text(resultMap.token_iss_tp=="01"?"연결방식 :개별인증":resultMap.token_iss_tp=="02"?"연결방식 :통합인증":"");	
			var dataBody = obj.children('table:eq(1)').find('tbody');
			
			dataBody.children('tr:eq(0)').children('td').text(mydataCommon.util.getStrDate(resultMap.strt_dt,'.'));//
			dataBody.children('tr:eq(1)').children('td').text(mydataCommon.util.getStrDate(resultMap.end_dt,'.'));//전송요구내역 종료
			dataBody.children('tr:eq(2)').children('td').text(mydataCommon.util.replace(resultMap.send_prps_cntn));
			dataBody.children('tr:eq(3)').children('td').text(resultMap.rglr_send_yn);//
			dataBody.children('tr:eq(4)').children('td').text(mydataCommon.util.getStrDate(resultMap.poss_expr_dt,'.'));//
			$("#info_cntn").text(mydataCommon.util.replace(resultMap.info_cntn));
			$("#chac_cntn").text(mydataCommon.util.replace(resultMap.chac_cntn));
			
									
			var listMain = obj.children('table:eq(0)').find('tbody');			
			$.each(resultMap && resultMap.g1 , function(idx1,item1){
				var addDivObj = listMain.find('tr:eq(0)').clone();
				addDivObj.find('th').html('<p>'+item1.gds_nm+'</p><p>'+item1.aset_inno+'</p>');
				addDivObj.find('td').text(mydataCommon.util.getStrDate(item1.up_time,'.'));				
				listMain.append(addDivObj.show());
			});
			listMain.find('tr:eq(0)').remove();
			obj.show();			
		},
		progressChk : function(){
			//console.log('process='+pageUnit.prop.process);
			$("#loading").find('p.fc-orange').text(pageUnit.prop.process+"%");
			if(pageUnit.prop.process == 100) {
				$("#loading").find('p.fc-orange').text("0%");
				pageUnit.prop.div = 0;
				pageUnit.prop.process = 0;
				$('article').removeClass("is-open");
				//$('#step3').addClass("is-open");
				$('#step2').css("display","none");
				$('#step3').css("display","");
				
				var obj = $('#step3 input[type=checkbox]');				
				 
				/*var id = obj.closest('div.module-box').attr('id');
				 var isChecked =$("#"+id+ " input:checked");			 
				 var checkedLen = isChecked.length;
				 var subCnt = $("#"+id).find('div.card-head').find('p.font-12');
				 				
				 subCnt.children('span:eq(0)').text(checkedLen);
				*/
				
				var cnt = 0;
				var titldId = "";
				$.each(obj,function(idx){
					 var id = $(this).closest('section.module-box').attr('id');				
					 //var idSplit = id.split("_");
					 var subMap = pageUnit.prop.map.get(id);					 
					 var orgSplit = $(this).val().split("|");
					 var orgArray = subMap.get(orgSplit[1]);
					 if($(this).is(":checked")){
						 //titldId = idSplit[2];
						 orgArray.push($(this).val());
						 cnt++;
					 }		
				});
				//$("#"+titldId).find('div.card-head').find('p').children('span:eq(0)').text(cnt);
				
			}
		},
		progressChk2 : function(){
			$("#loading").find('div.font-red').text(pageUnit.prop.process+"%");
			if(pageUnit.prop.process == 100) {
				$("#loading").find('div.font-red').text("0%");
				pageUnit.prop.div = 0;
				pageUnit.prop.process = 0;
				$('article').removeClass("is-open");
				$('#step4_4').css("display","none");
				$('#step5').css("display","");							
			}
		},
		setAgreeData : function(){		
			var mainMap = pageUnit.prop.map;			
			var keys = mainMap.getKeys();
			 console.log(keys);
			 pageUnit.prop.datas=[];
			 for(var i in keys){
				 var subMap = mainMap.get(keys[i]);
				 var orgCodes = subMap.getKeys();				
				 if(orgCodes.length > 0){
					 console.log("최초="+keys[i]);
					 for(var z in orgCodes){				
						 var gdsList = subMap.get(orgCodes[z]);
						 var orgNm = gdsList[0];						 						
						 for(var o=0 ; o< gdsList.length-1;o++){						
							 var gdsListSplit = gdsList[o+1].split("|");
							 pageUnit.prop.datas.push(gdsListSplit[1]+"|"+keys[i]+"|"+gdsListSplit[0]+"|"+gdsListSplit[2]+"|"+gdsListSplit[3]+"|"+orgNm+(gdsListSplit[0]=="bnk001"?"|"+gdsListSplit[4]+"|"+gdsListSplit[5]:gdsListSplit[0]=="rnt001"?"|"+gdsListSplit[4]:""));
							 console.log(gdsListSplit[1]+"|"+keys[i]+"|"+gdsListSplit[0]+"|"+gdsListSplit[2]+"|"+gdsListSplit[3]+"|"+orgNm+(gdsListSplit[0]=="bnk001"?"|"+gdsListSplit[4]:""));
						 }						
					 }		
				 }
			 }
		},
		sendTo : function(){
			var data = pageUnit.prop.data;
			var myd_orgn_code = data.substring(0,10);
			var tp = data.substring(11,13);			
			var myd_orgn_Nm = mydataCommon.util.replace(data.substring(14));
			console.log('tp='+tp+','+myd_orgn_code+','+myd_orgn_Nm);
			
			var totCnt = 1;
			pageUnit.prop.process = 100%totCnt;
			pageUnit.prop.div = (100-pageUnit.prop.process)/totCnt;
			$("#loading").addClass("is-open");
			if(tp == '01'){								
				pageUnit.trn.contact01(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '02'){
				pageUnit.trn.contact02(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '03'){								
				pageUnit.trn.contact03(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '04'){
				pageUnit.trn.contact04(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '05'){
				pageUnit.trn.contact05(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '06'){
				pageUnit.trn.contact06(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '07'){
				pageUnit.trn.contact07(myd_orgn_code,myd_orgn_Nm);
			}	
		}
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
