var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		id : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		setAgree : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010011Ajax",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){							
							location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goList : function(){
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
		},
		goAgreeList : function(){
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010011P001Pop";
		}
	},
	// 단위 진입부 함수
	init : function(){
		mydataCommon.util.removeData("atp");
		/*
		var tp = mydataCommon.util.getData("atp");
		if(tp == "a"){
			$("#sm1").css("display","");
			$("#sm2").css("display","");
		}else if(tp=="1"){
			$("#sm1").css("display","");
		}else if(tp=="2"){
			$("#sm2").css("display","");
		}
		*/		
		pageUnit.eventBind();						
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		$("button.btn-footer").off("click").on("click", function(){
			var id  = $(this).attr("id");			
			mydataCommon.util.setData("atp",""+id.substring(0,4));
			//mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
			pageUnit.trn.goList();
			//pageUnit.prop.id = id.substring(4,6);
			//$('#tab_'+pageUnit.prop.id).addClass('is-selected').siblings().removeClass('is-selected');			
			//$('#' + $('#tab_'+pageUnit.prop.id).attr('aria-controls')).addClass('is-selected').siblings('.tab-panel').removeClass('is-selected');
		});
		
		$("#next").off("click").on("click", function(){			
			pageUnit.fn.next();
		});		
		
		$("#chk_8").off("click").on("click", function(){
			pageUnit.fn.checkAll(this);
		});
		
		$("#modal_full-popup button.modal-prev").off("click").on("click", function(){
			pageUnit.trn.goList();
		});	
		
		$("#step5 button.modal-prev").off("click").on("click", function(){
			$('article').removeClass("is-open");
			$("#modal_full-popup").addClass("is-open");	
		});	
		
		$("#agree").off("click").on("click", function(){
			pageUnit.trn.setAgree();
		});	
		/*
		$("#submain [id^='chk_0']").off("click").on("click", function(){
			($("[id^='chk_0']:checked").length)==2?($("#chk_8").prop("checked",true)):($("#chk_8").prop("checked",false));
		});	
		*/		
	},
	// 단위 전용 함수 모음 패키지
	fn : {				
		next : function(){
			if($("#sm2").is(":visible")){
				 $("#mrkt_yn").val("Y");
			}
			mydataCommon.msg.confirm({msg : "마케팅 정보 활용 동의",msg2 : "(선택) 마이데이터 정보이용에 대한 마케팅 등 정보 활용 동의<br>고객님께서 동의하시면 마이데이터 고객의 자산을 분석한 정보 및 자산활용방법에 대한 정보 수신을 하실 수 있습니다. 수신 거부 하시면 마이데이터의 서비스 이용에는 지장이 없으시며 원하실 경우 언제든지 마이데이터 마케팅 활용 동의에 대한 철회를  하실 수 있습니다.",cancleBtnText:"거부",confirmBtnText:"동의함", callBackFn : function(isConfirm){
			      if(isConfirm){
			    	  $("#mrkt_yn").val("Y");
			      }else{
			    	  $("#mrkt_yn").val("N");
			      }
		        $('article').removeClass("is-open");
				$("#step5").addClass("is-open");	
		     }});
		},
		checkAll : function(Obj){
			$('ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',$(Obj).is(":checked"));
				$(Obj).is(":checked")?thisObj.val("Y"):thisObj.val("N");
			});
			pageUnit.fn.clickChk();
		},
		clickChk : function(){
			$("#chk_01").is(":checked")?($("#next").prop("disabled",false)):($("#next").prop("disabled",true));
		}
	
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
