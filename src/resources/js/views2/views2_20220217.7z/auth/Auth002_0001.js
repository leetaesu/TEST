var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		tab_panel : []
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList1 : function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020001Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){							
							pageUnit.fn.dataView1(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getList2 : function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020002Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView2(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getList3 : function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020003Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView3(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getList4: function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020004Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView4(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getList5 : function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020005Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView5(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getList6 : function(activeTab){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0020006Ajax",
					data : {tab:activeTab},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView6(resultMap,activeTab);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList1 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020001Ajax",
					data : {orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList1(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList2 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020002Ajax",
					data : {myd_orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList2(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList3 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020003Ajax",
					data : {myd_orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList3(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList4 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020004Ajax",
					data : {myd_orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList4(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList5 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020005Ajax",
					data : {orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList5(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		setList6 : function(data,tabGb){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/UAuth0020006Ajax",
					data : {myd_orgn_code:data},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.getList6(tabGb);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		}
	},
	// 단위 진입부 함수
	init : function(){	
		pageUnit.prop.tab_panel["tab_panel01"] = $("#tab_panel01").clone(true);
		pageUnit.prop.tab_panel["tab_panel02"] = $("#tab_panel02").clone(true);
		pageUnit.prop.tab_panel["tab_panel03"] = $("#tab_panel03").clone(true);
		pageUnit.prop.tab_panel["tab_panel04"] = $("#tab_panel04").clone(true);
		pageUnit.prop.tab_panel["tab_panel05"] = $("#tab_panel05").clone(true);
		pageUnit.prop.tab_panel["tab_panel06"] = $("#tab_panel06").clone(true);
		
		pageUnit.eventBind();
		pageUnit.fn.tabChk();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		$("#lists [id^='tab_']").off("click").on("click",function(){
			var id = $(this).attr("id");
			 $("#"+id).addClass('is-selected').siblings().removeClass('is-selected');
			
			var subId = $('#'+$("#"+id).attr('aria-controls')).attr("id");
			var sch = $("#lists [id^='tab_panel']");
			$.each(sch,function(){
				var sid = $(this).attr("id");
				if(subId == sid){
					$("#"+sid).addClass('is-selected');
				}else{
					$("#"+sid).removeClass('is-selected');
				}
			});
			 pageUnit.fn.tabChk();
		});
		$(document).on('click','a.cp',function(idx){
			mydataCommon.util.clibBoard($(this).text());
			/*
			var inp = document.createElement("input");
				inp.setAttribute("id","copy");
				document.body.appendChild(inp);
				inp.value = $(this).text();
				inp.select();
				document.execCommand('Copy');
				document.body.removeChild(inp);
			mydataCommon.appBridge.openToast("계좌 번호를 복사 하였습니다.");
			 */
		});
		$(document).on('click','[id^="tab_panel"] button.btn-round',function(idx){
			var data = $(this).data("info");
			var tabGb = $(this).data('tabGb');
			//alert($(this).text());
			var msg = "";
			var msg2 = "";
			if($(this).text() == "숨기기"){
				msg = "목록에서 제외 하시겠습니까?";
				 if(tabGb=="tab_01"){
					 msg2 = "뱅킹 현황에서 해당 자산을 숨기게 되며 자산 합계 금액에서 제외됩니다.";
				 }else if(tabGb=="tab_02"){
					 msg2 = "투자 현황에서 해당 자산을 숨기게 되며 자산 합계 금액에서 제외 됩니다.(해당 계좌에서 투자한 상품도 함께 제외)";
				 }else if(tabGb=="tab_03"){
					 msg2 = "대출 현황에서 해당 자산을 숨기게 되며 자산 합계 금액에서 제외됩니다.";
				 }else if(tabGb=="tab_04"){
					 msg2 = "보험 현황에서 해당 자산을 숨기게 되며 자산 합계 금액에서 제외됩니다.";
				 }else if(tabGb=="tab_05"){
					 msg2 = "연금 현황에서 해당 자산을 숨기게 되며 자산 합계 금액에서 제외 됩니다.(해당 계좌에서 운영중인 상품도 함께 제외)";
				 }else if(tabGb=="tab_06"){
					 msg2 = "카드 현황에서 해당 자산을 숨기게 되며 승인 내역 금액에서 제외됩니다.";
				 }								
			}else{
				msg = "목록에서 포함 하시겠습니까?";
				if(tabGb=="tab_01"){
					 msg2 = "뱅킹 현황에서 해당 자산이 보여지게 되며 자산 합계 금액에 포함됩니다.";
				 }else if(tabGb=="tab_02"){
					 msg2 = "투자 현황에서 해당 자산이 보여지게 되며 자산 합계 금액에 포함 됩니다.(해당 계좌에서 투자한 상품도 함께 포함)";
				 }else if(tabGb=="tab_03"){
					 msg2 = "대출 현황에서 해당 자산이 보여지게 되며 자산 합계 금액에 포함됩니다.";
				 }else if(tabGb=="tab_04"){
					 msg2 = "보험 현황에서 해당 자산이 보여지게 되며 자산 합계 금액에 포함됩니다.";
				 }else if(tabGb=="tab_05"){
					 msg2 = "연금 현황에서 해당 자산이 보여지게 되며 자산 합계 금액에 포함 됩니다.(해당 계좌에서 운영중인 상품도 함께 포함)";
				 }else if(tabGb=="tab_06"){
					 msg2 = "카드 현황에서 해당 자산이 보여지게 되며 승인 내역 합계 금액에 포함됩니다.";
				 }					
			}
			mydataCommon.msg.confirm({"msg" : msg ,"msg2" : msg2, callBackFn : function(isConfirm){
			      if(isConfirm){      
			    	 if(tabGb=="tab_01"){
			    		  pageUnit.trn.setList1(data,tabGb);
					 }else if(tabGb=="tab_02"){
						 pageUnit.trn.setList2(data,tabGb);
					 }else if(tabGb=="tab_03"){
						 pageUnit.trn.setList3(data,tabGb);
					 }else if(tabGb=="tab_04"){
						 pageUnit.trn.setList4(data,tabGb);
					 }else if(tabGb=="tab_05"){
						 pageUnit.trn.setList5(data,tabGb);
					 }else if(tabGb=="tab_06"){
						 pageUnit.trn.setList6(data,tabGb);
					 }
			      }
		    }});			
		 });		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		tabChk : function(){
			var obj = $("#lists");
			$.each(obj.children('div:eq(0)').find('ul'),function(idx,item){
				 var id = $(this).find("li.is-selected").attr("id");
				 if(id=="tab_01"){
					 pageUnit.trn.getList1(id);
				 }else if(id=="tab_02"){
					 pageUnit.trn.getList2(id);
				 }else if(id=="tab_03"){
					 pageUnit.trn.getList3(id);
				 }else if(id=="tab_04"){
					 pageUnit.trn.getList4(id);
				 }else if(id=="tab_05"){
					 pageUnit.trn.getList5(id);
				 }else if(id=="tab_06"){
					 pageUnit.trn.getList6(id);
				 }
				 
			 });
		},		
		dataView1 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			var itemTp = '';
			var itemName = '';
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
					$.each(rslt.g1 , function(idx1,item1){		
						if(itemTp != item1.tp){ 
							var addDivObj = obj.clone();
							addDivObj.attr("id",item1.orgn_code+"_"+item1.tp);
							if(idx1==0){
								addDivObj.addClass("pt30");
							}
							
							/*
							if(idx1==0){
								addDivObj.addClass("no-border");
								addDivObj.addClass("pt0");
							}else{
								addDivObj.addClass("pb20");
							}
							*/
							var nm=""; 
							
							switch(item1.tp){
							case '1' : nm="수시입출금"; break;
							case '2' : nm="예적금";  break;
							case '3' : nm="기타";  break;
							case '4' : nm="외화";  break;
							default : break;
							}	
							
							addDivObj.children('div').children('div.card-head').children('h3').text(nm);							
							itemTp= item1.tp;										
							$.each(rslt.g1 , function(idx2,item2){
								if(itemTp == item2.tp){
									var list_body = addDivObj.find('div.card-body:eq(0)');
									var list_body_clone = list_body.children('dl:eq(0)').clone();
									var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
									if(item2.hdn_yn == "Y"){
										list_body_clone.children('dt').addClass("error");
										button.text("보이기");
									}
									
									button.data("info",item2.orgn_code+"|"+item2.acnt_no+"|"+item2.acnt_sqno+"|"+(item2.hdn_yn == "Y"?"N":"Y"));
									button.data("tabGb",tmpId);
									list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item2.orgn_code+".png");
									list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(mydataCommon.util.replace(item2.gds_nm));
									list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(item2.acnt_no);
																		
									list_body.append(list_body_clone);									
								}
							});
							addDivObj.find('div.card-body:eq(0)').children('dl:eq(0)').remove();							
							$("#"+id).append(addDivObj);							
						}
					});
				$(obj).remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		},
		dataView2 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			var itemTp = '';
			var itemName = '';
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
					$.each(rslt.g1 , function(idx1,item1){		
						if(itemTp != item1.invt_gds_tp){ 
							var addDivObj = obj.clone();
							addDivObj.attr("id",item1.orgn_code+"_"+item1.invt_gds_tp);
							if(idx1==0){
								addDivObj.addClass("pt30");
							}
							/*
							if(idx1==0){
								addDivObj.addClass("no-border");
								addDivObj.addClass("pt0");
							}else{
								addDivObj.addClass("pb20");
							}
							*/
							var nm="";
							
							switch(item1.invt_gds_tp){
							case '01' : nm="국내주식"; break;
							case '02' : nm="해외주식";  break;
							case '03' : nm="현금성자산";  break;
							case '04' : nm="금융상품";  break;
							case '05' : nm="랩/ISA/신탁";  break;
							case '06' : nm="기타";  break;
							default : break;
							}
							
							addDivObj.children('div').children('div.card-head').children('h3').text(nm);
							itemTp= item1.invt_gds_tp;
							$.each(rslt.g1 , function(idx2,item2){
								if(itemTp == item2.invt_gds_tp){
									var list_body = addDivObj.find('div.card-body:eq(0)');
									var list_body_clone = list_body.children('dl:eq(0)').clone();
									var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
									if(item2.hide_yn == "Y"){
										list_body_clone.children('dt').addClass("error");
										button.text("보이기");
									}
									
									button.data("info",item2.invt_gds_tp+"|"+item2.orgn_code+"|"+item2.acnt_no+"|"+item2.acnt_sqno+"|"+(item2.hide_yn == "Y"?"N":"Y"));
									button.data("tabGb",tmpId);
									list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item2.orgn_code+".png");
									list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(mydataCommon.util.replace(item2.gds_nm));
									list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(item2.acnt_no);
																		
									list_body.append(list_body_clone);									
								}
							});
							addDivObj.find('div.card-body:eq(0)').children('dl:eq(0)').remove();
							$("#"+id).append(addDivObj);							
						}
					});
				$(obj).remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		},
		dataView3 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			var itemTp = '';
			var itemName = '';
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
					$.each(rslt.g1 , function(idx1,item1){		
						if(itemTp != item1.loan_tp){ 
							var addDivObj = obj.clone();
							addDivObj.attr("id",item1.orgn_code+"_"+item1.loan_tp);
							if(idx1==0){
								addDivObj.addClass("pt30");
							}
							/*
							if(idx1==0){
								addDivObj.addClass("no-border");
								addDivObj.addClass("pt0");
							}else{
								addDivObj.addClass("pb20");
							}
							*/
							var nm=""; 
							
							switch(item1.loan_tp){
							case '01' : nm="담보"; break;
							case '02' : nm="신용";  break;
							case '03' : nm="할부금융";  break;
							case '04' : nm="카드론";  break;
							case '05' : nm="기타";  break;
							case '06' : nm="보유리스";  break;
							default : break;
							}
							
							addDivObj.children('div').children('div.card-head').children('h3').text(nm);
							itemTp= item1.loan_tp;										
							$.each(rslt.g1 , function(idx2,item2){
								if(itemTp == item2.loan_tp){
									var list_body = addDivObj.find('div.card-body:eq(0)');
									var list_body_clone = list_body.children('dl:eq(0)').clone();
									var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
									if(item2.hdn_yn == "Y"){
										list_body_clone.children('dt').addClass("error");
										button.text("보이기");
									}
									
									button.data("info",(item2.hdn_yn == "Y"?"N":"Y")+"|"+item2.myd_acnt_no+"|"+item2.myd_orgn_code+"|"+item2.acnt_sqno+"|"+item2.job_tp+"|"+item2.loan_tp);
									button.data("tabGb",tmpId);
									list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item2.myd_orgn_code+".png");
									list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(mydataCommon.util.replace(item2.myd_gds_nm));
									list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(item2.myd_acnt_no);
																		
									list_body.append(list_body_clone);									
								}
							});
							addDivObj.find('div.card-body:eq(0)').children('dl:eq(0)').remove();
							$("#"+id).append(addDivObj);							
						}
					});
				$(obj).remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		},
		dataView4 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			var itemTp = '';
			var itemName = '';
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
					$.each(rslt.g1 , function(idx1,item1){
						if(itemTp != item1.insr_cls_tp){ 
							var addDivObj = obj.clone();
							addDivObj.attr("id",item1.myd_orgn_code+"_"+item1.insr_cls_tp);
							if(idx1==0){
								addDivObj.addClass("pt30");
							}
							/*
							if(idx1==0){
								addDivObj.addClass("no-border");
								addDivObj.addClass("pt0");
							}else{
								addDivObj.addClass("pb20");
							}
							*/
							
							var nm=""; 
							
							switch(item1.insr_cls_tp){
							case '01' : nm="보장보험"; break;
							case '02' : nm="저축보험";  break;
							case '03' : nm="자동차보험";  break;
							case '07' : nm="보증보험";  break;	
							default : break;
							}
							
							addDivObj.children('div').children('div.card-head').children('h3').text(nm);
							itemTp= item1.insr_cls_tp;										
							$.each(rslt.g1 , function(idx2,item2){
								if(itemTp == item2.insr_cls_tp){
									var list_body = addDivObj.find('div.card-body:eq(0)');
									var list_body_clone = list_body.children('dl:eq(0)').clone();
									var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
									if(item2.hide_yn == "Y"){
										list_body_clone.children('dt').addClass("error");
										button.text("보이기");
									}
									
									button.data("info",item2.myd_orgn_code+"|"+item2.insr_cntr_no+"|"+(item2.hide_yn == "Y"?"N":"Y")+"|"+item2.insr_cls_tp);
									button.data("tabGb",tmpId);
									list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item2.myd_orgn_code+".png");
									list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(mydataCommon.util.replace(item2.gds_nm));
									list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(item2.insr_cntr_no);
																		
									list_body.append(list_body_clone);									
								}
							});
							addDivObj.find('div.card-body:eq(0)').children('dl:eq(0)').remove();							
							$("#"+id).append(addDivObj);							
						}
					});
				$(obj).remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		},
		dataView5 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			var itemTp = '';
			var itemName = '';
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
					$.each(rslt.g1 , function(idx1,item1){		
						if(itemTp != item1.gds_tp){ 
							var addDivObj = obj.clone();
							addDivObj.attr("id",item1.orgn_code+"_"+item1.gds_tp);
							if(idx1==0){
								addDivObj.addClass("pt30");
							}
							/*
							if(idx1==0){
								addDivObj.addClass("no-border");
								addDivObj.addClass("pt0");
							}else{
								addDivObj.addClass("pb20");
							}
							*/
							var nm=""; 
							
							switch(item1.gds_tp){
							case '1' : nm="퇴직연금"; break;
							case '2' : nm="개인연금";  break;
							default : break;
							}	
							
							addDivObj.children('div').children('div.card-head').children('h3').text(nm);
							itemTp= item1.gds_tp;										
							$.each(rslt.g1 , function(idx2,item2){
								if(itemTp == item2.gds_tp){
									var list_body = addDivObj.find('div.card-body:eq(0)');
									var list_body_clone = list_body.children('dl:eq(0)').clone();
									var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
									if(item2.hdn_yn == "Y"){
										list_body_clone.children('dt').addClass("error");
										button.text("보이기");
									}
									
									button.data("info",item2.orgn_code+"|"+item2.acnt_no+"|"+(item2.hide_yn == "Y"?"N":"Y")+"|"+item2.gds_tp);
									button.data("tabGb",tmpId);
									list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item2.orgn_code+".png");
									list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(mydataCommon.util.replace(item2.gds_nm));
									list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(item2.acnt_no);
																		
									list_body.append(list_body_clone);									
								}
							});
							addDivObj.find('div.card-body:eq(0)').children('dl:eq(0)').remove();
							$("#"+id).append(addDivObj);							
						}
					});
				$(obj).remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		},
		dataView6 : function(resultMap,tmpId){
			var id = $("#"+($("#"+tmpId).attr("aria-controls"))).attr("id");
			$("#"+id).remove();
			var tmptab_panel01 = pageUnit.prop.tab_panel[id].clone(true);
			$('#lists').append(tmptab_panel01);			
			var rslt = resultMap;			
			var obj = $("#"+id).children('section.module-box:eq(0)');
			if( rslt && rslt.resp_gubn == "0"){
				$("#"+id).addClass("is-selected");
				obj.children('div').children('div.card-head').children('h3').text("보유카드");				
				obj.addClass("pt30");
				//obj.addClass("no-border");
				//obj.addClass("pt0");
				var list_body = obj.find('div.card-body:eq(0)');
					$.each(rslt.g1 , function(idx1,item1){						
						var list_body_clone = list_body.children('dl:eq(0)').clone();
						var button = list_body_clone.children('dd:eq(0)').children('button.btn-round');
						if(item1.hdn_yn == "Y"){
							list_body_clone.children('dt').addClass("error");
							button.text("보이기");
						}
						
						button.data("info",item1.myd_orgn_code+"|"+item1.card_id+"|"+(item1.hdn_yn == "Y"?"N":"Y"));
						button.data("tabGb",tmpId);
						list_body_clone.children('dt').children('div.icon-title').find('img').attr("src","/resources/images/icons/org/"+item1.myd_orgn_code+".png");
						list_body_clone.children('dt').children('div.icon-title').find('div').children('p:eq(0)').text(item1.card_kind_tp == '01'?"신용" : (item1.card_kind_tp == '02'?"체크":(item1.card_kind_tp == '03'?"소액신용체크":"")));
						list_body_clone.children('dt').children('div.icon-title').find('div').children('a').addClass('cp').text(mydataCommon.util.replace(item1.orgn_nm+" "+item1.card_nm));
															
						list_body.append(list_body_clone);					

					});
					list_body.children('dl:eq(0)').remove();
				$("#"+id).css("display","");
			}
			else{
				if(resultMap && resultMap.resp_code!="501724")
				mydataCommon.msg.alert({msg : rslt.resp_mesg});
			}
		}
	
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
