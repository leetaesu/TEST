var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		sTimer : null
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		sndSMS : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});
			var jsonObj = {
					url : pageCom.prop.contextPath + "/sendAuthPhone",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							if(!$("#authIn").is(":visible")){
								$("#authIn").show();
								$("#authIn")[0].scrollIntoView();
								$("#authIn").focus();
							}							
							pageUnit.fn.startTimer();
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		authSMS : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});		
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/authSMSChk",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;	
						if(resultMap && resultMap.resp_gubn == "0"){
							location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		}
	},
	// 단위 진입부 함수
	init : function(){	
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#sndSMS,#reSnd").off("click").on("click", function(){
			if($(this).attr("id")=="reSnd"){
				pageUnit.fn.stopTimer();
			}
			pageUnit.trn.sndSMS();
		});
		$("#next").off("click").on("click", function(){
			var isSuccess = !mydataCommon.vald.validation({target : $("#ci_agree"),immedtAlertPop:true});
			if(isSuccess){
				pageUnit.trn.authSMS();
			}			
		});
		$("input[name='ci_asnt_tp']").off("click").on("click", function(){
			if($(this).is(":checked")){$(this).val("Y");}
			else{ $(this).val("N");}
		});	
		
		$("select[name='tel_info'],select[name='hnph_th01_no']").off("change").on("change",function(){
			pageUnit.fn.isSndChk();
		});
		
		$("input[name='cust_flnm']").off("keyup").on("keyup", function(){
			pageUnit.fn.isSndChk();
		});	
		
		$("#hnph_th_no").off("click").on("click", function(){
			var datas = {keypadType : "2",keypadValue:$(this).val(),maxLength:"11",rId:"hnph_th_no"};
			mydataCommon.appBridge.openNumKeypad(datas,"pageUnit.fn.callback_getKeypadResult");
			//pageUnit.fn.isSndChk();
		});
		
		$("#auth_no").off("click").on("click", function(){
			var datas = {keypadType : "2",keypadValue:$(this).val(),maxLength:"8",rId:$(this).attr("id")};
			mydataCommon.appBridge.openNumKeypad(datas,"pageUnit.fn.callback_getKeypadResult");
			//pageUnit.fn.isAuthChk();
		});
		
		$("#chk_all").off("click").on("click", function(){
			pageUnit.fn.checkAll(this);
		});
		
		$("#ci_agree [id^='chk_']").off("click").on("click", function(){
			if($(this).is(":checked")){
				var id  = $(this).attr("id");
				if(id != 'chk_ci'){
					var subId = id.substring(4,6);
					$("#step1").css("display","none");
					$("article").removeClass("is-open");
					$("#agree_"+subId).addClass("is-open");					
				}				
			}
			pageUnit.fn.clickChk();
		});
		$('article .modal-prev').off("click").on("click", function(){
			$("article").removeClass("is-open");
			$("#step1").css("display","");
		});
		/*
		$("input[name='auth_no']").off("keyup").on("keyup", function(){
			pageUnit.fn.isAuthChk();
		});
		*/				
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		callback_getKeypadResult : function(jsonString){
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;
			$("#"+rId).val(nVal);
			if(rId == 'hnph_th_no'){
				pageUnit.fn.isSndChk();
			}else if(rId == 'auth_no'){
				pageUnit.fn.isAuthChk();
			}
		},
		startTimer : function(){			
			var setTime = 180;			
			pageUnit.prop.sTimer = setInterval(function(){
				var tm = Math.floor(setTime/60);
				var sec = ""+setTime%60;
				console.log(sec.length);
				sec = sec.length == 1 ? '0'+sec : sec
				$('span.clock').text(tm+":"+sec);
				setTime--;
				if(setTime<0){
					clearInterval(pageUnit.prop.sTimer);
				}
			},1000);
		},
		stopTimer : function(){
			clearInterval(pageUnit.prop.sTimer);
		},
		isSndChk : function(){
			if($("select[name='tel_info']").val() != "" && $("input[name='hnph_th_no']").val()!="" && $("input[name='cust_flnm']").val()!="" && ($("#ci_agree [id^='chk_']:checked").length)==6 ){
				var phone =  $("input[name='hnph_th_no'").val()+"";
				if(phone.length == 10 || phone.length == 11){
					$("#sndSMS").attr("disabled",false);
				}else{
					$("#sndSMS").attr("disabled",true);
				}
			}else{
				$("#sndSMS").attr("disabled",true);
			}
		},
		isAuthChk : function(){			
			var auth_no =  $("input[name='auth_no'").val()+"";
			if(auth_no.length == 6){
				$("#next").attr("disabled",false);
			}else{
				$("#next").attr("disabled",true);
			}
		},
		showNumKeypad : function(type,inData,mxlen){
			var obj = new Object();
			obj['keypadType'] = type;
			obj['keypadValue'] = inData;
			obj['maxLength'] = mxlen;
			
			if(pageCom.prop.isIPHONE)
			{
			   window.location = "iTransKeyS:"+obj;//handleOpenURL
			}
			else if(pageCom.prop.isANDROID)
			{
			   Window.MTranskey.setKey(obj);
			}
		},
		checkAll : function(Obj){
			$('#ci_agree').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',$(Obj).is(":checked"));
				$(Obj).is(":checked")?thisObj.val("Y"):thisObj.val("N");
			});
			pageUnit.fn.clickChk();
		},
		clickChk : function(){
			if($("#ci_agree [id^='chk_']:checked").length==6){
				$("#chk_all").prop("checked",true);				
			}else{
				$("#chk_all").prop("checked",false);
			}
			pageUnit.fn.isSndChk();
		}
	
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();		
});

var callback_getNumberKeyPad = function(jsonString){
	var json = JSON.parse(jsonString);
	alert(jsonString);
};
