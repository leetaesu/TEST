var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		id : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		setAgree : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010011Ajax",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){							
							location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getPInfo : function(){
			var data = mydataCommon.makeSerialParam({target : $("body")});			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/VAuth0010021View",
					data : data,
					async : false,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;	
						var resp_gubn = res.resp_gubn;
						if(resultMap && resp_gubn == "0"){
							//console.log(JSON.stringify(resultMap));
							//$("#rslt").append(resultMap.exprCntn);
						    var content = resultMap.exprCntn;
							$("#rslt").html($("#rslt").html(content).text());
							$("#submain").css("display","none");
							$("#step5").css("display","");
							
							if(res.wtListMap && res.wtListMap.resp_gubn =='0'){
								var obj = $("#wtd_list").children();
								$("#wtd_list").append('<script id="wtdListTemplate" type="text/x-jquery-tmpl">');			
								$("#wtdListTemplate").append(obj);							
								$("#wtdListTemplate").tmpl(res.wtListMap.g1).appendTo("#wtd_list");
							}
							
							if(res.jhListMap && res.jhListMap.resp_gubn =='0'){
								var obj = $("#jhd_list").children();
								$("#jhd_list").append('<script id="jhdListTemplate" type="text/x-jquery-tmpl">');			
								$("#jhdListTemplate").append(obj);							
								$("#jhdListTemplate").tmpl(res.jhListMap.g1).appendTo("#jhd_list");
							}
							
						}else{
							mydataCommon.msg.alert({msg : res.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goList : function(){
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
		},
		goAgreeList : function(){
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010011P001Pop";
		}
	},
	// 단위 진입부 함수
	init : function(){
		/*
		var atp = mydataCommon.util.getData("atp");				
		if(atp == "a"){
			$("#chk_8").prop("checked",true);
			pageUnit.fn.checkAll($("#chk_8"));
		}else if(atp == "1"){
			$("#chk_01").prop("checked",true);
			$("#chk_01").val("Y");
		}else if(atp == "2"){
			$("#chk_02" ).prop("checked",true);
			$("#mrkt_yn").val("Y");
			$("#chk_02").val("Y");
		}
		mydataCommon.util.removeData("atp");
		*/
		pageUnit.eventBind();						
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#next").off("click").on("click", function(){
			pageUnit.fn.next();
		});		
		
		$("#chk_8").off("click").on("click", function(){
			pageUnit.fn.checkAll($(this));
		});
		
		$("#submain button.sub-prev").off("click").on("click", function(){
			pageUnit.trn.goList();
		});	
		
		$("#step5 button.modal-close").off("click").on("click", function(){
			$('article').removeClass("is-open");
			$('step5').css("display","none");
			$("#submain").css("display","");
		});	
		
		$("#pop01").off("click").on("click", function(){
			alert(333)
		});	
		
		$("#pinfo").off("click").on("click", function(){
			//$("#submain").css("display","none");
			//$("#step5").addClass("is-open");
			pageUnit.trn.getPInfo();
		});	
		
		$("#submain [id^='chk_0']").off("click").on("click", function(){
			var thisObj = $(this);
			if(thisObj.is(":checked")){
				$("#"+thisObj.attr("id") ).prop("checked",false);				
				$("#submain").css("display","none");
				$("#sm"+thisObj.data("tp")).css("display","");
			}else{
				pageUnit.fn.clickChk();
			}
		});
		
		$('button.sub-close').off("click").on("click", function(){
			var id = $(this).closest('div.page-wrapper').attr("id");
			$("#"+id).css("display","none");
			if(id == "wtlist" || id =="jhlist"){
				$("#step5").css("display","");
			}else{
				$("#submain").css("display","");
			}
			
		});	
		
		$("div.btn-wrap [id^='next_']").off("click").on("click", function(){
			var id = $(this).prop("id").substring(5);
			/*
			if(id == "2"){
				 $("#mrkt_yn").val("Y");
			}
			*/
			$("#sm"+id).css("display","none");
			$("#chk_0"+id).prop("checked",true);
			$("#submain").css("display","");
			pageUnit.fn.clickChk();
		});	
		
		$(document).on('click','#pop01',function(){
			$("#step5").css("display","none");
			$("#wtlist").css("display","");
		 });
		
		$(document).on('click','#pop02',function(){
			$("#step5").css("display","none");
			$("#jhlist").css("display","");
		 });
	},
	// 단위 전용 함수 모음 패키지
	fn : {				
		next : function(){			
			pageUnit.trn.setAgree();
		},
		checkAll : function(Obj){
			$('ul.check-list').find('input:checkbox').each(function(){
				var thisObj = $(this); 
				thisObj.prop('checked',Obj.is(":checked"));
				thisObj.is(":checked")?thisObj.val("Y"):thisObj.val("N");				
			});
			pageUnit.fn.clickChk();
		},
		clickChk : function(){
			$("#chk_01").is(":checked")?($("#next").prop("disabled",false)):($("#next").prop("disabled",true));
			($("ul.check-list [id^='chk_0']:checked").length)==2?($("#chk_8").prop("checked",true)):($("#chk_8").prop("checked",false));			
		}
	
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
