var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {	
		msgSuc : [],
		msgFai : [],
		totCnt : 0,
		prcCnt : 0
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(inst_tp){
			//var data = mydataCommon.makeJsonParam({target : $("body")});
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0040001Ajax",
					data : {wst_yn:"Y"},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						pageUnit.fn.dataView(resultMap);	
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		sQuit : function(orgCd){
			var aryOrg = orgCd.split("|");
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0030003Ajax",
					data : {myd_orgn_code:aryOrg[0],infr_wst_yn:"Y"},
					async : false,
					success : function(res){
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.prop.msgSuc.push(aryOrg[1]);
						}else{
							pageUnit.prop.msgFai.push(aryOrg[1]);
						}
						pageUnit.prop.prcCnt++;
						pageUnit.fn.processChk();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		sAgree : function(){	
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0040002Ajax",
					data : '',
					async : true,
					success : function(res){
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});		
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
						
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		getAgreeInfo : function(){
			localStorage.setItem("lopopgb","l");
			location.href=pageCom.prop.contextPath +"/auth/VAuth0050003View";
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();				
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#s_quit").off("click").on("click",function(){
			mydataCommon.msg.confirm({msg : "약관을 철회 하고 서비스 해지 하시겠습니까?",msg2 : "마이데이터 서비스 이용 시 동의한 모든 약관을 철회하고 이용 동의를  해지 합니다. 서비스 해지 시 24시간 동안 서비스 재 이용이 불가능 합니다", callBackFn : function(isConfirm){
				if(isConfirm){					
					var ary = mydataCommon.util.getArrayData("cd");
					pageUnit.prop.totCnt = ary.length;
					if(pageUnit.prop.totCnt ==0){
						pageUnit.trn.sAgree();
					}else{
						$.each(ary,function(idx,item){
							console.log(idx);
							setTimeout(function(){pageUnit.trn.sQuit(item);},idx*300);
						});	
					}						
				}
			}});
			
		});		
		$("button.sub-prev").off().on("click",function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"" ,popClose:true});
		});
		
		$("section.module-box a.confirm-link").off("click").on("click", function(){			
			localStorage.setItem("svc_tp1",$(this).prop("id"));
			pageUnit.trn.getAgreeInfo();
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
		processChk : function(){			
			if(pageUnit.prop.prcCnt == pageUnit.prop.totCnt){
				if(pageUnit.prop.msgSuc.length != pageUnit.prop.totCnt){
					mydataCommon.msg.alert({msg : "해지 안된 기관이 존재합니다. 재 해지 신청 처리 진행바랍니다."});
					//mydataCommon.msg.alert({msg : "정상:["+pageUnit.prop.msgSuc.join(",")+"] 오류:["+pageUnit.prop.msgFai.join(",")+"]"});					
				}else{
					pageUnit.trn.sAgree();
				}
			}
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
