var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {	
		data : []
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(inst_tp){
			//var data = mydataCommon.makeJsonParam({target : $("body")});
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0040001Ajax",
					data : '',
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						pageUnit.fn.dataView(resultMap);	
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goCc : function(){			
			//location.href = pageCom.prop.contextPath + "/auth/VAuth0040002View";
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0402", callback:"callback_callMoveView", viewType:"half"});
		}
		
	},
	// 단위 진입부 함수
	init : function(){
		mydataCommon.util.removeData("cd");
		pageUnit.eventBind();
		pageUnit.trn.getList();
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){			
		$("#cncl").off("click").on("click",function(){
			 mydataCommon.msg.confirm({msg : "금융기관 전송 요구를 철회 하고 서비스 해지 하시겠습니까?",msg2 : "마이데이터 서비스 이용 시 연결된 금융기관 개인신용정보가 삭제되고 모든 전송요구가 철회 되어 더 이상 개인신용정보를 전송 받을 수 없습니다.", callBackFn : function(isConfirm){
			      if(isConfirm){
			    	  pageUnit.prop.data=[];
			    	  mydataCommon.util.removeData("cd");
			    	  var chk = $("#tst").find('p.orname');
						//alert($("div.main").find('input:checkbox:checked').length);
						$.each(chk,function(idx,item){		
							pageUnit.prop.data.push($(this).data("cd"));				
						});
						//mydataCommon.util.setData("cd",JSON.stringify(pageUnit.prop.data));
						mydataCommon.util.setArrayData("cd",pageUnit.prop.data);
						pageUnit.trn.goCc();
			      }
		     }});
		});
		$("#goto_my").off("click").on("click",function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"MY0101", callback:"", viewType:""});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
		dataView : function(resultMap){				
			var rslt = resultMap.rslt;						
			var obj = $("div.module-body");
			var bod_main_clone = obj.find("div:eq(1)");
			var itemCode = '';
			var itemName = '';
			if( (rslt && rslt[0].resp_gubn) == "0"){
				$("#cncl").attr("disabled",false);
				$.each(rslt , function(idx,item){
					$.each(rslt[idx].g1 , function(idx1,item1){
						var addDivObj = bod_main_clone.children('div:eq(0)').clone();									
						if(itemCode != item1.orgn_code){
							addDivObj.find('p.orname:eq(0)').text(mydataCommon.util.replace(item1.orgn_nm));
							addDivObj.find('p.orname:eq(0)').data("cd",item1.orgn_code+"|"+mydataCommon.util.replace(item1.orgn_nm));
							itemCode= item1.orgn_code;										
							$.each(rslt[idx].g1 , function(idx2,item2){
								if(itemCode == item2.orgn_code){
									itemName += '<p>'+mydataCommon.util.replace(item2.gds_nm)+'</p>';
								}
							});
							addDivObj.find('tbody').find('td').append(itemName);
							addDivObj.find('table').css("display","");
							itemName = "";
							bod_main_clone.append(addDivObj.show());
						}						
					});
				});
				bod_main_clone.children('div:eq(0)').remove();
				obj.append(bod_main_clone);
			}
			else{
				if(resultMap && resultMap.resp_code!="501724"){
					$("#cncl").attr("disabled",true);
					mydataCommon.msg.alert({msg : rslt[0].resp_mesg});
				}
			}
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
