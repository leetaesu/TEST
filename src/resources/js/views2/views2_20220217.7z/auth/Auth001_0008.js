var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		process : 0 ,
		div : 0,	
		rCnt : [0,0,0,0,0,0,0],
		tmpData: ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
	contact01 : function(org_code,gdsNm){
		console.log('은행-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060101Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;					
					console.log('start11');
					console.log(resultMap);
					console.log('end11');
					
					var bnk_001 = resultMap.bnk_001;
					var irp_001 = resultMap.irp_001;
					if( (bnk_001 && bnk_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
						pageUnit.trn.contact01Rslt(org_code,gdsNm);
					}else{							
						pageUnit.trn.contact01Rslt(org_code,gdsNm);
					}					
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact02 : function(org_code,gdsNm){
		console.log('카드-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060201Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
				var resultMap = res.resultMap;
				
				var crd_001 = resultMap.crd_001;
				
				console.log('start11');
				console.log(resultMap);
				console.log('end11');
					if( (crd_001 && crd_001[0].resp_gubn == "0")){					
						pageUnit.trn.contact02Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact02Rslt(org_code,gdsNm);
					}
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact03 : function(org_code,gdsNm){
		console.log('금투-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060301Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;
					
					
					console.log('start11');
					console.log(resultMap);
					console.log('end11');
					
					var sec_001 = resultMap.sec_001;
					var irp_001 = resultMap.irp_001;
				
					if( (sec_001 && sec_001[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
						pageUnit.trn.contact03Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact03Rslt(org_code,gdsNm);
					}					
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact04 : function(org_code,gdsNm){
		console.log('보험-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060401Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;

					console.log('start11');
					console.log(resultMap);
					console.log('end11');
					
					var ins_001 = resultMap.ins_001;
					var ins_008 = resultMap.ins_008;						
					var irp_001 = resultMap.irp_001;

					if( (ins_001 && ins_001[0].resp_gubn == "0") || (ins_008 && ins_008[0].resp_gubn == "0") || (irp_001 && irp_001.resp_gubn == "0") ){
						pageUnit.trn.contact04Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact04Rslt(org_code,gdsNm);
					}				
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact05 : function(org_code,gdsNm){
		console.log('전금-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060501Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;

					console.log('start11');
					console.log(resultMap);
					console.log('end11');

					var ele_001 = resultMap.ele_001;
					var ele_101 = resultMap.ele_101;

					if( (ele_001 && ele_001[0].resp_gubn == "0") || (ele_101 && ele_101[0].resp_gubn == "0") ){
						pageUnit.trn.contact05Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact05Rslt(org_code,gdsNm);
					}				
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact06 : function(org_code,gdsNm){
		console.log('할부금융-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060601Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;
					
					var rnt_001 = resultMap.rnt_001;
					var rnt_exd = resultMap.rnt_exd;
					
					console.log(resultMap);
					console.log('end11');
					if( (rnt_001 && rnt_001[0].resp_gubn == "0")){
						pageUnit.trn.contact06Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact06Rslt(org_code,gdsNm);
					}
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
	contact07 : function(org_code,gdsNm){
		console.log('보증보험-001'); console.log('org_code='+org_code);
		var jsonObj = {
				url : pageCom.prop.contextPath + "/auth/IAuth00100060701Ajax",
				data : {"myd_orgn_code" : org_code},
				async : true,					
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;

					console.log('start11');
					console.log(resultMap);
					console.log('end11');

					var sin_001 = resultMap.sin_001;

					if( (sin_001 && sin_001[0].resp_gubn == "0") ){
						pageUnit.trn.contact07Rslt(org_code,gdsNm);
					}else{
						pageUnit.trn.contact07Rslt(org_code,gdsNm);
					}				
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
		}
		mydataCommon.ajax(jsonObj);	
	},
		contact01Rslt : function(org_code,gdsNm){
			console.log('은행-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150001Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var bnk_007 = resultMap.bnk_007;
						var irp_007 = resultMap.irp_007;

						if( (bnk_007 && bnk_007.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#bnk_007"); obj.show();
							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							
							//var acntCnt = head_main.find('dd').find('span:eq(1)');						
							var	bod_main_clone = obj.children('div:eq(0)');					
							$.each(bnk_007 && bnk_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.gds_nm));
								$("#bnk_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[0]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[0]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[0];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.gds_nm));
								$("#bnk_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[0]);
							});

							console.log(bod_main_clone);
							obj.find('div:eq(0)').remove();
							//$("#bnk_007").append(bod_main_clone);
						}else{
							$("#loading").find('div.err-msg').text(bnk_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact02Rslt : function(org_code,gdsNm){
			console.log('카드-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150002Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
					var resultMap = res.resultMap;
					
					var crd_007 = resultMap.crd_007;
					
					console.log('start11');
					console.log(resultMap);
					console.log('end11');

					if( (crd_007 && crd_007.resp_gubn == "0") ){
						var obj = $("#crd_007"); obj.show();
						
						var head_main = obj.children('h3');
						head_main.children('span').text(gdsNm);
						
						//var acntCnt = head_main.find('dd').find('span:eq(1)');
						var	bod_main_clone = obj.children('div:eq(0)');					
						$.each(crd_007 && crd_007.g1 , function(idx1,item1){
							pageUnit.prop.rCnt[1]++;
							var addDivObj = bod_main_clone.clone();
							var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[1];
							addDivObj.attr("id",atr_id);
							addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
							addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.card_kind_nm));
							addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.card_nm));
							$("#crd_007").append(addDivObj.show());
							//acntCnt.text(pageUnit.prop.rCnt[1]);
						});
						console.log(bod_main_clone);
						obj.find('div:eq(0)').remove();
					}else{						
						$("#loading").find('div.err-msg').text(crd_007.resp_mesg);
					}
					
					pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact03Rslt : function(org_code,gdsNm){
			console.log('금투-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150003Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
												
						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var sec_007 = resultMap.sec_007;
						var irp_007 = resultMap.irp_007;

						if( (sec_007 && sec_007.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#sec_007"); obj.show();

							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							
							//var acntCnt = head_main.find('dd').find('span:eq(1)');
							var	bod_main_clone = obj.children('div:eq(0)');					
							$.each(sec_007 && sec_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.acnt_nm));
								$("#sec_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[2]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[2]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[2];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p').text(mydataCommon.util.replace(item1.acnt_tp));
								addDivObj.find('p').text(mydataCommon.util.replace(item1.gds_nm));
								$("#sec_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[2]);
							});

							console.log(bod_main_clone);
							obj.children('div:eq(0)').remove();
						}else{
							pageUnit.prop.process = pageUnit.prop.process+pageUnit.prop.div;
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact04Rslt : function(org_code,gdsNm){
			console.log('보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150004Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;

						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var ins_007 = resultMap.ins_007;
						var ins_008 = resultMap.ins_008;						
						var irp_007 = resultMap.irp_007;
						
						if( (ins_007 && ins_007.resp_gubn == "0" )|| (ins_008 && ins_008.resp_gubn == "0") || (irp_007 && irp_007.resp_gubn == "0") ){
							var obj = $("#ins_007"); obj.show();
							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							
							//var acntCnt = head_main.find('dd').find('span:eq(1)');
							var	bod_main_clone = obj.children('div:eq(0)');
							head_main.find('dt').find('p').text(gdsNm);
							$.each(ins_007 && ins_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.insr_kind_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.gds_nm));
								$("#ins_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[3]);
							});
							
							$.each(ins_008 && ins_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.loan_gds_nm));
								$("#ins_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[3]);
							});


							$.each(irp_007 && irp_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[3]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[3];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.gds_nm));
								$("#ins_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[3]);
							});

							console.log(bod_main_clone);
							obj.children('div:eq(0)').remove();
						}else{
							$("#loading").find('div.err-msg').text(ins_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact05Rslt : function(org_code,gdsNm){
			console.log('전금-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150006Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;

						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var ele_007 = resultMap.ele_007;
						var ele_008 = resultMap.ele_008;
						
						if( (ele_007 && ele_007.resp_gubn == "0") || (ele_008 && ele_008.resp_gubn == "0")){
							var obj = $("#ele_007"); obj.show();
							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							
							var	bod_main_clone = obj.children('div:eq(0)');
							head_main.find('dt').find('p').text(gdsNm);
							$.each(ele_007 && ele_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[4];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.fob_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.fob_id));
								$("#ele_007").append(addDivObj.show());
							});
							
							$.each(ele_008 && ele_008.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[4]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[4];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.efnc_acct_id));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.efnc_orgn_acct_id));
								$("#ele_007").append(addDivObj.show());
							});

							console.log(bod_main_clone);
							obj.children('div:eq(0)').remove();
						}else{
							$("#loading").find('div.err-msg').text(ele_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact06Rslt : function(org_code,gdsNm){
			console.log('할부금융-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150005Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						
						var rnt_007 = resultMap.rnt_007;
						
						console.log(resultMap);
						console.log('end11');
						if( (rnt_007 && rnt_007.resp_gubn == "0") ){
							var obj = $("#rnt_007"); obj.show();
							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							//var acntCnt = head_main.find('dd').find('span:eq(1)');
							var	bod_main_clone = obj.children('div:eq(0)');					
							$.each(rnt_007 && rnt_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[5]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[5];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.acnt_tp_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.myd_gds_nm));
								$("#rnt_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[4]);
							});

							console.log(bod_main_clone);
							obj.children('div:eq(0)').remove();
						}else{
							$("#loading").find('div.err-msg').text(rnt_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		},
		contact07Rslt : function(org_code,gdsNm){
			console.log('보증보험-001'); console.log('org_code='+org_code);
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth00100150007Ajax",
					data : {"myd_orgn_code" : org_code},
					async : true,					
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;

						console.log('start11');
						console.log(resultMap);
						console.log('end11');
						
						var sin_007 = resultMap.sin_007;
						
						if( (sin_007 && sin_007.resp_gubn == "0")){
							var obj = $("#sin_007"); obj.show();
							var head_main = obj.children('h3');
							head_main.children('span').text(gdsNm);
							
							//var acntCnt = head_main.find('dd').find('span:eq(1)');
							var	bod_main_clone = obj.children('div:eq(0)');
							head_main.find('dt').find('p').text(gdsNm);
							$.each(sin_007 && sin_007.g1 , function(idx1,item1){
								pageUnit.prop.rCnt[6]++;
								var addDivObj = bod_main_clone.clone();
								var atr_id = ""+addDivObj.attr("id")+pageUnit.prop.rCnt[6];
								addDivObj.attr("id",atr_id);
								addDivObj.find('img').attr('src','/resources/images/icons/org/'+org_code+'.png');
								addDivObj.find('p:eq(0)').text(mydataCommon.util.replace(item1.gds_nm));
								addDivObj.find('p:eq(1)').text(mydataCommon.util.replace(item1.insr_cntr_no));
								$("#sin_007").append(addDivObj.show());
								//acntCnt.text(pageUnit.prop.rCnt[3]);
							});
							
							console.log(bod_main_clone);
							obj.children('div:eq(0)').remove();
						}else{
							$("#loading").find('div.err-msg').text(sin_007.resp_mesg);
						}
						
						pageUnit.fn.progressChk2();
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);	
		}
	},
	// 단위 진입부 함수
	init : function(){		
		pageUnit.eventBind(); 	
		var rsltData = mydataCommon.util.getArrayData("indiRslt");		
		var resp_gubn = rsltData[0];	
		if(resp_gubn == "0"){
			$("#loading").addClass("is-open");
			var tp=rsltData[3];
			var myd_orgn_code = rsltData[4];
			var myd_orgn_Nm =  rsltData[2];
			console.log('tp='+tp+','+myd_orgn_Nm);
			if(tp == '01'){
				pageUnit.prop.tmpData = "BANK0101";
				pageUnit.trn.contact01(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '02'){
				pageUnit.prop.tmpData = "CARD0101";
				pageUnit.trn.contact02(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '03'){
				pageUnit.prop.tmpData = "INVE0101";
				pageUnit.trn.contact03(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '04'){
				pageUnit.prop.tmpData = "INSU0101";
				pageUnit.trn.contact04(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '05'){
				pageUnit.prop.tmpData = "INVE0101";
				pageUnit.trn.contact05(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '06'){
				pageUnit.prop.tmpData = "LOAN0101";
				pageUnit.trn.contact06(myd_orgn_code,myd_orgn_Nm);
			}else if(tp == '07'){
				pageUnit.prop.tmpData = "INSU0101";
				pageUnit.trn.contact07(myd_orgn_code,myd_orgn_Nm);
			}
		}else{
			$('article').removeClass("is-open");
			$("#step5").addClass("is-open");
			mydataCommon.msg.alert({msg : rsltData[1]});
		}
		
		
       
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		 $("button.modal-prev").off("click").on("click",function(){
			 location.href = pageCom.prop.contextPath + "/auth/VAuth0010002View";
		 });
		 
		 $("#goto_my").off("click").on("click",function(){/*추후 원복*/
			  //mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"MY0101", callback:"", viewType:""});
			 mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:pageUnit.prop.tmpData, callback:"", viewType:""});
		 });
		 
		 $("#goto_0101").off("click").on("click",function(){
			  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"", viewType:""});
		 });
		 
		 $("#goto_0301").off("click").on("click",function(){
			  mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0301", callback:"", viewType:""});
		 });
		 
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
		progressChk2 : function(){
			console.log('process='+pageUnit.prop.process);
			$('article').removeClass("is-open");
			$('#step5').addClass("is-open");
		}
	}
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});