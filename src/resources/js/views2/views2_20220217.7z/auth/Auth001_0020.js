var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {},
	// 단위 전용 통신함수 모음 패키지 
	trn : {
		goPage4 : function(){			
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010011View";		
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){		
		$("#back_step1,#prev_step1").off("click").on("click", function(){			
			mydataCommon.appBridge.webviewReq({command:"callSendViewData" ,popClose:true});
		});
		
		$("#go_exPage").off("click").on("click", function(){
			mydataCommon.util.setArrayData('mydata_cmm_data', {iframe: {title: '마이데이터종합포털', url: 'https://www.mydatacenter.or.kr:3441', viewtype: 'half'}});
		    mydataCommon.appBridge.webviewReq({command : "callMoveView",urlMapId : "IFRAME",viewType : 'half'});		    		    
		});
		
		$("#back_step2").off("click").on("click", function(){
			$('article').removeClass("is-open");
			$("#step2").addClass("is-open");	
		});
		
		$("#go_step3").off("click").on("click", function(){
			$('article').removeClass("is-open");
			$("#step3").addClass("is-open");
			$("#step3").css("display","");
		});	
		
		$("#go_step4").off("click").on("click", function(){
			pageUnit.trn.goPage4();
		});	
		
		$("#goHeroS").off("click").on("click", function(){
			//pageUnit.trn.getDB();
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {				
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
