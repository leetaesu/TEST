var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {},
	// 단위 전용 통신함수 모음 패키지 
	trn : {		
		step2 : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0120", callback:"", viewType:""});			
			//location.href="/auth/VAuth0010020View";
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		$("#go_step2").off("click").on("click", function(){
			pageUnit.trn.step2();
			/*
			$("#step1").css("display","none");
			$('article').removeClass("is-open");
			$("#step2").addClass("is-open");
			*/	
		});					
		
		$("#goHeroS").off("click").on("click", function(){
			//pageUnit.trn.getDB();
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {				
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
