//개인연금
var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			if(exeType == 'inqXmh1009q01'){
				var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0050001001Ajax",
					async : true,
					success : pageUnit.fn.set_section,
					error : pageUnit.fn.set_section_error
				}
				mydataCommon.ajax(jsonObj);	
			}
		},
		ypop : function(data){
			localStorage.setItem("svc_tp1",data);
			localStorage.setItem("lopopgb","p");
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0503", callback:"", viewType:"half"});
		}	
	},
	// 단위 진입부 함수
	init : function(){
		
		pageUnit.eventBind();		
		pageUnit.trn.ajax_call("inqXmh1009q01");
	},
	
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		//필수 동의팝업 확인버튼 
		$(".btn-footer").off("click").on("click", function(){
			KW_MOBILE.guiEvent.popup.closePop('#modal_full-popup');
		});			
	},
	fn : {		
		set_section : function(data){
			var outData = data.resultMap;
			outData.open_dt = mydataCommon.util.getStrDate(outData.open_dt);
			ao_html('#SingleInfo', outData);
		},
		set_section_personal_error : function(data){
			mydataCommon.util.log(['Auth005_0001.js :: req_error ----------> ', data]);
		},
	},
	
};

//선택이용동의 철회 링크
var btnSelectAgreeCncl= function (svc_tp){
	localStorage.setItem("svc_tp",svc_tp);
	mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0502", callback:"", viewType:"half"});
};


$(document).ready(function(){
	pageUnit.init();
});
window.onload = function(){
	localStorage.clear();
}



