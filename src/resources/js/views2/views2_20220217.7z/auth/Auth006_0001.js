var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		inst_tp : ['01','03','04','02','06','05','07'],
		cnt : 0,
		totCnt : 0,
		data : []
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(inst_tp){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0060001Ajax",
					data : {"inds_tp":inst_tp},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView(inst_tp,resultMap);							
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goCc : function(data){
			var snddata = null;
			if(data !=''){
				snddata = {org_code:data}
			}else{
				snddata = mydataCommon.makeSerialParam({target : $("body")});
			}			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0060001Ajax",
					data : snddata,
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap){
							mydataCommon.msg.alert({msg : resultMap.resp_mesg, callBackFn : function(){							
								var data = mydataCommon.makeJsonParam({target : $("body")});
								mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/auth/VAuth0060001View",data);
							}});	
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);
		}
		
	},
	// 단위 진입부 함수
	init : function(){
		
		pageUnit.eventBind();				
		$.each(pageUnit.prop.inst_tp,function(idx,item){
			setTimeout(function(){pageUnit.trn.getList(item);},idx*300);		
		});
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		$(document).on('click','section.module-box input[type=checkbox]',function(idx){
			$("div.main").find('input:checkbox:checked').length > 0?$("#proc").attr("disabled",false):$("#proc").attr("disabled",true);
		});
		
		$("#proc").off("click").on("click",function(){
			pageUnit.fn.goCncl('');
			/*
			var chk = $("div.main").find('input:checkbox');
			pageUnit.prop.data = [];
			//alert($("div.main").find('input:checkbox:checked').length);
			$.each(chk,function(idx,item){
				if($(this).is(":checked")){
					pageUnit.prop.data.push($(this).val());
				}
			});
			//pageUnit.fn.inData("org_cd",JSON.stringify(pageUnit.prop.data));
			mydataCommon.util.setArrayData("org_cd",pageUnit.prop.data);
			pageUnit.trn.goCc();
			*/
		});
		
		$(document).on('click','section.module-box button.cncl',function(idx){
			pageUnit.fn.goCncl($(this).attr("id"));
			/*
			//pageUnit.fn.inData("org_cd",$(this).attr("id"));
			mydataCommon.util.setData("org_cd",$(this).attr("id"));
			pageUnit.trn.goCc();
			*/
		})
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
		dataView : function(id,resultMap){
			var obj = $("#"+id);
			if(pageUnit.prop.cnt == 0) obj.addClass("pt30");
			console.log(resultMap);
			var listMain = obj.find('div.fold-body');
			
			$.each(resultMap && resultMap.g1 , function(idx1,item1){console.log(item1.orgn_cd);console.log(item1.orgn_nm);
			var addDivObj = listMain.find('dl.data-list:eq(0)').clone();	
				addDivObj.find('input:checkbox').attr("name","org_code").attr("id",""+obj.attr("id")+item1.orgn_cd).val(item1.orgn_cd+"|"+item1.token_stat_tp);
				addDivObj.find('label').attr('for',""+obj.attr("id")+item1.orgn_cd);	
				addDivObj.find('div.icon-title').children('img').attr("src","/resources/images/icons/org/"+item1.orgn_cd+".png");				
				addDivObj.find('p').text(mydataCommon.util.replace(item1.orgn_nm));				
				addDivObj.children('dd').find('button').attr("id",item1.orgn_cd+"|"+item1.token_stat_tp);
				
				listMain.append(addDivObj.show());
				pageUnit.prop.totCnt++;
			});
			listMain.children('dl:eq(0)').remove();			
			obj.show();
			pageUnit.prop.cnt++;
			$("#cnt").text(pageUnit.prop.totCnt);
		},
		goCncl : function(data){
			 mydataCommon.msg.confirm({msg : "보유한 개인신용정보가 삭제합니다",msg2 : "선택한 금융사의 현재까지 저장된 데이터를  삭제 합니다.데이터 삭제 시 금융사 연결도 함께 해지 됩니다.", callBackFn : function(isConfirm){
			      if(isConfirm){
			    	  pageUnit.trn.goCc(data);
			      }
		     }});
		}/*,
		inData : function(key,data){
			if(window.localStorage){
				localStorage.setItem(key,data);
			}else{
				alert('미지원');
			}
		}*/
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
