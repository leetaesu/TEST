var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		tp : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(activeArea){
			//var data = mydataCommon.makeJsonParam({target : $("body")});
			var tp = activeArea.substring(5,7);
			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth00100010001Ajax",
					data : {"inds_tp":tp,"sply_tp":"01"},
					async : true,
					//cache : true,
					success : function(res){												

						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){							
							$.each(resultMap.g1,function(idx,item){
								item.tp = tp;
							});
							console.log(resultMap.g1.length);
							if(tp =='00'){
								$("#areaComp").find('span').text(resultMap.g1.length);
							}							
							var obj = $("#"+activeArea).children();
							$("#"+activeArea).append('<script id="'+activeArea+'Template" type="text/x-jquery-tmpl">');			
							$("#"+activeArea+"Template").append(obj);							
							$("#"+activeArea+"Template").tmpl(resultMap.g1).appendTo("#"+activeArea);
							$("#"+activeArea).css("display","");
							
							if(pageUnit.prop.tp == tp){
								$('#main .module-wrapper .module-box .btn-wrap .btn').each(function(e){									
									if($(this).attr('area-controls')== ('area_'+pageUnit.prop.tp) ){
										$(this).addClass('navy');
										location.href = $(this).attr('href');
									}
								});	
							}
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		totalAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0103", callback:"callback_callMoveView", viewType:"half"});
		},
		goto_newAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"475"});
		},
		goto_getAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"446"});
		},
		goto_priAuth : function(){
			alert('사설인증app이동');
		},
		goto_agree1 : function(){
			//var data = mydataCommon.makeSerialParam({target : $("#main")});
			var data = mydataCommon.makeJsonParam({target : $("#main")});
			//mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/auth/VAuth0010016View",data);
			
			//var data = mydataCommon.makeJsonParam({target : $("body")});
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0010016View",
					data : data,
					async : true,
					//cache : true,
					success : function(res){
						$("#main").css("display","none");
						$("#st_use_agree").css("display","");
						console.log(data);
						var tp = data.orgn_code.substring(11,13);

						if(tp=='01'){
							$("#sh1").show();
							$("#sh1 input[type=radio]").each(function(e){
								$(this).prop("disabled",false);	
							});
						}else{
							$("#sh1").hide();
							$("#sh1 input[type=radio]").each(function(e){
								$(this).prop("disabled",true);	
							});
						}
						if(tp=='02'){
							$("#sh2").show();
							$("#sh2 input[type=radio]").each(function(e){
								$(this).prop("disabled",false);	
							});
						}else{
							$("#sh2").hide();
							$("#sh2 input[type=radio]").each(function(e){
								$(this).prop("disabled",true);	
							});
						}
						
						if(tp=='05'){
							$("#sh3").show();
							$("#sh3 input[type=radio]").each(function(e){
								$(this).prop("disabled",false);	
							});
						}else{
							$("#sh3").hide();
							$("#sh3 input[type=radio]").each(function(e){
								$(this).prop("disabled",true);	
							});
						}
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							console.log(resultMap);
							
							var info_cntn_key = "";
							$.each(resultMap.g1,function(idx,item){								
								//info_cntn_key += item.info_cntn_key+(idx+1==resultMap.g1.length?"":"|");	
								info_cntn_key +=(idx==0?"":"|")+item.info_cntn_key
							});														
							$("#info_cntn_key").val(info_cntn_key);
							
							var obj = $("#creditinfo").children();
							$("#creditinfo").append('<script id="creditinfoTemplate" type="text/x-jquery-tmpl">');			
							$("#creditinfoTemplate").append(obj);							
							$("#creditinfoTemplate").tmpl(resultMap.g1).appendTo("#creditinfo");

						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);							
		},
		goto_use_agree_prc : function(){
			//var data = mydataCommon.makeSerialParam({target : $("#main")});
			var data = mydataCommon.makeJsonParam({target : $("body")});
			//mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/auth/VAuth0010016View",data);
			console.log(data);
			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010016View",
					data : data,
					async : true,
					//cache : true,
					success : function(res){								
						console.log(data);
						var tp = data.orgn_code.split('|'); 
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							$("#st_use_agree").css("display","none");
							$("#st_prv_agree").css("display","");
							$("#st_prv_agree_org_nm").text(tp[2]);
							console.log(resultMap);
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);							
		},
		goto_prv_agree_prc : function(){
			//var data = mydataCommon.makeSerialParam({target : $("#main")});
			var data = mydataCommon.makeJsonParam({target : $("body")});
			//mydataCommon.contentRedirectUrl(pageCom.prop.contextPath + "/auth/VAuth0010016View",data);
			console.log(data);
			
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/IAuth0010017Ajax",
					data : data,
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.trn.sendTo();
						}else{
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);							
		},
		sendTo : function(Obj){		
			var data = mydataCommon.makeJsonParam({target : $("body")});
			mydataCommon.util.setArrayData("pridata",data);
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0102", callback:"callback_callMoveView", viewType:"full"});
			//location.href=pageCom.prop.contextPath + "/auth/VAuth0010015View";;
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		pageUnit.prop.tp = mydataCommon.util.getData('tp');

									
		//mydataCommon.util.removeData('tp');
		//pageUnit.prop.tp = '';
		
        $("#selectItem a").each(function(idx,item){        	
        	setTimeout(function(){
        		console.log($(item).attr("area-controls"));
        		console.log($(item).attr("area-controls").substring(5,7));
        		//var activeTab =  $(item).attr("aria-controls");
        		//var activeTab = $(item).find("a").attr("href");        		
            	pageUnit.trn.getList($(item).attr("area-controls"));
        	},idx*30);
        });
              
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		$("#selectItem a").off("click").on("click", function() {
			 $(this).addClass('navy').siblings().removeClass('navy');    
			/*
			 var name=$(this).attr("href").substring(1);
			 var obj = $("#"+name+"_n");
			// obj[0].scrollIntoView();
			// obj.focus();
			 $('body').scrollTop(1000);
			 */
        });
		
		$("#main .sub-prev").off("click").on("click", function() {
			pageUnit.fn.pageClose();
        });
		
		$("#goto_agree1").off("click").on("click", function() {
			 pageUnit.trn.goto_agree1();			
        });
		
		 $("#send").off("click").on("click", function() {
			 pageUnit.trn.sendTo();			
         });
		 
		 $("#totalAuth").off("click").on("click", function() {
			 pageUnit.trn.totalAuth();			
         });
		 
		 $("#newAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_newAuth();
         });
		 $("#getAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_getAuth();
         });
		 
		 $("#cPriAuth , #nPriAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_priAuth();
         });
		 		 
		 $("#st_use_agree .sub-prev").off("click").on("click", function() {
			 $("#st_use_agree").css("display","none");
			 $("#main").css("display","");
         });
		 
		 $("#st_prv_not_agree , #st_prv_agree_back").off("click").on("click", function() {
			 $("#st_prv_agree").css("display","none");
			 $("#st_use_agree").css("display","");
         });
		 
		 
		 
		 $("#st_prv_agree_prc").off("click").on("click", function() {
			 pageUnit.trn.goto_prv_agree_prc();
         });
		 /*
		 $("#st_use_agree input[type=radio]").off("click").on("click", function(e) {
			 if($(this).val() =="N"){
				 mydataCommon.msg.confirm({msg : "거부 권리 및 불이익 안내",msg2 : "개인(신용)정보 수집·이용에 관한 동의를 거부 하실 수 있습니다.다만  수집·이용에 관한 동의는 본인 신용정보 통합조회 서비스 이용을 위한 필수적인 사항이므로 동의 거부하실 경우 서비스 이용이 제한될 수 있습니다.", callBackFn : function(isConfirm){
				      if(isConfirm){      
				    	  location.href = pageCom.prop.contextPath + "/auth/VAuth0010011View";		    	
				      }else{
				    	  $('input:radio[name="'+e.target.name+'"][value="Y"]').prop("checked",true);				    	
				      }
			     }});
			 }			
         });
         */
		 //
		 $("#st_use_not_agree_prc").off("click").on("click", function() {
			 mydataCommon.msg.confirm({msghd:"",msg : "거부 권리 및 불이익 안내",msg2 : "개인(신용)정보 수집·이용에 관한 동의를 거부 하실 수 있습니다.다만  수집·이용에 관한 동의는 본인 신용정보 통합조회 서비스 이용을 위한 필수적인 사항이므로 동의 거부하실 경우 서비스 이용이 제한될 수 있습니다.", callBackFn : function(isConfirm){
			      if(isConfirm){      
			    	  pageUnit.fn.pageClose();   	
			      }
		     }});
         });
		 
         $("#st_use_agree_prc").off("click").on("click", function() {
        	 if($("#sh1").is(":visible")){        		
        		 var chk = $("input[name='bank_01']:checked").val();
        		 if(chk == undefined){
        			 mydataCommon.msg.alert({msg : "적요 정보수집 이용동의를 선택해주세요"});
        		 }else{
        			 pageUnit.trn.goto_use_agree_prc();
        		 }
        	 }else if($("#sh2").is(":visible")){//card_01
        		 var chk = $("input[name='card_01']:checked").val();
        		 if(chk == undefined){
        			 mydataCommon.msg.alert({msg : "가맹점정보 수집·이용 동의를 선택해주세요"});
        		 }else{
        			 pageUnit.trn.goto_use_agree_prc();
        		 }  
        	 }else if($("#sh3").is(":visible")){//card_01
        		 var chk1 = $("input[name='elec_01']:checked").val();
        		 var chk2 = $("input[name='elec_02']:checked").val();
        		 var chk3 = $("input[name='elec_03']:checked").val();
        		 if(chk1 == undefined){
        			 mydataCommon.msg.alert({msg : "상품구매정보 수집·이용 동의를 선택해주세요"});
        		 }else if(chk2 == undefined){
        			 mydataCommon.msg.alert({msg : "가맹점정보 수집·이용 동의를 선택해주세요"});
        		 }else if(chk3 == undefined){
        			 mydataCommon.msg.alert({msg : "거래메모정보 수집·이용 동의를 선택해주세요"});
        		 }
        		 else{        		 
        			 pageUnit.trn.goto_use_agree_prc();
        		 }  
        	 }else{
        		 pageUnit.trn.goto_use_agree_prc();
        	 }
         });
         
		 $(document).on('click','[id^="main"] input[type=radio]',function(idx){//
			 if($(this).is(":checked")){
				 $("#goto_agree1").attr("disabled",false);
			 }else{
				 $("#goto_agree1").attr("disabled",true);
			 }			 
		 });
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		pageClose : function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", callback:"callback_callMoveView" ,popClose:true});
		},
		callback_getCertMydataSign : function(obj){
			console.log("결과값 출력");
			console.log(JSON.stringify(obj));
		}
	}
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});