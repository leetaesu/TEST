var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		inst_tp : ['01','03','04','02','06','05','07'],
		cnt : 0,
		totCnt : 0,
		data : []	
			
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		getList : function(inst_tp){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/auth/SAuth0030001Ajax",
					data : {"inds_tp":inst_tp},
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;						
						if(resultMap && resultMap.resp_gubn == "0"){
							pageUnit.fn.dataView(inst_tp,resultMap);						
						}else{
							if(resultMap && resultMap.resp_code!="501724")
							mydataCommon.msg.alert({msg : resultMap.resp_mesg});
						}
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		goCc : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0304", callback:"", viewType:"half"});
		
		},
		goPage : function(){			
			//location.href = pageCom.prop.contextPath + "/auth/VAuth0010001View";
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0101", callback:"", viewType:""});
		}
		
	},
	// 단위 진입부 함수
	init : function(){
		
		pageUnit.eventBind();				
		$.each(pageUnit.prop.inst_tp,function(idx,item){
			setTimeout(function(){pageUnit.trn.getList(item);},idx*300);		
		});
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		$(document).on('click','div.module-box input[type=checkbox]',function(idx){
			$("div.main").find('input:checkbox:checked').length > 0?$("#proc").attr("disabled",false):$("#proc").attr("disabled",true);
		});
		$("#go_page").off("click").on("click",function(){
			pageUnit.trn.goPage();
		});				
		
		$(document).on('click','a',function(idx){			
			mydataCommon.util.setData("org_cd",$(this).attr("id")+"|"+$(this).closest('section').prop('id')+"|"+$(this).children('div.icon-title').children('p:eq(0)').text());
			var data = {};
			data.orgn_code = $(this).children('div.icon-title').children('p:eq(0)').data("info");
			mydataCommon.util.setArrayData("pridata",data);			

			pageUnit.trn.goCc();
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
		dataView : function(id,resultMap){
			var obj = $("#"+id);
			if(pageUnit.prop.cnt == 0) obj.addClass("pt30");
			console.log(resultMap);
			var listMain = obj.find('div.card-body');
			
			$.each(resultMap && resultMap.g1 , function(idx1,item1){
				var addDivObj = listMain.find('div:eq(0)').clone();
				addDivObj.find('div.icon-title').children('img').attr("src","/resources/images/icons/org/"+item1.orgn_cd+".png");
				addDivObj.find('div.icon-title').children('p').text(mydataCommon.util.replace(item1.orgn_nm));	
				addDivObj.find('div.icon-title').children('p').data("info",item1.orgn_cd+"|"+id+"|"+mydataCommon.util.replace(item1.orgn_nm)+"|"+item1.domain);
				
				if(item1.send_rqst_extn_yn=="Y"){
					addDivObj.children('dl:eq(0)').append('<p class="bullet-noti fc-orange ml50">'+mydataCommon.util.replace("개인(신용)정보 전송 요구 기간 만료가 얼마 남지 않았어요. 전송 요구를 연장해  보세요.")+'</p>');
				}					
				addDivObj.find('a.sub-link').attr("id",item1.orgn_cd);
				listMain.append(addDivObj.show());
				pageUnit.prop.totCnt++;
			});
			listMain.children('div:eq(0)').remove();
			obj.show();
			pageUnit.prop.cnt++;
			$("#cnt").text(pageUnit.prop.totCnt);
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
