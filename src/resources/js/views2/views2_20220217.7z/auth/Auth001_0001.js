var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {		
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		goto_newAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"475"});
		},
		goto_getAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"", callback:"", viewId:"446"});
		},
		goto_priAuth : function(){
			alert('사설인증app이동');
		},
		goto_pri : function(){			
			//location.href = pageCom.prop.contextPath + "/auth/VAuth0010003View";
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0104", callback:"", viewType:""});
			
		},
		totalAuth : function(){
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"AUTH0103", callback:"", viewType:""});
			//location.href="/auth/VAuth0010005View";
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		 $("#newAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_newAuth();
         });
		 $("#getAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_getAuth();
         });
		 $("#cPriAuth , #nPriAuth").off("click").on("click", function() {
			 pageUnit.trn.goto_priAuth();
         });
		 
		 $("#priSel .module-body .btn-wrap .btn").off("click").on("click", function() {
			 mydataCommon.util.setData("tp",$(this).data('tp'));
		 	pageUnit.trn.goto_pri();		 
         });
		 
		 $("#totalAuth").off("click").on("click", function() {
			 pageUnit.trn.totalAuth();			
         });
		 
		 
		 
	},
	// 단위 전용 함수 모음 패키지
	fn : {		
	}
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});