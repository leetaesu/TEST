var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VNoti0010001Pop",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'noti',
		v_storageSubKeyName : ''
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		callTrAjax : function(url, param, callback){
			var jsonObj = {
					url : pageCom.prop.contextPath + "/noti/" + url,
					data : param,
					async : true,
					//cache : true,
					success : function(res){
						var resultMap = res.resultMap;
						//mydataCommon.util.consoleOut("get"+url);
						//mydataCommon.util.consoleOut(res);
						//mydataCommon.util.consoleOut(resultMap);				
						
						callback(resultMap, param);
						
					},
					error : function(e1, e2, e3){
						mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
					}
			}
			mydataCommon.ajax(jsonObj);			
		},
		//설정내역조회 : pageUnit.trn.getList();
		getList : function() {
			var pageParam = mydataCommon.page.getSubParamData();
			var inputListItems = pageUnit.fn.getCheckedVals();				//설정항목 별 체크박스 파라미터 만들기.
			pageParam.inputListItems = JSON.stringify(inputListItems);		//항목별 설정 저장 파라미터 설정
			pageParam.issel_dev = '1';
			if(pageCom.prop.isIPHONE)
			{
				pageParam.my_mdgb = 'I';			/* 플랫폼(I:아이폰, F:안드로이드) */
			}
			else if(pageCom.prop.isANDROID)
			{
				pageParam.my_mdgb = 'F';			/* 플랫폼(I:아이폰, F:안드로이드) */
			}
			pageUnit.trn.callTrAjax("SNoti0010001P001Ajax", pageParam, pageUnit.fn.setNoti0010001001Ajax);
		},
		//설정내역저장 : pageUnit.trn.saveList();
		saveList : function() {
			//모바일 기기정보 로컬스토리지에 저장
			mydataCommon.appBridge.getPushData();
			//모바일 기기정보 저장하는 시간동안 지연.
			setTimeout(function(){
				var pageParam = mydataCommon.page.getSubParamData();
				var inputListItems = pageUnit.fn.getCheckedVals();				//설정항목 별 체크박스 파라미터 만들기.
				pageParam.inputListItems = JSON.stringify(inputListItems);		//항목별 설정 저장 파라미터 설정
				pageParam.isreg_dev = '0';
				pageParam.reg_plat = 'F';
				pageParam.my_mdgb = 'WE';
				pageParam.isreg_ums = '0';
				pageParam.isreg_cif = '0';
				if(pageCom.prop.isIPHONE)
				{
					pageParam.reg_plat = 'I';			/* 플랫폼(I:아이폰, F:안드로이드) */ 
				}
				else if(pageCom.prop.isANDROID)
				{
					pageParam.reg_plat = 'F';			/* 플랫폼(I:아이폰, F:안드로이드) */ 
				}
				//기기정보 설정
				pageCom.setDeviceInfo(pageParam);
				pageUnit.trn.callTrAjax("SNoti0010001P002Ajax", pageParam, pageUnit.fn.setNoti0010001002Ajax);
			},200);
		}
		
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		
		//푸시알람 설정정보 표기
		pageUnit.trn.getList();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		// 닫기
		$('.modal-close').off('click').on('click', function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		//전체 체크 / 해제 처리
		pageUnit.fn.getPageCtls('chkAll').off('click').on('click', function(e){
			pageUnit.fn.getPageCtls('chkSet').prop('checked',this.checked);
			//설정내역저장
			pageUnit.trn.saveList();
		});
		
		//설정 체크박스 값 변경 시, 설정 저장처리
		pageUnit.fn.getPageCtls('chkSet').off('change').on('change', function(e){
			//설정내역저장
			pageUnit.trn.saveList();
			//전체체크박스 상태갱신
			pageUnit.fn.updateChkAllStatus();
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 설정내역 리스트 조회결과 표시처리
		setNoti0010001001Ajax : function(resultMap) {
			//resultMap.resp_gubn : "1" - 결과없음, "0" - 결과있음.
			if(resultMap && resultMap.resp_gubn == "0"){
				//결과가 있을때 처리.
				var list = resultMap.rslt_items;
				var $chkSet = pageUnit.fn.getPageCtls('chkSet');
				if(list && list.length){
					for(var i=0;i<list.length;i++){
						var row = list[i];
						var svcGb = row.svc_gb;
						var statGb = row.stat_gb;	//등록:'1', 해지:'0', 삭제:'X'
						var $chkBx = $chkSet.filter('[data-svc_gb="'+svcGb+'"]');
						if(statGb==='1'){
							$chkBx.prop('checked',true);
						} else {
							$chkBx.prop('checked',false);
						}
					}
					//전체체크박스 상태갱신
					pageUnit.fn.updateChkAllStatus();
				}
			}else{
				//결과가 없을때 처리.
			}
		},
		// 설정내역 리스트 저장결과 표시처리
		setNoti0010001002Ajax : function(resultMap) {
			//resultMap.resp_gubn : "1" - 결과없음, "0" - 결과있음.
			if(resultMap && resultMap.resp_gubn == "0"){
				//결과가 있을때 처리.
				
			}else{
				//결과가 없을때 처리.
			}
		},
		//페이지내 컨트롤 반환 함수
		//var schDateBtns = pageUnit.fn.getPageCtls('schDateBtns');
		getPageCtls : function(gubun){
			var ctl = null;
			if(gubun=='chkAll'){
				//전체 체크박스
				ctl = $('#chk_all');
			} else if(gubun=='chkSet'){
				//설정 체크박스들
	    		ctl = $('.module-wrapper .module-box .data-list :checkbox');
			}
			return ctl;
		},
		//설정 체크박스 목록의 현재 체크된 값 배열 반환
		//var inputListItems = pageUnit.fn.getCheckedVals();
		getCheckedVals : function(gubun){
			var inputListItems = [];
			//설정항목 별 체크박스 파라미터 만들기.
			pageUnit.fn.getPageCtls('chkSet').each(function(index,el){
				var $item = $(el);
				var svc_gb = $item.data('svc_gb') ? $item.data('svc_gb') : '';
				var stat_gb = el.checked ? '1' : '0';
				inputListItems.push({svc_gb:svc_gb,stat_gb:stat_gb});
			});
			return inputListItems;
		},
		updateChkAllStatus : function() {
			//pageUnit.fn.updateChkAllStatus();
			//하위 설정 체크박스들의 체크 상태에 따라서, 전체 체크박스 상태 갱신
			//하위 설정 체크박스들이 전체가 선택되면, 전체 체크박스 체크 처리.
			//하위 설정 체크박스들이 전체가 선택안되면, 전체 체크박스 체크 해제 처리.
			var $chkSet = pageUnit.fn.getPageCtls('chkSet');
			var $chkAll = pageUnit.fn.getPageCtls('chkAll');
			var allCnt = $chkSet.length;
			var chkCnt = $chkSet.filter(':checked').length;
			if(allCnt==chkCnt){
				$chkAll.prop('checked',true);
				//console.info('updateChkAllStatus1');
			} else if(0==chkCnt){
				$chkAll.prop('checked',false);
			}
		}
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
