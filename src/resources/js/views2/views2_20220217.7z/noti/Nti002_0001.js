var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VNoti0020001Pop",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'noti',
		v_storageSubKeyName : '',
		//각 메뉴별 메인페이지 경로 키값 맵
		v_mainpageMap : {},
		//목록의 분류별 색상 맵
		v_listColorMap : {}
	},
	// 단위 진입부 함수
	init : function(){
		//메인페이지 경로 키값 맵 설정
		pageUnit.prop.v_mainpageMap['01'] = 'MY0101';		//공통 
		pageUnit.prop.v_mainpageMap['02'] = 'BANK0101';		//뱅킹
		pageUnit.prop.v_mainpageMap['03'] = 'INVE0101';		//투자
		pageUnit.prop.v_mainpageMap['04'] = 'LOAN0101';		//대출
		pageUnit.prop.v_mainpageMap['05'] = 'INSU0101';		//보험
		pageUnit.prop.v_mainpageMap['06'] = 'ANNU0101';		//연금
		pageUnit.prop.v_mainpageMap['08'] = 'CARD0101';		//카드
		pageUnit.prop.v_mainpageMap['07'] = 'CRED0101';		//신용
		
		//목록의 분류별 색상 맵
		pageUnit.prop.v_listColorMap['01'] = 'c-sky';		//공통
		pageUnit.prop.v_listColorMap['02'] = 'c-green';		//뱅킹 
		pageUnit.prop.v_listColorMap['03'] = 'c-red';		//투자
		pageUnit.prop.v_listColorMap['04'] = 'c-violet';	//대출
		pageUnit.prop.v_listColorMap['05'] = 'c-orange';	//보험
		pageUnit.prop.v_listColorMap['06'] = 'c-yellow';	//연금
		pageUnit.prop.v_listColorMap['08'] = 'c-navy';		//카드
		pageUnit.prop.v_listColorMap['07'] = 'c-blue';		//신용
		
		//이벤트 바인드
		pageUnit.eventBind();
		
		//알리미구분 외부전달 파라미터 값 설정
		var paramAlimiClsTp = document.frm.alimi_cls_tp.value;
		if(paramAlimiClsTp){
			pageUnit.fn.getPageCtls('schAlimiClsTpCombo').val(paramAlimiClsTp);
		}
		
		//컨트롤 초기값 설정
		pageUnit.fn.getPageCtls('schDateBtns').eq(0).trigger('change');		//검색기간버튼
		pageUnit.fn.getPageCtls('schAlimiClsTpCombo').trigger('change');	//알리미구분콤보
		
		//알림내역조회
		pageUnit.trn.getList();
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		callTrAjax : function(url, param, callback){
			var jsonObj = {
				url : pageCom.prop.contextPath + "/noti/" + url,
				data : param,
				async : true,
				//cache : true,
				success : function(res){
					var resultMap = res.resultMap;
					/*mydataCommon.util.consoleOut("get"+url);
					mydataCommon.util.consoleOut(res);
					mydataCommon.util.consoleOut(resultMap);*/
					
					callback(resultMap,param);
					
				},
				error : function(e1, e2, e3){
					mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});							
				}
			}
			mydataCommon.ajax(jsonObj);			
		},
		//알림내역조회 : pageUnit.trn.getList();
		getList : function() {
			pageUnit.trn.callTrAjax("SNoti0020001P001Ajax", mydataCommon.page.getSubParamData(), pageUnit.fn.setNoti0020001P001Ajax);
		}
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		// 닫기
		$('.modal-close').off('click').on('click', function(){
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		//기간버튼 클릭 시
		pageUnit.fn.getPageCtls('schDateBtns').off('change').on('change', function(e) {
    		var pageParam = mydataCommon.page.getSubParamData();
    		var rdoId = this.id;
    		//파라미터 값 설정
    		pageParam.qry_end_dt = mydataCommon_02.util.getStrDate();
    		if(rdoId == 'rdo_10'){
    			pageParam.qry_strt_dt = mydataCommon_02.util.getStrDate();
    		}else if(rdoId == 'rdo_11'){
    			pageParam.qry_strt_dt = mydataCommon_02.util.getBeforeDate('D', 3 );
    		}else if(rdoId == 'rdo_12'){
    			pageParam.qry_strt_dt = mydataCommon_02.util.getBeforeDate('D', 7 );
    		}else if(rdoId == 'rdo_13'){
    			pageParam.qry_strt_dt = mydataCommon_02.util.getBeforeDate('M', 1 );
    		}else if(rdoId == 'rdo_14'){
    			pageParam.qry_strt_dt = mydataCommon_02.util.getBeforeDate('M', 3 );
    		}
    		//검색날짜 기간 표기
    		pageUnit.fn.setSchDatesText(pageParam.qry_strt_dt,pageParam.qry_end_dt);
    		//파라미터 객체 스토리지 저장
    		mydataCommon.page.setSubParamData(pageParam);
    		//알림내역조회
			pageUnit.trn.getList();
    	});
		
		//알라미 구분 콤모박스 선택 이벤트
		pageUnit.fn.getPageCtls('schAlimiClsTpCombo').off('change').on('change', function(e) {
    		var pageParam = mydataCommon.page.getSubParamData();
    		//파라미터 값 설정
    		pageParam.alimi_cls_tp = this.value;
    		//파라미터 객체 스토리지 저장
    		mydataCommon.page.setSubParamData(pageParam);
    		//알림내역조회
			pageUnit.trn.getList();
		});
		
		//조회버튼 클릭 시
		pageUnit.fn.getPageCtls('schNaviBtn').off('click').on('click', function(e) {
			//알림내역조회
			pageUnit.trn.getList();
		});
		
		//목록 항목별 버튼 클릭 시, 각 메뉴별 메인페이지 이동
		pageUnit.fn.getPageCtls('listBtns').off('click').on('click', function(e) {
			var alimiClsTp = mydataCommon.util.nvl($(this).data('alimi_cls_tp')).trim();
			var mainpageKey = pageUnit.prop.v_mainpageMap[alimiClsTp];
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:mainpageKey, callback:"", viewType:""});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 알림내역 리스트 조회결과 표시처리
		setNoti0020001P001Ajax : function(resultMap,param) {
			//resultMap.resp_gubn : "1" - 결과없음, "0" - 결과있음.
			if(resultMap && resultMap.resp_gubn == "0"){
				//결과가 있을때 처리.
				//데이터 설정
				$.each(resultMap.g1,function(index,row){
					row.alimi_cls_tp_str = pageUnit.fn.getAlimiClsTpName(row.alimi_cls_tp);
					row.base_dt_str = mydataCommon_02.util.getStrDate(row.base_dt);
					row.cls_color = pageUnit.prop.v_listColorMap[row.alimi_cls_tp];
				});
				//템플릿 설정
				ao_html('#listTmpl', '#myd_list_tmpl', resultMap);
			}else{
				//결과가 없을때 처리.
				$('#listTmpl').html('');
			}
		},
		//페이지내 컨트롤 반환 함수
		//var schDateBtns = pageUnit.fn.getPageCtls('schDateBtns');
		getPageCtls : function(gubun){
			var ctl = null;
			if(gubun=='schDateBtns'){
				//검색: 기간 설정 버튼 배열
				ctl = $('.page-wrapper .module-wrapper .module-box .btn-wrap :radio');
			} else if(gubun=='schDateText'){
				//검색: 기간 설정 텍스트 박스
	    		ctl = $('.page-wrapper .module-wrapper .module-box .calendar:text');
			} else if(gubun=='schAlimiClsTpCombo'){
				//검색: 알림이분류구분 콤보 박스
	    		ctl = $('.page-wrapper .module-wrapper .module-box .custom-select select');
			} else if(gubun=='schNaviBtn'){
				//검색: 조회버튼
	    		ctl = $('#btnSearch');
			} else if(gubun=='listBtns'){
				//목록: 전체 목록의 항목별 링크 버튼들
	    		ctl = $('#listTmpl .data-list button');
			}
			return ctl;
		},
		//알리미 구분코드에 해당하는 명칭 반환
		//pageUnit.fn.getAlimiClsTpName('01');
		getAlimiClsTpName : function(alimiClsTp){
			var v_name = '';
			//알리미 구분 콤보박스
			var schAlimiClsTpCombo = pageUnit.fn.getPageCtls('schAlimiClsTpCombo');
			var searchOption = schAlimiClsTpCombo.find('option[value="'+alimiClsTp+'"]');
			if(alimiClsTp && searchOption.length){
				v_name = searchOption[0].text;
			}
			return v_name;
		},
		//검색날짜 기간 표기
		//pageUnit.fn.setSchDatesText('20210101','20210301');
		setSchDatesText : function(sdate,edate){
			if(sdate && edate){
				pageUnit.fn.getPageCtls('schDateText').val( mydataCommon_02.util.getStrDate(sdate) + " ~ " +  mydataCommon_02.util.getStrDate(edate)   );
			}
		}
		
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
 
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});
