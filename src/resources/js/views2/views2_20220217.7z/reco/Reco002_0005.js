var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0020005View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',	

	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		param_s : {
//			stk_code : mydataCommon.util.getData('stk_code'),
			stk_code : 'E01602', 
		},
	},
	//	단위 전용 통신함수 모음 패키지
	trn : {
		/*파생결합증권 상세 정보조회 TDD6510_Q04*/
		ajax_call : function(exeType){
//			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			var param = pageUnit.trn_param.param_s;
			if ( exeType == 'searchElsbDetail' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/reco/SReco0020005Ajax",
						data : param,
						async : true,
						success : pageUnit.fn.set_section,
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);
			}
		}
	},
	// 단위 진입부 함수
	init : function(){		
		pageUnit.trn.ajax_call('searchElsbDetail');
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		//TODO set button click event 
		
		//이전화면
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		//투자하기 상단버튼 (영S)
		$(document).on("click", "#btn_invest_top", function() {
			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"531"});
		});
		//투자하기 하단버튼 (영S)
		$(document).on("click", "#btn_invest_btm", function() {
			var stk_code =  pageUnit.fn.getStkCode();
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"531"});
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"531", urlMapId: stk_code});
		});
		
		// PDF모달 닫기 버튼
		$("#pdfViewer .modal-close").off("click").on("click", function(){
			$('article#pdfViewer').removeClass("is-open");
			$("article#data").addClass("is-open");
			$("#ifrm").remove();
		});
		
		// 상품요약서 A[stk_code].pdf  
		$(document).on("click", "#btn_coreInv", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();	
			pageUnit.fn.pdf_view("상품요약서","A",sal_fund_cd);
		});
		
		// 투자설명서 B[stk_code].pdf
		$(document).on("click", "#btn_inv", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();		
			pageUnit.fn.pdf_view("투자설명서","B",sal_fund_cd);		
		});
		
		// 간이투자설명서 C[stk_code].pdf
		$(document).on("click", "#btn_smplInv", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();	
			pageUnit.fn.pdf_view("간이투자설명서","C",sal_fund_cd);
		});
		
		// 퀵가이드 Q[stk_code].pdf
		$(document).on("click", "#btn_quickGuide", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();	
			pageUnit.fn.pdf_view("퀵가이드","Q",sal_fund_cd);	
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		pdf_view : function(title,tp,fund_cd){
			//https://www.kiwoom.com/wm/upload/gds/AE01602.pdf
			var url = "https://www.kiwoom.com/wm/upload/gds/"+tp+fund_cd+".pdf";
			mydataCommon.util.consoleOut(url);
			$('article').removeClass("is-open");	    		
	    	$("#pdfViewer").addClass("is-open");
	    	$("#pdfViewer .modal-title").text(title);
			$("#pdfViewer .modal-body").append("<iframe id='ifrm' src='https://docs.google.com/viewer?embedded=true&url="+encodeURIComponent(url)+ "' style='width: 100%; height: 100%; border: none; overflow-y : scroll;-webkit-overflow-scrolling: touch;'></iframe>");
		},
		set_section : function (data) {
			
			var outData = data.TDD6510_Q04,
				stk_code = pageUnit.fn.getStkCode();
			mydataCommon.util.consoleOut(outData);

			if (outData && outData.resp_gubn == "0") { 
				outData.stk_grde_tp = pageUnit.fn.getGradeStyle( outData.stk_grde );
				outData.scr_strt_dt = mydataCommon.util.getStrDate(outData.scr_strt_dt);
				outData.scr_end_dt = mydataCommon.util.getStrDate(outData.scr_end_dt);
				outData.scr_lwst_amt = mydataCommon.util.getStrDate(outData.scr_lwst_amt);
				outData.isu_dt = mydataCommon.util.getStrDate(outData.isu_dt);
				outData.scr_lwst_amt = mydataCommon.util.addComma(parseInt(outData.scr_lwst_amt));
				
				/* 줄바꿈 처리 test
				 * chrc_cntn 특징: 숙려대상자(일반개인투자자)\r\n청약가능기간:8/23(월)~8/30(월)17시까지
				 * type_cntn 유형: 만기3년 조기상환형\r\n(95-90-85-85-80-75/55KI)
				 * expr_rpy_cntn 만기/상환주기 : 3년 만기 / 6개월마다 조기상환 기회
				 * errt_cntn 수익률 : 조건 충족 시 : 연 5.2%(세전)\r\n조건 미충족 시 : 최대 -100% (원금 손실 가능)
				 */
//				outData.chrc_cntn = '숙려대상자(일반개인투자자)\r\n청약가능기간:8/23(월)~8/30(월)17시까지';
//				outData.type_cntn = '만기3년 조기상환형\r\n(95-90-85-85-80-75/55KI)';
//				outData.expr_rpy_cntn = '만기/상환주기 : 3년 만기 / 6개월마다 조기상환 기회';
//				outData.errt_cntn = '조건 충족 시 : 연 5.2%(세전)\r\n조건 미충족 시 : 최대 -100% (원금 손실 가능)';
				
				if (outData.chrc_cntn != "" ) {
					outData.chrc_cntn = outData.chrc_cntn.split("\r\n");
					$('#elsbChrcCntn').show();
				}
				outData.type_cntn = outData.type_cntn.split("\r\n");
				outData.expr_rpy_cntn = outData.expr_rpy_cntn.split("\r\n");
				outData.errt_cntn = outData.errt_cntn.split("\r\n");
				/*//줄바꿈 처리 test */

				ao_html('#elsbStkGrde', outData);
				
//				ao_html('#elsbStkName', outData);
				
				ao_html('#elsbExpcErrt', outData);
				
				ao_html('#elsbChrcCntn', outData);
				
				ao_html('#elsbDtlInfo', outData);
				
				pageUnit.fn.setAdminContent(stk_code);
				
			} else { 
		 		mydataCommon.msg.alert({msg : outData.resp_mesg}); 
		 	}
			
		},
		//상품위험등급 
		getGradeStyle : function(obj) {
			var gradeClassList = {
				"1" : "초고위험",
				"2" : "고위험",
				"3" : "중위험",
				"4" : "저위험",
				"5" : "초저위험",
			}
			for (var key in gradeClassList) 
				if(obj === key)
					return gradeClassList[key];
		},
		setAdminContent : function(code) {
			var str = code.substr(2,5);
			$('#adminContent img').attr('src', 'https://www.kiwoom.com/wm/upload/gds/web_els_'+str+'.png');
		},
		getStkCode : function() {
//			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			var param = pageUnit.trn_param.param_s;
			return param.stk_code;
		},
		req_error : function (data) {
			mydataCommon_02.util.log(['Reco003_0001.js :: req_error ----------> ', data]);
			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		}
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});





