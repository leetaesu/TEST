var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : { 
		v_id : "VReco0030001View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
	},                                   
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	//	단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				/* 대출상품 상세 XMO2030_Q02 */
				if ( exeType == 'loanDetailXMO2030_Q02' ){
					var param = mydataCommon.page.getSubParamData('VReco0010002View');
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0030001Ajax",
							data : param,
							async : true,
							success : res, 
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				/* 이벤트 배너  */
				else if ( exeType == 'evtBanrXMA1001_Q03' ){	
					var param = {
							banr_tp : "2", //배너유형구분
							banr_exps_tp : "09", //배너노출메뉴  
							acnt_lnkg_exps_tp : "01", //계좌연동노출유형
						}
					var jsonObj = {
							url : pageCom.prop.contextPath + "/common/SComBann001001Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				} 
			});	
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		
		var ajax_call = pageUnit.trn.ajax_call;
		ajax_call('loanDetailXMO2030_Q02').then(function(data){
			pageUnit.fn.set_section(data);
			return ajax_call('evtBanrXMA1001_Q03');
			
		}).then(function(data){
		// 배너 공통 적용
//			mydataCommon.util.getSimpleBanner({
//				banr_tp : "2", //배너유형구분
//				banr_exps_tp : "09", //배너노출메뉴  
//				acnt_lnkg_exps_tp : "01", //계좌연동노출유형
//			});
			pageUnit.fn.set_section_banr(data);
			
		}).catch(function(e){
			console.error(e);
		});
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){

		// 뒤로가기
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		//대출상품 상세 
		set_section: function (data) {
			var outData = data.XMO2030_Q02;
			mydataCommon.util.consoleOut( data , '/reco/SReco0030001Ajax(1)');
			
				//관리자에 등록된 연결 url
				mydataCommon.util.setData("cnct_url",outData.cnct_url);
				if (outData && outData.resp_gubn == "0") {
					outData.myd_orgn_code = pageUnit.fn.getMydOrgnCode();
					
					outData.lwst_expc_int = (parseInt(outData.lwst_expc_int*10)/10).toFixed(2);
					outData.high_expc_int =(parseInt(outData.high_expc_int*10)/10).toFixed(2);
					outData.max_limit_amt = mydataCommon.util.addComma(outData.max_limit_amt);
					outData.loan_limit_max_amt = mydataCommon.util.addComma(outData.loan_limit_max_amt);
					outData.loan_limit_min_amt = mydataCommon.util.addComma(outData.loan_limit_min_amt);
					
					//줄바꿈 처리
					outData.spcl_int_cond_cntn = outData.spcl_int_cond_cntn.split("\r\n");
					outData.int_type_cntn = outData.int_type_cntn.split("\r\n");
					outData.loan_rpy_way_cntn = outData.loan_rpy_way_cntn.split("\r\n");
					outData.int_pay_pft_cntn = outData.int_pay_pft_cntn.split("\r\n");
					outData.mdwy_rpy_cmsn_cntn = outData.mdwy_rpy_cmsn_cntn.split("\r\n");
					outData.rctx_clm_cond_cntn = outData.rctx_clm_cond_cntn.split("\r\n");
					outData.gvrm_poli_sprt_nm = outData.gvrm_poli_sprt_nm.split("\r\n");
					outData.loan_rqst_path_cntn = outData.loan_rqst_path_cntn.split("\r\n");
					
					ao_html('#loanPrdtSmryNm',outData);
					ao_html('#loanTerms',outData);
				} else {
					mydataCommon.msg.alert({ msg : outData.resp_mesg });
				}
		},
		//이벤트 모바일(배너) 세팅-->공통 적용예정
		set_section_banr : function (data) {
			var outData = data.resultMap;
			mydataCommon.util.consoleOut(data, '/common/SComBann001001Ajax(2)');
			
			if (outData && outData.resp_gubn == "0") {	
				// banr_exps_lctn_no : 배너노출위치번호
				// imag_url : 이미지URL
				// banr_url : 배너URL
				$.each(outData.g1, function(i ,v){
					v.acnt_gds_nm = mydataCommon.util.nvl(v.acnt_gds_nm,"../../../resources/images/common/img_ann_001_0002.png");
					v.banr_url = mydataCommon.util.nvl(v.banr_url,"");
					v.banr_exps_lctn_no = mydataCommon.util.nvl(v.banr_exps_lctn_no,"");
				});
				
				ao_html('#event_link',outData.g1);
			} else {
				//이벤트 배너 미노출 처리
//				$('.banr.banrDefult').show();
				$('.event_box').hide();
			}
		},
		goLoan : function(cnct_url){
			//대출신청하기 버튼
//			$("#btn_loan").off("click").on("click", function(){
//				var cnct_url = mydataCommon.util.getData('cnct_url');
//				mydataCommon.util.consoleOut($('#cnct_url').val());
				if ( cnct_url == '' || cnct_url == undefined || cnct_url == null ){
					mydataCommon.msg.alert({msg : "관리자에 등록된 연결 url이 없습니다."});
				} else if(cnct_url.includes('https:')){
					mydataCommon.util.consoleOut(cnct_url);
					document.location.href = cnct_url;
				} else {
					mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId: cnct_url });
				}
//			});
		},
		getMydOrgnCode : function() {
			var param = mydataCommon.page.getSubParamData('VReco0010002View');
			return param.myd_orgn_code;
		},
		req_error : function(data) {
			mydataCommon_02.util.log([ 'Reco0030001.js :: req_error ----------> ', data ]);
			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
		},
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});





