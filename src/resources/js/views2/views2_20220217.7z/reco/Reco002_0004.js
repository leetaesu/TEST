var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0020004View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',	
	},                                   
	// 전송 전용 프로퍼티 모음
	trn_param : {
		stk_code : "0000000001"
	},
	//	단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			/*추천투자상품_RP상품 자세히보기 TDD5020_Q04*/
			if ( exeType == 'rpDtlTDD5020_Q04' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/reco/SReco0020004Ajax",
						data : param,
						async : true,
						success : pageUnit.fn.set_section,
						error : pageUnit.fn.req_error
				}
				mydataCommon.ajax(jsonObj);
			}
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.trn.ajax_call('rpDtlTDD5020_Q04');
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		//TODO set button click event 
		//이전화면
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		//투자하기 상단버튼 (영S)
		$(document).on("click", "#btn_invest_top", function() {
			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"954"});
		});
		//투자하기 하단버튼 (영S)
		$(document).on("click", "#btn_invest_btm", function() {
			var stk_code =  pageUnit.fn.getStkCode();
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"954"});
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"954", urlMapId: stk_code});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_section: function (data) {
			var outData = data.TDD5020_Q04;
			mydataCommon.util.consoleOut( data , '/reco/SReco0020004Ajax');
			
			if (outData && outData.resp_gubn == "0"){				
				outData.g1 = pageUnit.fn.checkRpDtlData(outData.g1);
				
				mydataCommon.util.consoleOut( outData , ' RP상품');
				ao_html('#rpGrde', outData.g1);
				ao_html('#rpDtlInfo', outData.g1);
				
			} else {
				mydataCommon.msg.alert({ msg : outData.resp_mesg });
			}
		},
		//
		checkRpDtlData : function(arr) {
			var rsArr = new Array(),
				stkCode =  pageUnit.fn.getStkCode();
			
			$.each( arr, function(i, v) {
				// RP운용구분 및 등급구분 세팅
				v.rp_grde_tp_str = pageUnit.fn.getGradeStyle(v.rp_grde_tp, 'rp_grde_tp'); //RP등급구분
				v.rp_mngm_tp_str = pageUnit.fn.getGradeStyle(v.rp_mngm_tp, 'rp_mngm_tp'); //RP운용구분
				
				v.engg_bf_intrt =  (parseInt(v.engg_bf_intrt*10)/100000).toFixed(2);
				v.engg_intrt = (parseInt(v.engg_intrt*10)/100000).toFixed(2);
				v.engg_af_intrt = (parseInt(v.engg_af_intrt*10)/100000).toFixed(2);
			
				// 종목코드와 RP상품코드 비교후 같으면 해당 리스트를 반환
				if ( v.rp_gds_code ==  stkCode ) rsArr.push(v);
			});
			return rsArr;
		},
		//상품 위험등급 및 RP운용구분 가져오기
		getGradeStyle : function(obj, tpNm ) {
			var gradeClassList = { /*상품위험등급*/
				"1": "초고위험",
				"2": "고위험",
				"3": "중위험",
				"4": "저위험",
				"5": "초저위험"
			};
			
			var MngmClassList = { /*RP운용구분*/
				"4": "리테일RP",
				"5": "리테일RP(VIP)"
			};

			// 상품위험등급
			if (tpNm == 'rp_grde_tp') {			
				for (var key in gradeClassList) 
					if(obj === key) return gradeClassList[key];
			}
			// RP운용구분
			else if (tpNm == 'rp_mngm_tp') {	 	
				for (var key in MngmClassList) 
					if(obj === key) return MngmClassList[key];
			} else { return; }
		},
		getStkCode : function() {
//			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			var param = pageUnit.trn_param;
			return param.stk_code;
		},
		req_error : function(data) {
			mydataCommon_02.util.log([
					'Reco002_0004.js :: req_error ----------> ', data ]);
		},
	},
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});