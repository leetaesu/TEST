var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010003P003Pop",
		v_storageKeyName : 'reco',
		v_storageSubKeyName : ''
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			/*투자성향 조회*/
			if ( exeType == 'getXMB4006_Q01' ){
				var jsonObj = {
						url : pageCom.prop.contextPath + "/reco/SReco00100010001Ajax",
						async : true,
						success : pageUnit.fn.set_XMB4006_Q01,
						error : function(data){
							pageUnit.fn.req_error(data);
						},
				}
				mydataCommon.ajax(jsonObj);
			} 
		}, 
		 
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		pageUnit.trn.ajax_call('getXMB4006_Q01');
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(value){
		
		//팝업닫기
		$(document).on("click", ".modal-close", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		// 이전 버튼
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		// 다음 버튼 KIWMYD_COM_001_0007 : 투자 성향 진단(설문 조사 항목)
		$(document).on("click", ".sub-next", function() {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO0107", callback:"callback_callMoveView", viewType:"half"});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_XMB4006_Q01 : function(data){
			mydataCommon.util.consoleOut( data , '투자성향 조회');
			
			var outData = data.resultMap; 
			if (outData && outData.resp_gubn == "0") { 
				
				outData.resk_tp = pageUnit.fn.getGradeStyle(outData.invt_prpn_tp);
				outData.invt_prpn_dgns_dt = mydataCommon.util.getStrDate(outData.invt_prpn_dgns_dt);
				mydataCommon.util.consoleOut(outData);
				ao_html('#invtPrpn', outData);
				
			} else {
			}
		},
		//투자성향 
		getGradeStyle : function(obj) {
			mydataCommon.util.consoleOut(obj);
			var gradeClassList = {
				
				공격투자형 : "1",
				적극투자형 : "2",
				위험중립형 : "3",
				안전추구형 : "4",
				안정형 : "5",
			}
			
			for(var key in gradeClassList) {
				if(obj === key)
				return gradeClassList[key];
			}
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
	}
};
//페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});