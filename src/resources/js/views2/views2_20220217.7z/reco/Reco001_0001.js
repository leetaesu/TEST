var pageUnit = {
		
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010001View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		sort_tp : null,
		index : 0,
	},
	
	// 전송 전용 프로퍼티 모음
	trn_param : {
//		fund_type_lrcl_code : '1',
//		fund_type_mdcl_code : "101"
			
	},
	
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
				/*투자성향 조회*/
				if ( exeType == 'invPrpesXMB4006_Q01' ){
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010001Ajax",
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				} 
				
				
				/* 이벤트 배너  */
				else if ( exeType == 'evtBanrXMA1001_Q03' ){
					var param = {
						banr_tp : "2", //배너유형구분
						banr_exps_tp : "09", //배너노출메뉴  
						acnt_lnkg_exps_tp : "01", //계좌연동노출유형
					}
					var jsonObj = {
							url : pageCom.prop.contextPath + "/common/SComBann001001Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				} 
				
				
				/* 투자성향에 맞는 상품추천(펀드) 조회*/
				else if(exeType == 'fundXMB4010_Q01'){
					var param = JSON.parse(mydataCommon.util.getData("fund"));
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010002Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				
				
				/* 투자성향에 맞는 상품추천(장외채권) 조회*/
				else if(exeType == 'otcBondXMB4010_Q02'){
					var param = JSON.parse(localStorage.getItem('otcBond')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010003Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				
				
				/* 투자성향에 맞는 상품추천(단기사채) 조회 */ 
				else if(exeType == 'shrtPrdbXMB4010_Q03'){
					var param = JSON.parse(localStorage.getItem('shrtPrdb')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010004Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				
				
				/* 투자성향에 맞는 상품추천(RP) 조회*/ 
				else if(exeType == 'rpXMB4010_Q04'){
					var param = JSON.parse(localStorage.getItem('rp')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010005Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				
				
				/* 투자성향에 맞는 상품추천(파생결합증권) 조회*/ 
				else if(exeType == 'elsbXMB4010_Q05'){
					var param = JSON.parse(localStorage.getItem('elsb')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco00100010006Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
				
			});	
		}
	},
	
	
	// 단위 진입부 함수
	init : function(){
		
		var dsrChk = mydataCommon.util.getData("dsrChk");
		if(dsrChk != null && dsrChk!=undefined && dsrChk!= ""){
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010002View"
		}else{
			var pageParam = mydataCommon.page.getParamData("");
			
//			if( Object.keys(pageParam).length == 0 ){        
//				pageParam.fund_type_lrcl_code = pageUnit.trn_param.fund_type_lrcl_code;  //펀드유형대분류코드   
//				pageParam.fund_type_mdcl_code = pageUnit.trn_param.fund_type_mdcl_code; //펀드유형중분류코드       
//				mydataCommon.util.consoleOut(pageParam);    
//				mydataCommon.page.setParamData(pageParam, true);   
//			};
			
			pageUnit.fn.set_sort_tp();
			
			mydataCommon.util.setData('fund', JSON.stringify({
				fund_type_lrcl_code: "1",
				fund_type_mdcl_code: "101"
			}));
			
			pageUnit.eventBind();
			pageUnit.fn.allSearch();
		}
		
	},
	
	
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		// 대출 tab
		$(document).on("click", "#tab_02", function() {
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010002View";
		});
		// 카드 tab
		$(document).on("click", "#tab_03", function() {
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010003View"
		});
		
		// 투자성향 확인하기 버튼
		$(document).on("click", "#loan_popup_1", function() {
//			mydataCommon.msg.alert({msg : '투자성향 확인하기'});
//			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"BANK03P03", callback:"callback_callMoveView", viewType:"half"});
//			pageUnit.fn.goAccListPrpnTpInfo();
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO01P03", callback:"callback_callMoveView", viewType:"half"});
		});
		
		$(document).on("change", "#sort_tp", function() {
			pageUnit.fn.set_sort_tp();
		});
		
		$("#fundSearch").on("click", function(obj){
			pageUnit.fn.fundSearch();
	    });
		
		//단순배너
		mydataCommon.util.getSimpleBanner({
		    banr_tp: "2",
		    banr_exps_tp: "09",
		    acnt_lnkg_exps_tp: "01"
		});
	},
	
	
	// 단위 전용 함수 모음 패키지
	fn : {
		fundSearch : function(res) {
			if(!pageUnit.fn.isValidForFundSearch()) return;
			
			mydataCommon.util.setData('fund', JSON.stringify({
				fund_type_lrcl_code: $('#sort_tp').val(),
				fund_type_mdcl_code: $('#sub_sort_tp').val()
			}));
			
			var ajax_call = pageUnit.trn.ajax_call;
			
			ajax_call('fundXMB4010_Q01').then(data =>{
				$('#fundList').children().remove();
				pageUnit.fn.set_section_fund(data);
			});
			
		},
		
		isValidForFundSearch : function() {
			var sort_tp = $('#sort_tp').val();
			var sub_sort_tp = $('#sub_sort_tp').val();
			var isNull = mydataCommon.util.isNull;


			if(isNull(sort_tp)) {
				mydataCommon.msg.alert({msg : "펀드 대분류를 선택해 주세요"});
				return false;
			}
			if(isNull(sub_sort_tp)) {
				mydataCommon.msg.alert({msg : "펀드 중분류를 선택해 주세요"});
				return false;
			}
			
			return true;
		},
		set_sort_tp : function() {
			var data = {
				subSortArr : pageUnit.fn.getSubSortList($("#sort_tp :selected").val())
			}
			ao_html('#sub_sort_tp', data);
		},
		
		allSearch : function(){
			var ajax_call = pageUnit.trn.ajax_call;
			
			ajax_call('invPrpesXMB4006_Q01').then(function(data){
				mydataCommon.util.consoleOut( data , '/reco/SReco00100010001Ajax(1)');
				pageUnit.fn.set_section(data);
				return ajax_call('fundXMB4010_Q01');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data , '/reco/SReco00100010002Ajax(2)' );
				pageUnit.fn.set_section_fund(data);
				return ajax_call('otcBondXMB4010_Q02');
				
			}).then(function(data){
				mydataCommon.util.consoleOut(data , '/reco/SReco00100010003Ajax(3)');
				pageUnit.fn.set_section_otc_bond(data);
				return ajax_call('shrtPrdbXMB4010_Q03');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data , '/reco/SReco00100010004Ajax(4)');
				pageUnit.fn.set_section_shrt_prdb(data);
				return ajax_call('rpXMB4010_Q04');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data , '/reco/SReco00100010005Ajax(5)');
				pageUnit.fn.set_section_rp(data);
				return ajax_call('elsbXMB4010_Q05');
				
			}).then(function(data){
				mydataCommon.util.consoleOut( data , '/reco/SReco00100010006Ajax(6)');
				pageUnit.fn.set_section_elsb(data);

			}).catch(function(e){
				console.error(e);
			});
			
		},
		
		
		//투자성향 조회 세팅
		set_section : function (data){
			var outData = data.resultMap,
				recoPrdctFlag = pageUnit.fn.recoPrdctFlag(outData.recoPrdctRespGubn);

				var invTndncCmt_lst = ["인"," 성향을 가진",''];
				var recoPrdctCmt_str = "";//입니다.
 				
				//고객님의 개인 추천 조건 안내 멘트 영역  
				if (outData && outData.resp_gubn == "0") { 
					
					// 추천된 상품이 없는 경우
					if ( recoPrdctFlag == false ) {
						recoPrdctCmt_str = "추천 상품이 없습니다.";
						
						if(outData.invt_prpn_tp != '전문투자자' && outData.invt_prpn_tp != null && outData.invt_prpn_tp != '') {
							/* 추천된 상품이 없는(투자성향 O) */
							outData.resk_tp = pageUnit.fn.getGradeStyle(outData.invt_prpn_tp);	
							outData.invTndncCmt = invTndncCmt_lst[1];
							outData.recoPrdctCmt = recoPrdctCmt_str;
						
						} else {
							/* 추천된 상품이 없는(투자성향 X) */
							$('.invRisk').hide();
							$('#loan_popup_1').hide();
							outData.invTndncCmt = invTndncCmt_lst[2];
							outData.recoPrdctCmt = recoPrdctCmt_str;
						}
	 				}
					// 추천된 상품이 있는 경우
					else {
	 					recoPrdctCmt_str = "추천 상품입니다.";
	 					
	 					if(outData.invt_prpn_tp != '전문투자자' && outData.invt_prpn_tp != null && outData.invt_prpn_tp != ''){
							/* 투자성향 O */
							outData.resk_tp = pageUnit.fn.getGradeStyle(outData.invt_prpn_tp);	
							outData.invTndncCmt = invTndncCmt_lst[1];
							outData.recoPrdctCmt = recoPrdctCmt_str;
						}
	 					else {
	 						/* 투자성향 X */
	 						$('.invRisk').hide();
							$('#loan_popup_1').hide();
							outData.invTndncCmt = invTndncCmt_lst[2];
							outData.recoPrdctCmt = recoPrdctCmt_str;
						}
	 				};
	 				
	 				ao_html('#caseCmt',outData); 
	 				
	 				if($('#recoPrdctCmt').text() === '추천 상품이 없습니다.')
	 					$('#fundShow').hide();
	 					
				} else { 
				 		mydataCommon.msg.alert({msg : outData.resp_mesg}); 
				}
		},
		
		
		//펀드 상품목록 XMB4010_Q01
		set_section_fund : function (data) {
			
			var outData = data.resultMap;
			var outDataG1 = data.resultMap.g1;
			
			if (outData && outData.resp_gubn == "0") { 
				
				mydataCommon.util.removeData('fund');
				
				//대분류 타입 value 가져오기
				var sort_tp = $("#sort_tp :selected").val(); 
				pageUnit.prop.sort_tp = sort_tp
				
				//중분류 리스트맵 가져오기
				outData.subSortArr = pageUnit.fn.getSubSortList(sort_tp);
				
//				ao_html('#fundList', outDataG1);
				
				//다음 데이터 존재 여부 체크
				$("#fundList").parent().removeClass('d-none');
				
				$.each(outDataG1, function(i, v) {
					v.el = "fund";
					v.output_grade_tp = pageUnit.fn.getGradeStyle(v.gds_risk_grade_nm);
					ao_append('#fundList', v);
				});
				
				ao_html('#fundMoreView', outData);
				
				$("#fundMoreView").show();
				$("#noFund").hide();
				
			} else {
//				if (outData.resp_mesg == "펀드 상품목록 자료가 존재하지 않습니다.") mydataCommon.msg.alert({msg : outData.resp_mesg});
				$("#noFund").show();
				$("#noFund").text(outData.resp_mesg);
				$("#fundMoreView").hide();
			}
		},
		
		//장외채권 상품목록 XMB4010_Q02
		set_section_otc_bond : function (data) {
			
			var outData = data.resultMap;
			
			if (outData && outData.resp_gubn == "0"){ 

				mydataCommon.util.removeData('otcBond');
				$("#otcBondList").parent().removeClass('d-none'); 
				
				ao_html('#otcBondMoreView',outData);
				
				$.each(outData.g1, function(i, v) {
					v.el = "otcBond";
					v.output_grade_tp = pageUnit.fn.getGradeStyle(v.gds_risk_grade_nm);
					ao_append('#otcBondList', v);
				});
			} else {
//				if (!outData.resp_mesg == "자료가 존재하지 않습니다.") mydataCommon.msg.alert({msg : outData.resp_mesg});
				$("#resp_mesg1").show();
				$("#resp_mesg1").text(outData.resp_mesg);
				$("#moreView1").hide();
				$("#overTheCounterBonds").hide();
			}
		},
		
		
		//단기사채 상품목록 XMB4010_Q03
		set_section_shrt_prdb : function (data) {
			
			var outData = data.resultMap;

			//테스트데이터
//			var g1 = [{
//				stk_code : "12123123",
//				output_grade_tp : "1",
//				gds_risk_grade_nm : "고위험",
//				gds_nm : "테스트 데이터",
//				crd_grade_nm : "131231",
//				taxb_errt : "7,7"
//			}]
//			
//			outData.g1 = g1;
			
			if (outData && outData.resp_gubn == "0"){ 
				mydataCommon.util.removeData('shrtPrdb');
				
				$("#shrtPrdbList").parent().removeClass('d-none');
				
				ao_html('#shrtPrdbMoreView',outData);
				
				$.each(outData.g1, function(i, v) {
					v.el = "shrtPrdb";
					v.output_grade_tp = pageUnit.fn.getGradeStyle(v.gds_risk_grade_nm);
					ao_append('#shrtPrdbList', v);
				});
			} else {
//				if (!outData.resp_mesg == "자료가 존재하지 않습니다.") mydataCommon.msg.alert({msg : outData.resp_mesg});
				$("#resp_mesg2").show();
				$("#resp_mesg2").text(outData.resp_mesg);
				$("#moreView2").hide();
				$("#shortTermBonds").hide();
			}
		},
		
		
		//RP 상품 목록 XMB4010_Q04
		set_section_rp : function (data) {
			
			var outData = data.resultMap;
			
			if (outData && outData.resp_gubn == "0"){ 
				mydataCommon.util.removeData('rp');
				$("#rpList").parent().removeClass('d-none');
				
				ao_html('#rpMoreView',outData);
				
				$.each(outData.g1, function(i, v) {
					v.el = "rp";
					v.output_grade_tp = pageUnit.fn.getGradeStyle(v.gds_risk_grade_nm);
					ao_append('#rpList', v);
				});
			} else {
//				if (!outData.resp_mesg == "자료가 존재하지 않습니다.") mydataCommon.msg.alert({msg : outData.resp_mesg});
				$("#resp_mesg3").show();
				$("#resp_mesg3").text(outData.resp_mesg);
				$("#moreView3").hide();
				$("#bondRP").hide();
			}
		},
		
		
		//파생결합 상품목록 XMB4010_Q05
		set_section_elsb : function (data) {
			
			var outData = data.resultMap;
			
			if (outData && outData.resp_gubn == "0"){ 
				mydataCommon.util.removeData('elsb');
				$("#elsbList").parent().removeClass('d-none'); 
				
				ao_html('#elsbMoreView',outData);
				
				$.each(outData.g1, function(i, v) {
					v.el = "elsb";
					v.output_grade_tp = pageUnit.fn.getGradeStyle(v.gds_risk_grade_nm);
					ao_append('#elsbList', v);
				});
			} else {
//				if (!outData.resp_mesg == "자료가 존재하지 않습니다.") mydataCommon.msg.alert({msg : outData.resp_mesg});
				$("#resp_mesg4").show();
				$("#resp_mesg4").text(outData.resp_mesg);
				$("#moreView4").hide();
				$("#derivativeLinkedSecurities").hide();
			}
				
		},
		
		//더보기 조회
		getMoreNextData : function(cont_gubn, next_data, stkType) {
			var setDataMap = {};
			setDataMap.cont_gubn = cont_gubn;
			setDataMap.next_data = next_data;
			
			mydataCommon.util.setData(stkType, JSON.stringify(setDataMap));
			switch (stkType) {
				case 'fund':
					mydataCommon.util.setData(stkType, JSON.stringify({
						cont_gubn,
						next_data,
						fund_type_lrcl_code: $('#sort_tp').val(),
						fund_type_mdcl_code: $('#sub_sort_tp').val()
					}));
					
					pageUnit.trn.ajax_call('fundXMB4010_Q01').then(function(data) {
						pageUnit.fn.set_section_fund(data);	
					});
					break;
				case 'otcBond':
					pageUnit.trn.ajax_call('otcBondXMB4010_Q02').then(function(data) {
						pageUnit.fn.set_section_otc_bond(data);
					});
					break;
				case 'shrtPrdb':
					pageUnit.trn.ajax_call('shrtPrdbXMB4010_Q03').then(function(data) {
						pageUnit.fn.set_section_shrt_prdb(data);
					});
					break;
				case 'rp':
					pageUnit.trn.ajax_call('rpXMB4010_Q04').then(function(data) {
						pageUnit.fn.set_section_rp(data);
					});
					break;
				case 'elsb':
					pageUnit.trn.ajax_call('elsbXMB4010_Q05').then(function(data) {
						pageUnit.fn.set_section_elsb(data);
					});
					break;
				}
			
		},
		
//		//다음의 연속적인 데이터 조회를 위한 설정
//		checkNextData : function(resData, elId ) {
//			var icon_more = $("#"+elId+"").next(); //더보기 버튼
//			
//			if ( resData.g1 == null || resData.g1 == undefined || resData.g1.length == 0 || resData.cont_gubn == "N"){	
//				icon_more.hide();
//			}else if(resData.cont_gubn == "Y" && resData.next_data != "" ){
//				icon_more.show();
//				
//				var setDataMap = {};
//				setDataMap.cont_gubn = resData.cont_gubn;
//				setDataMap.next_data = resData.next_data;
//				
//				mydataCommon.util.removeData(elId);
//				mydataCommon.util.setData(elId, JSON.stringify(setDataMap));
//			}
//		},
		
		
		//recoPrdctFlag
		recoPrdctFlag : function(obj) {
			var flagCnt = 0,
				recoPrdctFlag = false; 
			
			$.each(obj, function(idx) {
				if(obj[idx].resp_gubn === "1") flagCnt++;
			})
			if (flagCnt == 5) {
				recoPrdctFlag = false; 
			} else {
				recoPrdctFlag = true; 
			}
			return recoPrdctFlag;
		},
		
		
		//상품위험등급 
		getGradeStyle : function(obj) {
			var gradeClassList = {
					
				// 금융상품(펀드제외) 위험등급
				"초고위험"	: "1",
				"고위험"	: "2",
				"중위험"	: "3",
				"저위험"	: "4",
				"초저위험"	: "5",	
				
				// 펀드 위험등급  
				"매우높은위험"	: "1",
				"높은위험"    	: "2",
				"다소높은위험"	: "3",
				"보통위험"		: "4",
				"낮은위험"		: "5",
				"매우낮은위험"	: "6",
				
				//투자성향 
				"공격투자형" : "1",
				"적극투자형" : "2",
				"위험중립형" : "3",
				"안전추구형" : "4",
				"안정형" : "5",
			}
			
			for (var key in gradeClassList) 
				if(obj === key)
					return gradeClassList[key];
		},
		
		
		//중분류 리스트맵 가져오기
		getSubSortList : function(obj) {
			
			var subSortMap = {
				
				// 대분류 :투자지역
				"1" : [{sub_sort_nm : '국내투자', sub_sort_value : '101'},
				      {sub_sort_nm : '해외투자', sub_sort_value : '102'}],
				// 대분류 :상품유형
				"2" : [{sub_sort_nm : '주식형', sub_sort_value : '201'},
				      {sub_sort_nm : '채권형', sub_sort_value : '202'},
				      {sub_sort_nm : '대체투자형', sub_sort_value : '203'}],
				// 대분류 :변동성      
				"3" : [{sub_sort_nm : '저변동성', sub_sort_value : '301'},
				      {sub_sort_nm : '중변동성', sub_sort_value : '302'},
				      {sub_sort_nm : '고변동성', sub_sort_value : '303'}],
				// 대분류 :투자스타일      
				"4" : [{sub_sort_nm : '대형 가치주', sub_sort_value : '401'},
				      {sub_sort_nm : '중형 가치주', sub_sort_value : '402'},
				      {sub_sort_nm : '소형 가치주', sub_sort_value : '403'},
				      {sub_sort_nm : '대형 혼합', sub_sort_value : '404'},
				      {sub_sort_nm : '중형 혼합', sub_sort_value : '405'},
				      {sub_sort_nm : '소형 혼합', sub_sort_value : '406'},
				      {sub_sort_nm : '대형 성장주', sub_sort_value : '407'},
				      {sub_sort_nm : '중형 성장주', sub_sort_value : '408'},
				      {sub_sort_nm : '소형 성장주', sub_sort_value : '409'},
				      {sub_sort_nm : '장기 고신용등급', sub_sort_value : '410'},
				      {sub_sort_nm : '장기 중신용등급', sub_sort_value : '411'},
				      {sub_sort_nm : '장기 저신용등급', sub_sort_value : '412'},
				      {sub_sort_nm : '중기 고신용등급', sub_sort_value : '413'},
				      {sub_sort_nm : '중기 중신용등급', sub_sort_value : '414'},
				      {sub_sort_nm : '중기 저신용등급', sub_sort_value : '415'},
				      {sub_sort_nm : '단기 고신용등급', sub_sort_value : '416'},
				      {sub_sort_nm : '단기 중신용등급', sub_sort_value : '417'},
				      {sub_sort_nm : '단기 저신용등급', sub_sort_value : '418'}],
				      
				      // 대분류 :투자지표      
				"5" : [{sub_sort_nm : '샤프지수', sub_sort_value : '501'},
					  {sub_sort_nm : '트레이너지수', sub_sort_value : '502'},
					  {sub_sort_nm : '젠센의 알파', sub_sort_value : '503'},
					  {sub_sort_nm : '정보비율', sub_sort_value : '504'}]
			}
			
			for (var key in subSortMap) 
				if(obj === key)
					return subSortMap[key];
		},
		
		
		//추천상품 자세히 보기
		popDetail : function(stk_code, el){
			var urlMapId = pageUnit.fn.getPopDtlUrlMapId(el);
			var pageParam = mydataCommon.page.getSubParamData();
			
			if (el == 'fund') {
				pageParam.stk_code = stk_code;
			} else {
				pageParam.stk_code = stk_code;
			}
			mydataCommon.page.setSubParamData(pageParam);
			
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId: urlMapId, callback:"callback_callMoveView"});
		},
		
		
		//MapId 찾기
		getPopDtlUrlMapId : function(obj) {
			
			var	urlMapIdClass = {
				fund 	 : "RECO0201",
				otcBond  : "RECO0202",
				shrtPrdb : "RECO0203",
				rp		 : "RECO0204",
				elsb	 : "RECO0205" 
			}
			
			for (var key in urlMapIdClass) 
				if(obj === key)
					return urlMapIdClass[key];
		},
		
		
		//투자성향 확인하기 >
		goAccListPrpnTpInfo : function () {
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId:"RECO01P03", callback:"callback_callMoveView", viewType:"half"});
		},
		req_error : function (data){
			mydataCommon_02.util.log(['Reco001_0001.js :: req_error ----------> ', data]);
			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
		},
		
	},
	
	
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		
	}
	
	
};


// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});


