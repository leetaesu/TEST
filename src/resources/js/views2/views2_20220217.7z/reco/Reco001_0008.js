var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010008View",
		v_storageKeyName : 'reco',
		v_storageSubKeyName : ''
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		 
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(value){
		// 뒤로가기
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
	}
};
//페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});