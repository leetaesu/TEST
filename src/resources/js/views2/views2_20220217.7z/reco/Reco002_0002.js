var pageUnit = {

	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0020002View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		trdeInfoData : {},
		strSendViewData : '',
	}, 
	// 전송 전용 프로퍼티 모음
	trn_param : {
		//test 용 param
		stk_code: 'KR6008691B66', //한양69(녹)
//		stk_code: 'KR6030041B42', //중앙일보38
//		stk_code: 'KR6335157998', //칼제이십사차유1-7
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
//				var param = mydataCommon.page.getSubParamData('VReco0010001View');
				var param = pageUnit.trn_param;
				
				//장외채권 공시매매 종목정보 조회(홈,H,영S,자) TDD2001_Q06
				if ( exeType == 'elsbTDD2001_Q06' ) {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020002Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
//								pageUnit.fn.req_error(data);
								res;
							},
						}
						mydataCommon.ajax(jsonObj);	
				} 
				//장외채권 일반공시 종목상세내역(채널사용) TDD2001_Q07
				else if(exeType == 'elsbTDD2001_Q07') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020002P001Ajax",
							async : true,
							data : param,
							success : res,
							error : function(data){
//								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
			});	
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		var ajax_call = pageUnit.trn.ajax_call;
		
		ajax_call('elsbTDD2001_Q06').then(function(data){
			mydataCommon.util.consoleOut( data , '/reco/SReco0020002Ajax');
			pageUnit.fn.set_TDD2001_Q06(data);
			return ajax_call('elsbTDD2001_Q07');
			
		}).then(function(data){
			mydataCommon.util.consoleOut( data , '/reco/SReco0020002P001Ajax' );
			pageUnit.fn.set_TDD2001_Q07(data);
			
		}).catch(function(e){
//			console.error(e);
		});
		
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		//TODO set button click event 
		
		//이전화면
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});

		//가상매매
		$(document).on("click", "#btn_virtual_trade", function() {
			var pageParam = mydataCommon.page.getSubParamData(),
				trdeInfoData = pageUnit.prop.trdeInfoData;
			
			pageParam.stk_code = pageUnit.fn.getStkCode();	
			pageParam.trde_prft_rt = trdeInfoData.trde_prft_rt ;	
			pageParam.trde_uv = trdeInfoData.trde_uv;
			
			mydataCommon.page.setSubParamData(pageParam);
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020002P001Pop";
		});
		
		//투자하기 상단버튼 (영S)
		$(document).on("click", "#btn_invest_top", function() {
			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"566"});
		});
		
		//투자하기 하단버튼 (영S)
		$(document).on("click", "#btn_invest_btm", function() {
//			var strSendViewData = pageUnit.prop.strSendViewData;
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"566", urlMapId: strSendViewData});
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"566"});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_TDD2001_Q06 : function(data){
			
			var outData = data.TDD2001_Q06;
			var trdeInfoData = {};
			
			if ( outData && outData.resp_gubn == "0" ) { 
				
				$.each(outData.g1, function(i, v) {
					trdeInfoData = {
							trde_prft_rt : (parseInt(v.trde_prft_rt*10)/1000).toFixed(2),
							trde_uv : mydataCommon.util.addComma(parseInt(v.trde_uv)),
							taxa_errt : (parseInt(v.taxa_errt*10)/1000).toFixed(2),
							trde_alowq : mydataCommon.util.addComma(parseInt(v.trde_alowq))
					};
				});
			} else {
				trdeInfoData = { trde_prft_rt : '0.00',	trde_uv : '0', taxa_errt : '0.00', trde_alowq : '0'};
			}
			pageUnit.prop.trdeInfoData = trdeInfoData;
			
		},
		set_TDD2001_Q07 : function(data){
			
			var outData = data.TDD2001_Q07;
			var trdeInfoData = pageUnit.prop.trdeInfoData;
			
			if ( outData && outData.resp_gubn == "0" ) { 
				var sendStr = '0;'+outData.stk_code+';'+outData.stk_nm.replace('&#40;','(')+';'+trdeInfoData.trde_prft_rt+';'+trdeInfoData.trde_uv+'.00 '+trdeInfoData.trde_alowq+';';
				pageUnit.prop.strSendViewData = sendStr;
				mydataCommon.util.consoleOut(sendStr);
				
				outData.trde_prft_rt = trdeInfoData.trde_prft_rt;
				outData.taxa_errt = trdeInfoData.taxa_errt;
				outData.remn_dys = outData.remn_dys.replace(/-/gi,'');
				outData.trde_uv = trdeInfoData.trde_uv;
				
				outData.isu_dt = mydataCommon.util.getStrDate(outData.isu_dt);
				outData.expr_dt = mydataCommon.util.getStrDate(outData.expr_dt);
				outData.isu_intrt = (parseInt(outData.isu_intrt/10)/100).toFixed(2);
				outData.dsct_rt = (parseInt(outData.dsct_rt/10)/100).toFixed(2);
				outData.tot_isu_qty =  mydataCommon.util.addComma(parseInt(outData.tot_isu_qty));
				outData.repl_pric = mydataCommon.util.addComma(parseInt(outData.repl_pric));
				outData.evlt_uv = mydataCommon.util.addComma(parseInt(outData.evlt_uv));
				
				ao_html('#otcBondRt', outData);
				ao_html('#otcBondGrde', outData);
//				ao_html('#otcBondStkNm', outData);
				ao_html('#otcBondInfoTable', outData);

			} else {
				
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
				
			}
		},
		getStkCode : function() {
//			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			var param = pageUnit.trn_param;
			return param.stk_code;
		},
		req_error : function(data){
//			mydataCommon_02.util.log(['Reco002_0002_1.js :: req_error ----------> ', data]);
//			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
		},
		getGradeStyle : function(obj) {
			var gradeClassList = {
				"1": "초고위험",
				"2": "고위험",
				"3": "중위험",
				"4": "저위험",
				"5": "초저위험"
			}
			for (var key in gradeClassList) 
				if(obj === key)
					return gradeClassList[key];
		},
	}// end fn
}
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});


