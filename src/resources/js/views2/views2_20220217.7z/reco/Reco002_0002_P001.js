var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0020002P001Pop",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		default_dt : mydataCommon.util.getStrDate(),
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
		stk_code: 'KR6335157998'
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
				/*장외채권 일반공시 종목상세내역 조회 */
				if ( exeType == 'vrtlTradeTDD2001_Q07' ) {
						var param = mydataCommon.page.getSubParamData('VReco0020002View');
					
						var jsonObj = {
								url : pageCom.prop.contextPath + "/reco/SReco0020002P001Ajax",
								data : param,
								async : true,
								success : res,
								error : function(data){
									pageUnit.fn.req_error(data);
									res;
								}
							}
							mydataCommon.ajax(jsonObj);	
				}
				/*장외채권 가상매매 결과보기*/
				else if ( exeType == 'vrtlTradeRstTDD2009_Q01' ) {
					
					var param = mydataCommon.makeSerialParam({target : $("#virtualSelBuy")});
					mydataCommon.util.consoleOut(param);
					var jsonObj = {
						url : pageCom.prop.contextPath + "/reco/SReco0020002P002Ajax",
						async : true,
						data : param,
						success : res,
						error : function(data) {
							pageUnit.fn.req_error(data);
							res;
						}
					}
					mydataCommon.ajax(jsonObj);	
				}
			});
		}
	},
	// 단위 진입부 함수
	init : function() {
		
		pageUnit.trn.ajax_call('vrtlTradeTDD2001_Q07')
		.then(function(data) {
			mydataCommon.util.consoleOut(data, '/reco/SReco0020002P001Ajax ');
			pageUnit.fn.set_vrtlTradeTDD2001_Q07(data);

		}).catch(function(e){
			console.error(e);
		});
		pageUnit.eventBind();
		pageUnit.fn.validateDateEvt();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function() {
		
	/* onClickEvent */

		// 닫기
		$(document).on("click", ".modal-close", function() {
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020002View"
			// mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		// 닫기
		$(document).on("click", ".modal-closeBtn", function() {
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0020002View"
			// mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});
		
		// 가상매매(결과) 조회하기
		$(document).on("click", "#virtualTradeResultBtn", function() {
			pageUnit.fn.validateFn();
			pageUnit.trn.ajax_call('vrtlTradeRstTDD2009_Q01')
			.then(function(data) {
				mydataCommon.util.consoleOut(data, '/reco/SReco0020002P002Ajax ');
				pageUnit.fn.pageLocationBeforeAction(data);

			}).catch(function(e){
				console.error(e);
			});
		});
		
	/*onChangeEvent*/
		
		// 투자구분 이벤트
		$(document).on("change", "input[name='mngm_chos']", function() {
			var mngm_chos = $(this).val(),								  //투자구분 값
				uv_inpt_tp = $("input[name='uv_inpt_tp']:checked").val(); //입력구분 값

			pageUnit.fn.setChangeInputDisabled(mngm_chos, uv_inpt_tp, '[투자구분:mngm_chos]');
		});
		
		// 입력구분 이벤트
		$(document).on("change", "input[name='uv_inpt_tp']", function() {
			var mngm_chos = $("input[name='mngm_chos']:checked").val(), //투자구분 값
				uv_inpt_tp = $(this).val();								//입력구분 값
			
			pageUnit.fn.setChangeInputDisabled(mngm_chos, uv_inpt_tp, '[입력구분:uv_inpt_tp]');
		});
		
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		// 장외채권 일반공시 종목상세내역 조회 : 가상 매매(조회)
		set_vrtlTradeTDD2001_Q07 : function(data){
			
			var outData = data.TDD2001_Q07;

			if ( outData && outData.resp_gubn == "0" ) {
				
				var param = mydataCommon.page.getSubParamData('VReco0020002View');
				//매수수익율
				outData.trde_prft_rt = param.trde_prft_rt;
				//매수단가
				outData.trde_uv = param.trde_uv;

				ao_html('#vrtlTradeInfo', outData);
				ao_html('#vrtlTradeRstInfo', outData);
				ao_html('#sel_uv_inpt_tp', outData);
				
				$("#buy_dt").val(mydataCommon.util.getStrDate(pageUnit.prop.default_dt));
				$("#sell_dt").val(mydataCommon.util.getStrDate(pageUnit.prop.default_dt));
				
			} else {
				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
			
		},
		// 가상 매매(결과) 페이지 세팅
		pageLocationBeforeAction : function(data) {
			var outData = data.TDD2009_Q01;
			
			if ( outData && outData.resp_gubn == "0" ) {
				
				$('#vrtlTradeRst').addClass('is-open');
				
				outData.expr_dt = mydataCommon.util.getStrDate(outData.expr_dt);
				outData.isu_intrt = parseInt(outData.isu_intrt) / 1000;
				outData.tot_pay_int_taxb_inco =  mydataCommon.util.addComma(parseInt(outData.tot_pay_int_taxb_inco));
				outData.poss_term_int_tot_inco =  mydataCommon.util.addComma(parseInt(outData.poss_term_int_tot_inco));
				outData.wthl_amt_tot_inco =  mydataCommon.util.addComma(parseInt(outData.wthl_amt_tot_inco));
				outData.rpy_amt_prnca =  mydataCommon.util.addComma(parseInt(outData.rpy_amt_prnca));
				outData.taxa_real_recv_amt_inco =  mydataCommon.util.addComma(parseInt(outData.taxa_real_recv_amt_inco));
				outData.taxb_tot_invt_errt = parseInt(outData.taxb_tot_invt_errt) / 100;
				outData.taxb_errt = parseInt(outData.taxb_errt) / 100;
				outData.taxa_tot_invt_errt = parseInt(outData.taxa_tot_invt_errt) / 100;
				outData.taxa_errt = parseInt(outData.taxa_errt) / 100;
				
				ao_html('#vrtlTradeRstDtl', outData); //가상매매 결과 : 상품정보 
				ao_html('#leePyochaeFlow', outData);//이표채흐름
				ao_html('#expctInvst', outData);//예상투자성과

				// 가상매매결과 - 예상현금흐름
				$.each(outData.g1, function(i, v) {
					
					v.sttx_stdt = mydataCommon.util.getStrDate(v.sttx_stdt);
					v.pay_frcs_dt = mydataCommon.util.getStrDate(v.pay_frcs_dt);
					v.pay_int = mydataCommon.util.addComma(parseInt(v.pay_int));
					v.finalTax =mydataCommon.util.addComma( parseInt(v.incm_tax)+ parseInt(v.cvil_tax)+ parseInt(v.rurl_tax));
					
					ao_append('#expctCashFlow', v);
				});
				
			} else {
				$('#buy_dt').val(mydataCommon.util.getStrDate($('#buy_dt').val()));
				$('input[name="sell_dt"]').val(mydataCommon.util.getStrDate($('input[name="sell_dt"]').val()));
				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		
		//상품위험등급
		getGradeStyle : function(obj) {
			var gradeClassList = {
				"초고위험"	: "1",
				"고위험"	: "2",
				"중위험"	: "3",
				"저위험"	: "4",
				"초저위험"	: "5"
			}
			for (var key in gradeClassList) 
				if(obj === key)
					return gradeClassList[key];
		},
		validateFn : function() {
			var buy_dt = $('#buy_dt'),
				sell_dt = $('input[name="sell_dt"]');
			pageUnit.fn.removeStrDate(buy_dt);
			pageUnit.fn.removeStrDate(sell_dt);

		},
		// 매수일자, 매도일자 유효성검사
		validateDateEvt : function() {
			$('#sell_dt').off("keypress").on("keypress", function(e) {
				e = e || window.event;
				var charCode = e.which || e.keyCode;
				if (!((charCode >= 48 && charCode <=57) || charCode === 46)) {
					mydataCommon.util.consoleOut('charCode false');
					return false;
				}else {
					mydataCommon.util.consoleOut('charCode true');
				}
			});
			$('#buy_dt').off("keypress").on("keypress", function(e) {
				e = e || window.event;
				var charCode = e.which || e.keyCode;
				if (!((charCode >= 48 && charCode <=57) || charCode === 46)) {
					mydataCommon.util.consoleOut('charCode false');
					return false;
				}else {
					mydataCommon.util.consoleOut('charCode true');
				}
			});
			$('#sell_dt').off("blur").on("blur", function() {
				var elId = $(this).attr('id');
				pageUnit.fn.validateDate(elId);
			});
			$('#buy_dt').off("blur").on("blur", function() {
				var elId = $(this).attr('id');
				pageUnit.fn.validateDate(elId);
			});
			$('#testInput').off("keypress").on("keypress", function(e) {
				e = e || window.event;
				var charCode = e.which || e.keyCode;
				if (!((charCode >= 48 && charCode <=57) || charCode === 46)) {
					mydataCommon.util.consoleOut('charCode false');
					return false;
				}else {
					mydataCommon.util.consoleOut('charCode true');
				}
			});
			
		},
		validateDate : function(elId) {
			var value = $("#"+elId).val();
				mydataCommon.util.consoleOut(value);
			var DateReg =/^(19|20\d{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[0-1])$/;
			var DateRegDotVer =/^(19|20\d{2}).(0[1-9]|1[012]).(0[1-9]|[12][0-9]|3[0-1])$/;
			
			if (value == '') return;
			if (!DateReg.test(value) && !DateRegDotVer.test(value)) {
				mydataCommon.msg.alert({msg : "유효한 매수일자를 입력하세요"});
				$("#"+elId).val("");
				return;
			} else if (DateReg.test(value)) {
				$("#"+elId).val(mydataCommon.util.getStrDate( value ));
			}

		},
		removeStrDate : function(paramobj) {
			var $obj = paramobj;
			var value = $obj.val() || "";
			
			if(value === "") return;
			
			value = value.replace(/\./gi, "");
			$obj.val(value);
		},
		
		callback_getKeypadResult : function(jsonString){
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;
			/* 매매 수량	{keypadType : '0', maxLength : '15', rId : 'trde_qty'}
			 * 매수 금액	{keypadType : '3', maxLength : '8', rId : 'buy_uv_inpt'}
			 * 매도 단가	{keypadType : '3', maxLength : '8', rId : 'sell_uv_inpt'}
			 * 매매 수익률	{keypadType : '3', maxLength : '5', rId : 'buy_prft_rt'}
			 * 매도 수익률	{keypadType : '3', maxLength : '5', rId : 'sell_prft_rt'} */
			if (rId == "buy_uv_inpt" || rId == "sell_uv_inpt") {  
				nVal = mydataCommon.util.addComma( nVal );
			} else if (rId == "sell_prft_rt" || rId == "sell_prft_rt") {
				var regExp1 =/^\d*.?\d{0,2}$/;
				var regExp2 =/^\.|\.$/;
				
				if (!regExp1.test(nVal)){
					mydataCommon.msg.alert({msg : "소수점2자리까지만 입력해주세요"});
					return;
				} 
				if (regExp2.test(nVal)) nVal = nVal.replace('.','');
			}
			
			$("#"+rId).val(nVal);
			pageUnit.fn.checkNull(); 
		},	
		//form input 셋팅
		setChangeInputDisabled( mngm_chos, uv_inpt_tp , targetStr){

			//투자구분이 중도매도 일경우
			if (mngm_chos == '1') {
				
				//매도일자 input 활성화
				$("input[name='sell_dt']").prop('disabled', false);
				
				if (uv_inpt_tp =='Y') {
					//입력구분이 단가일경우
					$('.unit_price').show();
					$('.profit_rate').hide();
					$(".profit_rate input[type='number']").prop('disabled', true );
					$(".unit_price input[type='number']").prop('disabled', false);
				} else {
					//입력구분이 수익률일경우
					$('.profit_rate').show();
					$('.unit_price').hide();
					$(".unit_price input[type='number']").prop('disabled', true);
					$(".profit_rate input[type='number']").prop('disabled', false);
				} 
				
			} else {
			//투자구분이 만기상환 일경우
				$("input[name='sell_dt']").prop('disabled', true);
				$("#midwaySale .profit_rate input[type='number']").prop('disabled', true);
				$("#midwaySale .unit_price input[type='number']").prop('disabled', true);
			}
			
			mydataCommon.util.consoleOut([{ 
				'투자구분 값'	: 	mngm_chos ,
				'입력구분 값'	: 	uv_inpt_tp ,
				'매도일자 input': 	$("input[name='sell_dt']").prop('disabled') == true? '비활성화': '활성화' ,
				'단가 input'	: 	$("#midwaySale .unit_price input[type='number']").prop('disabled') == true? '비활성화': '활성화' ,
				'수익률 input'	:  	$("#midwaySale .profit_rate input[type='number']").prop('disabled') == true? '비활성화': '활성화'}],
				targetStr
			);
		},
		req_error : function(data){
			mydataCommon_02.util.log(['VLoa0020002P001.js :: req_error ----------> ', data]);
			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
		},
	} // end fn
} // end pageUnit

// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});


