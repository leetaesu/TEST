var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010003View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
//		ajax_call : function(exeType){
//			if ( exeType == 'S' ){		
//				var jsonObj = {
//						url : pageCom.prop.contextPath + "/reco/",
//						data : pageUnit.trn_param,
//						async : true,
//						beforeSend : pageUnit.fn.set_section,
//						success : pageUnit.fn.set_section,
//						error : pageUnit.fn.req_error
//				}
//			}
//		}
	},
	// 단위 진입부 함수
	init : function(){
		
//		pageUnit.trn.ajax_call('S');
		pageUnit.eventBind();
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		//tab투자 영역
		$("#tab_01").off("click").on("click", function(){
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010001View"
		});	
		//tab대출 영역
		$("#tab_02").off("click").on("click", function(){
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010002View"
		});	

	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_section : function (res){
			if (res.resultMap && res.resultMap.resp_gubn == "0"){
				
			} else { 
		 		mydataCommon.msg.alert({msg : outData.resp_mesg}); 
		 	}
		},
		req_error : function (data){
			mydataCommon_02.util.log(['Reco001_0003.js :: req_error ----------> ', data]);
			mydataCommon.msg.alert({msg : "오류가 발생하였습니다. \n계속발생시 시스템 담당자에게 문의 하시길 바랍니다."});
		},
	},
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});