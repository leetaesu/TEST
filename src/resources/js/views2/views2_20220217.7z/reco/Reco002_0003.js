var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {                 
		v_id : "VReco0020003View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		strSendViewData : '', 
		trdeInfoData : {},
	},                                   
	// 전송 전용 프로퍼티 모음
	trn_param : {
		stk_code: 'KRZS36076005', //와이비풍암
	},
	//	단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
	//			var param = mydataCommon.page.getSubParamData('VReco0010001View');
				var param = pageUnit.trn_param;
				
				/*단기사채 상세정보 조회 TDD4021_Q06*/
				if ( exeType == 'shrtPrdbInfo' ){
					
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020003001Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
					
				}
				/*단기사채 발행정보 조회 TDD4021_Q07*/
				else if ( exeType == 'shrtPrdbIssue') {
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020003002Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				}
			});	
		}
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		
		var ajax_call = pageUnit.trn.ajax_call;
		
		ajax_call('shrtPrdbInfo').then(function(data){
			mydataCommon.util.consoleOut( data , '단기사채 상세정보 조회 /reco/SReco0020003001Ajax');
			pageUnit.fn.set_shrtPrdbInfo(data);
			
			return ajax_call('shrtPrdbIssue');
		}).then(function(data){
			mydataCommon.util.consoleOut( data , '단기사채 발행정보 조회/reco/SReco0020003002Ajax' );
			pageUnit.fn.set_shrtPrdbIssue(data);
			
		}).catch(function(e){
			console.error(e);
		});
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		//이전화면
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		
		//투자하기 상단버튼 (영S)
		$(document).on("click", "#btn_invest_top", function() {
			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"574"});
		});
		//투자하기 하단버튼 (영S)
		$(document).on("click", "#btn_invest_btm", function() {
			var strSendViewData = pageUnit.prop.strSendViewData;
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"574"});
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"574", urlMapId: strSendViewData});
		});
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_shrtPrdbInfo: function (data) {
			var outData = data.TDD4021_Q06;
			var trdeInfoData ={};
			
			if (outData && outData.resp_gubn == "0" ) { 

				$.each(outData.g1, function(i, v) {
					outData.taxa_errt = (parseInt(v.taxa_errt*10)/1000)					     //세후수익율
					outData.trde_prft_rt = (parseInt(v.trde_prft_rt*10)/1000)				 //매매수익율
					outData.trde_uv = mydataCommon.util.addComma(parseInt(v.trde_uv));  	 //매매단가
					outData.trde_alowq = mydataCommon.util.addComma(parseInt(v.trde_alowq)); //매매가능수량(천)
					
				});
				ao_html('#shrtPrdbRt',outData);
				ao_html('#shrtPrdbErrt',outData);
				
				trdeInfoData = { trde_prft_rt : outData.trde_prft_rt, trde_uv : outData.trde_uv, taxa_errt : outData.taxa_errt, trde_alowq : outData.trde_alowq };
			
			} else {
				outData.taxa_errt = "0.00";
				outData.trde_prft_rt = "0.00";
				outData.trde_uv = '0';
				outData.trde_alowq = '0';
				
				ao_html('#shrtPrdbRt',outData);
				ao_html('#shrtPrdbErrt',outData);
				
				trdeInfoData = { trde_prft_rt : '0.00',	trde_uv : '0', taxa_errt : '0.00', trde_alowq : '0'};
//				mydataCommon.msg.alert({ msg : outData.resp_mesg });
			}
			pageUnit.prop.trdeInfoData = trdeInfoData;
		},
		set_shrtPrdbIssue: function (data) {
			
			var outData = data.TDD4021_Q07;
			
			if (outData && outData.resp_gubn == "0" ) { 

				//단기사채 발행정보
				outData.isu_dt = mydataCommon.util.getStrDate(outData.isu_dt);
				outData.expr_dt = mydataCommon.util.getStrDate(outData.expr_dt);
				outData.isu_qty = mydataCommon.util.addComma(parseInt(outData.isu_qty));
				outData.evlt_uv = mydataCommon.util.addComma(parseInt(outData.evlt_uv));
				outData.crdt_grde = mydataCommon.util.nvl(outData.crdt_grde, "-");
				
				ao_html('#remn_dys',outData);
				ao_html('#shrtPrdbGrde',outData);
				ao_html('#shrtPrdbStkNm',outData);
				ao_html('#shrtPrdbInfo',outData);
				
				var trdeInfoData = pageUnit.prop.trdeInfoData;
				var sendStr = '0;'+outData.stk_code+';'+outData.stk_nm.replace('&#40;','(')+';'+trdeInfoData.trde_prft_rt+';'+trdeInfoData.trde_uv+'.00 '+trdeInfoData.trde_alowq+';';
				mydataCommon.util.consoleOut(sendStr);
				
				pageUnit.prop.strSendViewData = sendStr;
				
			} else {
				mydataCommon.msg.alert({ msg : outData.resp_mesg });
			}
		},
		getStkCode : function() {
			var param = mydataCommon.page.getSubParamData('VReco0010001View');
			return param.stk_code;
		},
		req_error : function(data) {
			mydataCommon_02.util.log([
					'Reco002_0003.js :: req_error ----------> ', data ]);
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});





