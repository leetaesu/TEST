var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0020001View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		colors : ['#6666cc', '#66ccff','#66cccc', '#fe74a2', '#ff9933'],
//		colors : ['#fe74a2', '#ff9933', '#66ccff', '#6666cc', '#66cccc','d1d6e8 '],
	},                
	// 전송 전용 프로퍼티 모음
	trn_param : {
		seach_param : {
			sal_fund_cd : '',
			stk_code: '',
			fund_term_tp : '1',	//펀드기간구분
			fund_grp_tp : '0', 	//펀드그룹구분
		},
		//수익률 
		chartByTermData_param : {
			zeroinTypeCd : '',
			term : "3",
			fundCd : ''
		},
		srchTop10Rate_param : {},
		srchPortfolio_param : {}
	},
	//	단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			return new Promise(function(res, rej) {
				
				/*펀드상세 DB 조회*/
				if ( exeType == 'searchFundDetail' ){
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001Ajax",
							data :param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				
				/*전주 대비 점수 변동값 조회  XMI1003_Q01*/
				else if( exeType == 'getXMI1003_Q01') {
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001001Ajax",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				/*펀드 분류 요약정보 조회  XMI1003_Q02*/
				else if( exeType == 'getXMI1003_Q02') {
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001002Ajax",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				
				/*펀드상품 수익성, 변동성, 운용규모 요약정보 조회  XMI1003_Q03*/
				else if( exeType == 'getXMI1003_Q03') {
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001003Ajax",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				/*투자효율 요약정보 조회  XMI1003_Q04*/
				else if( exeType == 'getXMI1003_Q04') {
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001004Ajax",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				/*투자 스타일 비중 요약정보 조회  XMI1003_Q05*/
				else if( exeType == 'getXMI1003_Q05') {		
					var param = pageUnit.trn_param.seach_param;
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/SReco0020001005Ajax",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				
				/*펀드 운용사 자산현황(포트폴리오-pieChart) 조회 */
				else if( exeType == 'getAssetComposeJson') {
					var paramPortfolio = JSON.parse(localStorage.getItem('srchPortfolio')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/getAssetComposeJson",
							data : paramPortfolio,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				}
				
				/*자산구성현황 (Top10 보유 종목/비중) 조회 */
				else if( exeType == 'getFndAssetStatsJson') {
					var paramTop10Rate = JSON.parse(localStorage.getItem('srchTop10Rate')); 
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/getFndAssetStatsJson",
							data : paramTop10Rate,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
				else if( exeType == 'getFndFromYmdByTerm') {
					var param = pageUnit.trn_param.chartByTermData_param;
					mydataCommon.util.consoleOut(param);
					
					var jsonObj = {
							url : pageCom.prop.contextPath + "/reco/selectFndFromYmdByTerm",
							data : param,
							async : true,
							success : res,
							error : function() {
								pageUnit.fn.req_error();
								res();
							}
					}
					mydataCommon.ajax(jsonObj);	
				} 
			});
		},// end ajax_call
		
	}, // end trn
	
	// 단위 진입부 함수
	init : function(){
		var param = mydataCommon.page.getSubParamData('VReco0010001View');
		pageUnit.trn_param.seach_param.sal_fund_cd = param.stk_code;
		pageUnit.trn_param.seach_param.stk_code = param.stk_code;
		
//		pageUnit.trn_param.seach_param.sal_fund_cd = "600860";
//		pageUnit.trn_param.seach_param.stk_code = "600860";
		
		mydataCommon.util.consoleOut(pageUnit.trn_param.seach_param);
		pageUnit.eventBind();

		var ajax_call = pageUnit.trn.ajax_call;

		ajax_call('searchFundDetail').then(function(data){
			mydataCommon.util.consoleOut(data, '펀드상세 DB조회');
			pageUnit.fn.set_section(data);
			
			return ajax_call('getXMI1003_Q01');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '전주 대비 점수 변동값 조회');
			pageUnit.fn.set_XMI1003_Q01(data);

			return ajax_call('getXMI1003_Q02');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '펀드 분류 요약정보 조회');
			pageUnit.fn.set_XMI1003_Q02(data);

			return ajax_call('getXMI1003_Q03');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '펀드상품 수익성, 변동성, 운용규모 요약정보 조회');
			pageUnit.fn.set_XMI1003_Q03(data);

			return ajax_call('getXMI1003_Q04');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '투자효율 요약정보 조회');
			pageUnit.fn.set_XMI1003_Q04(data);

			return ajax_call('getXMI1003_Q05');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '투자 스타일 비중 요약정보 조회');
			pageUnit.fn.set_XMI1003_Q05(data);

			return ajax_call('getAssetComposeJson');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '펀드 운용사 자산현황(포트폴리오-pieChart) 조회');
			pageUnit.fn.setAssetComposeJson(data);
			
			return ajax_call('getFndAssetStatsJson');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '자산구성현황 (Top10 보유 종목/비중) 조회 ');
			pageUnit.fn.setFndAssetStatsJson(data);
			
			return ajax_call('getFndFromYmdByTerm');
		}).then(function(data) {
			mydataCommon.util.consoleOut(data, '펀드 기간별 수익률 DB조회');
			pageUnit.fn.set_getFndFromYmdByTerm(data);
			
		}).catch(function(e){
			console.error(e);
		});
		
	}, // end init
	
	// 단위 이벤트 바인딩 함수
	eventBind : function(){
		
		//이전화면
		$(document).on("click", ".sub-prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});			
		});
		
		//툴팁 열기
		$(document).on("click", ".tooltip", function() {
			 $(this).next('.tooltip-box').addClass('is-open').after('<div class="dimmed"></div>');
             $('body').addClass('fixed');
		});
		//툴팁 닫기
		$(document).on("click", ".tooltip-close", function() {
			$('.tooltip-box').removeClass('is-open');
            $('.dimmed').remove();
            $('body').removeClass('fixed');
		});
		
		//투자하기 상단버튼 (영S)
		$(document).on("click", "#btn_invest_top", function() {
//			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"61"});
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"61", urlMapId: stk_code});
		});
		//투자하기 하단버튼 (영S)
		$(document).on("click", "#btn_invest_btm", function() {
//			var stk_code =  pageUnit.fn.getStkCode();
			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"61"});
//			mydataCommon.appBridge.webviewReq({command:"callMoveView",viewId:"61", urlMapId: stk_code});
		});
		
		// 투자설명서
		$(document).on("click", "#btn_inv", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();	
			pageUnit.fn.pdf_view("투자설명서",sal_fund_cd,"R2");
		});

		// 간이투자설명서
		$(document).on("click", "#btn_smplIngd", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();
			pageUnit.fn.pdf_view("간이투자설명서",sal_fund_cd,"R3");
		});
		
		// 약관
		$(document).on("click", "#btn_terms", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();
			pageUnit.fn.pdf_view("약관",sal_fund_cd,"R1");			
		});
		
		// 운용보고서
		$(document).on("click", "#btn_oprtnRprt", function() {
			var sal_fund_cd = pageUnit.fn.getStkCode();		
			pageUnit.fn.pdf_view("운용보고서",sal_fund_cd,"R5");
		});
		
		//Pdf뷰어 닫기
		$(document).on("click", "#pdfViewer .modal-close", function() {
			$('article#pdfViewer').removeClass("is-open");
			$("article#data").addClass("is-open");
			$("#ifrm").remove();
		});
		
		//수익율 이벤트
		$(document).on("change", "input[name=term]", function() {
			var term = $(this).val();
			
			pageUnit.trn_param.chartByTermData_param.term = term;
			mydataCommon.util.consoleOut(pageUnit.trn_param.chartByTermData_param);
						
			pageUnit.trn.ajax_call('getFndFromYmdByTerm')
			.then(function(data){
				mydataCommon.util.consoleOut(data, '펀드 기간별 수익률 DB조회');
				$('#fundRt').empty();
				pageUnit.fn.set_getFndFromYmdByTerm(data);
				
			}).catch(function(e){
				console.error(e);
			});
		});
		
		//투자효율 펀드기간구분 select이벤트
		$(document).on("change", "#fund_term_tp", function() {
			var fund_term_tp = $(this).val(),
			 	fund_grp_tp = $('#fund_grp_tp').val();
			pageUnit.fn.invsEfcncReseach(fund_term_tp, fund_grp_tp);
			
			
		});
		//펀드평균 펀드그룹구분 select이벤트
		$(document).on("change", "#fund_grp_tp", function() {
			var fund_term_tp = $('#fund_term_tp').val(),
		 		fund_grp_tp = $(this).val();
			pageUnit.fn.invsEfcncReseach(fund_term_tp, fund_grp_tp);

		});
		
	}, // end eventBind
	
	// 단위 전용 함수 모음 패키지
	fn : {
		//펀드 상세 상단, 간략설명보기 set
		set_section: function (data) {
			
			if(data !== undefined && data.fundDtlInfo !== null){
				
				var outData = data.fundDtlInfo;
				var srchPortfolio_param = {
						fundCd  : outData.fundCd,
						zeroinTypeCd : outData.zeroinTypeCd,
				};
				var srchTop10Rate_param = {
						typeGb  : outData.typeGb,
						fundCd  : outData.fundCd,
						zeroinTypeLcd : outData.zeroinTypeLcd,
						zeroinTypeCd : outData.zeroinTypeCd,
						salFundCd : pageUnit.fn.getStkCode()
				};
				
				//펀드 수익률 param 셋팅
				pageUnit.trn_param.chartByTermData_param.fundCd = outData.fundCd;
				pageUnit.trn_param.chartByTermData_param.zeroinTypeLcd =outData.zeroinTypeCd;
				
				mydataCommon.util.setData('srchPortfolio', JSON.stringify(srchPortfolio_param));
				mydataCommon.util.setData('srchTop10Rate', JSON.stringify(srchTop10Rate_param));
				
				//화면출력세팅
				outData.s_gijun_d = mydataCommon.util.getStrDate(outData.fsSrchVo.s_gijun_d);
				outData.fundGradeString = pageUnit.fn.getFundGradeString(outData.fundGrde);
				
				//null값일경우
				outData.suikRt3 = mydataCommon.util.nvl(outData.suikRt3, "0.00");
				outData.suikRt6 = mydataCommon.util.nvl(outData.suikRt6, "0.00");
				outData.suikRt12 = mydataCommon.util.nvl(outData.suikRt12, "0.00");
				outData.suikRt36 = mydataCommon.util.nvl(outData.suikRt36, "0.00");
				
				//수익률
				outData.arrowCheck_3 = pageUnit.fn.dataArrowCheck(outData.suikRt3);
				outData.arrowCheck_6 = pageUnit.fn.dataArrowCheck(outData.suikRt6);
				outData.arrowCheck_12 = pageUnit.fn.dataArrowCheck(outData.suikRt12);
				outData.arrowCheck_36 = pageUnit.fn.dataArrowCheck(outData.suikRt36);
				
				//투자기존가 안내 
				outData.acqMethModify = pageUnit.fn.baseDataMaker_ACQ_METH(outData.acqMeth);
				outData.redemMethModify = pageUnit.fn.baseDataMaker_REDEM_METH(outData.redemMeth);
				
				//페이지 상단 펀드상세정보 출력
				ao_html("#fundStkGrde", outData ); 
				ao_html("#fundStkNm", outData );
				ao_html("#fundInfo", outData );
				
				
				
				//간략설명보기 > 기본정보
				ao_html("#fundInfoDtl", outData );
				
				//간략설명보기 > 기본정보 > 투자기존가 테이블 셋팅
				if(outData.redemMethModify.list.length != 3){
					$('#giJunGaTb tr:nth-child(4) td:nth-child(5)').remove();
					$('#giJunGaTb tr:nth-child(5) td:nth-child(4)').remove();
					$('#giJunGaTb tr:nth-child(3)').remove();
				} else {
					$('#giJunGaTb tr:nth-child(4) td:nth-child(3)').remove();
					$('#giJunGaTb tr:nth-child(4) td:nth-child(1)').remove();
					$('#giJunGaTb tr:nth-child(5) td:nth-child(2)').remove();
				}
				
				if( outData.acqMethModify.list[0][2] == undefined ) $('#giJunGaTb tr:nth-child(2)').remove();
				
				$('#giJunGaTb').show();

			}else{
				var outData = {};
				
				outData.seol = "0";
				outData.suikRt3 =  "0.00";
				outData.suikRt6 =  "0.00";
				outData.suikRt12 = "0.00";
				outData.suikRt36 = "0.00";
				
				//페이지 상단 펀드상세정보 출력
				ao_html("#fundStkGrde", outData ); 
				ao_html("#fundStkNm", outData );
				ao_html("#fundInfo", outData );
				
			}
			
				
		},
		//전주 대비 점수 변동값 조회
		set_XMI1003_Q01 : function(data){
			outData = data.XMI1003_Q01;
			if(outData && outData.resp_gubn =="0"){
				ao_html("#ovrlScr", outData );
			}else{
				
			}
		},
		//펀드 분류 요약정보 조회
		set_XMI1003_Q02 : function(data){
			outData = data.XMI1003_Q02;
			if(outData && outData.resp_gubn =="0"){
				
				ao_html("#fundDtlInfo", outData );
				$('#fundDtlInfo').show();
			}else{
				
			}
		},
		//펀드상품 수익성, 변동성, 운용규모 요약정보 조회
		set_XMI1003_Q03 : function(data){
			var outData = data.XMI1003_Q03;
			
			if(outData && outData.resp_gubn =="0"){
				var fund_prftbl_scr_char = parseInt(outData.total_prftbl_scr) - parseInt(outData.fund_prftbl_scr),
					fund_vltl_scr_char = parseInt(outData.total_vltl_scr) - parseInt(outData.fund_vltl_scr),
					fund_mngm_scl_scr_char = parseInt(outData.total_mngm_scl_scr) - parseInt(outData.fund_mngm_scl_scr);
				
				
				outData.fund_prftbl_scr_char = fund_prftbl_scr_char;
				outData.fund_vltl_scr_char = fund_vltl_scr_char;
				outData.fund_mngm_scl_scr_char = fund_mngm_scl_scr_char;
				
				var fund_prftbl_scr_char_str = fund_prftbl_scr_char+'';
					fund_vltl_scr_char_str = fund_vltl_scr_char+'';
					fund_mngm_scl_scr_str = fund_mngm_scl_scr_char+'';
					
				outData.fund_prftbl_scr_char_str = fund_prftbl_scr_char_str.replace(/\-/g, '');
				outData.fund_vltl_scr_char_str = fund_vltl_scr_char_str.replace(/\-/g, '');
				outData.fund_mngm_scl_scr_str = fund_mngm_scl_scr_str.replace(/\-/g, '');

				//전체 펀드 평균 대비 수익성, 변동성, 운용규모 편차
				mydataCommon.util.consoleOut(outData);
				ao_html('#cmprdAvg', outData);
				
				
				var cate = ['수익성', '변동성', '운영규모'];
				var data = [{name: '해당펀드', data:[parseInt(outData.fund_prftbl_scr),parseInt(outData.fund_vltl_scr),parseInt(outData.fund_mngm_scl_scr)], color:'#6666cc'},
				            {name: '전체평균', data:[parseInt(outData.total_prftbl_scr),parseInt(outData.total_vltl_scr),parseInt(outData.total_mngm_scl_scr)], color:'#d1d6e8'},];
				var directOptions = {
						userSetOptionAppend : true,
						userSetColumnFormat : '{point.y}%',
						userSetColumnPointWidth: 20,
						userSetYAxisType1 : true,
						yAxis: {
	                        min: 0,
	                        max: 100,
	                        tickInterval: 10,
	                        gridLineWidth: 1,
	                        visible: true,
	                        labels: {
	                            style: { fontSize: '10px' }
	                        }
	                    }
				};
				var chartObj = mydataCommon.design.chartColumn2('chart-column2',data,cate,null, directOptions);
				
				
				
				$('#cmprdAvg').show();
			}else{
				
			}
		},
		//투자효율 요약정보 조회
		set_XMI1003_Q04 : function(data){
			outData = data.XMI1003_Q04;
			
			var seach_param = pageUnit.trn_param.seach_param;
			outData.fund_term_tp = seach_param.fund_term_tp; 	//펀드기간구분
			outData.fund_grp_tp = seach_param.fund_grp_tp; 		//펀드그룹구분

			if(outData && outData.resp_gubn =="0"){
				
				var case_gb = "",
					g1 = [],
					g2= [];
				
				//그룹 평균과 해당 펀드의 편차
				var fund_shrp_indx_scr_char = parseInt(outData.grp_shrp_indx_scr) - parseInt(outData.fund_shrp_indx_scr),
					fund_trnr_indx_scr_char = parseInt(outData.grp_trnr_indx_scr) - parseInt(outData.fund_trnr_indx_scr),
					fund_alph_scr_char = parseInt(outData.grp_alph_scr) - parseInt(outData.fund_alph_scr),
					fund_infr_rt_scr_char = parseInt(outData.grp_infr_rt_scr) - parseInt(outData.fund_infr_rt_scr);
				var scr_char_arr = [{'scr_nm':'샤프지수', 'scr_char':fund_shrp_indx_scr_char},
				                    {'scr_nm':'트레이너지수', 'scr_char':fund_trnr_indx_scr_char},
				                    {'scr_nm':'젠센의 알파', 'scr_char':fund_alph_scr_char},
				                    {'scr_nm':'정보비율', 'scr_char':fund_infr_rt_scr_char} ];
				
				//투자효율 case별 세팅
				if(	fund_shrp_indx_scr_char >= 0 && 
					fund_trnr_indx_scr_char >= 0 &&
					fund_alph_scr_char >= 0 &&
					fund_infr_rt_scr_char >= 0		){
					
					//case3 전부 낮은 지표일경우
					case_gb = "3";
					
				} else if(	fund_shrp_indx_scr_char < 0 &&
							fund_trnr_indx_scr_char < 0 &&
							fund_alph_scr_char < 0 &&
							fund_infr_rt_scr_char < 0	   ){
					
					//case2 전부 높은 지표일경우
					case_gb = "2";
					
				}else{
					
				//case1 4가지의 지표 중 높음 과 낮은 경우가 동시에 있을 경우
					case_gb = "1";
					$.each(scr_char_arr, function(i, v){
						if(v.scr_char < 0){
							//높음
							g1.push(v);
						}else if(v.scr_char >= 0){
							//낮음
							g2.push(v);
						}
					});
					
				}
				
				outData.g1 = g1;
				outData.g2 = g2;
				outData.case_gb = case_gb;
				
				ao_html('#invsEfcnc', outData);
				
				//spiderwebChart 공동적용
				var grpNmae = outData.fund_grp_nm;
				
				mydataCommon.util.consoleOut(grpNmae);
				var grpScrData = [parseInt(outData.grp_shrp_indx_scr), parseInt(outData.grp_trnr_indx_scr), parseInt(outData.grp_alph_scr), parseInt(outData.grp_infr_rt_scr)];
				var fundScrData = [parseInt(outData.fund_shrp_indx_scr),parseInt(outData.fund_trnr_indx_scr), parseInt(outData.fund_alph_scr),parseInt(outData.fund_infr_rt_scr)  ];
				
		
				var series =[{ name: grpNmae,  type: 'area', data: grpScrData, color: '#d2d7e9',  marker: {lineColor: '#d2d7e9'} },
				             { name: '이 펀드',  type: 'area', data: fundScrData, color: '#6364ca',  marker: {lineColor: '#6364ca'} }
				             ];
				var cate = [ "샤프지수", "정보비율", "젠센의 알파", "트레이너<br>지수" ];
				
				var chartObj = pageUnit.design.spiderwebChart('chart-spider', series, cate);
				
				$('#ivsEfcncRst').show();
				$('#invsEfcncTooltip').show();
			}else{
				ao_html('#invsEfcnc', outData);
				$('.ivsEfcncErr').show();
			}
		},
		//투자 스타일 비중 요약정보 조회
		set_XMI1003_Q05 : function(data){
			outData = data.XMI1003_Q05;
			if(outData && outData.resp_gubn =="0"){
				
				ao_html('#loanStyl', outData);
				// 차트에 넣을 Data 셋팅
				
				var cate = ['비중'];
//				var colors = ['#5b9bd5', '#ed7d31', '#a5a5a5', '#ffc000', '#1f4e79']; ['#6666cc', '#66ccff','#66cccc', '#fe74a2', '#ff9933']
				var colors =  ['#6666cc', '#66ccff','#66cccc', '#fe74a2', '#ff9933'];
				var stockChartData = [{'name': outData.stk_1rank_styl_nm ,'data': [parseFloat(outData.stk_1rank_wght)],'color': colors[0], index: 3 },
				                      {'name': outData.stk_2rank_styl_nm ,'data': [parseFloat(outData.stk_2rank_wght)],'color': colors[1], index: 2 },
				                      {'name': outData.stk_3rank_styl_nm ,'data': [parseFloat(outData.stk_3rank_wght)],'color': colors[2], index: 1 }];
				
				var bondChartData = [ {'name': outData.bond_1rank_styl_nm ,'data': [parseFloat(outData.bond_1rank_wght)],'color': colors[0], index: 3 },
				                      {'name': outData.bond_2rank_styl_nm ,'data': [parseFloat(outData.bond_2rank_wght)],'color': colors[1], index: 2 },
				                      {'name': outData.bond_3rank_styl_nm ,'data': [parseFloat(outData.bond_3rank_wght)],'color': colors[2], index: 1 }];
				var directOptions = {
						userSetOptionAppend : true,
						xAxis: {
		                    enable: false,
		                    visible: false
		                },
						yAxis: {
							 labels:{ formatter: function() {return this.value+'%';}, align: 'left' }, 
							 title: { text: '' }
	                    },
	                    plotOptions: {
	                        column: {
	                            pointWidth: 40
	                        },
	                        series: {
	                            pointPadding: 0.8,
	                            groupPadding: 0.8
	                        }
	                    },
	                    legend: {
	                        enabled: false,
	                        reversed: true
	                    }
				};
				
				
				//주식
				directOptions.yLabelTitle = '주식 투자 스타일';
				var chartObj = mydataCommon.design.chartStackedBar('chart-bar-stack-stock',stockChartData,cate,150, null, directOptions);
				mydataCommon.util.consoleOut( stockChartData ," 주식 투자스타일 비중 차트 Data ");
				
				//채권
				directOptions.yLabelTitle = '채권 투자 스타일';
				chartObj = mydataCommon.design.chartStackedBar('chart-bar-stack-bond',bondChartData,cate,150, null, directOptions);
				mydataCommon.util.consoleOut( bondChartData ," 채권 투자스타일 비중 차트 Data ");
				
				if(outData.styl_tp == "3"){			//혼합형펀드
					$('#stkfundStyle').show();
					$('#bondfundStyle').show();
					
				} else if(outData.styl_tp == "2"){ 	//채권형펀드
					$('#bondfundStyle').show();
					
				} else if(outData.styl_tp == "1"){ 	//주식형펀드
					$('#stkfundStyle').show();
					
				} else { //펀드스타일 없음 : 0
					
				}
				$('#loanStyl').show();
			}else{
				
			}
		},
		//펀드 수익률 조회(수익률 라인차트) 세팅
		set_getFndFromYmdByTerm : function(data){

			if(data !== undefined && data.resultList !== null){
				
				/* reqFsSrchVo
				 * resultFsFndSuikRt - 성과/위험분석> 수익률
				 * resultFsFndChartByTerm - 기간별 차트 데이터
				 * */
				var reqFsSrchVo =  data.reqFsSrchVo,
					fsFndSuikRt = data.resultFsFndSuikRt,
					fsFndChartByTerm = data.resultFsFndChartByTerm;
					
				
				var outData = {};
				outData.gijunDate = reqFsSrchVo.gijunDate;
				outData.term = reqFsSrchVo.term;
				
				
				mydataCommon.util.consoleOut(fsFndSuikRt);
				if(outData.term == '3'){
					outData.suikRt = fsFndSuikRt.fundSuikRt03;
					outData.termTp = '3개월';
				}else if(outData.term == '6'){
					outData.suikRt = fsFndSuikRt.fundSuikRt06;
					outData.termTp = '6개월';
				}else if(outData.term == '12'){
					outData.suikRt = fsFndSuikRt.fundSuikRt12;
					outData.termTp = '1년';
				}else if(outData.term == '36'){
					outData.suikRt = fsFndSuikRt.fundSuikRt36;
					outData.termTp = '3년';
				}
				
				mydataCommon.util.consoleOut(outData);
				//간략설명보기 > 수익률 
				ao_html("#fundRt", outData );

				var series =[];
				var cate  = [];

				$.each(fsFndChartByTerm, function(i, v){
					series.push(parseFloat(v.suikRt));
					cate.push(mydataCommon.util.getStrDate(v.gijunYmd));
				});
				mydataCommon.util.consoleOut(cate[0]);
				var startDate =  cate[0];
				mydataCommon.util.consoleOut(startDate);
				
				var dateY = parseInt(startDate.substring(0, 4)),
					dateM = parseInt(startDate.substring(4, 6)),
					dataD = parseInt(startDate.substring(6, 8));
				
				var options = {
						pointInterval: parseInt(outData.term)*30 ,
						pointStart: Date.UTC(dateY, dateM, dataD, 0, 0, 0)
				};
				
				var chartObj = pageUnit.design.splineChart('chart-line', series, cate, options);
//				var chartObj = mydataCommon.design.chartLine('chart-line',series,cate,null,directOptions);
				
			} else {
				//간략설명보기 > 수익률 
//				ao_html("#fundRt", outData );
			};
		},
		//펀드 운용사 자산현황(포트폴리오-pieChart) 세팅
		setAssetComposeJson : function(data) {

			if(data !== undefined && data.AssetComposeJson !== null){
				
				mydataCommon.util.removeData('srchPortfolio');
				data = data.AssetComposeJson;
				
				var dataArr = pageUnit.fn.getChartInData(data),
					colors = pageUnit.prop.colors;
				
//				mydataCommon.util.consoleOut(dataArr);
				//pieChart 공통함수 적용
				mydataCommon.design.chartPie('chart-pie',dataArr,null,null,colors,{'isViewLegend':['false']});

				//자산배분 현황 리스트 
				var listP =[];
				for(var i=0; i<dataArr.length; i++){
					var arrP ={};
					var color = $('.chart-wrapper').find('.highcharts-series-group .highcharts-pie-series path:nth-child('+(i+1)+')').attr('fill');
					
					mydataCommon.util.consoleOut(color);

					arrP.name = dataArr[i][0];
					arrP.Rt = dataArr[i][1];
					arrP.color =color;
					listP.push(arrP);
				}
				//자산배분 현황 리스트 오름차순 정렬 
				listP.sort(function(a , b) {
					return b["Rt"] - a["Rt"];
				});
				
				var cartColorList =pageUnit.prop.asetColors;
				var outData = {};
				var outHtmlData = {};
				mydataCommon.util.consoleOut(listP);
				
				$.each(listP, function(i, v){
					v.Rt = (parseInt(v.Rt*100)/100).toFixed(2);
					ao_append("Top10RateInfo", v);
				})
//				for(var i=0; i<listP.length; i++){
//					outData.jmUpjNm = listP[i].name;
//					outData.jmRt = (parseInt(listP[i].Rt*100)/100).toFixed(2);
//					outData.chartColor = listP[i].color;
//					
//				}
//				outHtmlData.TopjmRt = listP[0].name;
				$('#portfolioInfo').show();
			}else{
				
			}
				
			
		},
		//Top10 보유 종목/비중 세팅
		setFndAssetStatsJson: function (data) {
				mydataCommon.util.removeData('srchTop10Rate');
				var outData = data.FndAssetStatsJson;
				var fsSrchVo = outData.fsSrchVo;
				/*국내펀드*/
				if (fsSrchVo.typeGb == '1') {
					outListTop10 = [];
					// 주식형
					if (fsSrchVo.styleGb =='S' || fsSrchVo.styleGb =='E') {
						var sStyleData = outData.sStyle, 				//주식형 포트폴리오 정보
							stockJobRate = outData.stockJobRate, 		//주식업종별 투자비중
							stockTop10Info = outData.stockTop10Info,	//Top10종목(%)- 총보유종목, 비중
							stockTop10 = pageUnit.fn.setTop10List(outData.stockTop10); //TOP10 종목 주식  List 
						
						if(stockTop10.length != 0){
							var count = pageUnit.fn.getOutCount(stockTop10);
							$("#stockTable").show();	
							for(var i=0; i<count; i++){
								stockTop10[i].jmRt = (parseInt(stockTop10[i].jmRt*100)/100).toFixed(2);
								ao_append("stockTop10List", stockTop10[i]);
							}
						}
					}// 주식형 end
					// 채권형,MMF(나머지)
					if (fsSrchVo.styleGb =='B' || fsSrchVo.styleGb =='E' ) {
						
						var bStyleData = outData.bStyle;				//채권형 포트폴리오 정보
						var	bondTypeTop10 = outData.bondTypeTop10,		//채권 종류별 그래프
							bondGradeTop10 = outData.bondGradeTop10,	//채권 신용등급별 그래프
							bondTop10Info = outData.bondTop10Info,		//Top10종목(%)- 총보유종목, 비중
							bondTop10 = pageUnit.fn.setTop10List(outData.bondTop10); //TOP10 채권 
						
						if(bondTop10.length != 0){
							var count = pageUnit.fn.getOutCount(bondTop10);
							$("#bondTable").show();
							for(var i=0; i<count; i++){
								bondTop10[i].jmRt = (parseInt(bondTop10[i].jmRt*100)/100).toFixed(2);
								ao_append("bondTop10List", bondTop10[i]);
							}
						}
					}// 채권형,MMF(나머지) end
				} 
				/*해외펀드*/
				else {
					var stockTop10Info = outData.stockTop10Info,					//Top10종목(%)- 총보유종목, 비중
						stockTop10 = pageUnit.fn.setTop10List(outData.stockTop10); //TOP10 종목 주식 List 
						bondTop10Info = outData.bondTop10Info,						//Top10종목(%)- 총보유종목, 비중
						bondTop10 = pageUnit.fn.setTop10List(outData.bondTop10); 	//TOP10  종목 채권  List
					
					if(stockTop10.length != 0){
						var count = pageUnit.fn.getOutCount(stockTop10);
						$("#stockTable").removeClass('d-none'); 
						for(var i=0; i<count; i++){
							stockTop10[i].jmRt = (parseInt(stockTop10[i].jmRt*100)/100).toFixed(2);
							ao_append("stockTop10List", stockTop10[i]);
						}
					}
					if(bondTop10.length != 0){
						var count = pageUnit.fn.getOutCount(bondTop10);
						$("#bondTable").removeClass('d-none'); 
						for(var i=0; i<count; i++){
							bondTop10[i].jmRt = (parseInt(bondTop10[i].jmRt*100)/100).toFixed(2);
							ao_append("bondTop10List", bondTop10[i]);
						}
					}
				}//end
		},
		setTop10List : function (top10List) {
			if (top10List.length != 0) {
				for (var i=0; i<top10List.length; i++) {
					var idexNum = i+1;
					
					if(idexNum == 10){
						top10List[i].idex = idexNum;
					}else {
						top10List[i].idex = '0'+idexNum;	
					}
					if(parseInt(top10List[i].jmRt) <0){
						top10List[i].fontColor = "font-blue"
					}else {
						top10List[i].fontColor = "font-red"
					}
				}
			}
			return top10List;
		},
		getOutCount : function (top10List) {
			var count = 0;
			top10List.length > 10 ? count = 10 : count = top10List.length;
			
			mydataCommon.util.consoleOut(count);
			return count;
		},
		//PDF 뷰어
		pdf_view : function(title,fund_cd,tp){
			var url = "https://file.funddoctor.co.kr:444/app/file_download.asp?memb_cd=7450&pfund_cd="+fund_cd+"&file_gb="+tp
			mydataCommon.util.consoleOut(url);
			$('article#data').removeClass("is-open");	    		
	    	$("article#pdfViewer").addClass("is-open");
	    	$("#pdfViewer .modal-title").text(title);
			$("#pdfViewer .modal-body").append("<iframe id='ifrm' src='https://docs.google.com/viewer?embedded=true&url="+encodeURIComponent(url)+ "' style='width: 100%; height: 100%; border: none; overflow-y : scroll;-webkit-overflow-scrolling: touch;'></iframe>");
		},
		invsEfcncReseach : function(fund_term_tp, fund_grp_tp){
			
			pageUnit.trn_param.seach_param.fund_term_tp = fund_term_tp; //펀드기간구분
			pageUnit.trn_param.seach_param.fund_grp_tp = fund_grp_tp; //펀드그룹구분
			
			mydataCommon.util.consoleOut(pageUnit.trn_param.seach_param);
			
			//ajax call
			pageUnit.trn.ajax_call('getXMI1003_Q04').then(function(data){
				mydataCommon.util.consoleOut(data, '투자 스타일 비중 요약정보 리서치');
				pageUnit.fn.set_XMI1003_Q04(data);
			}).catch(function(e){
				console.error(e);
			});
		},
		getStkCode : function() {

			var param = mydataCommon.page.getSubParamData('VReco0010001View');
//			var param = pageUnit.trn_param.seach_param;
			
			return param.sal_fund_cd;
		},
		//상품위험등급
		getFundGradeString : function(fundGrade) {
			var list = {
					1 : "매우높은위험",
					2 : "높은위험",
					3 : "다소높은위험",
					4 : "보통위험",
					5 : "낮은위험",
					6 : "매우낮은위험",
			}
			var result = "";
			$.each(list, function(k, v) {
				if(k === fundGrade) {
					result = v;
					return;
				}
			});
			return result;
		} ,
		//기본정보 - 투자 기준가 table 세팅
		baseDataMaker_ACQ_METH : function(data) {
			var result = {
					type : data.split(' ').pop(),
					list : []
			};
			var b = data.replace(/&#40;/gi, '(').replace(/ 환매/gi, '').replace(/\r\n/gi, '\n').replace(/시 /gi, '시&nbsp;').replace(/분 /gi, '분&nbsp;').replace(/기준가로/gi, '').replace(/ 기준가/gi, '').replace(/ 이전/gi, '&nbsp;이전').replace(/ 경과후/gi, '&nbsp;이후').replace(/경과후/gi, '이후').replace(/: /gi, '');
			
			b = b.split('\n');
			$.each(b, function(k, v) {
				var value = v.split(' '),
					index = k,
					ob = new Object(),
					arr = new Array();
				
				ob.timeNm = value[0];
				for(var i = 1; i<value.length; i++){
					arr.push(value[i]);
				}
				ob.timeVal = arr;
				result.list.push(ob);
			});
			return result;
		},
		baseDataMaker_REDEM_METH : function(data) {
			var result = {
					type : data.split(' ').pop(),
					list : [],
			};
				var b = data.replace(/&#40;/gi, '(');
				var b = data.replace(/&#40;/gi, '(').replace(/\r\n/gi, '\n').replace(/일 /gi, '일&nbsp;').replace(/또는 /gi, '또는&nbsp;');
				b = b.replace(/ 이전 : /gi, '&nbsp;이전 ').replace(/ 경과후 : /gi, '&nbsp;이후 ').replace(/경과후/gi, '이후').replace(/ 기준가로/gi, '').replace(/ 환매/gi, '');
				b= b.replace(/시 /gi, '시&nbsp;').replace(/분 /gi, '분&nbsp;');
	
				b = b.split('\n');
				$.each(b, function(k, v) {
					var value = v.split(' '),
						index = k,
						ob = new Object(),
						arr = new Array();
					
					ob.timeNm = value[0];
					for(var i = 1; i<value.length; i++){
						arr.push(value[i]);
					}
					ob.timeVal = arr;
					result.list.push(ob);
				});
				mydataCommon.util.consoleOut(result.list);
				return result;
		},
		getChartColor : function(obj) {
			for (var key in pageUnit.prop.gradeClassList) 
				if(obj === key)
					return pageUnit.prop.gradeClassList[key];
		},
		//수익율 기타세팅
		dataArrowCheck : function(str) {
			var check_pattern = /[-]gi/;
			
			if(!check_pattern.test(str)) {
				return 'arrow-up';
			} else {
				return 'arrow-down';
			}
		},
		//포트폴리오 - piechart Data Array 세팅
		getChartInData : function(data){
			var dataArr = new Array();
			
			var json = {
					stockNativeAbsRate : "국내주식",
					stockForeignAbsRate : "해외주식",
					bondNativeAbsRate : "국내채권",
					bondForeginAbsRate : "해외채권",
					fundAmtAbsRate : "펀드",
					liquidAmtAbsRate : "유동성",
					etcAbsRate : "기타자산",
					futStockAmtAbsRate : "주식선물 순포지션",
					fundBondAmtAbsRate : "채권선물 순포지션",
			}
			$.each(json, function(key, value) {
				pageUnit.fn.chartInData(data[key], value, dataArr);
			});
			return dataArr;
		},
		chartInData : function(value, name, dataArr) {
			if (Number(value) != 0) {
				var resultArray = new Array();
				resultArray.push(name);
				resultArray.push(parseFloat(value));
				dataArr.push(resultArray);
			}
		},
		req_error : function(data) {
			mydataCommon_02.util.log([
					'Reco002_0001.js :: req_error ----------> ', data ]);
		},
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
		splineChart : function( chartId, series, cate ,options ){
			mydataCommon.util.consoleOut(cate);
			var chartLine4 = new Highcharts.Chart(chartId, Highcharts.merge (    
		            KW_MOBILE.highcharts.types.spline,
		            {
		                chart: {                                                
		                    height: 250                        
		                },        
		                plotOptions: {
		                    line: {
		                        lineWidth: 2,
		                        states: {
		                            hover: {
		                                lineWidth: 5
		                            }
		                        },
		                        marker: {
		                            enabled: false
		                        },
		                        pointInterval: options.pointInterval, 
		                        pointStart:	options.pointStart
		                    }
		                },                                   
		                series: [{
		                    name: '',
		                    data: series
		                }],
		            }
		        ));
		},
		spiderwebChart : function( chartId, series, cate ) {
			
			var chartLine3 = new Highcharts.Chart(chartId, Highcharts.merge (
	                KW_MOBILE.highcharts.types.line,
	                {
	                    chart: {
	                        height: 300,
	                        polar: true
	                    },
	                    pane: {
	                        size: '78%',
	                    },
	                    xAxis:{
	                        categories: cate,
	                        tickmarkPlacement: 'on',
	                        lineWidth: 0
	                    },
	                    yAxis: {
	                        gridLineInterpolation: 'polygon',
	                        lineWidth: 0,
	                        min: 0,
	                        labels:{
	                            style: { fontSize: '0' }
	                        }
	                    },
	                    legend: {
	                        enabled: true,
	                        reversed: true,
	                        align: 'center',
	                        verticalAlign: 'bottom',
	                        layout: 'horizontal'
	                    },
	                    plotOptions : {
	                        series: {
	                            fillOpacity: 0.1,
	                            pointPlacement: 'on'
	                        },
	                        area: {
	                            marker: {
	                                fillColor: 'white',
	                                lineWidth: 2,
	                                symbol: 'circle'
	                            }
	                        }
	                    },
	                    series: series
	                }
	            ));
			
		},// end spiderwebChart
	}
};
// 페이지 on load시 진입부
$(document).ready(function(){
	Highcharts.setOptions(KW_MOBILE.highcharts.general);
	KW_MOBILE.guiEvent.swiper.runSwiper('#swiper01', false);
	pageUnit.init();
});
