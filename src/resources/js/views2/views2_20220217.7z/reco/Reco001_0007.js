var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010007View",
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
		rstData_THA4050_Q01: {},
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType){
			
			
			/*투자성향 진단 - invt_prpn_tp투자성향구분(고객진단결과구분) ,rgst_dt 투자성향등록일자 ,prin_yn 전문투자자여부 */
			if ( exeType == 'getTHA4050_Q01' ){
				var data = mydataCommon.makeSerialParam({target : $("#step1")});
				var jsonObj = {
						url : pageCom.prop.contextPath + "/auth/VAuth0010013View",
						data : data,
						async : true,
						success : pageUnit.fn.set_THA4050_Q01,
						error : function(data){
							pageUnit.fn.req_error(data);
						},
				}
				mydataCommon.ajax(jsonObj);
				
			} 
			/*투자자성향 진단 등록_가계산 THA4050_U11 */
			else if(exeType == 'cnfrmTHA4050_U11'){
				var data = mydataCommon.makeSerialParam({target : $("#step1")});
				mydataCommon.util.consoleOut(data);
				var jsonObj = {
						url : pageCom.prop.contextPath + "/auth/IAuth0010013View",
						data : data,
						async : true,
						success : pageUnit.fn.set_cnfrmTHA4050_U11,
						error : function(data){
							pageUnit.fn.req_error(data);
						},
				}
				mydataCommon.ajax(jsonObj);
			}
			/*투자자성향 진단 등록_등록 THA4050_U11*/
			else if(exeType == 'rgstrTHA4050_U11'){
				var data = mydataCommon.makeSerialParam({target : $("#step1")});			
				var jsonObj = {
						url : pageCom.prop.contextPath + "/auth/IAuth0010014View",
						data : data,
						async : true,
						success : pageUnit.fn.set_rgstrTHA4050_U11,
						error : function(data){
							pageUnit.fn.req_error(data);
						},
				}
				mydataCommon.ajax(jsonObj);
			}
		}, 
	},
	// 단위 진입부 함수
	init : function(){
		pageUnit.eventBind();
		pageUnit.trn.ajax_call('getTHA4050_Q01');
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function(value){
		
		/*#### 이전  ####*/
		$(document).on("click", "#step1_prev", function() {
			mydataCommon.appBridge.webviewReq({command:"callSendViewData", popClose:true});
		});

		$(document).on("click", ".step2_prev, #step3_prev", function() {
			$("#step1").show();
			$("article").hide();
		});
		
		/*#### 다음 버튼 KIWMYD_COM_001_0007 : 투자 성향 진단(설문 조사 항목) ####*/
		$(document).on("click", "#step1_next", function() {
			
			var isSuccess = !mydataCommon.vald.validation({target : $("#step1"),immedtAlertPop:true});
			if(isSuccess){
				if(pageUnit.fn.mulChboxChk()){					
					pageUnit.trn.ajax_call('cnfrmTHA4050_U11');
				}
			}
		});
		
		$(document).on("click", "#step2_next", function() {
			pageUnit.trn.ajax_call('rgstrTHA4050_U11');
		});
		
		$(document).on("click", "#step3_next", function() {
			location.href = pageCom.prop.contextPath + "/auth/VAuth0010000View";
		});
		
		$("#step3_prev , #change").off("click").on("click", function(){			
			pageUnit.trn.goPage();
		});		
		
		

		/*#### 투자권유/정보제공 ####*/
		$(document).on("change", "input[name='infr_tp']", function() {
			var infr_tp = $(this).val();  // 0:신규작성(변경) 1:기본정보와 동일
			//infr_tp
			var tempRowObj = $("#step1"),
				outData = pageUnit.prop.rstData_THA4050_Q01;
			
			if(infr_tp =="2"){//기본정보와 동일 선택시
				$("#rdo_09_2").prop("checked",true);
				$("#rdo_09_1").prop("checked",false);
				//고객 정보 데이타 기존폼에 바인딩 
				mydataCommon.setDataBinding({target : tempRowObj, data : outData });
				
				//투자권유희망 및 정보제공 동의 여부 폼 오픈
				$("input[name='infr_sply_yn']").prop("readonly",false);
				$("input[name='invsr_tp']").prop("readonly",false);
				$('#invtPrpnClass').show();
				
				//투자권유희망, 정보제공 동의 일경우 다음 버튼 활성화
				if($("input[name='infr_sply_yn']").val() == "Y" && $("input[name='invsr_tp']").val() =="2"){
					$('#step1_next').prop("disabled",false);
				}
				
				//총 자산대비 금융상품 유형별 기준 input 활성화 여부
				outData.asrn_gds_wght = mydataCommon.util.getNumber(outData.asrn_gds_wght);
				outData.invt_gds_wght = mydataCommon.util.getNumber(outData.invt_gds_wght);
				outData.loan_gds_wght = mydataCommon.util.getNumber(outData.loan_gds_wght);
				
				//보장성 상품 비중
				if(outData.asrn_gds_wght > 0){
					$("#chk_01").prop("checked",true);
					$("input[name='asrn_gds_wght']").prop("disabled",false);
				}
				//투자 상품 비중
				if(outData.invt_gds_wght > 0){
					$("#chk_02").prop("checked",true);
					$("input[name='invt_gds_wght']").prop("disabled",false);
				}
				//대출 상품 비중
				if(outData.loan_gds_wght > 0){
					$("#chk_03").prop("checked",true);
					$("input[name='loan_gds_wght']").prop("disabled",false);
				}
			}else{
				
				mydataCommon.formReset2(tempRowObj);
//				$('#step1_next').prop("disabled",true);
				//신규작성(변경)
				$("#rdo_09_1").prop("checked",true);
				$("#rdo_09_2").prop("checked",false);
				$('rdo_01_1').prop("checked",true);
				$('rdo_01_3').prop("checked",true);
				$('#invtPrpnClass').hide();
				
				//총 자산대비 금융상품 유형별 기준 input 비활성
				$("input[name='asrn_gds_wght']").prop("disabled",true);
				$("input[name='invt_gds_wght']").prop("disabled",true);
				$("input[name='loan_gds_wght']").prop("disabled",true);
			}

			mydataCommon.util.consoleOut({
				'투자권유/정보제공' :infr_tp == 1? infr_tp+':신규작성': infr_tp+':기존정보와동일',
				'다음버튼활성화' : $('#step1_next').prop("disabled") == true? '비활성화':'활성화',
			}, '투자권유/정보제공 : 작성구분 선택');
			
		});
		
		/*#### 투자권유 희망 동의 여부 ####*/
		$(document).on("change", "input[name='invsr_tp']", function() {
			var invsr_tp = $(this).val();
			
			//투자권유희망 선택시 정보제공도 함께 체크, 다음버튼 활성화
			if(invsr_tp == "2"){
				$('#rdo_01_3').prop("checked",true);
				$('#step1_next').prop("disabled",false);
			}else{
				$('#step1_next').prop("disabled",true);
			}
		});
		
		/*#### 정보제공 동의 여부 ####*/
		$(document).on("change", "input[name='infr_sply_yn']", function() {
			var infr_sply_yn = $(this).val(),
				invsr_tp = $("input[name='invsr_tp']:checked").val();

			//투자권유희망 , 정보제공 모두 동의시 다음버튼 활성화
			if(infr_sply_yn == "Y" && invsr_tp == "2"){
				$('#step1_next').prop("disabled",false);
			}else{
				$('#step1_next').prop("disabled",true);
			}
		});
		/*#### 총 자산대비 금융상품 유형별 기준 ####*/
		$(document).on("click", "#chk_01 , #chk_02 , #chk_03", function() {
			if($(this).is(":checked")){
				var id = $(this).attr("id");
				if(id == 'chk_01'){
					//보장성
					$("input[name='asrn_gds_wght']").prop("disabled",false);
				}else if(id == 'chk_02'){
					//투자성
					$("input[name='invt_gds_wght']").prop("disabled",false);
				}else if(id == 'chk_03'){
					//대출성
					$("input[name='loan_gds_wght']").prop("disabled",false);
				}
			}else{
				var id = $(this).attr("id");
				if(id == 'chk_01'){
					//보장성 상품
					$("input[name='asrn_gds_wght']").prop("disabled",true);
					$("input[name='asrn_gds_wght']").val("");
				}else if(id == 'chk_02'){
					//투자성상품
					$("input[name='invt_gds_wght']").prop("disabled",true);
					$("input[name='invt_gds_wght']").val("");
				}else if(id == 'chk_03'){
					//대출성 상품
					$("input[name='loan_gds_wght']").prop("disabled",true);
					$("input[name='loan_gds_wght']").val("");
				}
			}

		});
		
//		/*####  ####*/
//		$("#asrn_gds_wght , #invt_gds_wght , #loan_gds_wght").off("click").on("click", function(){
//			var datas = {keypadType : "2",keypadValue:$(this).val(),maxLength:"3",rId:$(this).attr("id")};
//			mydataCommon.appBridge.openNumKeypad(datas,"pageUnit.fn.callback_getKeypadResult");
//		});

	},
	// 단위 전용 함수 모음 패키지
	fn : {
		set_THA4050_Q01: function(data){
			var outData = data.resultMap;			
			mydataCommon.util.consoleOut(data, '투자성향 진단 정보조회');
			
			if(outData && outData.resp_gubn == "0"){
				if(outData.resp_code != "855007"){
					
					ao_html('#ageInfo', outData);
					ao_html('#invtPrpnClass', outData);
					
					outData.asrn_gds_wght = mydataCommon.util.getNumber(outData.asrn_gds_wght);
					outData.invt_gds_wght = mydataCommon.util.getNumber(outData.invt_gds_wght);
					outData.loan_gds_wght = mydataCommon.util.getNumber(outData.loan_gds_wght);
					
					pageUnit.prop.rstData_THA4050_Q01 = outData;
				}
			}else{
				if(outData.resp_code != "855007"){
					mydataCommon.msg.alert({msg : outData.resp_mesg});
				}
			}
		},
		/*투자자성향 진단 등록_가계산 THA4050_U11 */
		set_cnfrmTHA4050_U11 : function(data){
			var outData = data.resultMap;			
			mydataCommon.util.consoleOut(data, '투자자성향 진단 등록_가계산');
			
			if(outData && outData.resp_gubn == "0"){
				$("#step1").hide();
				var tempRowObj = $("#step2");
					tempRowObj.show();	
				var datas = mydataCommon.makeJsonParam({target : $("#step1")});				
				var age = "";
				switch(datas.age_tp){
				case '1' : age="19세 이하"; break;
				case '2' : age="20~40세";  break;
				case '3' : age="41~50세";  break;
				case '4' : age="51~64세";  break;
				case '5' : age="65~79세";  break;
				case '6' : age="80세 이상";  break;
				default : break;
				}	
				datas.age_tp = age;							
				
				var invt_alow_term_nm = "";
				switch(datas.invt_alow_term_code){
				case '1' : invt_alow_term_nm="1년 미만"; break;
				case '2' : invt_alow_term_nm="1년 이상~2년 미만";  break;
				case '3' : invt_alow_term_nm="2년 이상~3년 미만";  break;
				case '4' : invt_alow_term_nm="3년 이상~5년 미만";  break;
				case '5' : invt_alow_term_nm="5년 이상";  break;
				default : break;
				}	
				datas.invt_alow_term_code = invt_alow_term_nm;
				
				var inex_nms = "";
				if(datas.inex_cd_1 == '1')inex_nms += "은행 예금이나 적금, 국채, 지방채, 보증채, MMF 등"+"<br/>";
				if(datas.inex_cd_2 == '1')inex_nms += "금융채, 신용도 높은 회사채, 채권형펀드, 원금보장형 ELS"+"<br/>";
				if(datas.inex_cd_3 == '1')inex_nms += "신용도 중간 회사채, 원금일부보장 ELS, 혼합형펀드"+"<br/>";
				if(datas.inex_cd_4 == '1')inex_nms += "신용도 낮은 회사채, 주식, 원금비보장형 ELS, 시장수익율 수준의 주식형펀드 등"+"<br/>";
				if(datas.inex_cd_5 == '1')inex_nms += "ELW, 선물옵션, 시장수익율이상의 주식형 펀드, 파생형펀드, 주식신용거래 등";
				datas.inex_nms = inex_nms;
				
				
				var invt_knwl_levl_nm = "";
				switch(datas.invt_knwl_levl_code){
				case '1' : invt_knwl_levl_nm="금융투자상품에 투자 경험 없음"; break;
				case '2' : invt_knwl_levl_nm="널리 알려진 금융투자상품(주식, 채권 및 펀드) 등의 내용 및 위험을 일정 부분 이해하고 있음";  break;
				case '3' : invt_knwl_levl_nm="널리 알려진 금융투자상품(주식, 채권 및 펀드) 등의 내용 및 위험을 깊이 있게 이해하고 있음";  break;
				case '4' : invt_knwl_levl_nm="파생상품을 포함한 대부분의 금융투자 상품의 내용 및 위험을 이해하고 있음";  break;
				default : break;
				}	
				datas.invt_knwl_levl_code=invt_knwl_levl_nm;
				
				
				var prft_loss_levl_nm = "";
				switch(datas.prft_loss_levl_code){
				case '1' : prft_loss_levl_nm="무슨 일이 있어도 투자 원금은 보전되어야 함"; break;
				case '2' : prft_loss_levl_nm="원금 기준 ±5%";  break;
				case '3' : prft_loss_levl_nm="원금 기준 ±10%";  break;
				case '4' : prft_loss_levl_nm="원금 기준 ±20%";  break;
				case '5' : prft_loss_levl_nm="원금 기준 ±20% 초과";  break;
				default : break;
				}	
				datas.prft_loss_levl_code=prft_loss_levl_nm;
				
				datas.asrn_gds_wght ="보장성 상품 "+mydataCommon.util.getNumber(datas.asrn_gds_wght)+"%";
				datas.invt_gds_wght ="투자성 상품 "+mydataCommon.util.getNumber(datas.invt_gds_wght)+"%";
				datas.loan_gds_wght ="대출성 상품 "+mydataCommon.util.getNumber(datas.loan_gds_wght)+"%";

				var gain_dsps_prps_nm = "";
				switch(datas.gain_dsps_prps_code){
				case '1' : gain_dsps_prps_nm="재무상환"; break;
				case '2' : gain_dsps_prps_nm="운용자금";  break;
				case '3' : gain_dsps_prps_nm="부동산 마련";  break;
				case '4' : gain_dsps_prps_nm="주택 마련";  break;
				case '5' : gain_dsps_prps_nm="자산 증식";  break;
				default : break;
				}	
				datas.gain_dsps_prps_code=gain_dsps_prps_nm;
				
											
				var invt_trgt_nm = "";
				switch(datas.invt_trgt_code){
				case '1' : invt_trgt_nm="공격투자형"; break;
				case '2' : invt_trgt_nm="적극투자형";  break;
				case '3' : invt_trgt_nm="위험중립형";  break;
				case '4' : invt_trgt_nm="안정추구형";  break;
				case '5' : invt_trgt_nm="안정형";  break;
				default : break;
				}								
				datas.invt_trgt_code = invt_trgt_nm;
				
				var drvt_invt_term_nm = "";
				switch(datas.drvt_invt_term_code){
				case '1' : drvt_invt_term_nm="경험이 없거나, 1년 미만"; break;
				case '2' : drvt_invt_term_nm="1년 이상 3년 미만";  break;
				case '3' : drvt_invt_term_nm="3년 이상";  break;							
				default : break;
				}								
				datas.drvt_invt_term_code = drvt_invt_term_nm;
				
				//행 데이터 바인딩
				mydataCommon.setDataBinding({target : tempRowObj, data : datas });
			}else{
				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		/*투자자성향 진단 등록_등록 THA4050_U11 */
		set_rgstrTHA4050_U11 : function(data){
			var outData = data.resultMap;			
			mydataCommon.util.consoleOut(data, '투자자성향 진단 등록_등록');
			
			if(outData && outData.resp_gubn == "0"){
				$("#step2").hide();
				var tempRowObj = $("#step3");
				tempRowObj.show();	
				var cust_dgns_rslt_nm = "";
				var cust_dgns_rslt_txt = "";
				switch(outData.cust_dgns_rslt_tp){
				case '1' : cust_dgns_rslt_nm="시장평균 수익률을 훨씬 넘어서는 높은 수준의 투자수익을 추구하며, 이를 위해 자산가치의 변동에 따른 손실위험을 적극 수용하는 성향"; 
						   cust_dgns_rslt_txt = "공격투자형 (초고위험 1등급)";	
						   $("#to_img").attr("src","../../../resources/images/views/auth/invest_type_grade01.png");
						   $("#to_img").attr("alt","초고위험 공격투자형 1등급.위험감수:적극 수용.기대수익:평균수익률을 훨씬 넘어서는");
						   break;
				case '2' : cust_dgns_rslt_nm="자 원금의 보전보다는 위험을 감내하더라도 높은 수준의 투자수익 실현을 추구하는 성향";
						   cust_dgns_rslt_txt = "적극투자형 (고위험 2등급)";	
						   $("#to_img").attr("src","../../../resources/images/views/auth/invest_type_grade02.png");
						   $("#to_img").attr("alt","고위험 적극투자형 2등급.위험감수:감내가능.기대수익:높은 수준의 수익률");
						   break;
				case '3' : cust_dgns_rslt_nm="투자에는 그에 상응하는 위험이 있음을 충분히 인식하고 있으며, 예적금보다 높은 수익을 기대할 수 있다면 일정수준의 손실 위험을 감수할 수 있는 성향";
						   cust_dgns_rslt_txt = "위험중립형 (중위험 3등급)";	
						   $("#to_img").attr("src","../../../resources/images/views/auth/invest_type_grade03.png");
						   $("#to_img").attr("alt","중위험 위험중립형 3등급.위험감수:충분히 인지.기대수익:예적금보다 좋은 수익률");
						   break;
				case '4' : cust_dgns_rslt_nm="투자 원금의 손실 위험을 최소화하고, 이자소득이나 배당소득 수준의 안정적인 투자를 목표로 하는 성향";
						   cust_dgns_rslt_txt = "안정추구형(저위험 4등급)";	
						   $("#to_img").attr("src","../../../resources/images/views/auth/invest_type_grade04.png");
						   $("#to_img").attr("alt","저위험 안전추구형 4등급.위험감수:최소화.기대수익:이자소득이나 배당소득");
						   break;
				case '5' : cust_dgns_rslt_nm="예금 또는 적금 수준의 수익률을 기대하며, 투자원금에 손실이 발생하는 것을 원하지 않는 성향";  
						   cust_dgns_rslt_txt = "안정형 (초저위험 5등급)";	
						   $("#to_img").attr("src","../../../resources/images/views/auth/invest_type_grade05.png");
						   $("#to_img").attr("alt","초저위험 안정형 5등급.위험감수:원치않음.기대수익:예적금 수준의 수익률");
						   break;
				default : break;
				}	
				outData.cust_dgns_rslt_tp = cust_dgns_rslt_nm;
				outData.cust_dgns_rslt_txt = cust_dgns_rslt_txt;
				
				var drvt_invt_term_nm = "";
				switch(outData.drvt_invt_term_code){
				case '1' : drvt_invt_term_nm="경험이 없거나, 1년 미만"; break;
				case '2' : drvt_invt_term_nm="1년 이상 3년 미만";  break;
				case '3' : drvt_invt_term_nm="3년 이상";  break;							
				default : break;
				}								
				outData.drvt_invt_term_code = drvt_invt_term_nm;
				mydataCommon.util.consoleOut(outData);		
				mydataCommon.setDataBinding({target : tempRowObj, data : outData});
			}else{
//				mydataCommon.msg.alert({msg : outData.resp_mesg});
			}
		},
		mulChboxChk : function(){
			var obj = $("#go_2");
			var cnt = obj.next().find("input:checkbox:checked").length;
			if(cnt ==0){
				mydataCommon.msg.alert({msg : "투자경험을 하나이상 선택해주세요."});
				obj[0].scrollIntoView();
				obj.focus();
				return false;
			}
			
			var asrn_gds_wght = $("input[name='asrn_gds_wght']").val();
			var invt_gds_wght = $("input[name='invt_gds_wght']").val();
			var loan_gds_wght = $("input[name='loan_gds_wght']").val();
			
			if($("#chk_01").is(":checked") && asrn_gds_wght == ''){
				mydataCommon.msg.alert({msg : "보장성상품 비중을 입력 해주세요."});
				return false;
			}else if($("#chk_02").is(":checked") && invt_gds_wght == ''){
				mydataCommon.msg.alert({msg : "투자성상품 비중을 입력 해주세요."});
				return false;
			}else if($("#chk_03").is(":checked") && loan_gds_wght == ''){
				mydataCommon.msg.alert({msg : "대출성상품 비중을 입력 해주세요."});
				return false;
			}else if(Number(asrn_gds_wght)+Number(invt_gds_wght)+Number(loan_gds_wght) != 100){
				mydataCommon.msg.alert({msg : "보장성 상품, 투자성 상품, 대출성 상품 비율의 합이 100%가 되어야 합니다."});
				$("#go_5")[0].scrollIntoView();
				$("#go_5").focus();
				return false;
			}			
			return true;
			
		},

		//키패드 callback
		callback_getKeypadResult : function(jsonString){
			var nVal = jsonString.numValue;
			var rId = jsonString.rId;			
			$("#"+rId).val(nVal);	
		},	
	},
	// 차트, 그리드 등등 디자인 및 그리기 처리 패키지
	design : {
	}
};
//페이지 on load시 진입부
$(document).ready(function(){
	pageUnit.init();
});