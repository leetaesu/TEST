var pageUnit = {
	// 단위 전용 프로퍼티 모음
	prop : {
		v_id : "VReco0010002View",
		//로컬스토리지 값저장 및 호출 시 키값
		v_storageKeyName : 'reco',
		v_storageSubKeyName : '',
	},
	// 전송 전용 프로퍼티 모음
	trn_param : {
	},
	// 단위 전용 통신함수 모음 패키지
	trn : {
		ajax_call : function(exeType) {
			return new Promise(function(res, rej) {
				var param = mydataCommon.page.getParamData('reco');
				mydataCommon.util.consoleOut(param);
				/* 대출 추천상품 조회 */
				if ( exeType == 'LoanPrdctXMO2030_Q01' ) {
					
					var jsonObj = {
						url : pageCom.prop.contextPath + "/reco/SReco0010002Ajax",
						async : true,
						data : param,
						beforeSend: function(){
							$('#eventLink').hide();
						},
						success : res,
						complete: function(){
							$('#eventLink').show();
						},
						error : function(data){
							pageUnit.fn.req_error(data);
							res;
						},
					}
					mydataCommon.ajax(jsonObj);
				}
				/* 이벤트 배너  */
				else if ( exeType == 'evtBanrXMA1001_Q03' ){	
					var param = {
							banr_tp : "2", //배너유형구분
							banr_exps_tp : "09", //배너노출메뉴  
							acnt_lnkg_exps_tp : "01", //계좌연동노출유형
						}
					var jsonObj = {
							url : pageCom.prop.contextPath + "/common/SComBann001001Ajax",
							data : param,
							async : true,
							success : res,
							error : function(data){
								pageUnit.fn.req_error(data);
								res;
							},
					}
					mydataCommon.ajax(jsonObj);
				} 
			});
		}
	},
	// 단위 진입부 함수
	init : function() {
		
		pageUnit.fn.setParam();
		pageUnit.eventBind();
		
		var ajax_call = pageUnit.trn.ajax_call;
		
		ajax_call('LoanPrdctXMO2030_Q01')
		.then(function(data){
			mydataCommon.util.consoleOut(data, '대출 추천상품 조회 /reco/SReco0010002Ajax');
			pageUnit.fn.set_section(data);
//			mydataCommon.util.getSimpleBanner({
//				banr_tp : "2", //배너유형구분
//				banr_exps_tp : "09", //배너노출메뉴  
//				acnt_lnkg_exps_tp : "01", //계좌연동노출유형
//			});
			return ajax_call('evtBanrXMA1001_Q03');
		}).then(function(data){
			mydataCommon.util.consoleOut(data, '배너/common/SComBann001001Ajax');
			pageUnit.fn.set_section_banr(data);
			
		}).catch(function(e){
			console.error(e);
		});
		 
	},
	// 단위 이벤트 바인딩 함수
	eventBind : function() {
		// 투자 tab
		$("#tab_01").off("click").on("click", function(){
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010001View"
		});	
		// 카드 tab
		$("#tab_03").off("click").on("click", function(){
			mydataCommon.util.removeAllData();
			document.location.href = pageCom.prop.contextPath+"/reco/VReco0010003View"
		});	
		// 금리순 한도순 조회
//		$("#sortSelect").off("change").on("change", function(){
//			var sort_tp = $(this).val();
//			pageUnit.fn.reSearch(sort_tp, '', '');
//		});

		$(document).on("click", "#tab_02_01", function() {
			var sort_tp = "01";
			pageUnit.fn.reSearch(sort_tp, '', '');
		});	
		
		$(document).on("click", "#tab_02_02", function() {
			var sort_tp = "02";
			pageUnit.fn.reSearch(sort_tp, '', '');

		});	
	},
	// 단위 전용 함수 모음 패키지
	fn : {
		//초기 Param 세팅
		setParam : function() {
			
			var param =  mydataCommon.util.getArrayData('reco');
			if ( param == null || param == undefined ) {
				
				var pageParam = mydataCommon.page.getParamData();
				
					mydataCommon.page.setParamData(pageParam);
					mydataCommon.page.setParamData({'sort_tp':'01'}, true);
			}
			
		},
		//대출 추천상품 조회 세팅
		set_section : function(data) {
			var	outData = data.XMO2030_Q01;
			
			
			if (outData && outData.resp_gubn == "0") {
				outData.sort_tp = pageUnit.fn.get_sort_tp();
				// 한도순
				if(outData.sort_tp == "01") {
					
					//한도순 탭선택하여 보여주기
					$('#tab_02_01').addClass('is-selected')
	                    .siblings()
	                    .removeClass('is-selected');
	                $('#tab_panel02_01')
	                    .addClass('is-selected')              
	                    .siblings('.tab-panel')
	                    .removeClass('is-selected');
					
					$.each(outData.g1, function(i, v) {
						v.high_expc_int =(parseInt(v.high_expc_int*10)/10).toFixed(2);
						v.lwst_expc_int =(parseInt(v.lwst_expc_int*10)/10).toFixed(2);
						v.loan_limit_max_amt = mydataCommon.util.addComma(v.loan_limit_max_amt);
						ao_append('#recoLoanList', v);
						
					});
					ao_html('#moreView', outData);
				} 
				// 금리순
				else if(outData.sort_tp == "02") {
					
					//금리순 탭선택 하여 보여주기
					$('#tab_02_02').addClass('is-selected')
                    .siblings()
                    .removeClass('is-selected');
	                $('#tab_panel02_02')
	                    .addClass('is-selected')              
	                    .siblings('.tab-panel')
	                    .removeClass('is-selected');
					
					$.each(outData.g1, function(i, v) {
						v.lwst_expc_int =(parseInt(v.lwst_expc_int*10)/10).toFixed(2);
						v.loan_limit_max_amt = mydataCommon.util.addComma(v.loan_limit_max_amt);
						ao_append('#recoLoanList2', v);
						
					});
					ao_html('#moreView1', outData);
				}

			} else {
//				mydataCommon.msg.alert({ msg : outData.resp_mesg });
			}
		},
		// 한도순, 금리순, 더보기 조회
		reSearch : function( sort_tp, cont_gubn, next_data) {
			
			var pageParam = mydataCommon.page.getParamData();
			mydataCommon.page.setParamData(pageParam);
			
			// 정렬구분
			mydataCommon.page.setParamData({'sort_tp':sort_tp}, true); 
			
			// 더보기
			if ((cont_gubn !='' && cont_gubn =='Y') && next_data !=''){
				mydataCommon.page.setParamData({'sort_tp':sort_tp, 'cont_gubn':cont_gubn, 'next_data':next_data}, true);
			} else {
				$('#recoLoanList').empty();
				$('#recoLoanList2').empty();
			}
			pageUnit.trn.ajax_call('LoanPrdctXMO2030_Q01')
			.then(function(data){
				pageUnit.fn.set_section(data);
			}).catch(function(e){
				console.error(e);
			});
		},
		//대출 상품상세 storageLoanInfo
		popDetail : function(orgn_nm, myd_orgn_code, loan_gds_type_tp, loan_gds_code) {
			var pageParam = mydataCommon.page.getSubParamData();
			pageParam.orgn_nm = orgn_nm;
			pageParam.myd_orgn_code = myd_orgn_code;
			pageParam.loan_gds_type_tp = loan_gds_type_tp;
			pageParam.loan_gds_code = loan_gds_code;
			
			mydataCommon.page.setSubParamData(pageParam);
			mydataCommon.appBridge.webviewReq({command:"callMoveView", urlMapId: "RECO0301", callback:"callback_callMoveView"});
		},
		//이벤트 모바일(배너) 세팅
		set_section_banr : function (data) {
			var outData = data.resultMap;
			mydataCommon.util.consoleOut( data , '/common/SComBann001001Ajax(2)');

			if(outData && outData.resp_gubn == "0"){	
				
				ao_html('#eventLink',outData.g1);
			}else{
				//이벤트 배너 미노출 처리
				$('.event_box').css({"display": "none"});
			}
		},
		//정렬구분 가져오기
		get_sort_tp :  function(){
			var param = mydataCommon.page.getParamData('reco');
			return param.sort_tp;
		},
		req_error : function(data) {
			mydataCommon_02.util.log(['Reco0010002.js :: req_error ----------> ', data ]);
		},
	}
};
// 페이지 on load시 진입부
$(document).ready(function() {
	pageUnit.init();
});